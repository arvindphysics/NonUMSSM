{{{VG[{ct1, lt1}], VG[{ct2, lt2}], VG[{ct3, lt3}]}, 
  {g3*fSU3[ct1, ct2, ct3], g[lt1, lt2]*(-Mom[VG[{ct1, lt1}], lt3] + 
      Mom[VG[{ct2, lt2}], lt3]) + g[lt2, lt3]*(-Mom[VG[{ct2, lt2}], lt1] + 
      Mom[VG[{ct3, lt3}], lt1]) + g[lt1, lt3]*(Mom[VG[{ct1, lt1}], lt2] - 
      Mom[VG[{ct3, lt3}], lt2])}}, 
 {{conj[VWm[{lt1}]], VP[{lt2}], VWm[{lt3}]}, 
  {I*g2*Sin[ThetaW], g[lt1, lt2]*(-Mom[conj[VWm[{lt1}]], lt3] + 
      Mom[VP[{lt2}], lt3]) + g[lt2, lt3]*(-Mom[VP[{lt2}], lt1] + 
      Mom[VWm[{lt3}], lt1]) + g[lt1, lt3]*(Mom[conj[VWm[{lt1}]], lt2] - 
      Mom[VWm[{lt3}], lt2])}}, {{conj[VWm[{lt1}]], VWm[{lt2}], VZ[{lt3}]}, 
  {(-I)*g2*Cos[ThetaW]*Cos[ThetaWp], 
   g[lt1, lt2]*(-Mom[conj[VWm[{lt1}]], lt3] + Mom[VWm[{lt2}], lt3]) + 
    g[lt2, lt3]*(-Mom[VWm[{lt2}], lt1] + Mom[VZ[{lt3}], lt1]) + 
    g[lt1, lt3]*(Mom[conj[VWm[{lt1}]], lt2] - Mom[VZ[{lt3}], lt2])}}, 
 {{conj[VWm[{lt1}]], VWm[{lt2}], VZp[{lt3}]}, {I*g2*Cos[ThetaW]*Sin[ThetaWp], 
   g[lt1, lt2]*(-Mom[conj[VWm[{lt1}]], lt3] + Mom[VWm[{lt2}], lt3]) + 
    g[lt2, lt3]*(-Mom[VWm[{lt2}], lt1] + Mom[VZp[{lt3}], lt1]) + 
    g[lt1, lt3]*(Mom[conj[VWm[{lt1}]], lt2] - Mom[VZp[{lt3}], lt2])}}}
