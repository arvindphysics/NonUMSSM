{{{bar[gWm], gWm, Ah[{gt3}]}, 
  {(g2^2*(vd*conj[ZA[gt3, 1]] - vu*conj[ZA[gt3, 2]])*RXi[Wm])/4, 1}}, 
 {{bar[gWmC], gWmC, Ah[{gt3}]}, 
  {-(g2^2*(vd*conj[ZA[gt3, 1]] - vu*conj[ZA[gt3, 2]])*RXi[Wm])/4, 1}}, 
 {{bar[gWm], gP, Hpm[{gt3}]}, 
  {(I/4)*g2*RXi[Wm]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*
    (vd*ZP[gt3, 1] - vu*ZP[gt3, 2]), 1}}, {{bar[gWmC], gP, conj[Hpm[{gt3}]]}, 
  {(I/4)*g2*RXi[Wm]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*
    (vd*ZP[gt3, 1] - vu*ZP[gt3, 2]), 1}}, {{bar[gWm], gWm, hh[{gt3}]}, 
  {(-I/4)*g2^2*(vd*conj[ZH[gt3, 1]] + vu*conj[ZH[gt3, 2]])*RXi[Wm], 1}}, 
 {{bar[gZ], gWm, conj[Hpm[{gt3}]]}, 
  {(-I/4)*g2*RXi[Z]*(vd*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*ZP[gt3, 1] - 
     vu*(g2*Cos[ThetaW]*Cos[ThetaWp] + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt3, 2]), 1}}, 
 {{bar[gZp], gWm, conj[Hpm[{gt3}]]}, 
  {(I/4)*g2*RXi[Zp]*(vd*(-2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZP[gt3, 1] - 
     vu*(2*gp*QHu*Cos[ThetaWp] + (g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt3, 2]), 1}}, {{bar[gWmC], gWmC, hh[{gt3}]}, 
  {(-I/4)*g2^2*(vd*conj[ZH[gt3, 1]] + vu*conj[ZH[gt3, 2]])*RXi[Wm], 1}}, 
 {{bar[gZ], gWmC, Hpm[{gt3}]}, 
  {(-I/4)*g2*RXi[Z]*(vd*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*ZP[gt3, 1] - 
     vu*(g2*Cos[ThetaW]*Cos[ThetaWp] + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt3, 2]), 1}}, 
 {{bar[gZp], gWmC, Hpm[{gt3}]}, 
  {(I/4)*g2*RXi[Zp]*(vd*(-2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZP[gt3, 1] - 
     vu*(2*gp*QHu*Cos[ThetaWp] + (g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt3, 2]), 1}}, {{bar[gZ], gZ, hh[{gt3}]}, 
  {(-I/4)*RXi[Z]*(4*gp^2*Qs^2*vS*conj[ZH[gt3, 3]]*Sin[ThetaWp]^2 + 
     vd*conj[ZH[gt3, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])^2 + 
     vu*conj[ZH[gt3, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])^2), 1}}, 
 {{bar[gZp], gZ, hh[{gt3}]}, 
  {(I/4)*RXi[Zp]*(-4*gp^2*Qs^2*vS*conj[ZH[gt3, 3]]*Cos[ThetaWp]*
      Sin[ThetaWp] + vd*conj[ZH[gt3, 1]]*(-2*g1*gp*QHd*Cos[ThetaWp]^2*
        Sin[ThetaW] + g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHd^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*QHd*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (-(gp*QHd*Cos[ThetaWp]^2) + g1*Cos[ThetaWp]*Sin[ThetaW]*
          Sin[ThetaWp] + gp*QHd*Sin[ThetaWp]^2)) + 
     vu*conj[ZH[gt3, 2]]*(2*g1*gp*QHu*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHu^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 
       2*g1*gp*QHu*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*QHu*Cos[ThetaWp]^2 + g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*QHu*Sin[ThetaWp]^2))), 1}}, {{bar[gWm], gZ, Hpm[{gt3}]}, 
  {(I/4)*g2*RXi[Wm]*(vd*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHd*Sin[ThetaWp])*ZP[gt3, 1] + 
     vu*(-(g2*Cos[ThetaW]*Cos[ThetaWp]) + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt3, 2]), 1}}, 
 {{bar[gWmC], gZ, conj[Hpm[{gt3}]]}, 
  {(I/4)*g2*RXi[Wm]*(vd*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHd*Sin[ThetaWp])*ZP[gt3, 1] + 
     vu*(-(g2*Cos[ThetaW]*Cos[ThetaWp]) + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt3, 2]), 1}}, 
 {{bar[gZ], gZp, hh[{gt3}]}, 
  {(I/4)*RXi[Z]*(-4*gp^2*Qs^2*vS*conj[ZH[gt3, 3]]*Cos[ThetaWp]*Sin[ThetaWp] + 
     vd*conj[ZH[gt3, 1]]*(-2*g1*gp*QHd*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHd^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*QHd*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (-(gp*QHd*Cos[ThetaWp]^2) + g1*Cos[ThetaWp]*Sin[ThetaW]*
          Sin[ThetaWp] + gp*QHd*Sin[ThetaWp]^2)) + 
     vu*conj[ZH[gt3, 2]]*(2*g1*gp*QHu*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHu^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 
       2*g1*gp*QHu*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*QHu*Cos[ThetaWp]^2 + g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*QHu*Sin[ThetaWp]^2))), 1}}, {{bar[gZp], gZp, hh[{gt3}]}, 
  {(-I/4)*RXi[Zp]*(4*gp^2*Qs^2*vS*conj[ZH[gt3, 3]]*Cos[ThetaWp]^2 + 
     vd*conj[ZH[gt3, 1]]*(-2*gp*QHd*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2 + 
     vu*conj[ZH[gt3, 2]]*(2*gp*QHu*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2), 1}}, 
 {{bar[gWm], gZp, Hpm[{gt3}]}, 
  {(-I/4)*g2*RXi[Wm]*(vd*(2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*ZP[gt3, 1] + 
     vu*(2*gp*QHu*Cos[ThetaWp] + (-(g2*Cos[ThetaW]) + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt3, 2]), 1}}, {{bar[gWmC], gZp, conj[Hpm[{gt3}]]}, 
  {(-I/4)*g2*RXi[Wm]*(vd*(2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*ZP[gt3, 1] + 
     vu*(2*gp*QHu*Cos[ThetaWp] + (-(g2*Cos[ThetaW]) + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt3, 2]), 1}}}
