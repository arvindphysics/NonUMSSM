{{{Ah[{gt1}], Ah[{gt2}], Ah[{gt3}]}, 
  {-((conj[ZA[gt1, 3]]*(conj[ZA[gt2, 2]]*conj[ZA[gt3, 1]] + 
         conj[ZA[gt2, 1]]*conj[ZA[gt3, 2]]) + conj[ZA[gt1, 2]]*
        (conj[ZA[gt2, 3]]*conj[ZA[gt3, 1]] + conj[ZA[gt2, 1]]*
          conj[ZA[gt3, 3]]) + conj[ZA[gt1, 1]]*
        (conj[ZA[gt2, 3]]*conj[ZA[gt3, 2]] + conj[ZA[gt2, 2]]*
          conj[ZA[gt3, 3]]))*(conj[T[\[Lambda]]] - T[\[Lambda]]))/
    (2*Sqrt[2]), 1}}, {{Ah[{gt1}], Ah[{gt2}], hh[{gt3}]}, 
  {(-I/4)*(conj[ZA[gt1, 3]]*(Sqrt[2]*conj[T[\[Lambda]]]*
        (conj[ZA[gt2, 2]]*conj[ZH[gt3, 1]] + conj[ZA[gt2, 1]]*
          conj[ZH[gt3, 2]]) + 4*conj[ZA[gt2, 3]]*
        (vd*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] + 
         vu*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 2]] + 
         gp^2*Qs^2*vS*conj[ZH[gt3, 3]]) + 
       Sqrt[2]*(conj[ZA[gt2, 2]]*conj[ZH[gt3, 1]] + conj[ZA[gt2, 1]]*
          conj[ZH[gt3, 2]])*T[\[Lambda]]) + conj[ZA[gt1, 2]]*
      (conj[ZA[gt2, 2]]*(-(vd*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
            4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]]) + 
         (g1^2 + g2^2 + 4*gp^2*QHu^2)*vu*conj[ZH[gt3, 2]] + 
         4*vS*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]) + 
       Sqrt[2]*(conj[ZA[gt2, 3]]*conj[ZH[gt3, 1]] + conj[ZA[gt2, 1]]*
          conj[ZH[gt3, 3]])*(conj[T[\[Lambda]]] + T[\[Lambda]])) + 
     conj[ZA[gt1, 1]]*(conj[ZA[gt2, 1]]*((g1^2 + g2^2 + 4*gp^2*QHd^2)*vd*
          conj[ZH[gt3, 1]] - vu*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
           4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 2]] + 
         4*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]) + 
       Sqrt[2]*(conj[ZA[gt2, 3]]*conj[ZH[gt3, 2]] + conj[ZA[gt2, 2]]*
          conj[ZH[gt3, 3]])*(conj[T[\[Lambda]]] + T[\[Lambda]]))), 1}}, 
 {{Ah[{gt1}], hh[{gt2}], hh[{gt3}]}, 
  {((conj[ZA[gt1, 3]]*(conj[ZH[gt2, 2]]*conj[ZH[gt3, 1]] + 
        conj[ZH[gt2, 1]]*conj[ZH[gt3, 2]]) + conj[ZA[gt1, 2]]*
       (conj[ZH[gt2, 3]]*conj[ZH[gt3, 1]] + conj[ZH[gt2, 1]]*
         conj[ZH[gt3, 3]]) + conj[ZA[gt1, 1]]*
       (conj[ZH[gt2, 3]]*conj[ZH[gt3, 2]] + conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 3]]))*(conj[T[\[Lambda]]] - T[\[Lambda]]))/(2*Sqrt[2]), 
   1}}, {{Ah[{gt1}], Hpm[{gt2}], conj[Hpm[{gt3}]]}, 
  {(vu*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*conj[ZA[gt1, 1]]*
      (ZP[gt2, 2]*ZP[gt3, 1] - ZP[gt2, 1]*ZP[gt3, 2]) + 
     vd*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*conj[ZA[gt1, 2]]*
      (ZP[gt2, 2]*ZP[gt3, 1] - ZP[gt2, 1]*ZP[gt3, 2]) + 
     2*Sqrt[2]*conj[ZA[gt1, 3]]*(-(conj[T[\[Lambda]]]*ZP[gt2, 2]*
         ZP[gt3, 1]) + T[\[Lambda]]*ZP[gt2, 1]*ZP[gt3, 2]))/4, 1}}, 
 {{Ah[{gt1}], Sd[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {(Delta[ct2, ct3]*(conj[\[Lambda]]*(vS*conj[ZA[gt1, 2]] + 
        vu*conj[ZA[gt1, 3]])*sum[j2, 1, 3, conj[ZD[gt2, j2]]*
         sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]] - 
      \[Lambda]*(vS*conj[ZA[gt1, 2]] + vu*conj[ZA[gt1, 3]])*
       sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt2, 3 + j1]]]*
         ZD[gt3, j2]] + Sqrt[2]*conj[ZA[gt1, 1]]*
       (sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, ZD[gt3, 3 + j1]*
            T[Yd][j1, j2]]] - sum[j2, 1, 3, 
         sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*conj[T[Yd][j1, j2]]]*
          ZD[gt3, j2]])))/2, 1}}, {{Ah[{gt1}], Se[{gt2}], conj[Se[{gt3}]]}, 
  {(-(Sqrt[2]*conj[T[Ye11]]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 4]]*ZE[gt3, 1]) - 
     Sqrt[2]*conj[Tep]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 4]]*ZE[gt3, 1] - 
     vS*\[Lambda]*conj[Ye11]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 4]]*ZE[gt3, 1] - 
     vu*\[Lambda]*conj[Ye11]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 4]]*ZE[gt3, 1] - 
     Sqrt[2]*conj[T[Ye22]]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 5]]*ZE[gt3, 2] - 
     Sqrt[2]*conj[Tmup]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 5]]*ZE[gt3, 2] - 
     vS*\[Lambda]*conj[Ye22]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 5]]*ZE[gt3, 2] - 
     vu*\[Lambda]*conj[Ye22]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 5]]*ZE[gt3, 2] - 
     Sqrt[2]*conj[T[Ye33]]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 6]]*ZE[gt3, 3] - 
     vS*\[Lambda]*conj[Ye33]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 6]]*ZE[gt3, 3] - 
     vu*\[Lambda]*conj[Ye33]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 6]]*ZE[gt3, 3] + 
     Sqrt[2]*Tep*conj[ZA[gt1, 2]]*conj[ZE[gt2, 1]]*ZE[gt3, 4] + 
     vS*Ye11*conj[\[Lambda]]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 1]]*ZE[gt3, 4] + 
     vu*Ye11*conj[\[Lambda]]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 1]]*ZE[gt3, 4] + 
     Sqrt[2]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 1]]*T[Ye11]*ZE[gt3, 4] + 
     Sqrt[2]*Tmup*conj[ZA[gt1, 2]]*conj[ZE[gt2, 2]]*ZE[gt3, 5] + 
     vS*Ye22*conj[\[Lambda]]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 2]]*ZE[gt3, 5] + 
     vu*Ye22*conj[\[Lambda]]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 2]]*ZE[gt3, 5] + 
     Sqrt[2]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 2]]*T[Ye22]*ZE[gt3, 5] + 
     vS*Ye33*conj[\[Lambda]]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 3]]*ZE[gt3, 6] + 
     vu*Ye33*conj[\[Lambda]]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 3]]*ZE[gt3, 6] + 
     Sqrt[2]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 3]]*T[Ye33]*ZE[gt3, 6])/2, 1}}, 
 {{Ah[{gt1}], Su[{gt2, ct2}], conj[Su[{gt3, ct3}]]}, 
  {(Delta[ct2, ct3]*(conj[\[Lambda]]*(vS*conj[ZA[gt1, 1]] + 
        vd*conj[ZA[gt1, 3]])*sum[j2, 1, 3, conj[ZU[gt2, j2]]*
         sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]] - 
      \[Lambda]*(vS*conj[ZA[gt1, 1]] + vd*conj[ZA[gt1, 3]])*
       sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt2, 3 + j1]]]*
         ZU[gt3, j2]] + Sqrt[2]*conj[ZA[gt1, 2]]*
       (sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, ZU[gt3, 3 + j1]*
            T[Yu][j1, j2]]] - sum[j2, 1, 3, 
         sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*conj[T[Yu][j1, j2]]]*
          ZU[gt3, j2]])))/2, 1}}, {{Ah[{gt1}], Sv[{gt2}], conj[Sv[{gt3}]]}, 
  {(-(Sqrt[2]*conj[T[Yv11]]*conj[ZA[gt1, 2]]*conj[ZV[gt2, 4]]*ZV[gt3, 1]) - 
     \[Lambda]*conj[Yv11]*(vS*conj[ZA[gt1, 1]] + vd*conj[ZA[gt1, 3]])*
      conj[ZV[gt2, 4]]*ZV[gt3, 1] - vS*\[Lambda]*conj[Yv22]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 5]]*ZV[gt3, 2] - Sqrt[2]*conj[T[Yv22]]*conj[ZA[gt1, 2]]*
      conj[ZV[gt2, 5]]*ZV[gt3, 2] - vd*\[Lambda]*conj[Yv22]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 5]]*ZV[gt3, 2] - vS*\[Lambda]*conj[Yv33]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 6]]*ZV[gt3, 3] - Sqrt[2]*conj[T[Yv33]]*conj[ZA[gt1, 2]]*
      conj[ZV[gt2, 6]]*ZV[gt3, 3] - vd*\[Lambda]*conj[Yv33]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 6]]*ZV[gt3, 3] + vS*Yv11*conj[\[Lambda]]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 1]]*ZV[gt3, 4] + vd*Yv11*conj[\[Lambda]]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 1]]*ZV[gt3, 4] + Sqrt[2]*conj[ZA[gt1, 2]]*conj[ZV[gt2, 1]]*
      T[Yv11]*ZV[gt3, 4] + vS*Yv22*conj[\[Lambda]]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 2]]*ZV[gt3, 5] + vd*Yv22*conj[\[Lambda]]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 2]]*ZV[gt3, 5] + Sqrt[2]*conj[ZA[gt1, 2]]*conj[ZV[gt2, 2]]*
      T[Yv22]*ZV[gt3, 5] + vS*Yv33*conj[\[Lambda]]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 3]]*ZV[gt3, 6] + vd*Yv33*conj[\[Lambda]]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 3]]*ZV[gt3, 6] + Sqrt[2]*conj[ZA[gt1, 2]]*conj[ZV[gt2, 3]]*
      T[Yv33]*ZV[gt3, 6])/2, 1}}, {{hh[{gt1}], hh[{gt2}], hh[{gt3}]}, 
  {(I/4)*(-(conj[ZH[gt1, 3]]*(-(Sqrt[2]*conj[T[\[Lambda]]]*conj[ZH[gt2, 2]]*
          conj[ZH[gt3, 1]]) + 4*gp^2*QHd*Qs*vd*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 1]] + 4*vd*\[Lambda]*conj[\[Lambda]]*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 1]] + 4*gp^2*QHu*Qs*vS*conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 2]] + 4*vS*\[Lambda]*conj[\[Lambda]]*conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 2]] + 4*gp^2*QHu*Qs*vu*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 2]] + 4*vu*\[Lambda]*conj[\[Lambda]]*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 2]] + 4*gp^2*QHu*Qs*vu*conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 3]] + 4*vu*\[Lambda]*conj[\[Lambda]]*conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 3]] + 12*gp^2*Qs^2*vS*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 3]] - Sqrt[2]*conj[ZH[gt2, 2]]*conj[ZH[gt3, 1]]*
         T[\[Lambda]] + conj[ZH[gt2, 1]]*
         (4*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] - 
          Sqrt[2]*conj[T[\[Lambda]]]*conj[ZH[gt3, 2]] + 4*gp^2*QHd*Qs*vd*
           conj[ZH[gt3, 3]] + 4*vd*\[Lambda]*conj[\[Lambda]]*
           conj[ZH[gt3, 3]] - Sqrt[2]*conj[ZH[gt3, 2]]*T[\[Lambda]]))) + 
     conj[ZH[gt1, 2]]*(conj[ZH[gt2, 2]]*(vd*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
           4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] - 
         3*(g1^2 + g2^2 + 4*gp^2*QHu^2)*vu*conj[ZH[gt3, 2]] - 
         4*vS*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]) + 
       conj[ZH[gt2, 3]]*(Sqrt[2]*conj[T[\[Lambda]]]*conj[ZH[gt3, 1]] - 
         4*vS*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 2]] - 
         4*gp^2*QHu*Qs*vu*conj[ZH[gt3, 3]] - 4*vu*\[Lambda]*conj[\[Lambda]]*
          conj[ZH[gt3, 3]] + Sqrt[2]*conj[ZH[gt3, 1]]*T[\[Lambda]]) + 
       conj[ZH[gt2, 1]]*(vu*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
           4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] + 
         vd*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
          conj[ZH[gt3, 2]] + Sqrt[2]*conj[ZH[gt3, 3]]*(conj[T[\[Lambda]]] + 
           T[\[Lambda]]))) + conj[ZH[gt1, 1]]*
      (-(conj[ZH[gt2, 1]]*(3*(g1^2 + g2^2 + 4*gp^2*QHd^2)*vd*
           conj[ZH[gt3, 1]] - vu*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
            4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 2]] + 
          4*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]])) + 
       conj[ZH[gt2, 3]]*(-4*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*
          conj[ZH[gt3, 1]] + Sqrt[2]*conj[T[\[Lambda]]]*conj[ZH[gt3, 2]] - 
         4*gp^2*QHd*Qs*vd*conj[ZH[gt3, 3]] - 4*vd*\[Lambda]*conj[\[Lambda]]*
          conj[ZH[gt3, 3]] + Sqrt[2]*conj[ZH[gt3, 2]]*T[\[Lambda]]) + 
       conj[ZH[gt2, 2]]*(vu*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
           4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] + 
         vd*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
          conj[ZH[gt3, 2]] + Sqrt[2]*conj[ZH[gt3, 3]]*(conj[T[\[Lambda]]] + 
           T[\[Lambda]])))), 1}}, {{hh[{gt1}], Hpm[{gt2}], conj[Hpm[{gt3}]]}, 
  {(-I/4)*(conj[ZH[gt1, 2]]*
      (ZP[gt2, 2]*(vd*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*ZP[gt3, 1] + 
         (g1^2 + g2^2 + 4*gp^2*QHu^2)*vu*ZP[gt3, 2]) + 
       ZP[gt2, 1]*((-g1^2 + g2^2 + 4*gp^2*QHd*QHu)*vu*ZP[gt3, 1] + 
         vd*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*ZP[gt3, 2])) + 
     conj[ZH[gt1, 1]]*(ZP[gt2, 2]*(vu*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*
          ZP[gt3, 1] + (-g1^2 + g2^2 + 4*gp^2*QHd*QHu)*vd*ZP[gt3, 2]) + 
       ZP[gt2, 1]*((g1^2 + g2^2 + 4*gp^2*QHd^2)*vd*ZP[gt3, 1] + 
         vu*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*ZP[gt3, 2])) + 
     2*conj[ZH[gt1, 3]]*(ZP[gt2, 2]*(Sqrt[2]*conj[T[\[Lambda]]]*ZP[gt3, 1] + 
         2*vS*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*ZP[gt3, 2]) + 
       ZP[gt2, 1]*(2*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*
          ZP[gt3, 1] + Sqrt[2]*T[\[Lambda]]*ZP[gt3, 2]))), 1}}, 
 {{hh[{gt1}], Sd[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {(I/12)*Delta[ct2, ct3]*(6*conj[ZH[gt1, 3]]*
      (-2*gp^2*Qq*Qs*vS*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]] - 
       2*gp^2*Qd*Qs*vS*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]] + 
       vu*conj[\[Lambda]]*sum[j2, 1, 3, conj[ZD[gt2, j2]]*
          sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]] + 
       vu*\[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*
            conj[ZD[gt2, 3 + j1]]]*ZD[gt3, j2]]) - 
     conj[ZH[gt1, 2]]*((g1^2 + 3*(g2^2 + 4*gp^2*QHu*Qq))*vu*
        sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]] + 
       2*(g1^2 + 6*gp^2*Qd*QHu)*vu*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*
          ZD[gt3, 3 + j1]] - 6*vS*(conj[\[Lambda]]*sum[j2, 1, 3, 
           conj[ZD[gt2, j2]]*sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]] + 
         \[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*
              conj[ZD[gt2, 3 + j1]]]*ZD[gt3, j2]])) + 
     conj[ZH[gt1, 1]]*((g1^2 + 3*(g2^2 - 4*gp^2*QHd*Qq))*vd*
        sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]] + 
       2*(g1^2 - 6*gp^2*Qd*QHd)*vd*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*
          ZD[gt3, 3 + j1]] - 
       6*(Sqrt[2]*sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, 
             ZD[gt3, 3 + j1]*T[Yd][j1, j2]]] + 
         Sqrt[2]*sum[j2, 1, 3, sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*
              conj[T[Yd][j1, j2]]]*ZD[gt3, j2]] + 
         2*vd*(sum[j3, 1, 3, conj[ZD[gt2, 3 + j3]]*sum[j2, 1, 3, 
              sum[j1, 1, 3, conj[Yd[j3, j1]]*Yd[j2, j1]]*ZD[gt3, 3 + j2]]] + 
           sum[j3, 1, 3, sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, 
                conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZD[gt3, j3]])))), 1}}, 
 {{hh[{gt1}], Se[{gt2}], conj[Se[{gt3}]]}, 
  {(-I/4)*(2*Sqrt[2]*conj[T[Ye11]]*conj[ZE[gt2, 4]]*conj[ZH[gt1, 1]]*
      ZE[gt3, 1] - 2*Sqrt[2]*conj[Tep]*conj[ZE[gt2, 4]]*conj[ZH[gt1, 2]]*
      ZE[gt3, 1] - 2*vS*\[Lambda]*conj[Ye11]*conj[ZE[gt2, 4]]*
      conj[ZH[gt1, 2]]*ZE[gt3, 1] - 2*vu*\[Lambda]*conj[Ye11]*
      conj[ZE[gt2, 4]]*conj[ZH[gt1, 3]]*ZE[gt3, 1] + 
     g1^2*vd*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] - 
     g2^2*vd*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] + 
     4*gp^2*QHd*Ql2*vd*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] + 
     4*vd*Ye22*conj[Ye22]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] + 
     2*Sqrt[2]*conj[T[Ye22]]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] - 
     g1^2*vu*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] + 
     g2^2*vu*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] + 
     4*gp^2*QHu*Ql2*vu*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] - 
     2*Sqrt[2]*conj[Tmup]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] - 
     2*vS*\[Lambda]*conj[Ye22]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] + 
     4*gp^2*Ql2*Qs*vS*conj[ZE[gt2, 2]]*conj[ZH[gt1, 3]]*ZE[gt3, 2] - 
     2*vu*\[Lambda]*conj[Ye22]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 3]]*ZE[gt3, 2] + 
     g1^2*vd*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] - 
     g2^2*vd*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] + 
     4*gp^2*QHd*Ql3*vd*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] + 
     4*vd*Ye33*conj[Ye33]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] + 
     2*Sqrt[2]*conj[T[Ye33]]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] - 
     g1^2*vu*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZE[gt3, 3] + 
     g2^2*vu*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZE[gt3, 3] + 
     4*gp^2*QHu*Ql3*vu*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZE[gt3, 3] - 
     2*vS*\[Lambda]*conj[Ye33]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 2]]*ZE[gt3, 3] + 
     4*gp^2*Ql3*Qs*vS*conj[ZE[gt2, 3]]*conj[ZH[gt1, 3]]*ZE[gt3, 3] - 
     2*vu*\[Lambda]*conj[Ye33]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 3]]*ZE[gt3, 3] - 
     2*g1^2*vd*conj[ZE[gt2, 4]]*conj[ZH[gt1, 1]]*ZE[gt3, 4] + 
     4*gp^2*Qe1*QHd*vd*conj[ZE[gt2, 4]]*conj[ZH[gt1, 1]]*ZE[gt3, 4] + 
     4*vd*Ye11*conj[Ye11]*conj[ZE[gt2, 4]]*conj[ZH[gt1, 1]]*ZE[gt3, 4] + 
     2*g1^2*vu*conj[ZE[gt2, 4]]*conj[ZH[gt1, 2]]*ZE[gt3, 4] + 
     4*gp^2*Qe1*QHu*vu*conj[ZE[gt2, 4]]*conj[ZH[gt1, 2]]*ZE[gt3, 4] + 
     4*gp^2*Qe1*Qs*vS*conj[ZE[gt2, 4]]*conj[ZH[gt1, 3]]*ZE[gt3, 4] + 
     conj[ZE[gt2, 1]]*(2*conj[ZH[gt1, 3]]*(2*gp^2*Ql1*Qs*vS*ZE[gt3, 1] - 
         vu*Ye11*conj[\[Lambda]]*ZE[gt3, 4]) + conj[ZH[gt1, 2]]*
        ((-g1^2 + g2^2 + 4*gp^2*QHu*Ql1)*vu*ZE[gt3, 1] - 
         2*(Sqrt[2]*Tep + vS*Ye11*conj[\[Lambda]])*ZE[gt3, 4]) + 
       conj[ZH[gt1, 1]]*(vd*(g1^2 - g2^2 + 4*gp^2*QHd*Ql1 + 
           4*Ye11*conj[Ye11])*ZE[gt3, 1] + 2*Sqrt[2]*T[Ye11]*ZE[gt3, 4])) - 
     2*g1^2*vd*conj[ZE[gt2, 5]]*conj[ZH[gt1, 1]]*ZE[gt3, 5] + 
     4*gp^2*Qe2*QHd*vd*conj[ZE[gt2, 5]]*conj[ZH[gt1, 1]]*ZE[gt3, 5] + 
     4*vd*Ye22*conj[Ye22]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 1]]*ZE[gt3, 5] - 
     2*Sqrt[2]*Tmup*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 5] - 
     2*vS*Ye22*conj[\[Lambda]]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 5] + 
     2*g1^2*vu*conj[ZE[gt2, 5]]*conj[ZH[gt1, 2]]*ZE[gt3, 5] + 
     4*gp^2*Qe2*QHu*vu*conj[ZE[gt2, 5]]*conj[ZH[gt1, 2]]*ZE[gt3, 5] - 
     2*vu*Ye22*conj[\[Lambda]]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 3]]*ZE[gt3, 5] + 
     4*gp^2*Qe2*Qs*vS*conj[ZE[gt2, 5]]*conj[ZH[gt1, 3]]*ZE[gt3, 5] + 
     2*Sqrt[2]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*T[Ye22]*ZE[gt3, 5] - 
     2*g1^2*vd*conj[ZE[gt2, 6]]*conj[ZH[gt1, 1]]*ZE[gt3, 6] + 
     4*gp^2*Qe3*QHd*vd*conj[ZE[gt2, 6]]*conj[ZH[gt1, 1]]*ZE[gt3, 6] + 
     4*vd*Ye33*conj[Ye33]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 1]]*ZE[gt3, 6] - 
     2*vS*Ye33*conj[\[Lambda]]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZE[gt3, 6] + 
     2*g1^2*vu*conj[ZE[gt2, 6]]*conj[ZH[gt1, 2]]*ZE[gt3, 6] + 
     4*gp^2*Qe3*QHu*vu*conj[ZE[gt2, 6]]*conj[ZH[gt1, 2]]*ZE[gt3, 6] - 
     2*vu*Ye33*conj[\[Lambda]]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 3]]*ZE[gt3, 6] + 
     4*gp^2*Qe3*Qs*vS*conj[ZE[gt2, 6]]*conj[ZH[gt1, 3]]*ZE[gt3, 6] + 
     2*Sqrt[2]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*T[Ye33]*ZE[gt3, 6]), 1}}, 
 {{hh[{gt1}], Su[{gt2, ct2}], conj[Su[{gt3, ct3}]]}, 
  {(I/12)*Delta[ct2, ct3]*(6*conj[ZH[gt1, 3]]*
      (-2*gp^2*Qq*Qs*vS*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]] - 
       2*gp^2*Qs*Qu*vS*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]] + 
       vd*conj[\[Lambda]]*sum[j2, 1, 3, conj[ZU[gt2, j2]]*
          sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]] + 
       vd*\[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
            conj[ZU[gt2, 3 + j1]]]*ZU[gt3, j2]]) + 
     conj[ZH[gt1, 1]]*((g1^2 - 3*(g2^2 + 4*gp^2*QHd*Qq))*vd*
        sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]] - 
       4*(g1^2 + 3*gp^2*QHd*Qu)*vd*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
          ZU[gt3, 3 + j1]] + 6*vS*(conj[\[Lambda]]*sum[j2, 1, 3, 
           conj[ZU[gt2, j2]]*sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]] + 
         \[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
              conj[ZU[gt2, 3 + j1]]]*ZU[gt3, j2]])) - 
     conj[ZH[gt1, 2]]*((g1^2 - 3*g2^2 + 12*gp^2*QHu*Qq)*vu*
        sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]] - 
       4*(g1^2 - 3*gp^2*QHu*Qu)*vu*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
          ZU[gt3, 3 + j1]] + 
       6*(Sqrt[2]*sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
             ZU[gt3, 3 + j1]*T[Yu][j1, j2]]] + 
         Sqrt[2]*sum[j2, 1, 3, sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
              conj[T[Yu][j1, j2]]]*ZU[gt3, j2]] + 
         2*vu*(sum[j3, 1, 3, conj[ZU[gt2, 3 + j3]]*sum[j2, 1, 3, 
              sum[j1, 1, 3, conj[Yu[j3, j1]]*Yu[j2, j1]]*ZU[gt3, 3 + j2]]] + 
           sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
                conj[Yu[j1, j3]]*Yu[j1, j2]]]*ZU[gt3, j3]])))), 1}}, 
 {{hh[{gt1}], Sv[{gt2}], conj[Sv[{gt3}]]}, 
  {(-I/4)*(conj[ZH[gt1, 1]]*(-2*vS*\[Lambda]*conj[Yv11]*conj[ZV[gt2, 4]]*
        ZV[gt3, 1] + g1^2*vd*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 
       g2^2*vd*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 4*gp^2*QHd*Ql2*vd*
        conj[ZV[gt2, 2]]*ZV[gt3, 2] - 2*vS*\[Lambda]*conj[Yv22]*
        conj[ZV[gt2, 5]]*ZV[gt3, 2] + g1^2*vd*conj[ZV[gt2, 3]]*ZV[gt3, 3] + 
       g2^2*vd*conj[ZV[gt2, 3]]*ZV[gt3, 3] + 4*gp^2*QHd*Ql3*vd*
        conj[ZV[gt2, 3]]*ZV[gt3, 3] - 2*vS*\[Lambda]*conj[Yv33]*
        conj[ZV[gt2, 6]]*ZV[gt3, 3] + 4*gp^2*QHd*Qv1*vd*conj[ZV[gt2, 4]]*
        ZV[gt3, 4] + conj[ZV[gt2, 1]]*((g1^2 + g2^2 + 4*gp^2*QHd*Ql1)*vd*
          ZV[gt3, 1] - 2*vS*Yv11*conj[\[Lambda]]*ZV[gt3, 4]) - 
       2*vS*Yv22*conj[\[Lambda]]*conj[ZV[gt2, 2]]*ZV[gt3, 5] + 
       4*gp^2*QHd*Qv2*vd*conj[ZV[gt2, 5]]*ZV[gt3, 5] - 
       2*vS*Yv33*conj[\[Lambda]]*conj[ZV[gt2, 3]]*ZV[gt3, 6] + 
       4*gp^2*QHd*Qv3*vd*conj[ZV[gt2, 6]]*ZV[gt3, 6]) - 
     2*conj[ZH[gt1, 3]]*(vd*\[Lambda]*conj[Yv11]*conj[ZV[gt2, 4]]*
        ZV[gt3, 1] - 2*gp^2*Ql2*Qs*vS*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 
       vd*\[Lambda]*conj[Yv22]*conj[ZV[gt2, 5]]*ZV[gt3, 2] - 
       2*gp^2*Ql3*Qs*vS*conj[ZV[gt2, 3]]*ZV[gt3, 3] + vd*\[Lambda]*conj[Yv33]*
        conj[ZV[gt2, 6]]*ZV[gt3, 3] - 2*gp^2*Qs*Qv1*vS*conj[ZV[gt2, 4]]*
        ZV[gt3, 4] + conj[ZV[gt2, 1]]*(-2*gp^2*Ql1*Qs*vS*ZV[gt3, 1] + 
         vd*Yv11*conj[\[Lambda]]*ZV[gt3, 4]) + vd*Yv22*conj[\[Lambda]]*
        conj[ZV[gt2, 2]]*ZV[gt3, 5] - 2*gp^2*Qs*Qv2*vS*conj[ZV[gt2, 5]]*
        ZV[gt3, 5] + vd*Yv33*conj[\[Lambda]]*conj[ZV[gt2, 3]]*ZV[gt3, 6] - 
       2*gp^2*Qs*Qv3*vS*conj[ZV[gt2, 6]]*ZV[gt3, 6]) + 
     conj[ZH[gt1, 2]]*(2*Sqrt[2]*conj[T[Yv11]]*conj[ZV[gt2, 4]]*ZV[gt3, 1] - 
       g1^2*vu*conj[ZV[gt2, 2]]*ZV[gt3, 2] - g2^2*vu*conj[ZV[gt2, 2]]*
        ZV[gt3, 2] + 4*gp^2*QHu*Ql2*vu*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 
       4*vu*Yv22*conj[Yv22]*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 
       2*Sqrt[2]*conj[T[Yv22]]*conj[ZV[gt2, 5]]*ZV[gt3, 2] - 
       g1^2*vu*conj[ZV[gt2, 3]]*ZV[gt3, 3] - g2^2*vu*conj[ZV[gt2, 3]]*
        ZV[gt3, 3] + 4*gp^2*QHu*Ql3*vu*conj[ZV[gt2, 3]]*ZV[gt3, 3] + 
       4*vu*Yv33*conj[Yv33]*conj[ZV[gt2, 3]]*ZV[gt3, 3] + 
       2*Sqrt[2]*conj[T[Yv33]]*conj[ZV[gt2, 6]]*ZV[gt3, 3] + 
       4*gp^2*QHu*Qv1*vu*conj[ZV[gt2, 4]]*ZV[gt3, 4] + 
       4*vu*Yv11*conj[Yv11]*conj[ZV[gt2, 4]]*ZV[gt3, 4] + 
       conj[ZV[gt2, 1]]*(-(vu*(g1^2 + g2^2 - 4*gp^2*QHu*Ql1 - 
            4*Yv11*conj[Yv11])*ZV[gt3, 1]) + 2*Sqrt[2]*T[Yv11]*ZV[gt3, 4]) + 
       4*gp^2*QHu*Qv2*vu*conj[ZV[gt2, 5]]*ZV[gt3, 5] + 
       4*vu*Yv22*conj[Yv22]*conj[ZV[gt2, 5]]*ZV[gt3, 5] + 
       2*Sqrt[2]*conj[ZV[gt2, 2]]*T[Yv22]*ZV[gt3, 5] + 
       4*gp^2*QHu*Qv3*vu*conj[ZV[gt2, 6]]*ZV[gt3, 6] + 
       4*vu*Yv33*conj[Yv33]*conj[ZV[gt2, 6]]*ZV[gt3, 6] + 
       2*Sqrt[2]*conj[ZV[gt2, 3]]*T[Yv33]*ZV[gt3, 6])), 1}}, 
 {{Hpm[{gt1}], Su[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {(-I/4)*Delta[ct2, ct3]*(Sqrt[2]*g2^2*sum[j1, 1, 3, 
       conj[ZU[gt2, j1]]*ZD[gt3, j1]]*(vd*ZP[gt1, 1] + vu*ZP[gt1, 2]) - 
     2*(2*sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, ZD[gt3, 3 + j1]*
            T[Yd][j1, j2]]]*ZP[gt1, 1] + Sqrt[2]*vS*\[Lambda]*
        sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt2, 3 + j1]]]*
          ZD[gt3, j2]]*ZP[gt1, 1] + Sqrt[2]*vu*sum[j3, 1, 3, 
         conj[ZU[gt2, 3 + j3]]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j3, j1]]*
              Yd[j2, j1]]*ZD[gt3, 3 + j2]]]*ZP[gt1, 1] + 
       Sqrt[2]*vd*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt2, j2]]*
            sum[j1, 1, 3, conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZD[gt3, j3]]*
        ZP[gt1, 1] + Sqrt[2]*vS*conj[\[Lambda]]*sum[j2, 1, 3, 
         conj[ZU[gt2, j2]]*sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]]*
        ZP[gt1, 2] + 2*sum[j2, 1, 3, sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
            conj[T[Yu][j1, j2]]]*ZD[gt3, j2]]*ZP[gt1, 2] + 
       Sqrt[2]*vd*sum[j3, 1, 3, conj[ZU[gt2, 3 + j3]]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yu[j3, j1]]*Yd[j2, j1]]*ZD[gt3, 3 + j2]]]*
        ZP[gt1, 2] + Sqrt[2]*vu*sum[j3, 1, 3, 
         sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, conj[Yu[j1, j3]]*
              Yu[j1, j2]]]*ZD[gt3, j3]]*ZP[gt1, 2])), 1}}, 
 {{Hpm[{gt1}], Sv[{gt2}], conj[Se[{gt3}]]}, 
  {(-I/4)*(Sqrt[2]*g2^2*vd*conj[ZV[gt2, 2]]*ZE[gt3, 2]*ZP[gt1, 1] - 
     2*Sqrt[2]*vd*Ye22*conj[Ye22]*conj[ZV[gt2, 2]]*ZE[gt3, 2]*ZP[gt1, 1] - 
     2*Sqrt[2]*vS*\[Lambda]*conj[Yv22]*conj[ZV[gt2, 5]]*ZE[gt3, 2]*
      ZP[gt1, 1] + Sqrt[2]*g2^2*vd*conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZP[gt1, 1] - 
     2*Sqrt[2]*vd*Ye33*conj[Ye33]*conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZP[gt1, 1] - 
     2*Sqrt[2]*vS*\[Lambda]*conj[Yv33]*conj[ZV[gt2, 6]]*ZE[gt3, 3]*
      ZP[gt1, 1] - 2*Sqrt[2]*vu*Ye22*conj[Yv22]*conj[ZV[gt2, 5]]*ZE[gt3, 5]*
      ZP[gt1, 1] - 4*conj[ZV[gt2, 2]]*T[Ye22]*ZE[gt3, 5]*ZP[gt1, 1] - 
     2*Sqrt[2]*vu*Ye33*conj[Yv33]*conj[ZV[gt2, 6]]*ZE[gt3, 6]*ZP[gt1, 1] - 
     4*conj[ZV[gt2, 3]]*T[Ye33]*ZE[gt3, 6]*ZP[gt1, 1] - 
     4*conj[T[Yv11]]*conj[ZV[gt2, 4]]*ZE[gt3, 1]*ZP[gt1, 2] + 
     Sqrt[2]*g2^2*vu*conj[ZV[gt2, 2]]*ZE[gt3, 2]*ZP[gt1, 2] - 
     2*Sqrt[2]*vu*Yv22*conj[Yv22]*conj[ZV[gt2, 2]]*ZE[gt3, 2]*ZP[gt1, 2] - 
     4*conj[T[Yv22]]*conj[ZV[gt2, 5]]*ZE[gt3, 2]*ZP[gt1, 2] + 
     Sqrt[2]*g2^2*vu*conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZP[gt1, 2] - 
     2*Sqrt[2]*vu*Yv33*conj[Yv33]*conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZP[gt1, 2] - 
     4*conj[T[Yv33]]*conj[ZV[gt2, 6]]*ZE[gt3, 3]*ZP[gt1, 2] - 
     4*Tmup*conj[ZV[gt2, 2]]*ZE[gt3, 5]*ZP[gt1, 2] - 
     2*Sqrt[2]*vS*Ye22*conj[\[Lambda]]*conj[ZV[gt2, 2]]*ZE[gt3, 5]*
      ZP[gt1, 2] - 2*Sqrt[2]*vd*Ye22*conj[Yv22]*conj[ZV[gt2, 5]]*ZE[gt3, 5]*
      ZP[gt1, 2] - 2*Sqrt[2]*vS*Ye33*conj[\[Lambda]]*conj[ZV[gt2, 3]]*
      ZE[gt3, 6]*ZP[gt1, 2] - 2*Sqrt[2]*vd*Ye33*conj[Yv33]*conj[ZV[gt2, 6]]*
      ZE[gt3, 6]*ZP[gt1, 2] - 2*Sqrt[2]*conj[Yv11]*conj[ZV[gt2, 4]]*
      (vS*\[Lambda]*ZE[gt3, 1]*ZP[gt1, 1] + Ye11*ZE[gt3, 4]*
        (vu*ZP[gt1, 1] + vd*ZP[gt1, 2])) + conj[ZV[gt2, 1]]*
      (Sqrt[2]*ZE[gt3, 1]*(vd*(g2^2 - 2*Ye11*conj[Ye11])*ZP[gt1, 1] + 
         vu*(g2^2 - 2*Yv11*conj[Yv11])*ZP[gt1, 2]) - 
       2*ZE[gt3, 4]*(2*T[Ye11]*ZP[gt1, 1] + 
         (2*Tep + Sqrt[2]*vS*Ye11*conj[\[Lambda]])*ZP[gt1, 2]))), 1}}, 
 {{Sd[{gt1, ct1}], conj[Hpm[{gt2}]], conj[Su[{gt3, ct3}]]}, 
  {(-I/4)*Delta[ct1, ct3]*(Sqrt[2]*g2^2*sum[j1, 1, 3, 
       conj[ZD[gt1, j1]]*ZU[gt3, j1]]*(vd*ZP[gt2, 1] + vu*ZP[gt2, 2]) - 
     2*(Sqrt[2]*vS*conj[\[Lambda]]*sum[j2, 1, 3, conj[ZD[gt1, j2]]*
          sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]]*ZP[gt2, 1] + 
       2*sum[j2, 1, 3, sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
            conj[T[Yd][j1, j2]]]*ZU[gt3, j2]]*ZP[gt2, 1] + 
       Sqrt[2]*vu*sum[j3, 1, 3, conj[ZD[gt1, 3 + j3]]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yd[j3, j1]]*Yu[j2, j1]]*ZU[gt3, 3 + j2]]]*
        ZP[gt2, 1] + Sqrt[2]*vd*sum[j3, 1, 3, 
         sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, conj[Yd[j1, j3]]*
              Yd[j1, j2]]]*ZU[gt3, j3]]*ZP[gt2, 1] + 
       2*sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, ZU[gt3, 3 + j1]*
            T[Yu][j1, j2]]]*ZP[gt2, 2] + Sqrt[2]*vS*\[Lambda]*
        sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt1, 3 + j1]]]*
          ZU[gt3, j2]]*ZP[gt2, 2] + Sqrt[2]*vd*sum[j3, 1, 3, 
         conj[ZD[gt1, 3 + j3]]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j3, j1]]*
              Yu[j2, j1]]*ZU[gt3, 3 + j2]]]*ZP[gt2, 2] + 
       Sqrt[2]*vu*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZD[gt1, j2]]*
            sum[j1, 1, 3, conj[Yu[j1, j3]]*Yu[j1, j2]]]*ZU[gt3, j3]]*
        ZP[gt2, 2])), 1}}, {{Se[{gt1}], conj[Hpm[{gt2}]], conj[Sv[{gt3}]]}, 
  {(I/4)*(4*conj[T[Ye11]]*conj[ZE[gt1, 4]]*ZP[gt2, 1]*ZV[gt3, 1] + 
     4*conj[Tep]*conj[ZE[gt1, 4]]*ZP[gt2, 2]*ZV[gt3, 1] + 
     2*Sqrt[2]*vS*\[Lambda]*conj[Ye11]*conj[ZE[gt1, 4]]*ZP[gt2, 2]*
      ZV[gt3, 1] - Sqrt[2]*g2^2*vd*conj[ZE[gt1, 2]]*ZP[gt2, 1]*ZV[gt3, 2] + 
     2*Sqrt[2]*vd*Ye22*conj[Ye22]*conj[ZE[gt1, 2]]*ZP[gt2, 1]*ZV[gt3, 2] + 
     4*conj[T[Ye22]]*conj[ZE[gt1, 5]]*ZP[gt2, 1]*ZV[gt3, 2] - 
     Sqrt[2]*g2^2*vu*conj[ZE[gt1, 2]]*ZP[gt2, 2]*ZV[gt3, 2] + 
     2*Sqrt[2]*vu*Yv22*conj[Yv22]*conj[ZE[gt1, 2]]*ZP[gt2, 2]*ZV[gt3, 2] + 
     4*conj[Tmup]*conj[ZE[gt1, 5]]*ZP[gt2, 2]*ZV[gt3, 2] + 
     2*Sqrt[2]*vS*\[Lambda]*conj[Ye22]*conj[ZE[gt1, 5]]*ZP[gt2, 2]*
      ZV[gt3, 2] - Sqrt[2]*g2^2*vd*conj[ZE[gt1, 3]]*ZP[gt2, 1]*ZV[gt3, 3] + 
     2*Sqrt[2]*vd*Ye33*conj[Ye33]*conj[ZE[gt1, 3]]*ZP[gt2, 1]*ZV[gt3, 3] + 
     4*conj[T[Ye33]]*conj[ZE[gt1, 6]]*ZP[gt2, 1]*ZV[gt3, 3] - 
     Sqrt[2]*g2^2*vu*conj[ZE[gt1, 3]]*ZP[gt2, 2]*ZV[gt3, 3] + 
     2*Sqrt[2]*vu*Yv33*conj[Yv33]*conj[ZE[gt1, 3]]*ZP[gt2, 2]*ZV[gt3, 3] + 
     2*Sqrt[2]*vS*\[Lambda]*conj[Ye33]*conj[ZE[gt1, 6]]*ZP[gt2, 2]*
      ZV[gt3, 3] + 2*Sqrt[2]*vu*Yv11*conj[Ye11]*conj[ZE[gt1, 4]]*ZP[gt2, 1]*
      ZV[gt3, 4] + 2*Sqrt[2]*vd*Yv11*conj[Ye11]*conj[ZE[gt1, 4]]*ZP[gt2, 2]*
      ZV[gt3, 4] + conj[ZE[gt1, 1]]*(Sqrt[2]*ZP[gt2, 1]*
        (-(vd*(g2^2 - 2*Ye11*conj[Ye11])*ZV[gt3, 1]) + 
         2*vS*Yv11*conj[\[Lambda]]*ZV[gt3, 4]) + 
       ZP[gt2, 2]*(-(Sqrt[2]*vu*(g2^2 - 2*Yv11*conj[Yv11])*ZV[gt3, 1]) + 
         4*T[Yv11]*ZV[gt3, 4])) + 2*Sqrt[2]*vS*Yv22*conj[\[Lambda]]*
      conj[ZE[gt1, 2]]*ZP[gt2, 1]*ZV[gt3, 5] + 2*Sqrt[2]*vu*Yv22*conj[Ye22]*
      conj[ZE[gt1, 5]]*ZP[gt2, 1]*ZV[gt3, 5] + 2*Sqrt[2]*vd*Yv22*conj[Ye22]*
      conj[ZE[gt1, 5]]*ZP[gt2, 2]*ZV[gt3, 5] + 4*conj[ZE[gt1, 2]]*T[Yv22]*
      ZP[gt2, 2]*ZV[gt3, 5] + 2*Sqrt[2]*vS*Yv33*conj[\[Lambda]]*
      conj[ZE[gt1, 3]]*ZP[gt2, 1]*ZV[gt3, 6] + 2*Sqrt[2]*vu*Yv33*conj[Ye33]*
      conj[ZE[gt1, 6]]*ZP[gt2, 1]*ZV[gt3, 6] + 2*Sqrt[2]*vd*Yv33*conj[Ye33]*
      conj[ZE[gt1, 6]]*ZP[gt2, 2]*ZV[gt3, 6] + 4*conj[ZE[gt1, 3]]*T[Yv33]*
      ZP[gt2, 2]*ZV[gt3, 6]), 1}}, {{Ah[{gt1}], hh[{gt2}], VZ[{lt3}]}, 
  {(2*gp*Qs*conj[ZA[gt1, 3]]*conj[ZH[gt2, 3]]*Sin[ThetaWp] + 
     conj[ZA[gt1, 1]]*conj[ZH[gt2, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp]) - 
     conj[ZA[gt1, 2]]*conj[ZH[gt2, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp]))/2, 
   Mom[Ah[{gt1}], lt3] - Mom[hh[{gt2}], lt3]}}, 
 {{Ah[{gt1}], hh[{gt2}], VZp[{lt3}]}, 
  {(2*gp*Qs*conj[ZA[gt1, 3]]*conj[ZH[gt2, 3]]*Cos[ThetaWp] + 
     conj[ZA[gt1, 2]]*conj[ZH[gt2, 2]]*(2*gp*QHu*Cos[ThetaWp] + 
       g2*Cos[ThetaW]*Sin[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp]) + 
     conj[ZA[gt1, 1]]*conj[ZH[gt2, 1]]*(2*gp*QHd*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp]))/2, 
   Mom[Ah[{gt1}], lt3] - Mom[hh[{gt2}], lt3]}}, 
 {{Ah[{gt1}], Hpm[{gt2}], conj[VWm[{lt3}]]}, 
  {(g2*(conj[ZA[gt1, 1]]*ZP[gt2, 1] + conj[ZA[gt1, 2]]*ZP[gt2, 2]))/2, 
   Mom[Ah[{gt1}], lt3] - Mom[Hpm[{gt2}], lt3]}}, 
 {{Ah[{gt1}], conj[Hpm[{gt2}]], VWm[{lt3}]}, 
  {(g2*(conj[ZA[gt1, 1]]*ZP[gt2, 1] + conj[ZA[gt1, 2]]*ZP[gt2, 2]))/2, 
   Mom[Ah[{gt1}], lt3] - Mom[conj[Hpm[{gt2}]], lt3]}}, 
 {{hh[{gt1}], Hpm[{gt2}], conj[VWm[{lt3}]]}, 
  {(I/2)*g2*(conj[ZH[gt1, 1]]*ZP[gt2, 1] - conj[ZH[gt1, 2]]*ZP[gt2, 2]), 
   Mom[hh[{gt1}], lt3] - Mom[Hpm[{gt2}], lt3]}}, 
 {{hh[{gt1}], conj[Hpm[{gt2}]], VWm[{lt3}]}, 
  {(-I/2)*g2*(conj[ZH[gt1, 1]]*ZP[gt2, 1] - conj[ZH[gt1, 2]]*ZP[gt2, 2]), 
   -Mom[conj[Hpm[{gt2}]], lt3] + Mom[hh[{gt1}], lt3]}}, 
 {{Hpm[{gt1}], conj[Hpm[{gt2}]], VP[{lt3}]}, 
  {(I/2)*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*(ZP[gt1, 1]*ZP[gt2, 1] + 
     ZP[gt1, 2]*ZP[gt2, 2]), -Mom[conj[Hpm[{gt2}]], lt3] + 
    Mom[Hpm[{gt1}], lt3]}}, {{Hpm[{gt1}], conj[Hpm[{gt2}]], VZ[{lt3}]}, 
  {(I/2)*((g2*Cos[ThetaW]*Cos[ThetaWp] - g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHd*Sin[ThetaWp])*ZP[gt1, 1]*ZP[gt2, 1] + 
     (g2*Cos[ThetaW]*Cos[ThetaWp] - g1*Cos[ThetaWp]*Sin[ThetaW] + 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt1, 2]*ZP[gt2, 2]), 
   -Mom[conj[Hpm[{gt2}]], lt3] + Mom[Hpm[{gt1}], lt3]}}, 
 {{Hpm[{gt1}], conj[Hpm[{gt2}]], VZp[{lt3}]}, 
  {(-I/2)*((2*gp*QHd*Cos[ThetaWp] + (g2*Cos[ThetaW] - g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt1, 1]*ZP[gt2, 1] + 
     (-2*gp*QHu*Cos[ThetaWp] + (g2*Cos[ThetaW] - g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt1, 2]*ZP[gt2, 2]), -Mom[conj[Hpm[{gt2}]], lt3] + 
    Mom[Hpm[{gt1}], lt3]}}, {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], 
   VG[{ct3, lt3}]}, {(-I/2)*g3*Delta[gt1, gt2]*Lam[ct3, ct2, ct1], 
   -Mom[conj[Sd[{gt2, ct2}]], lt3] + Mom[Sd[{gt1, ct1}], lt3]}}, 
 {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VP[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*((g1*Cos[ThetaW] - 3*g2*Sin[ThetaW])*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] - 
     2*g1*Cos[ThetaW]*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), 
   -Mom[conj[Sd[{gt2, ct2}]], lt3] + Mom[Sd[{gt1, ct1}], lt3]}}, 
 {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VZ[{lt3}]}, 
  {(I/6)*Delta[ct1, ct2]*((3*g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 6*gp*Qq*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] - 
     2*(g1*Cos[ThetaWp]*Sin[ThetaW] - 3*gp*Qd*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), 
   -Mom[conj[Sd[{gt2, ct2}]], lt3] + Mom[Sd[{gt1, ct1}], lt3]}}, 
 {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VZp[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*
    ((6*gp*Qq*Cos[ThetaWp] + (3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] - 
     2*(3*gp*Qd*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), 
   -Mom[conj[Sd[{gt2, ct2}]], lt3] + Mom[Sd[{gt1, ct1}], lt3]}}, 
 {{Sd[{gt1, ct1}], conj[Su[{gt2, ct2}]], conj[VWm[{lt3}]]}, 
  {((-I)*g2*Delta[ct1, ct2]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZU[gt2, j1]])/
    Sqrt[2], -Mom[conj[Su[{gt2, ct2}]], lt3] + Mom[Sd[{gt1, ct1}], lt3]}}, 
 {{Se[{gt1}], conj[Se[{gt2}]], VP[{lt3}]}, 
  {(I/2)*(conj[ZE[gt1, 1]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*ZE[gt2, 1] + 
     conj[ZE[gt1, 2]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*ZE[gt2, 2] + 
     g1*conj[ZE[gt1, 3]]*Cos[ThetaW]*ZE[gt2, 3] + g2*conj[ZE[gt1, 3]]*
      Sin[ThetaW]*ZE[gt2, 3] + 2*g1*conj[ZE[gt1, 4]]*Cos[ThetaW]*ZE[gt2, 4] + 
     2*g1*conj[ZE[gt1, 5]]*Cos[ThetaW]*ZE[gt2, 5] + 
     2*g1*conj[ZE[gt1, 6]]*Cos[ThetaW]*ZE[gt2, 6]), 
   -Mom[conj[Se[{gt2}]], lt3] + Mom[Se[{gt1}], lt3]}}, 
 {{Se[{gt1}], conj[Se[{gt2}]], VZ[{lt3}]}, 
  {(I/2)*(conj[ZE[gt1, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*Ql1*Sin[ThetaWp])*ZE[gt2, 1] + 
     conj[ZE[gt1, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*Ql2*Sin[ThetaWp])*ZE[gt2, 2] + 
     g2*conj[ZE[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*ZE[gt2, 3] - 
     g1*conj[ZE[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaW]*ZE[gt2, 3] - 
     2*gp*Ql3*conj[ZE[gt1, 3]]*Sin[ThetaWp]*ZE[gt2, 3] - 
     2*g1*conj[ZE[gt1, 4]]*Cos[ThetaWp]*Sin[ThetaW]*ZE[gt2, 4] + 
     2*gp*Qe1*conj[ZE[gt1, 4]]*Sin[ThetaWp]*ZE[gt2, 4] - 
     2*g1*conj[ZE[gt1, 5]]*Cos[ThetaWp]*Sin[ThetaW]*ZE[gt2, 5] + 
     2*gp*Qe2*conj[ZE[gt1, 5]]*Sin[ThetaWp]*ZE[gt2, 5] - 
     2*g1*conj[ZE[gt1, 6]]*Cos[ThetaWp]*Sin[ThetaW]*ZE[gt2, 6] + 
     2*gp*Qe3*conj[ZE[gt1, 6]]*Sin[ThetaWp]*ZE[gt2, 6]), 
   -Mom[conj[Se[{gt2}]], lt3] + Mom[Se[{gt1}], lt3]}}, 
 {{Se[{gt1}], conj[Se[{gt2}]], VZp[{lt3}]}, 
  {(-I/2)*(conj[ZE[gt1, 1]]*(2*gp*Ql1*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*ZE[gt2, 1] + 
     conj[ZE[gt1, 2]]*(2*gp*Ql2*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] - 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZE[gt2, 2] + 2*gp*Ql3*conj[ZE[gt1, 3]]*
      Cos[ThetaWp]*ZE[gt2, 3] + g2*conj[ZE[gt1, 3]]*Cos[ThetaW]*Sin[ThetaWp]*
      ZE[gt2, 3] - g1*conj[ZE[gt1, 3]]*Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 3] - 
     2*gp*Qe1*conj[ZE[gt1, 4]]*Cos[ThetaWp]*ZE[gt2, 4] - 
     2*g1*conj[ZE[gt1, 4]]*Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 4] - 
     2*gp*Qe2*conj[ZE[gt1, 5]]*Cos[ThetaWp]*ZE[gt2, 5] - 
     2*g1*conj[ZE[gt1, 5]]*Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 5] - 
     2*gp*Qe3*conj[ZE[gt1, 6]]*Cos[ThetaWp]*ZE[gt2, 6] - 
     2*g1*conj[ZE[gt1, 6]]*Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 6]), 
   -Mom[conj[Se[{gt2}]], lt3] + Mom[Se[{gt1}], lt3]}}, 
 {{Se[{gt1}], conj[Sv[{gt2}]], conj[VWm[{lt3}]]}, 
  {((-I)*g2*(conj[ZE[gt1, 1]]*ZV[gt2, 1] + conj[ZE[gt1, 2]]*ZV[gt2, 2] + 
      conj[ZE[gt1, 3]]*ZV[gt2, 3]))/Sqrt[2], -Mom[conj[Sv[{gt2}]], lt3] + 
    Mom[Se[{gt1}], lt3]}}, {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], 
   VG[{ct3, lt3}]}, {(-I/2)*g3*Delta[gt1, gt2]*Lam[ct3, ct2, ct1], 
   -Mom[conj[Su[{gt2, ct2}]], lt3] + Mom[Su[{gt1, ct1}], lt3]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VP[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*((g1*Cos[ThetaW] + 3*g2*Sin[ThetaW])*
      sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] + 
     4*g1*Cos[ThetaW]*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), 
   -Mom[conj[Su[{gt2, ct2}]], lt3] + Mom[Su[{gt1, ct1}], lt3]}}, 
 {{Su[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VWm[{lt3}]}, 
  {((-I)*g2*Delta[ct1, ct2]*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZD[gt2, j1]])/
    Sqrt[2], -Mom[conj[Sd[{gt2, ct2}]], lt3] + Mom[Su[{gt1, ct1}], lt3]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VZ[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*((3*g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 6*gp*Qq*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] - 
     2*(2*g1*Cos[ThetaWp]*Sin[ThetaW] + 3*gp*Qu*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), 
   -Mom[conj[Su[{gt2, ct2}]], lt3] + Mom[Su[{gt1, ct1}], lt3]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VZp[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*
    ((6*gp*Qq*Cos[ThetaWp] + (-3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] + 
     2*(-3*gp*Qu*Cos[ThetaWp] + 2*g1*Sin[ThetaW]*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), 
   -Mom[conj[Su[{gt2, ct2}]], lt3] + Mom[Su[{gt1, ct1}], lt3]}}, 
 {{Sv[{gt1}], conj[Se[{gt2}]], VWm[{lt3}]}, 
  {((-I)*g2*(conj[ZV[gt1, 1]]*ZE[gt2, 1] + conj[ZV[gt1, 2]]*ZE[gt2, 2] + 
      conj[ZV[gt1, 3]]*ZE[gt2, 3]))/Sqrt[2], -Mom[conj[Se[{gt2}]], lt3] + 
    Mom[Sv[{gt1}], lt3]}}, {{Sv[{gt1}], conj[Sv[{gt2}]], VZ[{lt3}]}, 
  {(-I/2)*(conj[ZV[gt1, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql1*Sin[ThetaWp])*ZV[gt2, 1] + 
     conj[ZV[gt1, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql2*Sin[ThetaWp])*ZV[gt2, 2] + 
     g2*conj[ZV[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*ZV[gt2, 3] + 
     g1*conj[ZV[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaW]*ZV[gt2, 3] + 
     2*gp*Ql3*conj[ZV[gt1, 3]]*Sin[ThetaWp]*ZV[gt2, 3] - 
     2*gp*Qv1*conj[ZV[gt1, 4]]*Sin[ThetaWp]*ZV[gt2, 4] - 
     2*gp*Qv2*conj[ZV[gt1, 5]]*Sin[ThetaWp]*ZV[gt2, 5] - 
     2*gp*Qv3*conj[ZV[gt1, 6]]*Sin[ThetaWp]*ZV[gt2, 6]), 
   -Mom[conj[Sv[{gt2}]], lt3] + Mom[Sv[{gt1}], lt3]}}, 
 {{Sv[{gt1}], conj[Sv[{gt2}]], VZp[{lt3}]}, 
  {(-I/2)*(conj[ZV[gt1, 1]]*(2*gp*Ql1*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZV[gt2, 1] + 
     conj[ZV[gt1, 2]]*(2*gp*Ql2*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZV[gt2, 2] + 
     2*gp*Ql3*conj[ZV[gt1, 3]]*Cos[ThetaWp]*ZV[gt2, 3] - 
     g2*conj[ZV[gt1, 3]]*Cos[ThetaW]*Sin[ThetaWp]*ZV[gt2, 3] - 
     g1*conj[ZV[gt1, 3]]*Sin[ThetaW]*Sin[ThetaWp]*ZV[gt2, 3] - 
     2*gp*Qv1*conj[ZV[gt1, 4]]*Cos[ThetaWp]*ZV[gt2, 4] - 
     2*gp*Qv2*conj[ZV[gt1, 5]]*Cos[ThetaWp]*ZV[gt2, 5] - 
     2*gp*Qv3*conj[ZV[gt1, 6]]*Cos[ThetaWp]*ZV[gt2, 6]), 
   -Mom[conj[Sv[{gt2}]], lt3] + Mom[Sv[{gt1}], lt3]}}, 
 {{hh[{gt1}], conj[VWm[{lt2}]], VWm[{lt3}]}, 
  {(I/2)*g2^2*(vd*conj[ZH[gt1, 1]] + vu*conj[ZH[gt1, 2]]), g[lt2, lt3]}}, 
 {{hh[{gt1}], VZ[{lt2}], VZ[{lt3}]}, 
  {(I/2)*(4*gp^2*Qs^2*vS*conj[ZH[gt1, 3]]*Sin[ThetaWp]^2 + 
     vd*conj[ZH[gt1, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])^2 + 
     vu*conj[ZH[gt1, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])^2), 
   g[lt2, lt3]}}, {{hh[{gt1}], VZ[{lt2}], VZp[{lt3}]}, 
  {(-I/2)*(-4*gp^2*Qs^2*vS*conj[ZH[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaWp] + 
     vd*conj[ZH[gt1, 1]]*(-2*g1*gp*QHd*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHd^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*QHd*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (-(gp*QHd*Cos[ThetaWp]^2) + g1*Cos[ThetaWp]*Sin[ThetaW]*
          Sin[ThetaWp] + gp*QHd*Sin[ThetaWp]^2)) + 
     vu*conj[ZH[gt1, 2]]*(2*g1*gp*QHu*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHu^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 
       2*g1*gp*QHu*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*QHu*Cos[ThetaWp]^2 + g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*QHu*Sin[ThetaWp]^2))), g[lt2, lt3]}}, 
 {{hh[{gt1}], VZp[{lt2}], VZp[{lt3}]}, 
  {(I/2)*(4*gp^2*Qs^2*vS*conj[ZH[gt1, 3]]*Cos[ThetaWp]^2 + 
     vd*conj[ZH[gt1, 1]]*(-2*gp*QHd*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2 + 
     vu*conj[ZH[gt1, 2]]*(2*gp*QHu*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2), g[lt2, lt3]}}, 
 {{Hpm[{gt1}], conj[VWm[{lt2}]], VP[{lt3}]}, 
  {(-I/2)*g1*g2*Cos[ThetaW]*(vd*ZP[gt1, 1] - vu*ZP[gt1, 2]), g[lt2, lt3]}}, 
 {{Hpm[{gt1}], conj[VWm[{lt2}]], VZ[{lt3}]}, 
  {(I/2)*g2*(vd*(g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*
      ZP[gt1, 1] + vu*(-(g1*Cos[ThetaWp]*Sin[ThetaW]) + 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt1, 2]), g[lt2, lt3]}}, 
 {{Hpm[{gt1}], conj[VWm[{lt2}]], VZp[{lt3}]}, 
  {(I/2)*g2*(vd*(2*gp*QHd*Cos[ThetaWp] - g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZP[gt1, 1] + vu*(2*gp*QHu*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZP[gt1, 2]), g[lt2, lt3]}}, {{conj[Hpm[{gt1}]], VP[{lt2}], VWm[{lt3}]}, 
  {(-I/2)*g1*g2*Cos[ThetaW]*(vd*ZP[gt1, 1] - vu*ZP[gt1, 2]), g[lt2, lt3]}}, 
 {{conj[Hpm[{gt1}]], VWm[{lt2}], VZ[{lt3}]}, 
  {(I/2)*g2*(vd*(g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*
      ZP[gt1, 1] + vu*(-(g1*Cos[ThetaWp]*Sin[ThetaW]) + 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt1, 2]), g[lt2, lt3]}}, 
 {{conj[Hpm[{gt1}]], VWm[{lt2}], VZp[{lt3}]}, 
  {(I/2)*g2*(vd*(2*gp*QHd*Cos[ThetaWp] - g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZP[gt1, 1] + vu*(2*gp*QHu*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZP[gt1, 2]), g[lt2, lt3]}}, 
 {{VG[{ct1, lt1}], VG[{ct2, lt2}], VG[{ct3, lt3}]}, 
  {g3*fSU3[ct1, ct2, ct3], g[lt1, lt2]*(-Mom[VG[{ct1, lt1}], lt3] + 
      Mom[VG[{ct2, lt2}], lt3]) + g[lt2, lt3]*(-Mom[VG[{ct2, lt2}], lt1] + 
      Mom[VG[{ct3, lt3}], lt1]) + g[lt1, lt3]*(Mom[VG[{ct1, lt1}], lt2] - 
      Mom[VG[{ct3, lt3}], lt2])}}, 
 {{conj[VWm[{lt1}]], VP[{lt2}], VWm[{lt3}]}, 
  {I*g2*Sin[ThetaW], g[lt1, lt2]*(-Mom[conj[VWm[{lt1}]], lt3] + 
      Mom[VP[{lt2}], lt3]) + g[lt2, lt3]*(-Mom[VP[{lt2}], lt1] + 
      Mom[VWm[{lt3}], lt1]) + g[lt1, lt3]*(Mom[conj[VWm[{lt1}]], lt2] - 
      Mom[VWm[{lt3}], lt2])}}, {{conj[VWm[{lt1}]], VWm[{lt2}], VZ[{lt3}]}, 
  {(-I)*g2*Cos[ThetaW]*Cos[ThetaWp], 
   g[lt1, lt2]*(-Mom[conj[VWm[{lt1}]], lt3] + Mom[VWm[{lt2}], lt3]) + 
    g[lt2, lt3]*(-Mom[VWm[{lt2}], lt1] + Mom[VZ[{lt3}], lt1]) + 
    g[lt1, lt3]*(Mom[conj[VWm[{lt1}]], lt2] - Mom[VZ[{lt3}], lt2])}}, 
 {{conj[VWm[{lt1}]], VWm[{lt2}], VZp[{lt3}]}, {I*g2*Cos[ThetaW]*Sin[ThetaWp], 
   g[lt1, lt2]*(-Mom[conj[VWm[{lt1}]], lt3] + Mom[VWm[{lt2}], lt3]) + 
    g[lt2, lt3]*(-Mom[VWm[{lt2}], lt1] + Mom[VZp[{lt3}], lt1]) + 
    g[lt1, lt3]*(Mom[conj[VWm[{lt1}]], lt2] - Mom[VZp[{lt3}], lt2])}}, 
 {{bar[Cha[{gt1}]], Cha[{gt2}], Ah[{gt3}]}, 
  {(-(g2*conj[UM[gt2, 1]]*conj[UP[gt1, 2]]*conj[ZA[gt3, 2]]) + 
     conj[UM[gt2, 2]]*(-(g2*conj[UP[gt1, 1]]*conj[ZA[gt3, 1]]) + 
       \[Lambda]*conj[UP[gt1, 2]]*conj[ZA[gt3, 3]]))/Sqrt[2], PL}, 
  {(g2*conj[ZA[gt3, 1]]*UM[gt1, 2]*UP[gt2, 1] + 
     (g2*conj[ZA[gt3, 2]]*UM[gt1, 1] - conj[\[Lambda]]*conj[ZA[gt3, 3]]*
        UM[gt1, 2])*UP[gt2, 2])/Sqrt[2], PR}}, 
 {{Chi[{gt1}], Chi[{gt2}], Ah[{gt3}]}, 
  {(-(conj[ZA[gt3, 3]]*(2*gp*Qs*conj[ZN[gt1, 6]]*conj[ZN[gt2, 1]] + 
        Sqrt[2]*\[Lambda]*conj[ZN[gt1, 5]]*conj[ZN[gt2, 4]] + 
        Sqrt[2]*\[Lambda]*conj[ZN[gt1, 4]]*conj[ZN[gt2, 5]] + 
        2*gp*Qs*conj[ZN[gt1, 1]]*conj[ZN[gt2, 6]])) - 
     conj[ZA[gt3, 2]]*(conj[ZN[gt1, 5]]*(2*gp*QHu*conj[ZN[gt2, 1]] + 
         g1*conj[ZN[gt2, 2]] - g2*conj[ZN[gt2, 3]]) + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 6]]*conj[ZN[gt2, 4]] + 
       2*gp*QHu*conj[ZN[gt1, 1]]*conj[ZN[gt2, 5]] + g1*conj[ZN[gt1, 2]]*
        conj[ZN[gt2, 5]] - g2*conj[ZN[gt1, 3]]*conj[ZN[gt2, 5]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 4]]*conj[ZN[gt2, 6]]) - 
     conj[ZA[gt3, 1]]*(conj[ZN[gt1, 4]]*(2*gp*QHd*conj[ZN[gt2, 1]] - 
         g1*conj[ZN[gt2, 2]] + g2*conj[ZN[gt2, 3]]) + 
       2*gp*QHd*conj[ZN[gt1, 1]]*conj[ZN[gt2, 4]] - g1*conj[ZN[gt1, 2]]*
        conj[ZN[gt2, 4]] + g2*conj[ZN[gt1, 3]]*conj[ZN[gt2, 4]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 6]]*conj[ZN[gt2, 5]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 5]]*conj[ZN[gt2, 6]]))/2, PL}, 
  {(conj[ZA[gt3, 3]]*(2*gp*Qs*ZN[gt1, 6]*ZN[gt2, 1] + Sqrt[2]*conj[\[Lambda]]*
        (ZN[gt1, 5]*ZN[gt2, 4] + ZN[gt1, 4]*ZN[gt2, 5]) + 
       2*gp*Qs*ZN[gt1, 1]*ZN[gt2, 6]) + conj[ZA[gt3, 1]]*
      (ZN[gt1, 4]*(2*gp*QHd*ZN[gt2, 1] - g1*ZN[gt2, 2] + g2*ZN[gt2, 3]) + 
       2*gp*QHd*ZN[gt1, 1]*ZN[gt2, 4] - g1*ZN[gt1, 2]*ZN[gt2, 4] + 
       g2*ZN[gt1, 3]*ZN[gt2, 4] + Sqrt[2]*conj[\[Lambda]]*ZN[gt1, 6]*
        ZN[gt2, 5] + Sqrt[2]*conj[\[Lambda]]*ZN[gt1, 5]*ZN[gt2, 6]) + 
     conj[ZA[gt3, 2]]*(ZN[gt1, 5]*(2*gp*QHu*ZN[gt2, 1] + g1*ZN[gt2, 2] - 
         g2*ZN[gt2, 3]) + (2*gp*QHu*ZN[gt1, 1] + g1*ZN[gt1, 2] - 
         g2*ZN[gt1, 3])*ZN[gt2, 5] + Sqrt[2]*conj[\[Lambda]]*
        (ZN[gt1, 6]*ZN[gt2, 4] + ZN[gt1, 4]*ZN[gt2, 6])))/2, PR}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], Ah[{gt3}]}, 
  {(conj[ZA[gt3, 1]]*Delta[ct1, ct2]*sum[j2, 1, 3, conj[ZDL[gt2, j2]]*
       sum[j1, 1, 3, conj[ZDR[gt1, j1]]*Yd[j1, j2]]])/Sqrt[2], PL}, 
  {-((conj[ZA[gt3, 1]]*Delta[ct1, ct2]*sum[j2, 1, 3, 
       sum[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*ZDL[gt1, j2]])/Sqrt[2]), 
   PR}}, {{bar[Fe[{gt1}]], Fe[{gt2}], Ah[{gt3}]}, 
  {(conj[ZA[gt3, 1]]*(Ye11*conj[ZEL[gt2, 1]]*conj[ZER[gt1, 1]] + 
      Ye22*conj[ZEL[gt2, 2]]*conj[ZER[gt1, 2]] + Ye33*conj[ZEL[gt2, 3]]*
       conj[ZER[gt1, 3]]))/Sqrt[2], PL}, 
  {-((conj[ZA[gt3, 1]]*(conj[Ye11]*ZEL[gt1, 1]*ZER[gt2, 1] + 
       conj[Ye22]*ZEL[gt1, 2]*ZER[gt2, 2] + conj[Ye33]*ZEL[gt1, 3]*
        ZER[gt2, 3]))/Sqrt[2]), PR}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], Ah[{gt3}]}, 
  {(conj[ZA[gt3, 2]]*Delta[ct1, ct2]*sum[j2, 1, 3, conj[ZUL[gt2, j2]]*
       sum[j1, 1, 3, conj[ZUR[gt1, j1]]*Yu[j1, j2]]])/Sqrt[2], PL}, 
  {-((conj[ZA[gt3, 2]]*Delta[ct1, ct2]*sum[j2, 1, 3, 
       sum[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*ZUL[gt1, j2]])/Sqrt[2]), 
   PR}}, {{bar[Fv[{gt1}]], Fv[{gt2}], Ah[{gt3}]}, 
  {(conj[ZA[gt3, 2]]*(Yv11*conj[ZVL[gt2, 1]]*conj[ZVR[gt1, 1]] + 
      Yv22*conj[ZVL[gt2, 2]]*conj[ZVR[gt1, 2]] + Yv33*conj[ZVL[gt2, 3]]*
       conj[ZVR[gt1, 3]]))/Sqrt[2], PL}, 
  {-((conj[ZA[gt3, 2]]*(conj[Yv11]*ZVL[gt1, 1]*ZVR[gt2, 1] + 
       conj[Yv22]*ZVL[gt1, 2]*ZVR[gt2, 2] + conj[Yv33]*ZVL[gt1, 3]*
        ZVR[gt2, 3]))/Sqrt[2]), PR}}, 
 {{Chi[{gt1}], Cha[{gt2}], conj[Hpm[{gt3}]]}, 
  {(-I/2)*(2*g2*conj[UM[gt2, 1]]*conj[ZN[gt1, 4]]*ZP[gt3, 1] + 
     conj[UM[gt2, 2]]*(2*Sqrt[2]*gp*QHd*conj[ZN[gt1, 1]]*ZP[gt3, 1] - 
       Sqrt[2]*g1*conj[ZN[gt1, 2]]*ZP[gt3, 1] - Sqrt[2]*g2*conj[ZN[gt1, 3]]*
        ZP[gt3, 1] + 2*\[Lambda]*conj[ZN[gt1, 6]]*ZP[gt3, 2])), PL}, 
  {(-I/2)*(2*conj[\[Lambda]]*UP[gt2, 2]*ZN[gt1, 6]*ZP[gt3, 1] + 
     (Sqrt[2]*UP[gt2, 2]*(2*gp*QHu*ZN[gt1, 1] + g1*ZN[gt1, 2] + 
         g2*ZN[gt1, 3]) + 2*g2*UP[gt2, 1]*ZN[gt1, 5])*ZP[gt3, 2]), PR}}, 
 {{Cha[{gt1}], Fu[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {(-I)*Delta[ct2, ct3]*(g2*conj[UM[gt1, 1]]*sum[j1, 1, 3, 
       conj[ZUL[gt2, j1]]*ZD[gt3, j1]] - conj[UM[gt1, 2]]*
      sum[j2, 1, 3, conj[ZUL[gt2, j2]]*sum[j1, 1, 3, 
         Yd[j1, j2]*ZD[gt3, 3 + j1]]]), PL}, 
  {I*Delta[ct2, ct3]*sum[j2, 1, 3, 
     sum[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*ZD[gt3, j2]]*UP[gt1, 2], 
   PR}}, {{Cha[{gt1}], Fv[{gt2}], conj[Se[{gt3}]]}, 
  {(-I)*(g2*conj[UM[gt1, 1]]*(conj[ZVL[gt2, 1]]*ZE[gt3, 1] + 
       conj[ZVL[gt2, 2]]*ZE[gt3, 2] + conj[ZVL[gt2, 3]]*ZE[gt3, 3]) - 
     conj[UM[gt1, 2]]*(Ye11*conj[ZVL[gt2, 1]]*ZE[gt3, 4] + 
       Ye22*conj[ZVL[gt2, 2]]*ZE[gt3, 5] + Ye33*conj[ZVL[gt2, 3]]*
        ZE[gt3, 6])), PL}, {I*UP[gt1, 2]*(conj[Yv11]*ZE[gt3, 1]*ZVR[gt2, 1] + 
     conj[Yv22]*ZE[gt3, 2]*ZVR[gt2, 2] + conj[Yv33]*ZE[gt3, 3]*ZVR[gt2, 3]), 
   PR}}, {{bar[Cha[{gt1}]], Cha[{gt2}], hh[{gt3}]}, 
  {((-I)*(g2*conj[UM[gt2, 1]]*conj[UP[gt1, 2]]*conj[ZH[gt3, 2]] + 
      conj[UM[gt2, 2]]*(g2*conj[UP[gt1, 1]]*conj[ZH[gt3, 1]] + 
        \[Lambda]*conj[UP[gt1, 2]]*conj[ZH[gt3, 3]])))/Sqrt[2], PL}, 
  {((-I)*(g2*conj[ZH[gt3, 1]]*UM[gt1, 2]*UP[gt2, 1] + 
      (g2*conj[ZH[gt3, 2]]*UM[gt1, 1] + conj[\[Lambda]]*conj[ZH[gt3, 3]]*
         UM[gt1, 2])*UP[gt2, 2]))/Sqrt[2], PR}}, 
 {{bar[Fd[{gt1, ct1}]], Cha[{gt2}], Su[{gt3, ct3}]}, 
  {I*conj[UM[gt2, 2]]*Delta[ct1, ct3]*sum[j2, 1, 3, 
     conj[ZU[gt3, j2]]*sum[j1, 1, 3, conj[ZDR[gt1, j1]]*Yd[j1, j2]]], PL}, 
  {(-I)*Delta[ct1, ct3]*(g2*sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZDL[gt1, j1]]*
      UP[gt2, 1] - sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
          conj[ZU[gt3, 3 + j1]]]*ZDL[gt1, j2]]*UP[gt2, 2]), PR}}, 
 {{bar[Fe[{gt1}]], Cha[{gt2}], Sv[{gt3}]}, 
  {I*conj[UM[gt2, 2]]*(Ye11*conj[ZER[gt1, 1]]*conj[ZV[gt3, 1]] + 
     Ye22*conj[ZER[gt1, 2]]*conj[ZV[gt3, 2]] + Ye33*conj[ZER[gt1, 3]]*
      conj[ZV[gt3, 3]]), PL}, 
  {(-I)*(g2*conj[ZV[gt3, 1]]*UP[gt2, 1]*ZEL[gt1, 1] - 
     conj[Yv11]*conj[ZV[gt3, 4]]*UP[gt2, 2]*ZEL[gt1, 1] + 
     g2*conj[ZV[gt3, 2]]*UP[gt2, 1]*ZEL[gt1, 2] - conj[Yv22]*conj[ZV[gt3, 5]]*
      UP[gt2, 2]*ZEL[gt1, 2] + g2*conj[ZV[gt3, 3]]*UP[gt2, 1]*ZEL[gt1, 3] - 
     conj[Yv33]*conj[ZV[gt3, 6]]*UP[gt2, 2]*ZEL[gt1, 3]), PR}}, 
 {{Chi[{gt1}], Chi[{gt2}], hh[{gt3}]}, 
  {(-I/2)*(conj[ZH[gt3, 3]]*(2*gp*Qs*conj[ZN[gt1, 6]]*conj[ZN[gt2, 1]] - 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 5]]*conj[ZN[gt2, 4]] - 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 4]]*conj[ZN[gt2, 5]] + 
       2*gp*Qs*conj[ZN[gt1, 1]]*conj[ZN[gt2, 6]]) + 
     conj[ZH[gt3, 2]]*(conj[ZN[gt1, 5]]*(2*gp*QHu*conj[ZN[gt2, 1]] + 
         g1*conj[ZN[gt2, 2]] - g2*conj[ZN[gt2, 3]]) - 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 6]]*conj[ZN[gt2, 4]] + 
       2*gp*QHu*conj[ZN[gt1, 1]]*conj[ZN[gt2, 5]] + g1*conj[ZN[gt1, 2]]*
        conj[ZN[gt2, 5]] - g2*conj[ZN[gt1, 3]]*conj[ZN[gt2, 5]] - 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 4]]*conj[ZN[gt2, 6]]) + 
     conj[ZH[gt3, 1]]*(conj[ZN[gt1, 4]]*(2*gp*QHd*conj[ZN[gt2, 1]] - 
         g1*conj[ZN[gt2, 2]] + g2*conj[ZN[gt2, 3]]) + 
       2*gp*QHd*conj[ZN[gt1, 1]]*conj[ZN[gt2, 4]] - g1*conj[ZN[gt1, 2]]*
        conj[ZN[gt2, 4]] + g2*conj[ZN[gt1, 3]]*conj[ZN[gt2, 4]] - 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 6]]*conj[ZN[gt2, 5]] - 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 5]]*conj[ZN[gt2, 6]])), PL}, 
  {(-I/2)*(conj[ZH[gt3, 3]]*(2*gp*Qs*ZN[gt1, 6]*ZN[gt2, 1] - 
       Sqrt[2]*conj[\[Lambda]]*(ZN[gt1, 5]*ZN[gt2, 4] + 
         ZN[gt1, 4]*ZN[gt2, 5]) + 2*gp*Qs*ZN[gt1, 1]*ZN[gt2, 6]) + 
     conj[ZH[gt3, 1]]*(ZN[gt1, 4]*(2*gp*QHd*ZN[gt2, 1] - g1*ZN[gt2, 2] + 
         g2*ZN[gt2, 3]) + 2*gp*QHd*ZN[gt1, 1]*ZN[gt2, 4] - 
       g1*ZN[gt1, 2]*ZN[gt2, 4] + g2*ZN[gt1, 3]*ZN[gt2, 4] - 
       Sqrt[2]*conj[\[Lambda]]*ZN[gt1, 6]*ZN[gt2, 5] - 
       Sqrt[2]*conj[\[Lambda]]*ZN[gt1, 5]*ZN[gt2, 6]) + 
     conj[ZH[gt3, 2]]*(ZN[gt1, 5]*(2*gp*QHu*ZN[gt2, 1] + g1*ZN[gt2, 2] - 
         g2*ZN[gt2, 3]) + (2*gp*QHu*ZN[gt1, 1] + g1*ZN[gt1, 2] - 
         g2*ZN[gt1, 3])*ZN[gt2, 5] - Sqrt[2]*conj[\[Lambda]]*
        (ZN[gt1, 6]*ZN[gt2, 4] + ZN[gt1, 4]*ZN[gt2, 6]))), PR}}, 
 {{Chi[{gt1}], Fd[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {(-I/6)*Delta[ct2, ct3]*(6*Sqrt[2]*gp*Qq*conj[ZN[gt1, 1]]*
      sum[j1, 1, 3, conj[ZDL[gt2, j1]]*ZD[gt3, j1]] + 
     Sqrt[2]*g1*conj[ZN[gt1, 2]]*sum[j1, 1, 3, conj[ZDL[gt2, j1]]*
        ZD[gt3, j1]] - 3*Sqrt[2]*g2*conj[ZN[gt1, 3]]*
      sum[j1, 1, 3, conj[ZDL[gt2, j1]]*ZD[gt3, j1]] + 
     6*conj[ZN[gt1, 4]]*sum[j2, 1, 3, conj[ZDL[gt2, j2]]*
        sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]]), PL}, 
  {(-I/3)*Delta[ct2, ct3]*
    (Sqrt[2]*sum[j1, 1, 3, ZD[gt3, 3 + j1]*ZDR[gt2, j1]]*
      (3*gp*Qd*ZN[gt1, 1] + g1*ZN[gt1, 2]) + 
     3*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*
        ZD[gt3, j2]]*ZN[gt1, 4]), PR}}, 
 {{Chi[{gt1}], Fe[{gt2}], conj[Se[{gt3}]]}, 
  {(-I/2)*(conj[ZEL[gt2, 1]]*(2*Sqrt[2]*gp*Ql1*conj[ZN[gt1, 1]]*ZE[gt3, 1] - 
       Sqrt[2]*g1*conj[ZN[gt1, 2]]*ZE[gt3, 1] - Sqrt[2]*g2*conj[ZN[gt1, 3]]*
        ZE[gt3, 1] + 2*Ye11*conj[ZN[gt1, 4]]*ZE[gt3, 4]) + 
     conj[ZEL[gt2, 2]]*(2*Sqrt[2]*gp*Ql2*conj[ZN[gt1, 1]]*ZE[gt3, 2] - 
       Sqrt[2]*g1*conj[ZN[gt1, 2]]*ZE[gt3, 2] - Sqrt[2]*g2*conj[ZN[gt1, 3]]*
        ZE[gt3, 2] + 2*Ye22*conj[ZN[gt1, 4]]*ZE[gt3, 5]) + 
     conj[ZEL[gt2, 3]]*(2*Sqrt[2]*gp*Ql3*conj[ZN[gt1, 1]]*ZE[gt3, 3] - 
       Sqrt[2]*g1*conj[ZN[gt1, 2]]*ZE[gt3, 3] - Sqrt[2]*g2*conj[ZN[gt1, 3]]*
        ZE[gt3, 3] + 2*Ye33*conj[ZN[gt1, 4]]*ZE[gt3, 6])), PL}, 
  {(-I)*(Sqrt[2]*gp*Qe3*ZE[gt3, 6]*ZER[gt2, 3]*ZN[gt1, 1] + 
     Sqrt[2]*g1*ZE[gt3, 6]*ZER[gt2, 3]*ZN[gt1, 2] + 
     Sqrt[2]*ZE[gt3, 4]*ZER[gt2, 1]*(gp*Qe1*ZN[gt1, 1] + g1*ZN[gt1, 2]) + 
     Sqrt[2]*ZE[gt3, 5]*ZER[gt2, 2]*(gp*Qe2*ZN[gt1, 1] + g1*ZN[gt1, 2]) + 
     conj[Ye11]*ZE[gt3, 1]*ZER[gt2, 1]*ZN[gt1, 4] + 
     conj[Ye22]*ZE[gt3, 2]*ZER[gt2, 2]*ZN[gt1, 4] + 
     conj[Ye33]*ZE[gt3, 3]*ZER[gt2, 3]*ZN[gt1, 4]), PR}}, 
 {{Chi[{gt1}], Fu[{gt2, ct2}], conj[Su[{gt3, ct3}]]}, 
  {(-I/6)*Delta[ct2, ct3]*(6*Sqrt[2]*gp*Qq*conj[ZN[gt1, 1]]*
      sum[j1, 1, 3, conj[ZUL[gt2, j1]]*ZU[gt3, j1]] + 
     Sqrt[2]*g1*conj[ZN[gt1, 2]]*sum[j1, 1, 3, conj[ZUL[gt2, j1]]*
        ZU[gt3, j1]] + 3*Sqrt[2]*g2*conj[ZN[gt1, 3]]*
      sum[j1, 1, 3, conj[ZUL[gt2, j1]]*ZU[gt3, j1]] + 
     6*conj[ZN[gt1, 5]]*sum[j2, 1, 3, conj[ZUL[gt2, j2]]*
        sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]]), PL}, 
  {(-I/3)*Delta[ct2, ct3]*
    (Sqrt[2]*sum[j1, 1, 3, ZU[gt3, 3 + j1]*ZUR[gt2, j1]]*
      (3*gp*Qu*ZN[gt1, 1] - 2*g1*ZN[gt1, 2]) + 
     3*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*
        ZU[gt3, j2]]*ZN[gt1, 5]), PR}}, 
 {{Chi[{gt1}], Fv[{gt2}], conj[Sv[{gt3}]]}, 
  {(-I/2)*(Sqrt[2]*g2*conj[ZN[gt1, 3]]*conj[ZVL[gt2, 1]]*ZV[gt3, 1] + 
     Sqrt[2]*g2*conj[ZN[gt1, 3]]*conj[ZVL[gt2, 2]]*ZV[gt3, 2] + 
     Sqrt[2]*g2*conj[ZN[gt1, 3]]*conj[ZVL[gt2, 3]]*ZV[gt3, 3] - 
     Sqrt[2]*g1*conj[ZN[gt1, 2]]*(conj[ZVL[gt2, 1]]*ZV[gt3, 1] + 
       conj[ZVL[gt2, 2]]*ZV[gt3, 2] + conj[ZVL[gt2, 3]]*ZV[gt3, 3]) + 
     2*Sqrt[2]*gp*conj[ZN[gt1, 1]]*(Ql1*conj[ZVL[gt2, 1]]*ZV[gt3, 1] + 
       Ql2*conj[ZVL[gt2, 2]]*ZV[gt3, 2] + Ql3*conj[ZVL[gt2, 3]]*ZV[gt3, 3]) + 
     2*Yv11*conj[ZN[gt1, 5]]*conj[ZVL[gt2, 1]]*ZV[gt3, 4] + 
     2*Yv22*conj[ZN[gt1, 5]]*conj[ZVL[gt2, 2]]*ZV[gt3, 5] + 
     2*Yv33*conj[ZN[gt1, 5]]*conj[ZVL[gt2, 3]]*ZV[gt3, 6]), PL}, 
  {(-I)*(conj[Yv11]*ZN[gt1, 5]*ZV[gt3, 1]*ZVR[gt2, 1] + 
     ZN[gt1, 5]*(conj[Yv22]*ZV[gt3, 2]*ZVR[gt2, 2] + conj[Yv33]*ZV[gt3, 3]*
        ZVR[gt2, 3]) + Sqrt[2]*gp*ZN[gt1, 1]*(Qv1*ZV[gt3, 4]*ZVR[gt2, 1] + 
       Qv2*ZV[gt3, 5]*ZVR[gt2, 2] + Qv3*ZV[gt3, 6]*ZVR[gt2, 3])), PR}}, 
 {{bar[Cha[{gt1}]], Chi[{gt2}], Hpm[{gt3}]}, 
  {(-I/2)*(2*g2*conj[UP[gt1, 1]]*conj[ZN[gt2, 5]]*ZP[gt3, 2] + 
     conj[UP[gt1, 2]]*(2*\[Lambda]*conj[ZN[gt2, 6]]*ZP[gt3, 1] + 
       Sqrt[2]*(2*gp*QHu*conj[ZN[gt2, 1]] + g1*conj[ZN[gt2, 2]] + 
         g2*conj[ZN[gt2, 3]])*ZP[gt3, 2])), PL}, 
  {(-I/2)*(2*g2*UM[gt1, 1]*ZN[gt2, 4]*ZP[gt3, 1] + 
     UM[gt1, 2]*(2*Sqrt[2]*gp*QHd*ZN[gt2, 1]*ZP[gt3, 1] - 
       Sqrt[2]*g1*ZN[gt2, 2]*ZP[gt3, 1] - Sqrt[2]*g2*ZN[gt2, 3]*ZP[gt3, 1] + 
       2*conj[\[Lambda]]*ZN[gt2, 6]*ZP[gt3, 2])), PR}}, 
 {{bar[Fd[{gt1, ct1}]], Chi[{gt2}], Sd[{gt3, ct3}]}, 
  {(-I/3)*Delta[ct1, ct3]*(3*Sqrt[2]*gp*Qd*conj[ZN[gt2, 1]]*
      sum[j1, 1, 3, conj[ZD[gt3, 3 + j1]]*conj[ZDR[gt1, j1]]] + 
     Sqrt[2]*g1*conj[ZN[gt2, 2]]*sum[j1, 1, 3, conj[ZD[gt3, 3 + j1]]*
        conj[ZDR[gt1, j1]]] + 3*conj[ZN[gt2, 4]]*
      sum[j2, 1, 3, conj[ZD[gt3, j2]]*sum[j1, 1, 3, conj[ZDR[gt1, j1]]*
          Yd[j1, j2]]]), PL}, 
  {(-I/6)*Delta[ct1, ct3]*
    (Sqrt[2]*sum[j1, 1, 3, conj[ZD[gt3, j1]]*ZDL[gt1, j1]]*
      (6*gp*Qq*ZN[gt2, 1] + g1*ZN[gt2, 2] - 3*g2*ZN[gt2, 3]) + 
     6*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt3, 3 + j1]]]*
        ZDL[gt1, j2]]*ZN[gt2, 4]), PR}}, 
 {{bar[Fe[{gt1}]], Chi[{gt2}], Se[{gt3}]}, 
  {(-I)*(Sqrt[2]*gp*Qe3*conj[ZE[gt3, 6]]*conj[ZER[gt1, 3]]*conj[ZN[gt2, 1]] + 
     Sqrt[2]*g1*conj[ZE[gt3, 6]]*conj[ZER[gt1, 3]]*conj[ZN[gt2, 2]] + 
     Sqrt[2]*conj[ZE[gt3, 4]]*conj[ZER[gt1, 1]]*(gp*Qe1*conj[ZN[gt2, 1]] + 
       g1*conj[ZN[gt2, 2]]) + Sqrt[2]*conj[ZE[gt3, 5]]*conj[ZER[gt1, 2]]*
      (gp*Qe2*conj[ZN[gt2, 1]] + g1*conj[ZN[gt2, 2]]) + 
     Ye11*conj[ZE[gt3, 1]]*conj[ZER[gt1, 1]]*conj[ZN[gt2, 4]] + 
     Ye22*conj[ZE[gt3, 2]]*conj[ZER[gt1, 2]]*conj[ZN[gt2, 4]] + 
     Ye33*conj[ZE[gt3, 3]]*conj[ZER[gt1, 3]]*conj[ZN[gt2, 4]]), PL}, 
  {(-I/2)*(2*Sqrt[2]*gp*Ql3*conj[ZE[gt3, 3]]*ZEL[gt1, 3]*ZN[gt2, 1] - 
     Sqrt[2]*g1*conj[ZE[gt3, 3]]*ZEL[gt1, 3]*ZN[gt2, 2] - 
     Sqrt[2]*g2*conj[ZE[gt3, 3]]*ZEL[gt1, 3]*ZN[gt2, 3] + 
     Sqrt[2]*conj[ZE[gt3, 1]]*ZEL[gt1, 1]*(2*gp*Ql1*ZN[gt2, 1] - 
       g1*ZN[gt2, 2] - g2*ZN[gt2, 3]) + Sqrt[2]*conj[ZE[gt3, 2]]*ZEL[gt1, 2]*
      (2*gp*Ql2*ZN[gt2, 1] - g1*ZN[gt2, 2] - g2*ZN[gt2, 3]) + 
     2*conj[Ye11]*conj[ZE[gt3, 4]]*ZEL[gt1, 1]*ZN[gt2, 4] + 
     2*conj[Ye22]*conj[ZE[gt3, 5]]*ZEL[gt1, 2]*ZN[gt2, 4] + 
     2*conj[Ye33]*conj[ZE[gt3, 6]]*ZEL[gt1, 3]*ZN[gt2, 4]), PR}}, 
 {{bar[Fu[{gt1, ct1}]], Chi[{gt2}], Su[{gt3, ct3}]}, 
  {(-I/3)*Delta[ct1, ct3]*(3*Sqrt[2]*gp*Qu*conj[ZN[gt2, 1]]*
      sum[j1, 1, 3, conj[ZU[gt3, 3 + j1]]*conj[ZUR[gt1, j1]]] - 
     2*Sqrt[2]*g1*conj[ZN[gt2, 2]]*sum[j1, 1, 3, conj[ZU[gt3, 3 + j1]]*
        conj[ZUR[gt1, j1]]] + 3*conj[ZN[gt2, 5]]*
      sum[j2, 1, 3, conj[ZU[gt3, j2]]*sum[j1, 1, 3, conj[ZUR[gt1, j1]]*
          Yu[j1, j2]]]), PL}, 
  {(-I/6)*Delta[ct1, ct3]*
    (Sqrt[2]*sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZUL[gt1, j1]]*
      (6*gp*Qq*ZN[gt2, 1] + g1*ZN[gt2, 2] + 3*g2*ZN[gt2, 3]) + 
     6*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt3, 3 + j1]]]*
        ZUL[gt1, j2]]*ZN[gt2, 5]), PR}}, 
 {{bar[Fv[{gt1}]], Chi[{gt2}], Sv[{gt3}]}, 
  {(-I)*(conj[ZN[gt2, 5]]*(Yv11*conj[ZV[gt3, 1]]*conj[ZVR[gt1, 1]] + 
       Yv22*conj[ZV[gt3, 2]]*conj[ZVR[gt1, 2]] + Yv33*conj[ZV[gt3, 3]]*
        conj[ZVR[gt1, 3]]) + Sqrt[2]*gp*conj[ZN[gt2, 1]]*
      (Qv1*conj[ZV[gt3, 4]]*conj[ZVR[gt1, 1]] + Qv2*conj[ZV[gt3, 5]]*
        conj[ZVR[gt1, 2]] + Qv3*conj[ZV[gt3, 6]]*conj[ZVR[gt1, 3]])), PL}, 
  {(-I/2)*(Sqrt[2]*conj[ZV[gt3, 1]]*(2*gp*Ql1*ZN[gt2, 1] - g1*ZN[gt2, 2] + 
       g2*ZN[gt2, 3])*ZVL[gt1, 1] + 2*conj[Yv11]*conj[ZV[gt3, 4]]*ZN[gt2, 5]*
      ZVL[gt1, 1] + 2*Sqrt[2]*gp*Ql2*conj[ZV[gt3, 2]]*ZN[gt2, 1]*
      ZVL[gt1, 2] - Sqrt[2]*g1*conj[ZV[gt3, 2]]*ZN[gt2, 2]*ZVL[gt1, 2] + 
     Sqrt[2]*g2*conj[ZV[gt3, 2]]*ZN[gt2, 3]*ZVL[gt1, 2] + 
     2*conj[Yv22]*conj[ZV[gt3, 5]]*ZN[gt2, 5]*ZVL[gt1, 2] + 
     2*Sqrt[2]*gp*Ql3*conj[ZV[gt3, 3]]*ZN[gt2, 1]*ZVL[gt1, 3] - 
     Sqrt[2]*g1*conj[ZV[gt3, 3]]*ZN[gt2, 2]*ZVL[gt1, 3] + 
     Sqrt[2]*g2*conj[ZV[gt3, 3]]*ZN[gt2, 3]*ZVL[gt1, 3] + 
     2*conj[Yv33]*conj[ZV[gt3, 6]]*ZN[gt2, 5]*ZVL[gt1, 3]), PR}}, 
 {{Glu[{ct1}], Fd[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {((-I)*g3*PhaseGlu*Lam[ct1, ct3, ct2]*sum[j1, 1, 3, 
      conj[ZDL[gt2, j1]]*ZD[gt3, j1]])/Sqrt[2], PL}, 
  {(I*g3*conj[PhaseGlu]*Lam[ct1, ct3, ct2]*sum[j1, 1, 3, 
      ZD[gt3, 3 + j1]*ZDR[gt2, j1]])/Sqrt[2], PR}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], hh[{gt3}]}, 
  {((-I)*conj[ZH[gt3, 1]]*Delta[ct1, ct2]*sum[j2, 1, 3, 
      conj[ZDL[gt2, j2]]*sum[j1, 1, 3, conj[ZDR[gt1, j1]]*Yd[j1, j2]]])/
    Sqrt[2], PL}, {((-I)*conj[ZH[gt3, 1]]*Delta[ct1, ct2]*
     sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*
       ZDL[gt1, j2]])/Sqrt[2], PR}}, 
 {{bar[Cha[{gt1}]], Fd[{gt2, ct2}], conj[Su[{gt3, ct3}]]}, 
  {(-I)*Delta[ct2, ct3]*(g2*conj[UP[gt1, 1]]*sum[j1, 1, 3, 
       conj[ZDL[gt2, j1]]*ZU[gt3, j1]] - conj[UP[gt1, 2]]*
      sum[j2, 1, 3, conj[ZDL[gt2, j2]]*sum[j1, 1, 3, 
         Yu[j1, j2]*ZU[gt3, 3 + j1]]]), PL}, 
  {I*Delta[ct2, ct3]*sum[j2, 1, 3, 
     sum[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*ZU[gt3, j2]]*UM[gt1, 2], 
   PR}}, {{bar[Fu[{gt1, ct1}]], Fd[{gt2, ct2}], conj[Hpm[{gt3}]]}, 
  {I*Delta[ct1, ct2]*sum[j2, 1, 3, conj[ZDL[gt2, j2]]*
      sum[j1, 1, 3, conj[ZUR[gt1, j1]]*Yu[j1, j2]]]*ZP[gt3, 2], PL}, 
  {I*Delta[ct1, ct2]*sum[j2, 1, 3, 
     sum[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*ZUL[gt1, j2]]*ZP[gt3, 1], 
   PR}}, {{bar[Fe[{gt1}]], Fe[{gt2}], hh[{gt3}]}, 
  {((-I)*(Ye11*conj[ZEL[gt2, 1]]*conj[ZER[gt1, 1]] + 
      Ye22*conj[ZEL[gt2, 2]]*conj[ZER[gt1, 2]] + Ye33*conj[ZEL[gt2, 3]]*
       conj[ZER[gt1, 3]])*conj[ZH[gt3, 1]])/Sqrt[2], PL}, 
  {((-I)*conj[ZH[gt3, 1]]*(conj[Ye11]*ZEL[gt1, 1]*ZER[gt2, 1] + 
      conj[Ye22]*ZEL[gt1, 2]*ZER[gt2, 2] + conj[Ye33]*ZEL[gt1, 3]*
       ZER[gt2, 3]))/Sqrt[2], PR}}, 
 {{bar[Cha[{gt1}]], Fe[{gt2}], conj[Sv[{gt3}]]}, 
  {(-I)*(g2*conj[UP[gt1, 1]]*(conj[ZEL[gt2, 1]]*ZV[gt3, 1] + 
       conj[ZEL[gt2, 2]]*ZV[gt3, 2] + conj[ZEL[gt2, 3]]*ZV[gt3, 3]) - 
     conj[UP[gt1, 2]]*(Yv11*conj[ZEL[gt2, 1]]*ZV[gt3, 4] + 
       Yv22*conj[ZEL[gt2, 2]]*ZV[gt3, 5] + Yv33*conj[ZEL[gt2, 3]]*
        ZV[gt3, 6])), PL}, {I*UM[gt1, 2]*(conj[Ye11]*ZER[gt2, 1]*ZV[gt3, 1] + 
     conj[Ye22]*ZER[gt2, 2]*ZV[gt3, 2] + conj[Ye33]*ZER[gt2, 3]*ZV[gt3, 3]), 
   PR}}, {{bar[Fv[{gt1}]], Fe[{gt2}], conj[Hpm[{gt3}]]}, 
  {I*(Yv11*conj[ZEL[gt2, 1]]*conj[ZVR[gt1, 1]] + Yv22*conj[ZEL[gt2, 2]]*
      conj[ZVR[gt1, 2]] + Yv33*conj[ZEL[gt2, 3]]*conj[ZVR[gt1, 3]])*
    ZP[gt3, 2], PL}, {I*ZP[gt3, 1]*(conj[Ye11]*ZER[gt2, 1]*ZVL[gt1, 1] + 
     conj[Ye22]*ZER[gt2, 2]*ZVL[gt1, 2] + conj[Ye33]*ZER[gt2, 3]*
      ZVL[gt1, 3]), PR}}, {{Glu[{ct1}], Fu[{gt2, ct2}], 
   conj[Su[{gt3, ct3}]]}, {((-I)*g3*PhaseGlu*Lam[ct1, ct3, ct2]*
     sum[j1, 1, 3, conj[ZUL[gt2, j1]]*ZU[gt3, j1]])/Sqrt[2], PL}, 
  {(I*g3*conj[PhaseGlu]*Lam[ct1, ct3, ct2]*sum[j1, 1, 3, 
      ZU[gt3, 3 + j1]*ZUR[gt2, j1]])/Sqrt[2], PR}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], hh[{gt3}]}, 
  {((-I)*conj[ZH[gt3, 2]]*Delta[ct1, ct2]*sum[j2, 1, 3, 
      conj[ZUL[gt2, j2]]*sum[j1, 1, 3, conj[ZUR[gt1, j1]]*Yu[j1, j2]]])/
    Sqrt[2], PL}, {((-I)*conj[ZH[gt3, 2]]*Delta[ct1, ct2]*
     sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*
       ZUL[gt1, j2]])/Sqrt[2], PR}}, 
 {{bar[Fd[{gt1, ct1}]], Fu[{gt2, ct2}], Hpm[{gt3}]}, 
  {I*Delta[ct1, ct2]*sum[j2, 1, 3, conj[ZUL[gt2, j2]]*
      sum[j1, 1, 3, conj[ZDR[gt1, j1]]*Yd[j1, j2]]]*ZP[gt3, 1], PL}, 
  {I*Delta[ct1, ct2]*sum[j2, 1, 3, 
     sum[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*ZDL[gt1, j2]]*ZP[gt3, 2], 
   PR}}, {{bar[Fv[{gt1}]], Fv[{gt2}], hh[{gt3}]}, 
  {((-I)*conj[ZH[gt3, 2]]*(Yv11*conj[ZVL[gt2, 1]]*conj[ZVR[gt1, 1]] + 
      Yv22*conj[ZVL[gt2, 2]]*conj[ZVR[gt1, 2]] + Yv33*conj[ZVL[gt2, 3]]*
       conj[ZVR[gt1, 3]]))/Sqrt[2], PL}, 
  {((-I)*conj[ZH[gt3, 2]]*(conj[Yv11]*ZVL[gt1, 1]*ZVR[gt2, 1] + 
      conj[Yv22]*ZVL[gt1, 2]*ZVR[gt2, 2] + conj[Yv33]*ZVL[gt1, 3]*
       ZVR[gt2, 3]))/Sqrt[2], PR}}, {{bar[Fe[{gt1}]], Fv[{gt2}], Hpm[{gt3}]}, 
  {I*(Ye11*conj[ZER[gt1, 1]]*conj[ZVL[gt2, 1]] + Ye22*conj[ZER[gt1, 2]]*
      conj[ZVL[gt2, 2]] + Ye33*conj[ZER[gt1, 3]]*conj[ZVL[gt2, 3]])*
    ZP[gt3, 1], PL}, {I*ZP[gt3, 2]*(conj[Yv11]*ZEL[gt1, 1]*ZVR[gt2, 1] + 
     conj[Yv22]*ZEL[gt1, 2]*ZVR[gt2, 2] + conj[Yv33]*ZEL[gt1, 3]*
      ZVR[gt2, 3]), PR}}, {{bar[Fd[{gt1, ct1}]], Glu[{ct2}], Sd[{gt3, ct3}]}, 
  {(I*g3*PhaseGlu*Lam[ct2, ct1, ct3]*sum[j1, 1, 3, conj[ZD[gt3, 3 + j1]]*
       conj[ZDR[gt1, j1]]])/Sqrt[2], PL}, 
  {((-I)*g3*conj[PhaseGlu]*Lam[ct2, ct1, ct3]*sum[j1, 1, 3, 
      conj[ZD[gt3, j1]]*ZDL[gt1, j1]])/Sqrt[2], PR}}, 
 {{bar[Fu[{gt1, ct1}]], Glu[{ct2}], Su[{gt3, ct3}]}, 
  {(I*g3*PhaseGlu*Lam[ct2, ct1, ct3]*sum[j1, 1, 3, conj[ZU[gt3, 3 + j1]]*
       conj[ZUR[gt1, j1]]])/Sqrt[2], PL}, 
  {((-I)*g3*conj[PhaseGlu]*Lam[ct2, ct1, ct3]*sum[j1, 1, 3, 
      conj[ZU[gt3, j1]]*ZUL[gt1, j1]])/Sqrt[2], PR}}, 
 {{bar[Cha[{gt1}]], bar[Fu[{gt2, ct2}]], Sd[{gt3, ct3}]}, 
  {I*conj[UP[gt1, 2]]*Delta[ct2, ct3]*sum[j2, 1, 3, 
     conj[ZD[gt3, j2]]*sum[j1, 1, 3, conj[ZUR[gt2, j1]]*Yu[j1, j2]]], PL}, 
  {(-I)*Delta[ct2, ct3]*(g2*sum[j1, 1, 3, conj[ZD[gt3, j1]]*ZUL[gt2, j1]]*
      UM[gt1, 1] - sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*
          conj[ZD[gt3, 3 + j1]]]*ZUL[gt2, j2]]*UM[gt1, 2]), PR}}, 
 {{bar[Cha[{gt1}]], bar[Fv[{gt2}]], Se[{gt3}]}, 
  {I*conj[UP[gt1, 2]]*(Yv11*conj[ZE[gt3, 1]]*conj[ZVR[gt2, 1]] + 
     Yv22*conj[ZE[gt3, 2]]*conj[ZVR[gt2, 2]] + Yv33*conj[ZE[gt3, 3]]*
      conj[ZVR[gt2, 3]]), PL}, 
  {(-I)*(g2*conj[ZE[gt3, 1]]*UM[gt1, 1]*ZVL[gt2, 1] - 
     conj[Ye11]*conj[ZE[gt3, 4]]*UM[gt1, 2]*ZVL[gt2, 1] + 
     g2*conj[ZE[gt3, 2]]*UM[gt1, 1]*ZVL[gt2, 2] - conj[Ye22]*conj[ZE[gt3, 5]]*
      UM[gt1, 2]*ZVL[gt2, 2] + g2*conj[ZE[gt3, 3]]*UM[gt1, 1]*ZVL[gt2, 3] - 
     conj[Ye33]*conj[ZE[gt3, 6]]*UM[gt1, 2]*ZVL[gt2, 3]), PR}}, 
 {{Chi[{gt1}], Cha[{gt2}], conj[VWm[{lt3}]]}, 
  {(-I/2)*g2*(2*conj[UM[gt2, 1]]*ZN[gt1, 3] + Sqrt[2]*conj[UM[gt2, 2]]*
      ZN[gt1, 4]), LorentzProduct[gamma[lt3], PL]}, 
  {(-I)*g2*conj[ZN[gt1, 3]]*UP[gt2, 1] + (I*g2*conj[ZN[gt1, 5]]*UP[gt2, 2])/
     Sqrt[2], LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Cha[{gt1}]], Cha[{gt2}], VP[{lt3}]}, 
  {(I/2)*(2*g2*conj[UM[gt2, 1]]*Sin[ThetaW]*UM[gt1, 1] + 
     conj[UM[gt2, 2]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*UM[gt1, 2]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(I/2)*(2*g2*conj[UP[gt1, 1]]*Sin[ThetaW]*UP[gt2, 1] + 
     conj[UP[gt1, 2]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*UP[gt2, 2]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Cha[{gt1}]], Cha[{gt2}], VZ[{lt3}]}, 
  {(I/2)*(2*g2*conj[UM[gt2, 1]]*Cos[ThetaW]*Cos[ThetaWp]*UM[gt1, 1] + 
     conj[UM[gt2, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHd*Sin[ThetaWp])*UM[gt1, 2]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(I/2)*(2*g2*conj[UP[gt1, 1]]*Cos[ThetaW]*Cos[ThetaWp]*UP[gt2, 1] + 
     conj[UP[gt1, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHu*Sin[ThetaWp])*UP[gt2, 2]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Cha[{gt1}]], Cha[{gt2}], VZp[{lt3}]}, 
  {(-I/2)*(2*g2*conj[UM[gt2, 1]]*Cos[ThetaW]*Sin[ThetaWp]*UM[gt1, 1] + 
     conj[UM[gt2, 2]]*(2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*UM[gt1, 2]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(-I/2)*(2*g2*conj[UP[gt1, 1]]*Cos[ThetaW]*Sin[ThetaWp]*UP[gt2, 1] + 
     conj[UP[gt1, 2]]*(-2*gp*QHu*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*UP[gt2, 2]), 
   LorentzProduct[gamma[lt3], PR]}}, {{Chi[{gt1}], Chi[{gt2}], VZ[{lt3}]}, 
  {(-I/2)*(conj[ZN[gt2, 4]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*ZN[gt1, 4] - 
     conj[ZN[gt2, 5]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])*ZN[gt1, 5] + 
     2*gp*Qs*conj[ZN[gt2, 6]]*Sin[ThetaWp]*ZN[gt1, 6]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(I/2)*(conj[ZN[gt1, 4]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*ZN[gt2, 4] - 
     conj[ZN[gt1, 5]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])*ZN[gt2, 5] + 
     2*gp*Qs*conj[ZN[gt1, 6]]*Sin[ThetaWp]*ZN[gt2, 6]), 
   LorentzProduct[gamma[lt3], PR]}}, {{Chi[{gt1}], Chi[{gt2}], VZp[{lt3}]}, 
  {(-I/2)*(conj[ZN[gt2, 4]]*(2*gp*QHd*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZN[gt1, 4] + 
     conj[ZN[gt2, 5]]*(2*gp*QHu*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] + 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZN[gt1, 5] + 2*gp*Qs*conj[ZN[gt2, 6]]*
      Cos[ThetaWp]*ZN[gt1, 6]), LorentzProduct[gamma[lt3], PL]}, 
  {(I/2)*(conj[ZN[gt1, 4]]*(2*gp*QHd*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZN[gt2, 4] + 
     conj[ZN[gt1, 5]]*(2*gp*QHu*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] + 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZN[gt2, 5] + 2*gp*Qs*conj[ZN[gt1, 6]]*
      Cos[ThetaWp]*ZN[gt2, 6]), LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Cha[{gt1}]], Chi[{gt2}], VWm[{lt3}]}, 
  {(-I/2)*g2*(2*conj[ZN[gt2, 3]]*UM[gt1, 1] + Sqrt[2]*conj[ZN[gt2, 4]]*
      UM[gt1, 2]), LorentzProduct[gamma[lt3], PL]}, 
  {(-I)*g2*conj[UP[gt1, 1]]*ZN[gt2, 3] + (I*g2*conj[UP[gt1, 2]]*ZN[gt2, 5])/
     Sqrt[2], LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], VG[{ct3, lt3}]}, 
  {(-I/2)*g3*Delta[gt1, gt2]*Lam[ct3, ct1, ct2], LorentzProduct[gamma[lt3], 
    PL]}, {(-I/2)*g3*Delta[gt1, gt2]*Lam[ct3, ct1, ct2], 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], VP[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*Delta[gt1, gt2]*(g1*Cos[ThetaW] - 
     3*g2*Sin[ThetaW]), LorentzProduct[gamma[lt3], PL]}, 
  {(I/3)*g1*Cos[ThetaW]*Delta[ct1, ct2]*Delta[gt1, gt2], 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], VZ[{lt3}]}, 
  {(I/6)*Delta[ct1, ct2]*Delta[gt1, gt2]*(3*g2*Cos[ThetaW]*Cos[ThetaWp] + 
     g1*Cos[ThetaWp]*Sin[ThetaW] - 6*gp*Qq*Sin[ThetaWp]), 
   LorentzProduct[gamma[lt3], PL]}, {(-I/3)*Delta[ct1, ct2]*Delta[gt1, gt2]*
    (g1*Cos[ThetaWp]*Sin[ThetaW] - 3*gp*Qd*Sin[ThetaWp]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], VZp[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*Delta[gt1, gt2]*(6*gp*Qq*Cos[ThetaWp] + 
     (3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp]), 
   LorentzProduct[gamma[lt3], PL]}, {(I/3)*Delta[ct1, ct2]*Delta[gt1, gt2]*
    (3*gp*Qd*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fu[{gt1, ct1}]], Fd[{gt2, ct2}], conj[VWm[{lt3}]]}, 
  {((-I)*g2*Delta[ct1, ct2]*sum[j1, 1, 3, conj[ZDL[gt2, j1]]*ZUL[gt1, j1]])/
    Sqrt[2], LorentzProduct[gamma[lt3], PL]}, {0, PR}}, 
 {{bar[Fe[{gt1}]], Fe[{gt2}], VP[{lt3}]}, 
  {(I/2)*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*(conj[ZEL[gt2, 1]]*ZEL[gt1, 1] + 
     conj[ZEL[gt2, 2]]*ZEL[gt1, 2] + conj[ZEL[gt2, 3]]*ZEL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {I*g1*Cos[ThetaW]*(conj[ZER[gt1, 1]]*ZER[gt2, 1] + 
     conj[ZER[gt1, 2]]*ZER[gt2, 2] + conj[ZER[gt1, 3]]*ZER[gt2, 3]), 
   LorentzProduct[gamma[lt3], PR]}}, {{bar[Fe[{gt1}]], Fe[{gt2}], VZ[{lt3}]}, 
  {(I/2)*(conj[ZEL[gt2, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*Ql1*Sin[ThetaWp])*ZEL[gt1, 1] + 
     conj[ZEL[gt2, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*Ql2*Sin[ThetaWp])*ZEL[gt1, 2] + 
     conj[ZEL[gt2, 3]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*Ql3*Sin[ThetaWp])*ZEL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(-I)*(conj[ZER[gt1, 1]]*(g1*Cos[ThetaWp]*Sin[ThetaW] - 
       gp*Qe1*Sin[ThetaWp])*ZER[gt2, 1] + conj[ZER[gt1, 2]]*
      (g1*Cos[ThetaWp]*Sin[ThetaW] - gp*Qe2*Sin[ThetaWp])*ZER[gt2, 2] + 
     conj[ZER[gt1, 3]]*(g1*Cos[ThetaWp]*Sin[ThetaW] - gp*Qe3*Sin[ThetaWp])*
      ZER[gt2, 3]), LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fe[{gt1}]], Fe[{gt2}], VZp[{lt3}]}, 
  {(-I/2)*(conj[ZEL[gt2, 1]]*(2*gp*Ql1*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*ZEL[gt1, 1] + 
     conj[ZEL[gt2, 2]]*(2*gp*Ql2*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] - 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZEL[gt1, 2] + 
     conj[ZEL[gt2, 3]]*(2*gp*Ql3*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] - 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZEL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {I*(conj[ZER[gt1, 1]]*(gp*Qe1*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZER[gt2, 1] + conj[ZER[gt1, 2]]*(gp*Qe2*Cos[ThetaWp] + 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZER[gt2, 2] + 
     conj[ZER[gt1, 3]]*(gp*Qe3*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZER[gt2, 3]), LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fv[{gt1}]], Fe[{gt2}], conj[VWm[{lt3}]]}, 
  {((-I)*g2*(conj[ZEL[gt2, 1]]*ZVL[gt1, 1] + conj[ZEL[gt2, 2]]*ZVL[gt1, 2] + 
      conj[ZEL[gt2, 3]]*ZVL[gt1, 3]))/Sqrt[2], LorentzProduct[gamma[lt3], 
    PL]}, {0, PR}}, {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], VG[{ct3, lt3}]}, 
  {(-I/2)*g3*Delta[gt1, gt2]*Lam[ct3, ct1, ct2], LorentzProduct[gamma[lt3], 
    PL]}, {(-I/2)*g3*Delta[gt1, gt2]*Lam[ct3, ct1, ct2], 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], VP[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*Delta[gt1, gt2]*(g1*Cos[ThetaW] + 
     3*g2*Sin[ThetaW]), LorentzProduct[gamma[lt3], PL]}, 
  {((-2*I)/3)*g1*Cos[ThetaW]*Delta[ct1, ct2]*Delta[gt1, gt2], 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fu[{gt2, ct2}], VWm[{lt3}]}, 
  {((-I)*g2*Delta[ct1, ct2]*sum[j1, 1, 3, conj[ZUL[gt2, j1]]*ZDL[gt1, j1]])/
    Sqrt[2], LorentzProduct[gamma[lt3], PL]}, {0, PR}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], VZ[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*Delta[gt1, gt2]*(3*g2*Cos[ThetaW]*Cos[ThetaWp] - 
     g1*Cos[ThetaWp]*Sin[ThetaW] + 6*gp*Qq*Sin[ThetaWp]), 
   LorentzProduct[gamma[lt3], PL]}, {(I/3)*Delta[ct1, ct2]*Delta[gt1, gt2]*
    (2*g1*Cos[ThetaWp]*Sin[ThetaW] + 3*gp*Qu*Sin[ThetaWp]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], VZp[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*Delta[gt1, gt2]*(6*gp*Qq*Cos[ThetaWp] + 
     (-3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp]), 
   LorentzProduct[gamma[lt3], PL]}, {(I/3)*Delta[ct1, ct2]*Delta[gt1, gt2]*
    (3*gp*Qu*Cos[ThetaWp] - 2*g1*Sin[ThetaW]*Sin[ThetaWp]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fe[{gt1}]], Fv[{gt2}], VWm[{lt3}]}, 
  {((-I)*g2*(conj[ZVL[gt2, 1]]*ZEL[gt1, 1] + conj[ZVL[gt2, 2]]*ZEL[gt1, 2] + 
      conj[ZVL[gt2, 3]]*ZEL[gt1, 3]))/Sqrt[2], LorentzProduct[gamma[lt3], 
    PL]}, {0, PR}}, {{bar[Fv[{gt1}]], Fv[{gt2}], VZ[{lt3}]}, 
  {(-I/2)*(conj[ZVL[gt2, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql1*Sin[ThetaWp])*ZVL[gt1, 1] + 
     conj[ZVL[gt2, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql2*Sin[ThetaWp])*ZVL[gt1, 2] + 
     conj[ZVL[gt2, 3]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql3*Sin[ThetaWp])*ZVL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {I*gp*Sin[ThetaWp]*(Qv1*conj[ZVR[gt1, 1]]*ZVR[gt2, 1] + 
     Qv2*conj[ZVR[gt1, 2]]*ZVR[gt2, 2] + Qv3*conj[ZVR[gt1, 3]]*ZVR[gt2, 3]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fv[{gt1}]], Fv[{gt2}], VZp[{lt3}]}, 
  {(-I/2)*(conj[ZVL[gt2, 1]]*(2*gp*Ql1*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZVL[gt1, 1] + 
     conj[ZVL[gt2, 2]]*(2*gp*Ql2*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZVL[gt1, 2] + 
     conj[ZVL[gt2, 3]]*(2*gp*Ql3*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZVL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {I*gp*Cos[ThetaWp]*(Qv1*conj[ZVR[gt1, 1]]*ZVR[gt2, 1] + 
     Qv2*conj[ZVR[gt1, 2]]*ZVR[gt2, 2] + Qv3*conj[ZVR[gt1, 3]]*ZVR[gt2, 3]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{Glu[{ct1}], Glu[{ct2}], VG[{ct3, lt3}]}, 
  {-(g3*PhaseGlu*conj[PhaseGlu]*fSU3[ct1, ct2, ct3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {-(g3*PhaseGlu*conj[PhaseGlu]*fSU3[ct1, ct2, ct3]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[gG[{ct1}]], gG[{ct2}], VG[{ct3, lt3}]}, {g3*fSU3[ct1, ct2, ct3], 
   Mom[gG[{ct2}], lt3]}}, {{bar[gWm], gP, VWm[{lt3}]}, 
  {I*g2*Sin[ThetaW], Mom[gP, lt3]}}, {{bar[gWmC], gP, conj[VWm[{lt3}]]}, 
  {(-I)*g2*Sin[ThetaW], Mom[gP, lt3]}}, {{bar[gWm], gWm, VP[{lt3}]}, 
  {(-I)*g2*Sin[ThetaW], Mom[gWm, lt3]}}, {{bar[gWm], gWm, VZ[{lt3}]}, 
  {(-I)*g2*Cos[ThetaW]*Cos[ThetaWp], Mom[gWm, lt3]}}, 
 {{bar[gWm], gWm, VZp[{lt3}]}, {I*g2*Cos[ThetaW]*Sin[ThetaWp], 
   Mom[gWm, lt3]}}, {{bar[gP], gWm, conj[VWm[{lt3}]]}, 
  {I*g2*Sin[ThetaW], Mom[gWm, lt3]}}, {{bar[gZ], gWm, conj[VWm[{lt3}]]}, 
  {I*g2*Cos[ThetaW]*Cos[ThetaWp], Mom[gWm, lt3]}}, 
 {{bar[gZp], gWm, conj[VWm[{lt3}]]}, {(-I)*g2*Cos[ThetaW]*Sin[ThetaWp], 
   Mom[gWm, lt3]}}, {{bar[gWmC], gWmC, VP[{lt3}]}, 
  {I*g2*Sin[ThetaW], Mom[gWmC, lt3]}}, {{bar[gP], gWmC, VWm[{lt3}]}, 
  {(-I)*g2*Sin[ThetaW], Mom[gWmC, lt3]}}, {{bar[gZ], gWmC, VWm[{lt3}]}, 
  {(-I)*g2*Cos[ThetaW]*Cos[ThetaWp], Mom[gWmC, lt3]}}, 
 {{bar[gZp], gWmC, VWm[{lt3}]}, {I*g2*Cos[ThetaW]*Sin[ThetaWp], 
   Mom[gWmC, lt3]}}, {{bar[gWmC], gWmC, VZ[{lt3}]}, 
  {I*g2*Cos[ThetaW]*Cos[ThetaWp], Mom[gWmC, lt3]}}, 
 {{bar[gWmC], gWmC, VZp[{lt3}]}, {(-I)*g2*Cos[ThetaW]*Sin[ThetaWp], 
   Mom[gWmC, lt3]}}, {{bar[gWm], gZ, VWm[{lt3}]}, 
  {I*g2*Cos[ThetaW]*Cos[ThetaWp], Mom[gZ, lt3]}}, 
 {{bar[gWmC], gZ, conj[VWm[{lt3}]]}, {(-I)*g2*Cos[ThetaW]*Cos[ThetaWp], 
   Mom[gZ, lt3]}}, {{bar[gWm], gZp, VWm[{lt3}]}, 
  {(-I)*g2*Cos[ThetaW]*Sin[ThetaWp], Mom[gZp, lt3]}}, 
 {{bar[gWmC], gZp, conj[VWm[{lt3}]]}, {I*g2*Cos[ThetaW]*Sin[ThetaWp], 
   Mom[gZp, lt3]}}, {{bar[gWm], gWm, Ah[{gt3}]}, 
  {(g2^2*(vd*conj[ZA[gt3, 1]] - vu*conj[ZA[gt3, 2]])*RXi[Wm])/4, 1}}, 
 {{bar[gWmC], gWmC, Ah[{gt3}]}, 
  {(g2^2*(-(vd*conj[ZA[gt3, 1]]) + vu*conj[ZA[gt3, 2]])*RXi[Wm])/4, 1}}, 
 {{bar[gWm], gP, Hpm[{gt3}]}, 
  {(I/4)*g2*RXi[Wm]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*
    (vd*ZP[gt3, 1] - vu*ZP[gt3, 2]), 1}}, {{bar[gWmC], gP, conj[Hpm[{gt3}]]}, 
  {(I/4)*g2*RXi[Wm]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*
    (vd*ZP[gt3, 1] - vu*ZP[gt3, 2]), 1}}, {{bar[gWm], gWm, hh[{gt3}]}, 
  {(-I/4)*g2^2*(vd*conj[ZH[gt3, 1]] + vu*conj[ZH[gt3, 2]])*RXi[Wm], 1}}, 
 {{bar[gZ], gWm, conj[Hpm[{gt3}]]}, 
  {(-I/4)*g2*RXi[Z]*(vd*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*ZP[gt3, 1] - 
     vu*(g2*Cos[ThetaW]*Cos[ThetaWp] + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt3, 2]), 1}}, 
 {{bar[gZp], gWm, conj[Hpm[{gt3}]]}, 
  {(I/4)*g2*RXi[Zp]*(vd*(-2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZP[gt3, 1] - 
     vu*(2*gp*QHu*Cos[ThetaWp] + (g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt3, 2]), 1}}, {{bar[gWmC], gWmC, hh[{gt3}]}, 
  {(-I/4)*g2^2*(vd*conj[ZH[gt3, 1]] + vu*conj[ZH[gt3, 2]])*RXi[Wm], 1}}, 
 {{bar[gZ], gWmC, Hpm[{gt3}]}, 
  {(-I/4)*g2*RXi[Z]*(vd*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*ZP[gt3, 1] - 
     vu*(g2*Cos[ThetaW]*Cos[ThetaWp] + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt3, 2]), 1}}, 
 {{bar[gZp], gWmC, Hpm[{gt3}]}, 
  {(I/4)*g2*RXi[Zp]*(vd*(-2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZP[gt3, 1] - 
     vu*(2*gp*QHu*Cos[ThetaWp] + (g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt3, 2]), 1}}, {{bar[gZ], gZ, hh[{gt3}]}, 
  {(-I/4)*RXi[Z]*(4*gp^2*Qs^2*vS*conj[ZH[gt3, 3]]*Sin[ThetaWp]^2 + 
     vd*conj[ZH[gt3, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])^2 + 
     vu*conj[ZH[gt3, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])^2), 1}}, 
 {{bar[gZp], gZ, hh[{gt3}]}, 
  {(I/4)*RXi[Zp]*(-4*gp^2*Qs^2*vS*conj[ZH[gt3, 3]]*Cos[ThetaWp]*
      Sin[ThetaWp] + vd*conj[ZH[gt3, 1]]*(-2*g1*gp*QHd*Cos[ThetaWp]^2*
        Sin[ThetaW] + g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHd^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*QHd*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (-(gp*QHd*Cos[ThetaWp]^2) + g1*Cos[ThetaWp]*Sin[ThetaW]*
          Sin[ThetaWp] + gp*QHd*Sin[ThetaWp]^2)) + 
     vu*conj[ZH[gt3, 2]]*(2*g1*gp*QHu*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHu^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 
       2*g1*gp*QHu*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*QHu*Cos[ThetaWp]^2 + g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*QHu*Sin[ThetaWp]^2))), 1}}, {{bar[gWm], gZ, Hpm[{gt3}]}, 
  {(I/4)*g2*RXi[Wm]*(vd*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHd*Sin[ThetaWp])*ZP[gt3, 1] + 
     vu*(-(g2*Cos[ThetaW]*Cos[ThetaWp]) + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt3, 2]), 1}}, 
 {{bar[gWmC], gZ, conj[Hpm[{gt3}]]}, 
  {(I/4)*g2*RXi[Wm]*(vd*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHd*Sin[ThetaWp])*ZP[gt3, 1] + 
     vu*(-(g2*Cos[ThetaW]*Cos[ThetaWp]) + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt3, 2]), 1}}, 
 {{bar[gZ], gZp, hh[{gt3}]}, 
  {(I/4)*RXi[Z]*(-4*gp^2*Qs^2*vS*conj[ZH[gt3, 3]]*Cos[ThetaWp]*Sin[ThetaWp] + 
     vd*conj[ZH[gt3, 1]]*(-2*g1*gp*QHd*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHd^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*QHd*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (-(gp*QHd*Cos[ThetaWp]^2) + g1*Cos[ThetaWp]*Sin[ThetaW]*
          Sin[ThetaWp] + gp*QHd*Sin[ThetaWp]^2)) + 
     vu*conj[ZH[gt3, 2]]*(2*g1*gp*QHu*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHu^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 
       2*g1*gp*QHu*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*QHu*Cos[ThetaWp]^2 + g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*QHu*Sin[ThetaWp]^2))), 1}}, {{bar[gZp], gZp, hh[{gt3}]}, 
  {(-I/4)*RXi[Zp]*(4*gp^2*Qs^2*vS*conj[ZH[gt3, 3]]*Cos[ThetaWp]^2 + 
     vd*conj[ZH[gt3, 1]]*(-2*gp*QHd*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2 + 
     vu*conj[ZH[gt3, 2]]*(2*gp*QHu*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2), 1}}, 
 {{bar[gWm], gZp, Hpm[{gt3}]}, 
  {(-I/4)*g2*RXi[Wm]*(vd*(2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*ZP[gt3, 1] + 
     vu*(2*gp*QHu*Cos[ThetaWp] + (-(g2*Cos[ThetaW]) + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt3, 2]), 1}}, {{bar[gWmC], gZp, conj[Hpm[{gt3}]]}, 
  {(-I/4)*g2*RXi[Wm]*(vd*(2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*ZP[gt3, 1] + 
     vu*(2*gp*QHu*Cos[ThetaWp] + (-(g2*Cos[ThetaW]) + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt3, 2]), 1}}}
