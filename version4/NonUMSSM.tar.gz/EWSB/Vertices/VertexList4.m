{{{Ah[{gt1}], Ah[{gt2}], Ah[{gt3}], Ah[{gt4}]}, 
  {(-I/4)*(4*conj[ZA[gt1, 3]]*((gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*
        conj[ZA[gt2, 1]]*(conj[ZA[gt3, 3]]*conj[ZA[gt4, 1]] + 
         conj[ZA[gt3, 1]]*conj[ZA[gt4, 3]]) + 
       (gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZA[gt2, 2]]*
        (conj[ZA[gt3, 3]]*conj[ZA[gt4, 2]] + conj[ZA[gt3, 2]]*
          conj[ZA[gt4, 3]]) + conj[ZA[gt2, 3]]*
        ((gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZA[gt3, 1]]*
          conj[ZA[gt4, 1]] + (gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*
          conj[ZA[gt3, 2]]*conj[ZA[gt4, 2]] + 3*gp^2*Qs^2*conj[ZA[gt3, 3]]*
          conj[ZA[gt4, 3]])) + conj[ZA[gt1, 1]]*
      (-((g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
         conj[ZA[gt2, 2]]*(conj[ZA[gt3, 2]]*conj[ZA[gt4, 1]] + 
          conj[ZA[gt3, 1]]*conj[ZA[gt4, 2]])) + 
       4*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZA[gt2, 3]]*
        (conj[ZA[gt3, 3]]*conj[ZA[gt4, 1]] + conj[ZA[gt3, 1]]*
          conj[ZA[gt4, 3]]) + conj[ZA[gt2, 1]]*
        (3*(g1^2 + g2^2 + 4*gp^2*QHd^2)*conj[ZA[gt3, 1]]*conj[ZA[gt4, 1]] - 
         (g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
          conj[ZA[gt3, 2]]*conj[ZA[gt4, 2]] + 
         4*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZA[gt3, 3]]*
          conj[ZA[gt4, 3]])) + conj[ZA[gt1, 2]]*
      (-((g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
         conj[ZA[gt2, 1]]*(conj[ZA[gt3, 2]]*conj[ZA[gt4, 1]] + 
          conj[ZA[gt3, 1]]*conj[ZA[gt4, 2]])) + 
       4*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZA[gt2, 3]]*
        (conj[ZA[gt3, 3]]*conj[ZA[gt4, 2]] + conj[ZA[gt3, 2]]*
          conj[ZA[gt4, 3]]) + conj[ZA[gt2, 2]]*
        (-((g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
           conj[ZA[gt3, 1]]*conj[ZA[gt4, 1]]) + 
         3*(g1^2 + g2^2 + 4*gp^2*QHu^2)*conj[ZA[gt3, 2]]*conj[ZA[gt4, 2]] + 
         4*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZA[gt3, 3]]*
          conj[ZA[gt4, 3]]))), 1}}, 
 {{Ah[{gt1}], Ah[{gt2}], hh[{gt3}], hh[{gt4}]}, 
  {(-I/4)*(4*conj[ZA[gt1, 3]]*conj[ZA[gt2, 3]]*
      ((gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]]*
        conj[ZH[gt4, 1]] + (gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*
        conj[ZH[gt3, 2]]*conj[ZH[gt4, 2]] + gp^2*Qs^2*conj[ZH[gt3, 3]]*
        conj[ZH[gt4, 3]]) + conj[ZA[gt1, 1]]*conj[ZA[gt2, 1]]*
      ((g1^2 + g2^2 + 4*gp^2*QHd^2)*conj[ZH[gt3, 1]]*conj[ZH[gt4, 1]] - 
       (g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
        conj[ZH[gt3, 2]]*conj[ZH[gt4, 2]] + 
       4*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]*
        conj[ZH[gt4, 3]]) + conj[ZA[gt1, 2]]*conj[ZA[gt2, 2]]*
      (-((g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
         conj[ZH[gt3, 1]]*conj[ZH[gt4, 1]]) + (g1^2 + g2^2 + 4*gp^2*QHu^2)*
        conj[ZH[gt3, 2]]*conj[ZH[gt4, 2]] + 
       4*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]*
        conj[ZH[gt4, 3]])), 1}}, {{Ah[{gt1}], Ah[{gt2}], Hpm[{gt3}], 
   conj[Hpm[{gt4}]]}, 
  {(-I/4)*(4*conj[ZA[gt1, 3]]*conj[ZA[gt2, 3]]*
      ((gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*ZP[gt3, 1]*ZP[gt4, 1] + 
       (gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*ZP[gt3, 2]*ZP[gt4, 2]) + 
     conj[ZA[gt1, 1]]*(-((g2^2 - 2*\[Lambda]*conj[\[Lambda]])*
         conj[ZA[gt2, 2]]*(ZP[gt3, 2]*ZP[gt4, 1] + ZP[gt3, 1]*ZP[gt4, 2])) + 
       conj[ZA[gt2, 1]]*((g1^2 + g2^2 + 4*gp^2*QHd^2)*ZP[gt3, 1]*ZP[gt4, 1] + 
         (-g1^2 + g2^2 + 4*gp^2*QHd*QHu)*ZP[gt3, 2]*ZP[gt4, 2])) + 
     conj[ZA[gt1, 2]]*(-((g2^2 - 2*\[Lambda]*conj[\[Lambda]])*
         conj[ZA[gt2, 1]]*(ZP[gt3, 2]*ZP[gt4, 1] + ZP[gt3, 1]*ZP[gt4, 2])) + 
       conj[ZA[gt2, 2]]*((-g1^2 + g2^2 + 4*gp^2*QHd*QHu)*ZP[gt3, 1]*
          ZP[gt4, 1] + (g1^2 + g2^2 + 4*gp^2*QHu^2)*ZP[gt3, 2]*ZP[gt4, 2]))), 
   1}}, {{Ah[{gt1}], Ah[{gt2}], Sd[{gt3, ct3}], conj[Sd[{gt4, ct4}]]}, 
  {(-I/12)*Delta[ct3, ct4]*(6*conj[ZA[gt1, 3]]*
      (2*gp^2*Qs*conj[ZA[gt2, 3]]*(Qq*sum[j1, 1, 3, conj[ZD[gt3, j1]]*
            ZD[gt4, j1]] + Qd*sum[j1, 1, 3, conj[ZD[gt3, 3 + j1]]*
            ZD[gt4, 3 + j1]]) + conj[ZA[gt2, 2]]*
        (conj[\[Lambda]]*sum[j2, 1, 3, conj[ZD[gt3, j2]]*sum[j1, 1, 3, 
             Yd[j1, j2]*ZD[gt4, 3 + j1]]] + \[Lambda]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt3, 3 + j1]]]*
            ZD[gt4, j2]])) + conj[ZA[gt1, 2]]*
      (conj[ZA[gt2, 2]]*((g1^2 + 3*g2^2 + 12*gp^2*QHu*Qq)*
          sum[j1, 1, 3, conj[ZD[gt3, j1]]*ZD[gt4, j1]] + 
         2*(g1^2 + 6*gp^2*Qd*QHu)*sum[j1, 1, 3, conj[ZD[gt3, 3 + j1]]*
            ZD[gt4, 3 + j1]]) + 6*conj[ZA[gt2, 3]]*
        (conj[\[Lambda]]*sum[j2, 1, 3, conj[ZD[gt3, j2]]*sum[j1, 1, 3, 
             Yd[j1, j2]*ZD[gt4, 3 + j1]]] + \[Lambda]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt3, 3 + j1]]]*
            ZD[gt4, j2]])) + conj[ZA[gt1, 1]]*conj[ZA[gt2, 1]]*
      (-((g1^2 + 3*(g2^2 - 4*gp^2*QHd*Qq))*sum[j1, 1, 3, conj[ZD[gt3, j1]]*
           ZD[gt4, j1]]) - 2*(g1^2 - 6*gp^2*Qd*QHd)*sum[j1, 1, 3, 
         conj[ZD[gt3, 3 + j1]]*ZD[gt4, 3 + j1]] + 
       12*(sum[j3, 1, 3, conj[ZD[gt3, 3 + j3]]*sum[j2, 1, 3, 
            sum[j1, 1, 3, conj[Yd[j3, j1]]*Yd[j2, j1]]*ZD[gt4, 3 + j2]]] + 
         sum[j3, 1, 3, sum[j2, 1, 3, conj[ZD[gt3, j2]]*sum[j1, 1, 3, 
              conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZD[gt4, j3]]))), 1}}, 
 {{Ah[{gt1}], Ah[{gt2}], Se[{gt3}], conj[Se[{gt4}]]}, 
  {(-I/4)*(conj[ZA[gt1, 1]]*conj[ZA[gt2, 1]]*
      ((g1^2 - g2^2 + 4*gp^2*QHd*Ql1 + 4*Ye11*conj[Ye11])*conj[ZE[gt3, 1]]*
        ZE[gt4, 1] + (g1^2 - g2^2 + 4*gp^2*QHd*Ql2 + 4*Ye22*conj[Ye22])*
        conj[ZE[gt3, 2]]*ZE[gt4, 2] + g1^2*conj[ZE[gt3, 3]]*ZE[gt4, 3] - 
       g2^2*conj[ZE[gt3, 3]]*ZE[gt4, 3] + 4*gp^2*QHd*Ql3*conj[ZE[gt3, 3]]*
        ZE[gt4, 3] + 4*Ye33*conj[Ye33]*conj[ZE[gt3, 3]]*ZE[gt4, 3] - 
       2*g1^2*conj[ZE[gt3, 4]]*ZE[gt4, 4] + 4*gp^2*Qe1*QHd*conj[ZE[gt3, 4]]*
        ZE[gt4, 4] + 4*Ye11*conj[Ye11]*conj[ZE[gt3, 4]]*ZE[gt4, 4] - 
       2*g1^2*conj[ZE[gt3, 5]]*ZE[gt4, 5] + 4*gp^2*Qe2*QHd*conj[ZE[gt3, 5]]*
        ZE[gt4, 5] + 4*Ye22*conj[Ye22]*conj[ZE[gt3, 5]]*ZE[gt4, 5] - 
       2*g1^2*conj[ZE[gt3, 6]]*ZE[gt4, 6] + 4*gp^2*Qe3*QHd*conj[ZE[gt3, 6]]*
        ZE[gt4, 6] + 4*Ye33*conj[Ye33]*conj[ZE[gt3, 6]]*ZE[gt4, 6]) + 
     2*conj[ZA[gt1, 3]]*(conj[ZA[gt2, 2]]*(\[Lambda]*conj[Ye11]*
          conj[ZE[gt3, 4]]*ZE[gt4, 1] + \[Lambda]*conj[Ye22]*conj[ZE[gt3, 5]]*
          ZE[gt4, 2] + \[Lambda]*conj[Ye33]*conj[ZE[gt3, 6]]*ZE[gt4, 3] + 
         Ye11*conj[\[Lambda]]*conj[ZE[gt3, 1]]*ZE[gt4, 4] + 
         Ye22*conj[\[Lambda]]*conj[ZE[gt3, 2]]*ZE[gt4, 5] + 
         Ye33*conj[\[Lambda]]*conj[ZE[gt3, 3]]*ZE[gt4, 6]) + 
       2*gp^2*Qs*conj[ZA[gt2, 3]]*(Ql1*conj[ZE[gt3, 1]]*ZE[gt4, 1] + 
         Ql2*conj[ZE[gt3, 2]]*ZE[gt4, 2] + Ql3*conj[ZE[gt3, 3]]*ZE[gt4, 3] + 
         Qe1*conj[ZE[gt3, 4]]*ZE[gt4, 4] + Qe2*conj[ZE[gt3, 5]]*ZE[gt4, 5] + 
         Qe3*conj[ZE[gt3, 6]]*ZE[gt4, 6])) + conj[ZA[gt1, 2]]*
      (2*conj[ZA[gt2, 3]]*(\[Lambda]*conj[Ye11]*conj[ZE[gt3, 4]]*ZE[gt4, 1] + 
         \[Lambda]*conj[Ye22]*conj[ZE[gt3, 5]]*ZE[gt4, 2] + 
         \[Lambda]*conj[Ye33]*conj[ZE[gt3, 6]]*ZE[gt4, 3] + 
         Ye11*conj[\[Lambda]]*conj[ZE[gt3, 1]]*ZE[gt4, 4] + 
         Ye22*conj[\[Lambda]]*conj[ZE[gt3, 2]]*ZE[gt4, 5] + 
         Ye33*conj[\[Lambda]]*conj[ZE[gt3, 3]]*ZE[gt4, 6]) + 
       conj[ZA[gt2, 2]]*((-g1^2 + g2^2 + 4*gp^2*QHu*Ql1)*conj[ZE[gt3, 1]]*
          ZE[gt4, 1] + (-g1^2 + g2^2 + 4*gp^2*QHu*Ql2)*conj[ZE[gt3, 2]]*
          ZE[gt4, 2] - g1^2*conj[ZE[gt3, 3]]*ZE[gt4, 3] + 
         g2^2*conj[ZE[gt3, 3]]*ZE[gt4, 3] + 4*gp^2*QHu*Ql3*conj[ZE[gt3, 3]]*
          ZE[gt4, 3] + 2*g1^2*conj[ZE[gt3, 4]]*ZE[gt4, 4] + 
         4*gp^2*Qe1*QHu*conj[ZE[gt3, 4]]*ZE[gt4, 4] + 2*g1^2*conj[ZE[gt3, 5]]*
          ZE[gt4, 5] + 4*gp^2*Qe2*QHu*conj[ZE[gt3, 5]]*ZE[gt4, 5] + 
         2*g1^2*conj[ZE[gt3, 6]]*ZE[gt4, 6] + 4*gp^2*Qe3*QHu*conj[ZE[gt3, 6]]*
          ZE[gt4, 6]))), 1}}, {{Ah[{gt1}], Ah[{gt2}], Su[{gt3, ct3}], 
   conj[Su[{gt4, ct4}]]}, {(-I/12)*Delta[ct3, ct4]*
    (6*conj[ZA[gt1, 3]]*(2*gp^2*Qs*conj[ZA[gt2, 3]]*
        (Qq*sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZU[gt4, j1]] + 
         Qu*sum[j1, 1, 3, conj[ZU[gt3, 3 + j1]]*ZU[gt4, 3 + j1]]) + 
       conj[ZA[gt2, 1]]*(conj[\[Lambda]]*sum[j2, 1, 3, conj[ZU[gt3, j2]]*
            sum[j1, 1, 3, Yu[j1, j2]*ZU[gt4, 3 + j1]]] + 
         \[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
              conj[ZU[gt3, 3 + j1]]]*ZU[gt4, j2]])) + 
     conj[ZA[gt1, 1]]*(conj[ZA[gt2, 1]]*((-g1^2 + 3*g2^2 + 12*gp^2*QHd*Qq)*
          sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZU[gt4, j1]] + 
         4*(g1^2 + 3*gp^2*QHd*Qu)*sum[j1, 1, 3, conj[ZU[gt3, 3 + j1]]*
            ZU[gt4, 3 + j1]]) + 6*conj[ZA[gt2, 3]]*
        (conj[\[Lambda]]*sum[j2, 1, 3, conj[ZU[gt3, j2]]*sum[j1, 1, 3, 
             Yu[j1, j2]*ZU[gt4, 3 + j1]]] + \[Lambda]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt3, 3 + j1]]]*
            ZU[gt4, j2]])) + conj[ZA[gt1, 2]]*conj[ZA[gt2, 2]]*
      ((g1^2 - 3*g2^2 + 12*gp^2*QHu*Qq)*sum[j1, 1, 3, conj[ZU[gt3, j1]]*
          ZU[gt4, j1]] - 4*(g1^2 - 3*gp^2*QHu*Qu)*sum[j1, 1, 3, 
         conj[ZU[gt3, 3 + j1]]*ZU[gt4, 3 + j1]] + 
       12*(sum[j3, 1, 3, conj[ZU[gt3, 3 + j3]]*sum[j2, 1, 3, 
            sum[j1, 1, 3, conj[Yu[j3, j1]]*Yu[j2, j1]]*ZU[gt4, 3 + j2]]] + 
         sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt3, j2]]*sum[j1, 1, 3, 
              conj[Yu[j1, j3]]*Yu[j1, j2]]]*ZU[gt4, j3]]))), 1}}, 
 {{Ah[{gt1}], Ah[{gt2}], Sv[{gt3}], conj[Sv[{gt4}]]}, 
  {(-I/4)*(conj[ZA[gt1, 2]]*conj[ZA[gt2, 2]]*
      (-((g1^2 + g2^2 - 4*gp^2*QHu*Ql1 - 4*Yv11*conj[Yv11])*conj[ZV[gt3, 1]]*
         ZV[gt4, 1]) - (g1^2 + g2^2 - 4*gp^2*QHu*Ql2 - 4*Yv22*conj[Yv22])*
        conj[ZV[gt3, 2]]*ZV[gt4, 2] - g1^2*conj[ZV[gt3, 3]]*ZV[gt4, 3] - 
       g2^2*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 4*gp^2*QHu*Ql3*conj[ZV[gt3, 3]]*
        ZV[gt4, 3] + 4*Yv33*conj[Yv33]*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 
       4*gp^2*QHu*Qv1*conj[ZV[gt3, 4]]*ZV[gt4, 4] + 4*Yv11*conj[Yv11]*
        conj[ZV[gt3, 4]]*ZV[gt4, 4] + 4*gp^2*QHu*Qv2*conj[ZV[gt3, 5]]*
        ZV[gt4, 5] + 4*Yv22*conj[Yv22]*conj[ZV[gt3, 5]]*ZV[gt4, 5] + 
       4*gp^2*QHu*Qv3*conj[ZV[gt3, 6]]*ZV[gt4, 6] + 4*Yv33*conj[Yv33]*
        conj[ZV[gt3, 6]]*ZV[gt4, 6]) + 2*conj[ZA[gt1, 3]]*
      (conj[ZA[gt2, 1]]*(\[Lambda]*conj[Yv11]*conj[ZV[gt3, 4]]*ZV[gt4, 1] + 
         \[Lambda]*conj[Yv22]*conj[ZV[gt3, 5]]*ZV[gt4, 2] + 
         \[Lambda]*conj[Yv33]*conj[ZV[gt3, 6]]*ZV[gt4, 3] + 
         Yv11*conj[\[Lambda]]*conj[ZV[gt3, 1]]*ZV[gt4, 4] + 
         Yv22*conj[\[Lambda]]*conj[ZV[gt3, 2]]*ZV[gt4, 5] + 
         Yv33*conj[\[Lambda]]*conj[ZV[gt3, 3]]*ZV[gt4, 6]) + 
       2*gp^2*Qs*conj[ZA[gt2, 3]]*(Ql1*conj[ZV[gt3, 1]]*ZV[gt4, 1] + 
         Ql2*conj[ZV[gt3, 2]]*ZV[gt4, 2] + Ql3*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 
         Qv1*conj[ZV[gt3, 4]]*ZV[gt4, 4] + Qv2*conj[ZV[gt3, 5]]*ZV[gt4, 5] + 
         Qv3*conj[ZV[gt3, 6]]*ZV[gt4, 6])) + conj[ZA[gt1, 1]]*
      (2*conj[ZA[gt2, 3]]*(\[Lambda]*conj[Yv11]*conj[ZV[gt3, 4]]*ZV[gt4, 1] + 
         \[Lambda]*conj[Yv22]*conj[ZV[gt3, 5]]*ZV[gt4, 2] + 
         \[Lambda]*conj[Yv33]*conj[ZV[gt3, 6]]*ZV[gt4, 3] + 
         Yv11*conj[\[Lambda]]*conj[ZV[gt3, 1]]*ZV[gt4, 4] + 
         Yv22*conj[\[Lambda]]*conj[ZV[gt3, 2]]*ZV[gt4, 5] + 
         Yv33*conj[\[Lambda]]*conj[ZV[gt3, 3]]*ZV[gt4, 6]) + 
       conj[ZA[gt2, 1]]*((g1^2 + g2^2 + 4*gp^2*QHd*Ql1)*conj[ZV[gt3, 1]]*
          ZV[gt4, 1] + (g1^2 + g2^2 + 4*gp^2*QHd*Ql2)*conj[ZV[gt3, 2]]*
          ZV[gt4, 2] + g1^2*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 
         g2^2*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 4*gp^2*QHd*Ql3*conj[ZV[gt3, 3]]*
          ZV[gt4, 3] + 4*gp^2*QHd*Qv1*conj[ZV[gt3, 4]]*ZV[gt4, 4] + 
         4*gp^2*QHd*Qv2*conj[ZV[gt3, 5]]*ZV[gt4, 5] + 4*gp^2*QHd*Qv3*
          conj[ZV[gt3, 6]]*ZV[gt4, 6]))), 1}}, 
 {{Ah[{gt1}], hh[{gt2}], Hpm[{gt3}], conj[Hpm[{gt4}]]}, 
  {((g2^2 - 2*\[Lambda]*conj[\[Lambda]])*(conj[ZA[gt1, 2]]*conj[ZH[gt2, 1]] + 
      conj[ZA[gt1, 1]]*conj[ZH[gt2, 2]])*(ZP[gt3, 2]*ZP[gt4, 1] - 
      ZP[gt3, 1]*ZP[gt4, 2]))/4, 1}}, 
 {{Ah[{gt1}], hh[{gt2}], Sd[{gt3, ct3}], conj[Sd[{gt4, ct4}]]}, 
  {((conj[ZA[gt1, 3]]*conj[ZH[gt2, 2]] + conj[ZA[gt1, 2]]*conj[ZH[gt2, 3]])*
     Delta[ct3, ct4]*(conj[\[Lambda]]*sum[j2, 1, 3, conj[ZD[gt3, j2]]*
         sum[j1, 1, 3, Yd[j1, j2]*ZD[gt4, 3 + j1]]] - 
      \[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*
           conj[ZD[gt3, 3 + j1]]]*ZD[gt4, j2]]))/2, 1}}, 
 {{Ah[{gt1}], hh[{gt2}], Se[{gt3}], conj[Se[{gt4}]]}, 
  {-((conj[ZA[gt1, 3]]*conj[ZH[gt2, 2]] + conj[ZA[gt1, 2]]*conj[ZH[gt2, 3]])*
      (\[Lambda]*conj[Ye11]*conj[ZE[gt3, 4]]*ZE[gt4, 1] + 
       \[Lambda]*conj[Ye22]*conj[ZE[gt3, 5]]*ZE[gt4, 2] + 
       \[Lambda]*conj[Ye33]*conj[ZE[gt3, 6]]*ZE[gt4, 3] - 
       Ye11*conj[\[Lambda]]*conj[ZE[gt3, 1]]*ZE[gt4, 4] - 
       Ye22*conj[\[Lambda]]*conj[ZE[gt3, 2]]*ZE[gt4, 5] - 
       Ye33*conj[\[Lambda]]*conj[ZE[gt3, 3]]*ZE[gt4, 6]))/2, 1}}, 
 {{Ah[{gt1}], hh[{gt2}], Su[{gt3, ct3}], conj[Su[{gt4, ct4}]]}, 
  {((conj[ZA[gt1, 3]]*conj[ZH[gt2, 1]] + conj[ZA[gt1, 1]]*conj[ZH[gt2, 3]])*
     Delta[ct3, ct4]*(conj[\[Lambda]]*sum[j2, 1, 3, conj[ZU[gt3, j2]]*
         sum[j1, 1, 3, Yu[j1, j2]*ZU[gt4, 3 + j1]]] - 
      \[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
           conj[ZU[gt3, 3 + j1]]]*ZU[gt4, j2]]))/2, 1}}, 
 {{Ah[{gt1}], hh[{gt2}], Sv[{gt3}], conj[Sv[{gt4}]]}, 
  {-((conj[ZA[gt1, 3]]*conj[ZH[gt2, 1]] + conj[ZA[gt1, 1]]*conj[ZH[gt2, 3]])*
      (\[Lambda]*conj[Yv11]*conj[ZV[gt3, 4]]*ZV[gt4, 1] + 
       \[Lambda]*conj[Yv22]*conj[ZV[gt3, 5]]*ZV[gt4, 2] + 
       \[Lambda]*conj[Yv33]*conj[ZV[gt3, 6]]*ZV[gt4, 3] - 
       Yv11*conj[\[Lambda]]*conj[ZV[gt3, 1]]*ZV[gt4, 4] - 
       Yv22*conj[\[Lambda]]*conj[ZV[gt3, 2]]*ZV[gt4, 5] - 
       Yv33*conj[\[Lambda]]*conj[ZV[gt3, 3]]*ZV[gt4, 6]))/2, 1}}, 
 {{Ah[{gt1}], Hpm[{gt2}], Su[{gt3, ct3}], conj[Sd[{gt4, ct4}]]}, 
  {(Delta[ct3, ct4]*(conj[ZA[gt1, 3]]*
       (-2*\[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
             conj[ZU[gt3, 3 + j1]]]*ZD[gt4, j2]]*ZP[gt2, 1] + 
        2*conj[\[Lambda]]*sum[j2, 1, 3, conj[ZU[gt3, j2]]*
           sum[j1, 1, 3, Yd[j1, j2]*ZD[gt4, 3 + j1]]]*ZP[gt2, 2]) - 
      conj[ZA[gt1, 1]]*(g2^2*sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZD[gt4, j1]]*
         ZP[gt2, 1] - 2*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt3, j2]]*
             sum[j1, 1, 3, conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZD[gt4, j3]]*
         ZP[gt2, 1] + 2*sum[j3, 1, 3, conj[ZU[gt3, 3 + j3]]*
           sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j3, j1]]*Yd[j2, j1]]*
             ZD[gt4, 3 + j2]]]*ZP[gt2, 2]) + conj[ZA[gt1, 2]]*
       (2*sum[j3, 1, 3, conj[ZU[gt3, 3 + j3]]*sum[j2, 1, 3, 
            sum[j1, 1, 3, conj[Yu[j3, j1]]*Yd[j2, j1]]*ZD[gt4, 3 + j2]]]*
         ZP[gt2, 1] + (g2^2*sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZD[gt4, j1]] - 
          2*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt3, j2]]*sum[j1, 1, 3, 
                conj[Yu[j1, j3]]*Yu[j1, j2]]]*ZD[gt4, j3]])*ZP[gt2, 2])))/
    (2*Sqrt[2]), 1}}, {{Ah[{gt1}], Hpm[{gt2}], Sv[{gt3}], conj[Se[{gt4}]]}, 
  {(-2*\[Lambda]*conj[Yv22]*conj[ZA[gt1, 3]]*conj[ZV[gt3, 5]]*ZE[gt4, 2]*
      ZP[gt2, 1] - 2*\[Lambda]*conj[Yv33]*conj[ZA[gt1, 3]]*conj[ZV[gt3, 6]]*
      ZE[gt4, 3]*ZP[gt2, 1] + 2*Ye22*conj[Yv22]*conj[ZA[gt1, 2]]*
      conj[ZV[gt3, 5]]*ZE[gt4, 5]*ZP[gt2, 1] + 2*Ye33*conj[Yv33]*
      conj[ZA[gt1, 2]]*conj[ZV[gt3, 6]]*ZE[gt4, 6]*ZP[gt2, 1] + 
     g2^2*conj[ZA[gt1, 2]]*conj[ZV[gt3, 1]]*ZE[gt4, 1]*ZP[gt2, 2] + 
     g2^2*conj[ZA[gt1, 2]]*conj[ZV[gt3, 2]]*ZE[gt4, 2]*ZP[gt2, 2] - 
     2*Yv22*conj[Yv22]*conj[ZA[gt1, 2]]*conj[ZV[gt3, 2]]*ZE[gt4, 2]*
      ZP[gt2, 2] + g2^2*conj[ZA[gt1, 2]]*conj[ZV[gt3, 3]]*ZE[gt4, 3]*
      ZP[gt2, 2] - 2*Yv33*conj[Yv33]*conj[ZA[gt1, 2]]*conj[ZV[gt3, 3]]*
      ZE[gt4, 3]*ZP[gt2, 2] + 2*Ye11*conj[\[Lambda]]*conj[ZA[gt1, 3]]*
      conj[ZV[gt3, 1]]*ZE[gt4, 4]*ZP[gt2, 2] + 2*Ye22*conj[\[Lambda]]*
      conj[ZA[gt1, 3]]*conj[ZV[gt3, 2]]*ZE[gt4, 5]*ZP[gt2, 2] + 
     2*Ye33*conj[\[Lambda]]*conj[ZA[gt1, 3]]*conj[ZV[gt3, 3]]*ZE[gt4, 6]*
      ZP[gt2, 2] - conj[ZA[gt1, 1]]*((g2^2 - 2*Ye11*conj[Ye11])*
        conj[ZV[gt3, 1]]*ZE[gt4, 1]*ZP[gt2, 1] + (g2^2 - 2*Ye22*conj[Ye22])*
        conj[ZV[gt3, 2]]*ZE[gt4, 2]*ZP[gt2, 1] + g2^2*conj[ZV[gt3, 3]]*
        ZE[gt4, 3]*ZP[gt2, 1] - 2*Ye33*conj[Ye33]*conj[ZV[gt3, 3]]*ZE[gt4, 3]*
        ZP[gt2, 1] + 2*Ye11*conj[Yv11]*conj[ZV[gt3, 4]]*ZE[gt4, 4]*
        ZP[gt2, 2] + 2*Ye22*conj[Yv22]*conj[ZV[gt3, 5]]*ZE[gt4, 5]*
        ZP[gt2, 2] + 2*Ye33*conj[Yv33]*conj[ZV[gt3, 6]]*ZE[gt4, 6]*
        ZP[gt2, 2]) - 2*conj[Yv11]*(\[Lambda]*conj[ZA[gt1, 3]]*
        conj[ZV[gt3, 4]]*ZE[gt4, 1]*ZP[gt2, 1] + conj[ZA[gt1, 2]]*
        (-(Ye11*conj[ZV[gt3, 4]]*ZE[gt4, 4]*ZP[gt2, 1]) + 
         Yv11*conj[ZV[gt3, 1]]*ZE[gt4, 1]*ZP[gt2, 2])))/(2*Sqrt[2]), 1}}, 
 {{Ah[{gt1}], Sd[{gt2, ct2}], conj[Hpm[{gt3}]], conj[Su[{gt4, ct4}]]}, 
  {(Delta[ct2, ct4]*(2*conj[\[Lambda]]*conj[ZA[gt1, 3]]*
       sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, Yu[j1, j2]*
           ZU[gt4, 3 + j1]]]*ZP[gt3, 1] - 2*conj[ZA[gt1, 2]]*
       sum[j3, 1, 3, conj[ZD[gt2, 3 + j3]]*sum[j2, 1, 3, 
          sum[j1, 1, 3, conj[Yd[j3, j1]]*Yu[j2, j1]]*ZU[gt4, 3 + j2]]]*
       ZP[gt3, 1] - g2^2*conj[ZA[gt1, 2]]*sum[j1, 1, 3, 
        conj[ZD[gt2, j1]]*ZU[gt4, j1]]*ZP[gt3, 2] - 
      2*\[Lambda]*conj[ZA[gt1, 3]]*sum[j2, 1, 3, 
        sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt2, 3 + j1]]]*ZU[gt4, j2]]*
       ZP[gt3, 2] + 2*conj[ZA[gt1, 2]]*sum[j3, 1, 3, 
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, conj[Yu[j1, j3]]*
             Yu[j1, j2]]]*ZU[gt4, j3]]*ZP[gt3, 2] + 
      conj[ZA[gt1, 1]]*(g2^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZU[gt4, j1]]*
         ZP[gt3, 1] - 2*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZD[gt2, j2]]*
             sum[j1, 1, 3, conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZU[gt4, j3]]*
         ZP[gt3, 1] + 2*sum[j3, 1, 3, conj[ZD[gt2, 3 + j3]]*
           sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j3, j1]]*Yu[j2, j1]]*
             ZU[gt4, 3 + j2]]]*ZP[gt3, 2])))/(2*Sqrt[2]), 1}}, 
 {{Ah[{gt1}], Se[{gt2}], conj[Hpm[{gt3}]], conj[Sv[{gt4}]]}, 
  {(2*conj[ZA[gt1, 3]]*(-(\[Lambda]*conj[Ye11]*conj[ZE[gt2, 4]]*ZP[gt3, 2]*
         ZV[gt4, 1]) - \[Lambda]*conj[Ye22]*conj[ZE[gt2, 5]]*ZP[gt3, 2]*
        ZV[gt4, 2] - \[Lambda]*conj[Ye33]*conj[ZE[gt2, 6]]*ZP[gt3, 2]*
        ZV[gt4, 3] + Yv11*conj[\[Lambda]]*conj[ZE[gt2, 1]]*ZP[gt3, 1]*
        ZV[gt4, 4] + Yv22*conj[\[Lambda]]*conj[ZE[gt2, 2]]*ZP[gt3, 1]*
        ZV[gt4, 5] + Yv33*conj[\[Lambda]]*conj[ZE[gt2, 3]]*ZP[gt3, 1]*
        ZV[gt4, 6]) - conj[ZA[gt1, 2]]*((g2^2 - 2*Yv11*conj[Yv11])*
        conj[ZE[gt2, 1]]*ZP[gt3, 2]*ZV[gt4, 1] + (g2^2 - 2*Yv22*conj[Yv22])*
        conj[ZE[gt2, 2]]*ZP[gt3, 2]*ZV[gt4, 2] + g2^2*conj[ZE[gt2, 3]]*
        ZP[gt3, 2]*ZV[gt4, 3] - 2*Yv33*conj[Yv33]*conj[ZE[gt2, 3]]*ZP[gt3, 2]*
        ZV[gt4, 3] + 2*Yv11*conj[Ye11]*conj[ZE[gt2, 4]]*ZP[gt3, 1]*
        ZV[gt4, 4] + 2*Yv22*conj[Ye22]*conj[ZE[gt2, 5]]*ZP[gt3, 1]*
        ZV[gt4, 5] + 2*Yv33*conj[Ye33]*conj[ZE[gt2, 6]]*ZP[gt3, 1]*
        ZV[gt4, 6]) + conj[ZA[gt1, 1]]*((g2^2 - 2*Ye11*conj[Ye11])*
        conj[ZE[gt2, 1]]*ZP[gt3, 1]*ZV[gt4, 1] + (g2^2 - 2*Ye22*conj[Ye22])*
        conj[ZE[gt2, 2]]*ZP[gt3, 1]*ZV[gt4, 2] + g2^2*conj[ZE[gt2, 3]]*
        ZP[gt3, 1]*ZV[gt4, 3] - 2*Ye33*conj[Ye33]*conj[ZE[gt2, 3]]*ZP[gt3, 1]*
        ZV[gt4, 3] + 2*Yv11*conj[Ye11]*conj[ZE[gt2, 4]]*ZP[gt3, 2]*
        ZV[gt4, 4] + 2*Yv22*conj[Ye22]*conj[ZE[gt2, 5]]*ZP[gt3, 2]*
        ZV[gt4, 5] + 2*Yv33*conj[Ye33]*conj[ZE[gt2, 6]]*ZP[gt3, 2]*
        ZV[gt4, 6]))/(2*Sqrt[2]), 1}}, 
 {{hh[{gt1}], hh[{gt2}], hh[{gt3}], hh[{gt4}]}, 
  {(-I/4)*(4*conj[ZH[gt1, 3]]*((gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*
        conj[ZH[gt2, 1]]*(conj[ZH[gt3, 3]]*conj[ZH[gt4, 1]] + 
         conj[ZH[gt3, 1]]*conj[ZH[gt4, 3]]) + 
       (gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt2, 2]]*
        (conj[ZH[gt3, 3]]*conj[ZH[gt4, 2]] + conj[ZH[gt3, 2]]*
          conj[ZH[gt4, 3]]) + conj[ZH[gt2, 3]]*
        ((gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]]*
          conj[ZH[gt4, 1]] + (gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*
          conj[ZH[gt3, 2]]*conj[ZH[gt4, 2]] + 3*gp^2*Qs^2*conj[ZH[gt3, 3]]*
          conj[ZH[gt4, 3]])) + conj[ZH[gt1, 1]]*
      (-((g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
         conj[ZH[gt2, 2]]*(conj[ZH[gt3, 2]]*conj[ZH[gt4, 1]] + 
          conj[ZH[gt3, 1]]*conj[ZH[gt4, 2]])) + 
       4*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt2, 3]]*
        (conj[ZH[gt3, 3]]*conj[ZH[gt4, 1]] + conj[ZH[gt3, 1]]*
          conj[ZH[gt4, 3]]) + conj[ZH[gt2, 1]]*
        (3*(g1^2 + g2^2 + 4*gp^2*QHd^2)*conj[ZH[gt3, 1]]*conj[ZH[gt4, 1]] - 
         (g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
          conj[ZH[gt3, 2]]*conj[ZH[gt4, 2]] + 
         4*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]*
          conj[ZH[gt4, 3]])) + conj[ZH[gt1, 2]]*
      (-((g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
         conj[ZH[gt2, 1]]*(conj[ZH[gt3, 2]]*conj[ZH[gt4, 1]] + 
          conj[ZH[gt3, 1]]*conj[ZH[gt4, 2]])) + 
       4*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt2, 3]]*
        (conj[ZH[gt3, 3]]*conj[ZH[gt4, 2]] + conj[ZH[gt3, 2]]*
          conj[ZH[gt4, 3]]) + conj[ZH[gt2, 2]]*
        (-((g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
           conj[ZH[gt3, 1]]*conj[ZH[gt4, 1]]) + 
         3*(g1^2 + g2^2 + 4*gp^2*QHu^2)*conj[ZH[gt3, 2]]*conj[ZH[gt4, 2]] + 
         4*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]*
          conj[ZH[gt4, 3]]))), 1}}, 
 {{hh[{gt1}], hh[{gt2}], Hpm[{gt3}], conj[Hpm[{gt4}]]}, 
  {(-I/4)*(4*conj[ZH[gt1, 3]]*conj[ZH[gt2, 3]]*
      ((gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*ZP[gt3, 1]*ZP[gt4, 1] + 
       (gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*ZP[gt3, 2]*ZP[gt4, 2]) + 
     conj[ZH[gt1, 1]]*((g2^2 - 2*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt2, 2]]*
        (ZP[gt3, 2]*ZP[gt4, 1] + ZP[gt3, 1]*ZP[gt4, 2]) + 
       conj[ZH[gt2, 1]]*((g1^2 + g2^2 + 4*gp^2*QHd^2)*ZP[gt3, 1]*ZP[gt4, 1] + 
         (-g1^2 + g2^2 + 4*gp^2*QHd*QHu)*ZP[gt3, 2]*ZP[gt4, 2])) + 
     conj[ZH[gt1, 2]]*((g2^2 - 2*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt2, 1]]*
        (ZP[gt3, 2]*ZP[gt4, 1] + ZP[gt3, 1]*ZP[gt4, 2]) + 
       conj[ZH[gt2, 2]]*((-g1^2 + g2^2 + 4*gp^2*QHd*QHu)*ZP[gt3, 1]*
          ZP[gt4, 1] + (g1^2 + g2^2 + 4*gp^2*QHu^2)*ZP[gt3, 2]*ZP[gt4, 2]))), 
   1}}, {{hh[{gt1}], hh[{gt2}], Sd[{gt3, ct3}], conj[Sd[{gt4, ct4}]]}, 
  {(I/12)*Delta[ct3, ct4]*(6*conj[ZH[gt1, 3]]*
      (-2*gp^2*Qs*conj[ZH[gt2, 3]]*(Qq*sum[j1, 1, 3, conj[ZD[gt3, j1]]*
            ZD[gt4, j1]] + Qd*sum[j1, 1, 3, conj[ZD[gt3, 3 + j1]]*
            ZD[gt4, 3 + j1]]) + conj[ZH[gt2, 2]]*
        (conj[\[Lambda]]*sum[j2, 1, 3, conj[ZD[gt3, j2]]*sum[j1, 1, 3, 
             Yd[j1, j2]*ZD[gt4, 3 + j1]]] + \[Lambda]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt3, 3 + j1]]]*
            ZD[gt4, j2]])) - conj[ZH[gt1, 2]]*
      (conj[ZH[gt2, 2]]*((g1^2 + 3*g2^2 + 12*gp^2*QHu*Qq)*
          sum[j1, 1, 3, conj[ZD[gt3, j1]]*ZD[gt4, j1]] + 
         2*(g1^2 + 6*gp^2*Qd*QHu)*sum[j1, 1, 3, conj[ZD[gt3, 3 + j1]]*
            ZD[gt4, 3 + j1]]) - 6*conj[ZH[gt2, 3]]*
        (conj[\[Lambda]]*sum[j2, 1, 3, conj[ZD[gt3, j2]]*sum[j1, 1, 3, 
             Yd[j1, j2]*ZD[gt4, 3 + j1]]] + \[Lambda]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt3, 3 + j1]]]*
            ZD[gt4, j2]])) + conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*
      ((g1^2 + 3*(g2^2 - 4*gp^2*QHd*Qq))*sum[j1, 1, 3, conj[ZD[gt3, j1]]*
          ZD[gt4, j1]] + 2*((g1^2 - 6*gp^2*Qd*QHd)*sum[j1, 1, 3, 
           conj[ZD[gt3, 3 + j1]]*ZD[gt4, 3 + j1]] - 
         6*(sum[j3, 1, 3, conj[ZD[gt3, 3 + j3]]*sum[j2, 1, 3, 
              sum[j1, 1, 3, conj[Yd[j3, j1]]*Yd[j2, j1]]*ZD[gt4, 3 + j2]]] + 
           sum[j3, 1, 3, sum[j2, 1, 3, conj[ZD[gt3, j2]]*sum[j1, 1, 3, 
                conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZD[gt4, j3]])))), 1}}, 
 {{hh[{gt1}], hh[{gt2}], Se[{gt3}], conj[Se[{gt4}]]}, 
  {(-I/4)*(g1^2*conj[ZE[gt3, 2]]*conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*
      ZE[gt4, 2] - g2^2*conj[ZE[gt3, 2]]*conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*
      ZE[gt4, 2] + 4*gp^2*QHd*Ql2*conj[ZE[gt3, 2]]*conj[ZH[gt1, 1]]*
      conj[ZH[gt2, 1]]*ZE[gt4, 2] + 4*Ye22*conj[Ye22]*conj[ZE[gt3, 2]]*
      conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*ZE[gt4, 2] - 
     g1^2*conj[ZE[gt3, 2]]*conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*ZE[gt4, 2] + 
     g2^2*conj[ZE[gt3, 2]]*conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*ZE[gt4, 2] + 
     4*gp^2*QHu*Ql2*conj[ZE[gt3, 2]]*conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*
      ZE[gt4, 2] - 2*\[Lambda]*conj[Ye22]*conj[ZE[gt3, 5]]*conj[ZH[gt1, 3]]*
      conj[ZH[gt2, 2]]*ZE[gt4, 2] - 2*\[Lambda]*conj[Ye22]*conj[ZE[gt3, 5]]*
      conj[ZH[gt1, 2]]*conj[ZH[gt2, 3]]*ZE[gt4, 2] + 
     4*gp^2*Ql2*Qs*conj[ZE[gt3, 2]]*conj[ZH[gt1, 3]]*conj[ZH[gt2, 3]]*
      ZE[gt4, 2] + g1^2*conj[ZE[gt3, 3]]*conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*
      ZE[gt4, 3] - g2^2*conj[ZE[gt3, 3]]*conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*
      ZE[gt4, 3] + 4*gp^2*QHd*Ql3*conj[ZE[gt3, 3]]*conj[ZH[gt1, 1]]*
      conj[ZH[gt2, 1]]*ZE[gt4, 3] + 4*Ye33*conj[Ye33]*conj[ZE[gt3, 3]]*
      conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*ZE[gt4, 3] - 
     g1^2*conj[ZE[gt3, 3]]*conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*ZE[gt4, 3] + 
     g2^2*conj[ZE[gt3, 3]]*conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*ZE[gt4, 3] + 
     4*gp^2*QHu*Ql3*conj[ZE[gt3, 3]]*conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*
      ZE[gt4, 3] - 2*\[Lambda]*conj[Ye33]*conj[ZE[gt3, 6]]*conj[ZH[gt1, 3]]*
      conj[ZH[gt2, 2]]*ZE[gt4, 3] - 2*\[Lambda]*conj[Ye33]*conj[ZE[gt3, 6]]*
      conj[ZH[gt1, 2]]*conj[ZH[gt2, 3]]*ZE[gt4, 3] + 
     4*gp^2*Ql3*Qs*conj[ZE[gt3, 3]]*conj[ZH[gt1, 3]]*conj[ZH[gt2, 3]]*
      ZE[gt4, 3] - 2*g1^2*conj[ZE[gt3, 4]]*conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*
      ZE[gt4, 4] + 4*gp^2*Qe1*QHd*conj[ZE[gt3, 4]]*conj[ZH[gt1, 1]]*
      conj[ZH[gt2, 1]]*ZE[gt4, 4] + 2*g1^2*conj[ZE[gt3, 4]]*conj[ZH[gt1, 2]]*
      conj[ZH[gt2, 2]]*ZE[gt4, 4] + 4*gp^2*Qe1*QHu*conj[ZE[gt3, 4]]*
      conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*ZE[gt4, 4] + 
     4*gp^2*Qe1*Qs*conj[ZE[gt3, 4]]*conj[ZH[gt1, 3]]*conj[ZH[gt2, 3]]*
      ZE[gt4, 4] - 2*conj[Ye11]*conj[ZE[gt3, 4]]*
      (\[Lambda]*conj[ZH[gt1, 3]]*conj[ZH[gt2, 2]]*ZE[gt4, 1] + 
       \[Lambda]*conj[ZH[gt1, 2]]*conj[ZH[gt2, 3]]*ZE[gt4, 1] - 
       2*Ye11*conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*ZE[gt4, 4]) + 
     conj[ZE[gt3, 1]]*((g1^2 - g2^2 + 4*gp^2*QHd*Ql1 + 4*Ye11*conj[Ye11])*
        conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*ZE[gt4, 1] + 
       2*conj[ZH[gt1, 3]]*(2*gp^2*Ql1*Qs*conj[ZH[gt2, 3]]*ZE[gt4, 1] - 
         Ye11*conj[\[Lambda]]*conj[ZH[gt2, 2]]*ZE[gt4, 4]) + 
       conj[ZH[gt1, 2]]*((-g1^2 + g2^2 + 4*gp^2*QHu*Ql1)*conj[ZH[gt2, 2]]*
          ZE[gt4, 1] - 2*Ye11*conj[\[Lambda]]*conj[ZH[gt2, 3]]*ZE[gt4, 4])) - 
     2*g1^2*conj[ZE[gt3, 5]]*conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*ZE[gt4, 5] + 
     4*gp^2*Qe2*QHd*conj[ZE[gt3, 5]]*conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*
      ZE[gt4, 5] + 4*Ye22*conj[Ye22]*conj[ZE[gt3, 5]]*conj[ZH[gt1, 1]]*
      conj[ZH[gt2, 1]]*ZE[gt4, 5] + 2*g1^2*conj[ZE[gt3, 5]]*conj[ZH[gt1, 2]]*
      conj[ZH[gt2, 2]]*ZE[gt4, 5] + 4*gp^2*Qe2*QHu*conj[ZE[gt3, 5]]*
      conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*ZE[gt4, 5] - 
     2*Ye22*conj[\[Lambda]]*conj[ZE[gt3, 2]]*conj[ZH[gt1, 3]]*
      conj[ZH[gt2, 2]]*ZE[gt4, 5] - 2*Ye22*conj[\[Lambda]]*conj[ZE[gt3, 2]]*
      conj[ZH[gt1, 2]]*conj[ZH[gt2, 3]]*ZE[gt4, 5] + 
     4*gp^2*Qe2*Qs*conj[ZE[gt3, 5]]*conj[ZH[gt1, 3]]*conj[ZH[gt2, 3]]*
      ZE[gt4, 5] - 2*g1^2*conj[ZE[gt3, 6]]*conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*
      ZE[gt4, 6] + 4*gp^2*Qe3*QHd*conj[ZE[gt3, 6]]*conj[ZH[gt1, 1]]*
      conj[ZH[gt2, 1]]*ZE[gt4, 6] + 4*Ye33*conj[Ye33]*conj[ZE[gt3, 6]]*
      conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*ZE[gt4, 6] + 
     2*g1^2*conj[ZE[gt3, 6]]*conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*ZE[gt4, 6] + 
     4*gp^2*Qe3*QHu*conj[ZE[gt3, 6]]*conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*
      ZE[gt4, 6] - 2*Ye33*conj[\[Lambda]]*conj[ZE[gt3, 3]]*conj[ZH[gt1, 3]]*
      conj[ZH[gt2, 2]]*ZE[gt4, 6] - 2*Ye33*conj[\[Lambda]]*conj[ZE[gt3, 3]]*
      conj[ZH[gt1, 2]]*conj[ZH[gt2, 3]]*ZE[gt4, 6] + 
     4*gp^2*Qe3*Qs*conj[ZE[gt3, 6]]*conj[ZH[gt1, 3]]*conj[ZH[gt2, 3]]*
      ZE[gt4, 6]), 1}}, {{hh[{gt1}], hh[{gt2}], Su[{gt3, ct3}], 
   conj[Su[{gt4, ct4}]]}, {(I/12)*Delta[ct3, ct4]*
    (6*conj[ZH[gt1, 3]]*(-2*gp^2*Qs*conj[ZH[gt2, 3]]*
        (Qq*sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZU[gt4, j1]] + 
         Qu*sum[j1, 1, 3, conj[ZU[gt3, 3 + j1]]*ZU[gt4, 3 + j1]]) + 
       conj[ZH[gt2, 1]]*(conj[\[Lambda]]*sum[j2, 1, 3, conj[ZU[gt3, j2]]*
            sum[j1, 1, 3, Yu[j1, j2]*ZU[gt4, 3 + j1]]] + 
         \[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
              conj[ZU[gt3, 3 + j1]]]*ZU[gt4, j2]])) + 
     conj[ZH[gt1, 1]]*(conj[ZH[gt2, 1]]*((g1^2 - 3*(g2^2 + 4*gp^2*QHd*Qq))*
          sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZU[gt4, j1]] - 
         4*(g1^2 + 3*gp^2*QHd*Qu)*sum[j1, 1, 3, conj[ZU[gt3, 3 + j1]]*
            ZU[gt4, 3 + j1]]) + 6*conj[ZH[gt2, 3]]*
        (conj[\[Lambda]]*sum[j2, 1, 3, conj[ZU[gt3, j2]]*sum[j1, 1, 3, 
             Yu[j1, j2]*ZU[gt4, 3 + j1]]] + \[Lambda]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt3, 3 + j1]]]*
            ZU[gt4, j2]])) - conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*
      ((g1^2 - 3*g2^2 + 12*gp^2*QHu*Qq)*sum[j1, 1, 3, conj[ZU[gt3, j1]]*
          ZU[gt4, j1]] - 4*(g1^2 - 3*gp^2*QHu*Qu)*sum[j1, 1, 3, 
         conj[ZU[gt3, 3 + j1]]*ZU[gt4, 3 + j1]] + 
       12*(sum[j3, 1, 3, conj[ZU[gt3, 3 + j3]]*sum[j2, 1, 3, 
            sum[j1, 1, 3, conj[Yu[j3, j1]]*Yu[j2, j1]]*ZU[gt4, 3 + j2]]] + 
         sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt3, j2]]*sum[j1, 1, 3, 
              conj[Yu[j1, j3]]*Yu[j1, j2]]]*ZU[gt4, j3]]))), 1}}, 
 {{hh[{gt1}], hh[{gt2}], Sv[{gt3}], conj[Sv[{gt4}]]}, 
  {(-I/4)*(conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*
      (-((g1^2 + g2^2 - 4*gp^2*QHu*Ql1 - 4*Yv11*conj[Yv11])*conj[ZV[gt3, 1]]*
         ZV[gt4, 1]) - (g1^2 + g2^2 - 4*gp^2*QHu*Ql2 - 4*Yv22*conj[Yv22])*
        conj[ZV[gt3, 2]]*ZV[gt4, 2] - g1^2*conj[ZV[gt3, 3]]*ZV[gt4, 3] - 
       g2^2*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 4*gp^2*QHu*Ql3*conj[ZV[gt3, 3]]*
        ZV[gt4, 3] + 4*Yv33*conj[Yv33]*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 
       4*gp^2*QHu*Qv1*conj[ZV[gt3, 4]]*ZV[gt4, 4] + 4*Yv11*conj[Yv11]*
        conj[ZV[gt3, 4]]*ZV[gt4, 4] + 4*gp^2*QHu*Qv2*conj[ZV[gt3, 5]]*
        ZV[gt4, 5] + 4*Yv22*conj[Yv22]*conj[ZV[gt3, 5]]*ZV[gt4, 5] + 
       4*gp^2*QHu*Qv3*conj[ZV[gt3, 6]]*ZV[gt4, 6] + 4*Yv33*conj[Yv33]*
        conj[ZV[gt3, 6]]*ZV[gt4, 6]) + 2*conj[ZH[gt1, 3]]*
      (-(conj[ZH[gt2, 1]]*(\[Lambda]*conj[Yv11]*conj[ZV[gt3, 4]]*ZV[gt4, 1] + 
          \[Lambda]*conj[Yv22]*conj[ZV[gt3, 5]]*ZV[gt4, 2] + 
          \[Lambda]*conj[Yv33]*conj[ZV[gt3, 6]]*ZV[gt4, 3] + 
          Yv11*conj[\[Lambda]]*conj[ZV[gt3, 1]]*ZV[gt4, 4] + 
          Yv22*conj[\[Lambda]]*conj[ZV[gt3, 2]]*ZV[gt4, 5] + 
          Yv33*conj[\[Lambda]]*conj[ZV[gt3, 3]]*ZV[gt4, 6])) + 
       2*gp^2*Qs*conj[ZH[gt2, 3]]*(Ql1*conj[ZV[gt3, 1]]*ZV[gt4, 1] + 
         Ql2*conj[ZV[gt3, 2]]*ZV[gt4, 2] + Ql3*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 
         Qv1*conj[ZV[gt3, 4]]*ZV[gt4, 4] + Qv2*conj[ZV[gt3, 5]]*ZV[gt4, 5] + 
         Qv3*conj[ZV[gt3, 6]]*ZV[gt4, 6])) + conj[ZH[gt1, 1]]*
      (-2*conj[ZH[gt2, 3]]*(\[Lambda]*conj[Yv11]*conj[ZV[gt3, 4]]*
          ZV[gt4, 1] + \[Lambda]*conj[Yv22]*conj[ZV[gt3, 5]]*ZV[gt4, 2] + 
         \[Lambda]*conj[Yv33]*conj[ZV[gt3, 6]]*ZV[gt4, 3] + 
         Yv11*conj[\[Lambda]]*conj[ZV[gt3, 1]]*ZV[gt4, 4] + 
         Yv22*conj[\[Lambda]]*conj[ZV[gt3, 2]]*ZV[gt4, 5] + 
         Yv33*conj[\[Lambda]]*conj[ZV[gt3, 3]]*ZV[gt4, 6]) + 
       conj[ZH[gt2, 1]]*((g1^2 + g2^2 + 4*gp^2*QHd*Ql1)*conj[ZV[gt3, 1]]*
          ZV[gt4, 1] + (g1^2 + g2^2 + 4*gp^2*QHd*Ql2)*conj[ZV[gt3, 2]]*
          ZV[gt4, 2] + g1^2*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 
         g2^2*conj[ZV[gt3, 3]]*ZV[gt4, 3] + 4*gp^2*QHd*Ql3*conj[ZV[gt3, 3]]*
          ZV[gt4, 3] + 4*gp^2*QHd*Qv1*conj[ZV[gt3, 4]]*ZV[gt4, 4] + 
         4*gp^2*QHd*Qv2*conj[ZV[gt3, 5]]*ZV[gt4, 5] + 4*gp^2*QHd*Qv3*
          conj[ZV[gt3, 6]]*ZV[gt4, 6]))), 1}}, 
 {{hh[{gt1}], Hpm[{gt2}], Su[{gt3, ct3}], conj[Sd[{gt4, ct4}]]}, 
  {((I/2)*Delta[ct3, ct4]*(2*conj[ZH[gt1, 3]]*
       (\[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
             conj[ZU[gt3, 3 + j1]]]*ZD[gt4, j2]]*ZP[gt2, 1] + 
        conj[\[Lambda]]*sum[j2, 1, 3, conj[ZU[gt3, j2]]*sum[j1, 1, 3, 
            Yd[j1, j2]*ZD[gt4, 3 + j1]]]*ZP[gt2, 2]) + 
      conj[ZH[gt1, 1]]*(-(g2^2*sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZD[gt4, j1]]*
          ZP[gt2, 1]) + 2*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt3, j2]]*
             sum[j1, 1, 3, conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZD[gt4, j3]]*
         ZP[gt2, 1] + 2*sum[j3, 1, 3, conj[ZU[gt3, 3 + j3]]*
           sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j3, j1]]*Yd[j2, j1]]*
             ZD[gt4, 3 + j2]]]*ZP[gt2, 2]) + conj[ZH[gt1, 2]]*
       (2*sum[j3, 1, 3, conj[ZU[gt3, 3 + j3]]*sum[j2, 1, 3, 
            sum[j1, 1, 3, conj[Yu[j3, j1]]*Yd[j2, j1]]*ZD[gt4, 3 + j2]]]*
         ZP[gt2, 1] + (-(g2^2*sum[j1, 1, 3, conj[ZU[gt3, j1]]*ZD[gt4, j1]]) + 
          2*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt3, j2]]*sum[j1, 1, 3, 
                conj[Yu[j1, j3]]*Yu[j1, j2]]]*ZD[gt4, j3]])*ZP[gt2, 2])))/
    Sqrt[2], 1}}, {{hh[{gt1}], Hpm[{gt2}], Sv[{gt3}], conj[Se[{gt4}]]}, 
  {((I/2)*(2*\[Lambda]*conj[Yv22]*conj[ZH[gt1, 3]]*conj[ZV[gt3, 5]]*
       ZE[gt4, 2]*ZP[gt2, 1] + 2*\[Lambda]*conj[Yv33]*conj[ZH[gt1, 3]]*
       conj[ZV[gt3, 6]]*ZE[gt4, 3]*ZP[gt2, 1] + 2*Ye22*conj[Yv22]*
       conj[ZH[gt1, 2]]*conj[ZV[gt3, 5]]*ZE[gt4, 5]*ZP[gt2, 1] + 
      2*Ye33*conj[Yv33]*conj[ZH[gt1, 2]]*conj[ZV[gt3, 6]]*ZE[gt4, 6]*
       ZP[gt2, 1] - g2^2*conj[ZH[gt1, 2]]*conj[ZV[gt3, 1]]*ZE[gt4, 1]*
       ZP[gt2, 2] - g2^2*conj[ZH[gt1, 2]]*conj[ZV[gt3, 2]]*ZE[gt4, 2]*
       ZP[gt2, 2] + 2*Yv22*conj[Yv22]*conj[ZH[gt1, 2]]*conj[ZV[gt3, 2]]*
       ZE[gt4, 2]*ZP[gt2, 2] - g2^2*conj[ZH[gt1, 2]]*conj[ZV[gt3, 3]]*
       ZE[gt4, 3]*ZP[gt2, 2] + 2*Yv33*conj[Yv33]*conj[ZH[gt1, 2]]*
       conj[ZV[gt3, 3]]*ZE[gt4, 3]*ZP[gt2, 2] + 2*Ye11*conj[\[Lambda]]*
       conj[ZH[gt1, 3]]*conj[ZV[gt3, 1]]*ZE[gt4, 4]*ZP[gt2, 2] + 
      2*Ye22*conj[\[Lambda]]*conj[ZH[gt1, 3]]*conj[ZV[gt3, 2]]*ZE[gt4, 5]*
       ZP[gt2, 2] + 2*Ye33*conj[\[Lambda]]*conj[ZH[gt1, 3]]*conj[ZV[gt3, 3]]*
       ZE[gt4, 6]*ZP[gt2, 2] + conj[ZH[gt1, 1]]*
       (-((g2^2 - 2*Ye11*conj[Ye11])*conj[ZV[gt3, 1]]*ZE[gt4, 1]*
          ZP[gt2, 1]) - (g2^2 - 2*Ye22*conj[Ye22])*conj[ZV[gt3, 2]]*
         ZE[gt4, 2]*ZP[gt2, 1] - g2^2*conj[ZV[gt3, 3]]*ZE[gt4, 3]*
         ZP[gt2, 1] + 2*Ye33*conj[Ye33]*conj[ZV[gt3, 3]]*ZE[gt4, 3]*
         ZP[gt2, 1] + 2*Ye11*conj[Yv11]*conj[ZV[gt3, 4]]*ZE[gt4, 4]*
         ZP[gt2, 2] + 2*Ye22*conj[Yv22]*conj[ZV[gt3, 5]]*ZE[gt4, 5]*
         ZP[gt2, 2] + 2*Ye33*conj[Yv33]*conj[ZV[gt3, 6]]*ZE[gt4, 6]*
         ZP[gt2, 2]) + 2*conj[Yv11]*(\[Lambda]*conj[ZH[gt1, 3]]*
         conj[ZV[gt3, 4]]*ZE[gt4, 1]*ZP[gt2, 1] + conj[ZH[gt1, 2]]*
         (Ye11*conj[ZV[gt3, 4]]*ZE[gt4, 4]*ZP[gt2, 1] + Yv11*conj[ZV[gt3, 1]]*
           ZE[gt4, 1]*ZP[gt2, 2]))))/Sqrt[2], 1}}, 
 {{hh[{gt1}], Sd[{gt2, ct2}], conj[Hpm[{gt3}]], conj[Su[{gt4, ct4}]]}, 
  {((I/2)*Delta[ct2, ct4]*(2*conj[\[Lambda]]*conj[ZH[gt1, 3]]*
       sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, Yu[j1, j2]*
           ZU[gt4, 3 + j1]]]*ZP[gt3, 1] + 2*conj[ZH[gt1, 2]]*
       sum[j3, 1, 3, conj[ZD[gt2, 3 + j3]]*sum[j2, 1, 3, 
          sum[j1, 1, 3, conj[Yd[j3, j1]]*Yu[j2, j1]]*ZU[gt4, 3 + j2]]]*
       ZP[gt3, 1] - g2^2*conj[ZH[gt1, 2]]*sum[j1, 1, 3, 
        conj[ZD[gt2, j1]]*ZU[gt4, j1]]*ZP[gt3, 2] + 
      2*\[Lambda]*conj[ZH[gt1, 3]]*sum[j2, 1, 3, 
        sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt2, 3 + j1]]]*ZU[gt4, j2]]*
       ZP[gt3, 2] + 2*conj[ZH[gt1, 2]]*sum[j3, 1, 3, 
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, conj[Yu[j1, j3]]*
             Yu[j1, j2]]]*ZU[gt4, j3]]*ZP[gt3, 2] + 
      conj[ZH[gt1, 1]]*(-(g2^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZU[gt4, j1]]*
          ZP[gt3, 1]) + 2*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZD[gt2, j2]]*
             sum[j1, 1, 3, conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZU[gt4, j3]]*
         ZP[gt3, 1] + 2*sum[j3, 1, 3, conj[ZD[gt2, 3 + j3]]*
           sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j3, j1]]*Yu[j2, j1]]*
             ZU[gt4, 3 + j2]]]*ZP[gt3, 2])))/Sqrt[2], 1}}, 
 {{hh[{gt1}], Se[{gt2}], conj[Hpm[{gt3}]], conj[Sv[{gt4}]]}, 
  {((-I/2)*(g2^2*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZP[gt3, 1]*ZV[gt4, 2] - 
      2*Ye22*conj[Ye22]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZP[gt3, 1]*
       ZV[gt4, 2] + g2^2*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZP[gt3, 2]*
       ZV[gt4, 2] - 2*Yv22*conj[Yv22]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*
       ZP[gt3, 2]*ZV[gt4, 2] - 2*\[Lambda]*conj[Ye22]*conj[ZE[gt2, 5]]*
       conj[ZH[gt1, 3]]*ZP[gt3, 2]*ZV[gt4, 2] + g2^2*conj[ZE[gt2, 3]]*
       conj[ZH[gt1, 1]]*ZP[gt3, 1]*ZV[gt4, 3] - 2*Ye33*conj[Ye33]*
       conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*ZP[gt3, 1]*ZV[gt4, 3] + 
      g2^2*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZP[gt3, 2]*ZV[gt4, 3] - 
      2*Yv33*conj[Yv33]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZP[gt3, 2]*
       ZV[gt4, 3] - 2*\[Lambda]*conj[Ye33]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 3]]*
       ZP[gt3, 2]*ZV[gt4, 3] + conj[ZE[gt2, 1]]*
       ((g2^2 - 2*Ye11*conj[Ye11])*conj[ZH[gt1, 1]]*ZP[gt3, 1]*ZV[gt4, 1] + 
        (g2^2 - 2*Yv11*conj[Yv11])*conj[ZH[gt1, 2]]*ZP[gt3, 2]*ZV[gt4, 1] - 
        2*Yv11*conj[\[Lambda]]*conj[ZH[gt1, 3]]*ZP[gt3, 1]*ZV[gt4, 4]) - 
      2*conj[Ye11]*conj[ZE[gt2, 4]]*(\[Lambda]*conj[ZH[gt1, 3]]*ZP[gt3, 2]*
         ZV[gt4, 1] + Yv11*(conj[ZH[gt1, 2]]*ZP[gt3, 1] + 
          conj[ZH[gt1, 1]]*ZP[gt3, 2])*ZV[gt4, 4]) - 
      2*Yv22*conj[Ye22]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 2]]*ZP[gt3, 1]*
       ZV[gt4, 5] - 2*Yv22*conj[\[Lambda]]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 3]]*
       ZP[gt3, 1]*ZV[gt4, 5] - 2*Yv22*conj[Ye22]*conj[ZE[gt2, 5]]*
       conj[ZH[gt1, 1]]*ZP[gt3, 2]*ZV[gt4, 5] - 2*Yv33*conj[Ye33]*
       conj[ZE[gt2, 6]]*conj[ZH[gt1, 2]]*ZP[gt3, 1]*ZV[gt4, 6] - 
      2*Yv33*conj[\[Lambda]]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 3]]*ZP[gt3, 1]*
       ZV[gt4, 6] - 2*Yv33*conj[Ye33]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 1]]*
       ZP[gt3, 2]*ZV[gt4, 6]))/Sqrt[2], 1}}, 
 {{Hpm[{gt1}], Hpm[{gt2}], conj[Hpm[{gt3}]], conj[Hpm[{gt4}]]}, 
  {(-I/4)*(ZP[gt1, 2]*(2*(g1^2 + g2^2 + 4*gp^2*QHu^2)*ZP[gt2, 2]*ZP[gt3, 2]*
        ZP[gt4, 2] - (g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
         4*\[Lambda]*conj[\[Lambda]])*ZP[gt2, 1]*(ZP[gt3, 2]*ZP[gt4, 1] + 
         ZP[gt3, 1]*ZP[gt4, 2])) + ZP[gt1, 1]*
      (2*(g1^2 + g2^2 + 4*gp^2*QHd^2)*ZP[gt2, 1]*ZP[gt3, 1]*ZP[gt4, 1] - 
       (g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
        ZP[gt2, 2]*(ZP[gt3, 2]*ZP[gt4, 1] + ZP[gt3, 1]*ZP[gt4, 2]))), 1}}, 
 {{Hpm[{gt1}], Sd[{gt2, ct2}], conj[Hpm[{gt3}]], conj[Sd[{gt4, ct4}]]}, 
  {(I/12)*Delta[ct2, ct4]*(sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt4, j1]]*
      ((g1^2 - 3*(g2^2 + 4*gp^2*QHd*Qq))*ZP[gt1, 1]*ZP[gt3, 1] - 
       (g1^2 - 3*g2^2 + 12*gp^2*QHu*Qq)*ZP[gt1, 2]*ZP[gt3, 2]) + 
     2*(sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt4, 3 + j1]]*
        ((g1^2 - 6*gp^2*Qd*QHd)*ZP[gt1, 1]*ZP[gt3, 1] - 
         (g1^2 + 6*gp^2*Qd*QHu)*ZP[gt1, 2]*ZP[gt3, 2]) - 
       6*(sum[j3, 1, 3, conj[ZD[gt2, 3 + j3]]*sum[j2, 1, 3, 
             sum[j1, 1, 3, conj[Yd[j3, j1]]*Yd[j2, j1]]*ZD[gt4, 3 + j2]]]*
          ZP[gt1, 1]*ZP[gt3, 1] + sum[j3, 1, 3, 
           sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, conj[Yu[j1, j3]]*
                Yu[j1, j2]]]*ZD[gt4, j3]]*ZP[gt1, 2]*ZP[gt3, 2]))), 1}}, 
 {{Hpm[{gt1}], Se[{gt2}], conj[Hpm[{gt3}]], conj[Se[{gt4}]]}, 
  {(-I/4)*(g1^2*conj[ZE[gt2, 3]]*ZE[gt4, 3]*ZP[gt1, 1]*ZP[gt3, 1] + 
     g2^2*conj[ZE[gt2, 3]]*ZE[gt4, 3]*ZP[gt1, 1]*ZP[gt3, 1] + 
     4*gp^2*QHd*Ql3*conj[ZE[gt2, 3]]*ZE[gt4, 3]*ZP[gt1, 1]*ZP[gt3, 1] - 
     2*g1^2*conj[ZE[gt2, 4]]*ZE[gt4, 4]*ZP[gt1, 1]*ZP[gt3, 1] + 
     4*gp^2*Qe1*QHd*conj[ZE[gt2, 4]]*ZE[gt4, 4]*ZP[gt1, 1]*ZP[gt3, 1] + 
     4*Ye11*conj[Ye11]*conj[ZE[gt2, 4]]*ZE[gt4, 4]*ZP[gt1, 1]*ZP[gt3, 1] - 
     2*g1^2*conj[ZE[gt2, 5]]*ZE[gt4, 5]*ZP[gt1, 1]*ZP[gt3, 1] + 
     4*gp^2*Qe2*QHd*conj[ZE[gt2, 5]]*ZE[gt4, 5]*ZP[gt1, 1]*ZP[gt3, 1] + 
     4*Ye22*conj[Ye22]*conj[ZE[gt2, 5]]*ZE[gt4, 5]*ZP[gt1, 1]*ZP[gt3, 1] - 
     2*g1^2*conj[ZE[gt2, 6]]*ZE[gt4, 6]*ZP[gt1, 1]*ZP[gt3, 1] + 
     4*gp^2*Qe3*QHd*conj[ZE[gt2, 6]]*ZE[gt4, 6]*ZP[gt1, 1]*ZP[gt3, 1] + 
     4*Ye33*conj[Ye33]*conj[ZE[gt2, 6]]*ZE[gt4, 6]*ZP[gt1, 1]*ZP[gt3, 1] - 
     g1^2*conj[ZE[gt2, 3]]*ZE[gt4, 3]*ZP[gt1, 2]*ZP[gt3, 2] - 
     g2^2*conj[ZE[gt2, 3]]*ZE[gt4, 3]*ZP[gt1, 2]*ZP[gt3, 2] + 
     4*gp^2*QHu*Ql3*conj[ZE[gt2, 3]]*ZE[gt4, 3]*ZP[gt1, 2]*ZP[gt3, 2] + 
     4*Yv33*conj[Yv33]*conj[ZE[gt2, 3]]*ZE[gt4, 3]*ZP[gt1, 2]*ZP[gt3, 2] + 
     2*g1^2*conj[ZE[gt2, 4]]*ZE[gt4, 4]*ZP[gt1, 2]*ZP[gt3, 2] + 
     4*gp^2*Qe1*QHu*conj[ZE[gt2, 4]]*ZE[gt4, 4]*ZP[gt1, 2]*ZP[gt3, 2] + 
     2*g1^2*conj[ZE[gt2, 5]]*ZE[gt4, 5]*ZP[gt1, 2]*ZP[gt3, 2] + 
     4*gp^2*Qe2*QHu*conj[ZE[gt2, 5]]*ZE[gt4, 5]*ZP[gt1, 2]*ZP[gt3, 2] + 
     2*g1^2*conj[ZE[gt2, 6]]*ZE[gt4, 6]*ZP[gt1, 2]*ZP[gt3, 2] + 
     4*gp^2*Qe3*QHu*conj[ZE[gt2, 6]]*ZE[gt4, 6]*ZP[gt1, 2]*ZP[gt3, 2] + 
     conj[ZE[gt2, 1]]*ZE[gt4, 1]*((g1^2 + g2^2 + 4*gp^2*QHd*Ql1)*ZP[gt1, 1]*
        ZP[gt3, 1] - (g1^2 + g2^2 - 4*gp^2*QHu*Ql1 - 4*Yv11*conj[Yv11])*
        ZP[gt1, 2]*ZP[gt3, 2]) + conj[ZE[gt2, 2]]*ZE[gt4, 2]*
      ((g1^2 + g2^2 + 4*gp^2*QHd*Ql2)*ZP[gt1, 1]*ZP[gt3, 1] - 
       (g1^2 + g2^2 - 4*gp^2*QHu*Ql2 - 4*Yv22*conj[Yv22])*ZP[gt1, 2]*
        ZP[gt3, 2])), 1}}, {{Hpm[{gt1}], Su[{gt2, ct2}], conj[Hpm[{gt3}]], 
   conj[Su[{gt4, ct4}]]}, {(I/12)*Delta[ct2, ct4]*
    (sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]]*
      ((g1^2 + 3*g2^2 - 12*gp^2*QHd*Qq)*ZP[gt1, 1]*ZP[gt3, 1] - 
       (g1^2 + 3*g2^2 + 12*gp^2*QHu*Qq)*ZP[gt1, 2]*ZP[gt3, 2]) - 
     4*(sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt4, 3 + j1]]*
        ((g1^2 + 3*gp^2*QHd*Qu)*ZP[gt1, 1]*ZP[gt3, 1] - 
         (g1^2 - 3*gp^2*QHu*Qu)*ZP[gt1, 2]*ZP[gt3, 2]) + 
       3*(sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
               conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZU[gt4, j3]]*ZP[gt1, 1]*
          ZP[gt3, 1] + sum[j3, 1, 3, conj[ZU[gt2, 3 + j3]]*
            sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j3, j1]]*Yu[j2, j1]]*
              ZU[gt4, 3 + j2]]]*ZP[gt1, 2]*ZP[gt3, 2]))), 1}}, 
 {{Hpm[{gt1}], Sv[{gt2}], conj[Hpm[{gt3}]], conj[Sv[{gt4}]]}, 
  {(-I/4)*(conj[ZV[gt2, 1]]*((g1^2 - g2^2 + 4*gp^2*QHd*Ql1 + 
         4*Ye11*conj[Ye11])*ZP[gt1, 1]*ZP[gt3, 1] + 
       (-g1^2 + g2^2 + 4*gp^2*QHu*Ql1)*ZP[gt1, 2]*ZP[gt3, 2])*ZV[gt4, 1] + 
     conj[ZV[gt2, 2]]*((g1^2 - g2^2 + 4*gp^2*QHd*Ql2 + 4*Ye22*conj[Ye22])*
        ZP[gt1, 1]*ZP[gt3, 1] + (-g1^2 + g2^2 + 4*gp^2*QHu*Ql2)*ZP[gt1, 2]*
        ZP[gt3, 2])*ZV[gt4, 2] + g1^2*conj[ZV[gt2, 3]]*ZP[gt1, 1]*ZP[gt3, 1]*
      ZV[gt4, 3] - g2^2*conj[ZV[gt2, 3]]*ZP[gt1, 1]*ZP[gt3, 1]*ZV[gt4, 3] + 
     4*gp^2*QHd*Ql3*conj[ZV[gt2, 3]]*ZP[gt1, 1]*ZP[gt3, 1]*ZV[gt4, 3] + 
     4*Ye33*conj[Ye33]*conj[ZV[gt2, 3]]*ZP[gt1, 1]*ZP[gt3, 1]*ZV[gt4, 3] - 
     g1^2*conj[ZV[gt2, 3]]*ZP[gt1, 2]*ZP[gt3, 2]*ZV[gt4, 3] + 
     g2^2*conj[ZV[gt2, 3]]*ZP[gt1, 2]*ZP[gt3, 2]*ZV[gt4, 3] + 
     4*gp^2*QHu*Ql3*conj[ZV[gt2, 3]]*ZP[gt1, 2]*ZP[gt3, 2]*ZV[gt4, 3] + 
     4*gp^2*QHd*Qv1*conj[ZV[gt2, 4]]*ZP[gt1, 1]*ZP[gt3, 1]*ZV[gt4, 4] + 
     4*gp^2*QHu*Qv1*conj[ZV[gt2, 4]]*ZP[gt1, 2]*ZP[gt3, 2]*ZV[gt4, 4] + 
     4*Yv11*conj[Yv11]*conj[ZV[gt2, 4]]*ZP[gt1, 2]*ZP[gt3, 2]*ZV[gt4, 4] + 
     4*gp^2*QHd*Qv2*conj[ZV[gt2, 5]]*ZP[gt1, 1]*ZP[gt3, 1]*ZV[gt4, 5] + 
     4*gp^2*QHu*Qv2*conj[ZV[gt2, 5]]*ZP[gt1, 2]*ZP[gt3, 2]*ZV[gt4, 5] + 
     4*Yv22*conj[Yv22]*conj[ZV[gt2, 5]]*ZP[gt1, 2]*ZP[gt3, 2]*ZV[gt4, 5] + 
     4*gp^2*QHd*Qv3*conj[ZV[gt2, 6]]*ZP[gt1, 1]*ZP[gt3, 1]*ZV[gt4, 6] + 
     4*gp^2*QHu*Qv3*conj[ZV[gt2, 6]]*ZP[gt1, 2]*ZP[gt3, 2]*ZV[gt4, 6] + 
     4*Yv33*conj[Yv33]*conj[ZV[gt2, 6]]*ZP[gt1, 2]*ZP[gt3, 2]*ZV[gt4, 6]), 
   1}}, {{Sd[{gt1, ct1}], Sd[{gt2, ct2}], conj[Sd[{gt3, ct3}]], 
   conj[Sd[{gt4, ct4}]]}, 
  {(-I/72)*(Delta[ct1, ct4]*Delta[ct2, ct3]*
      (g1^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt4, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt3, j2]] + 
       9*g2^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt4, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt3, j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt4, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt3, j2]] + 
       36*gp^2*Qq^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt4, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt3, j2]] + 
       2*g1^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt3, j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt3, j2]] + 
       36*gp^2*Qd*Qq*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt3, j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt4, j1]]*
        (sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt3, j2]] - 
         sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt3, 3 + j2]]) - 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt4, 3 + j1]]*
        (sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt3, j2]] - 
         sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt3, 3 + j2]]) + 
       2*g1^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt4, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt3, 3 + j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt4, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt3, 3 + j2]] + 
       36*gp^2*Qd*Qq*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt4, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt3, 3 + j2]] + 
       4*g1^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt3, 3 + j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt3, 3 + j2]] + 
       36*gp^2*Qd^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt3, 3 + j2]] + 
       g1^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt4, j2]] + 
       9*g2^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt4, j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt4, j2]] + 
       36*gp^2*Qq^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt4, j2]] + 
       2*g1^2*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt4, j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt4, j2]] + 
       36*gp^2*Qd*Qq*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt4, j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt4, j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt4, j2]] + 
       2*g1^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       36*gp^2*Qd*Qq*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       4*g1^2*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt4, 3 + j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       36*gp^2*Qd^2*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt4, 3 + j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       72*sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, 
           Yd[j1, j2]*ZD[gt4, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yd[j3, j4]]*conj[ZD[gt2, 3 + j3]]]*ZD[gt3, j4]] + 
       72*sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, 
           Yd[j1, j2]*ZD[gt3, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yd[j3, j4]]*conj[ZD[gt1, 3 + j3]]]*
          ZD[gt4, j4]]) + Delta[ct1, ct3]*Delta[ct2, ct4]*
      (18*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt4, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt3, j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt3, j2]] + 
       2*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt4, 3 + j1]]*
        ((g1^2 + 3*g3^2 + 18*gp^2*Qd*Qq)*sum[j2, 1, 3, conj[ZD[gt1, j2]]*
            ZD[gt3, j2]] + (2*g1^2 - 3*g3^2 + 18*gp^2*Qd^2)*
          sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt3, 3 + j2]]) + 
       sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt4, j1]]*
        ((g1^2 + 9*g2^2 - 6*g3^2 + 36*gp^2*Qq^2)*sum[j2, 1, 3, 
           conj[ZD[gt1, j2]]*ZD[gt3, j2]] + 2*(g1^2 + 3*g3^2 + 18*gp^2*Qd*Qq)*
          sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt3, 3 + j2]]) - 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt4, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt3, 3 + j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt3, 3 + j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt4, j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt4, j2]] + 
       g1^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt4, j2]] + 
       9*g2^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt4, j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt4, j2]] + 
       36*gp^2*Qq^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt4, j2]] + 
       2*g1^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt4, j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt4, j2]] + 
       36*gp^2*Qd*Qq*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, j2]]*ZD[gt4, j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       2*g1^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       36*gp^2*Qd*Qq*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       4*g1^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt4, 3 + j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       36*gp^2*Qd^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZD[gt2, 3 + j2]]*ZD[gt4, 3 + j2]] + 
       72*sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, 
           Yd[j1, j2]*ZD[gt4, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yd[j3, j4]]*conj[ZD[gt1, 3 + j3]]]*ZD[gt3, j4]] + 
       72*sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, 
           Yd[j1, j2]*ZD[gt3, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yd[j3, j4]]*conj[ZD[gt2, 3 + j3]]]*
          ZD[gt4, j4]])), 1}}, 
 {{Sd[{gt1, ct1}], Se[{gt2}], conj[Sd[{gt3, ct3}]], conj[Se[{gt4}]]}, 
  {(-I/12)*Delta[ct1, ct3]*(12*conj[Ye11]*conj[ZE[gt2, 4]]*
      sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, 
         Yd[j1, j2]*ZD[gt3, 3 + j1]]]*ZE[gt4, 1] - g1^2*conj[ZE[gt2, 2]]*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*ZE[gt4, 2] + 
     3*g2^2*conj[ZE[gt2, 2]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
      ZE[gt4, 2] + 12*gp^2*Ql2*Qq*conj[ZE[gt2, 2]]*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*ZE[gt4, 2] - 
     2*g1^2*conj[ZE[gt2, 2]]*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
        ZD[gt3, 3 + j1]]*ZE[gt4, 2] + 12*gp^2*Qd*Ql2*conj[ZE[gt2, 2]]*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZE[gt4, 2] + 
     12*conj[Ye22]*conj[ZE[gt2, 5]]*sum[j2, 1, 3, conj[ZD[gt1, j2]]*
        sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]]*ZE[gt4, 2] - 
     g1^2*conj[ZE[gt2, 3]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
      ZE[gt4, 3] + 3*g2^2*conj[ZE[gt2, 3]]*sum[j1, 1, 3, 
       conj[ZD[gt1, j1]]*ZD[gt3, j1]]*ZE[gt4, 3] + 
     12*gp^2*Ql3*Qq*conj[ZE[gt2, 3]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*
        ZD[gt3, j1]]*ZE[gt4, 3] - 2*g1^2*conj[ZE[gt2, 3]]*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZE[gt4, 3] + 
     12*gp^2*Qd*Ql3*conj[ZE[gt2, 3]]*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
        ZD[gt3, 3 + j1]]*ZE[gt4, 3] + 12*conj[Ye33]*conj[ZE[gt2, 6]]*
      sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, 
         Yd[j1, j2]*ZD[gt3, 3 + j1]]]*ZE[gt4, 3] + 2*g1^2*conj[ZE[gt2, 4]]*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*ZE[gt4, 4] + 
     12*gp^2*Qe1*Qq*conj[ZE[gt2, 4]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*
        ZD[gt3, j1]]*ZE[gt4, 4] + 4*g1^2*conj[ZE[gt2, 4]]*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZE[gt4, 4] + 
     12*gp^2*Qd*Qe1*conj[ZE[gt2, 4]]*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
        ZD[gt3, 3 + j1]]*ZE[gt4, 4] + conj[ZE[gt2, 1]]*
      ((-g1^2 + 3*(g2^2 + 4*gp^2*Ql1*Qq))*sum[j1, 1, 3, 
         conj[ZD[gt1, j1]]*ZD[gt3, j1]]*ZE[gt4, 1] - 2*(g1^2 - 6*gp^2*Qd*Ql1)*
        sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZE[gt4, 1] + 
       12*Ye11*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*
            conj[ZD[gt1, 3 + j1]]]*ZD[gt3, j2]]*ZE[gt4, 4]) + 
     2*g1^2*conj[ZE[gt2, 5]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
      ZE[gt4, 5] + 12*gp^2*Qe2*Qq*conj[ZE[gt2, 5]]*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*ZE[gt4, 5] + 
     4*g1^2*conj[ZE[gt2, 5]]*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
        ZD[gt3, 3 + j1]]*ZE[gt4, 5] + 12*gp^2*Qd*Qe2*conj[ZE[gt2, 5]]*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZE[gt4, 5] + 
     12*Ye22*conj[ZE[gt2, 2]]*sum[j2, 1, 3, 
       sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt1, 3 + j1]]]*ZD[gt3, j2]]*
      ZE[gt4, 5] + 2*g1^2*conj[ZE[gt2, 6]]*sum[j1, 1, 3, 
       conj[ZD[gt1, j1]]*ZD[gt3, j1]]*ZE[gt4, 6] + 
     12*gp^2*Qe3*Qq*conj[ZE[gt2, 6]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*
        ZD[gt3, j1]]*ZE[gt4, 6] + 4*g1^2*conj[ZE[gt2, 6]]*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZE[gt4, 6] + 
     12*gp^2*Qd*Qe3*conj[ZE[gt2, 6]]*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
        ZD[gt3, 3 + j1]]*ZE[gt4, 6] + 12*Ye33*conj[ZE[gt2, 3]]*
      sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt1, 3 + j1]]]*
        ZD[gt3, j2]]*ZE[gt4, 6]), 1}}, 
 {{Sd[{gt1, ct1}], Su[{gt2, ct2}], conj[Sd[{gt3, ct3}]], 
   conj[Su[{gt4, ct4}]]}, 
  {(-I/72)*(Delta[ct1, ct3]*Delta[ct2, ct4]*
      (sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]]*
        ((g1^2 - 9*g2^2 - 6*g3^2 + 36*gp^2*Qq^2)*sum[j2, 1, 3, 
           conj[ZD[gt1, j2]]*ZD[gt3, j2]] + 2*(g1^2 + 3*g3^2 + 18*gp^2*Qd*Qq)*
          sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt3, 3 + j2]]) + 
       sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt4, 3 + j1]]*
        ((-4*g1^2 + 6*g3^2 + 36*gp^2*Qq*Qu)*sum[j2, 1, 3, conj[ZD[gt1, j2]]*
            ZD[gt3, j2]] - 2*(4*g1^2 + 3*g3^2 - 18*gp^2*Qd*Qu)*
          sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt3, 3 + j2]]) + 
       g1^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       9*g2^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] + 
       36*gp^2*Qq^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] + 
       2*g1^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] + 
       36*gp^2*Qd*Qq*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       4*g1^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       36*gp^2*Qq*Qu*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] - 
       8*g1^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       36*gp^2*Qd*Qu*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]]) + 
     18*Delta[ct1, ct4]*Delta[ct2, ct3]*
      (g2^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZD[gt3, j2]] + 
       g3^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]]*
        (sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt3, j2]] - 
         sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt3, 3 + j2]]) + 
       g3^2*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt4, 3 + j1]]*
        (-sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZD[gt3, j2]] + 
         sum[j2, 1, 3, conj[ZD[gt1, 3 + j2]]*ZD[gt3, 3 + j2]]) + 
       g2^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZD[gt1, j2]]*ZU[gt4, j2]] + 
       g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       g3^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       g3^2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       4*sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, 
           Yu[j1, j2]*ZU[gt4, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yu[j3, j4]]*conj[ZU[gt2, 3 + j3]]]*ZD[gt3, j4]] + 
       4*sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
           Yd[j1, j2]*ZD[gt3, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yd[j3, j4]]*conj[ZD[gt1, 3 + j3]]]*
          ZU[gt4, j4]])), 1}}, 
 {{Sd[{gt1, ct1}], Sv[{gt2}], conj[Sd[{gt3, ct3}]], conj[Sv[{gt4}]]}, 
  {(I/12)*Delta[ct1, ct3]*(conj[ZV[gt2, 1]]*
      ((g1^2 + 3*g2^2 - 12*gp^2*Ql1*Qq)*sum[j1, 1, 3, conj[ZD[gt1, j1]]*
          ZD[gt3, j1]] + 2*(g1^2 - 6*gp^2*Qd*Ql1)*sum[j1, 1, 3, 
         conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]])*ZV[gt4, 1] + 
     conj[ZV[gt2, 2]]*((g1^2 + 3*g2^2 - 12*gp^2*Ql2*Qq)*
        sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]] + 
       2*(g1^2 - 6*gp^2*Qd*Ql2)*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
          ZD[gt3, 3 + j1]])*ZV[gt4, 2] + g1^2*conj[ZV[gt2, 3]]*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*ZV[gt4, 3] + 
     3*g2^2*conj[ZV[gt2, 3]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*
      ZV[gt4, 3] - 12*gp^2*Ql3*Qq*conj[ZV[gt2, 3]]*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt3, j1]]*ZV[gt4, 3] + 
     2*g1^2*conj[ZV[gt2, 3]]*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
        ZD[gt3, 3 + j1]]*ZV[gt4, 3] - 12*gp^2*Qd*Ql3*conj[ZV[gt2, 3]]*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZV[gt4, 3] - 
     12*gp^2*Qq*Qv1*conj[ZV[gt2, 4]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*
        ZD[gt3, j1]]*ZV[gt4, 4] - 12*gp^2*Qd*Qv1*conj[ZV[gt2, 4]]*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZV[gt4, 4] - 
     12*gp^2*Qq*Qv2*conj[ZV[gt2, 5]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*
        ZD[gt3, j1]]*ZV[gt4, 5] - 12*gp^2*Qd*Qv2*conj[ZV[gt2, 5]]*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZV[gt4, 5] - 
     12*gp^2*Qq*Qv3*conj[ZV[gt2, 6]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*
        ZD[gt3, j1]]*ZV[gt4, 6] - 12*gp^2*Qd*Qv3*conj[ZV[gt2, 6]]*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt3, 3 + j1]]*ZV[gt4, 6]), 1}}, 
 {{Sd[{gt1, ct1}], Sv[{gt2}], conj[Se[{gt3}]], conj[Su[{gt4, ct4}]]}, 
  {(-I/2)*Delta[ct1, ct4]*(2*conj[Yv11]*conj[ZV[gt2, 4]]*
      sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, 
         Yu[j1, j2]*ZU[gt4, 3 + j1]]]*ZE[gt3, 1] + g2^2*conj[ZV[gt2, 2]]*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZU[gt4, j1]]*ZE[gt3, 2] + 
     2*conj[Yv22]*conj[ZV[gt2, 5]]*sum[j2, 1, 3, conj[ZD[gt1, j2]]*
        sum[j1, 1, 3, Yu[j1, j2]*ZU[gt4, 3 + j1]]]*ZE[gt3, 2] + 
     g2^2*conj[ZV[gt2, 3]]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZU[gt4, j1]]*
      ZE[gt3, 3] + 2*conj[Yv33]*conj[ZV[gt2, 6]]*
      sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, 
         Yu[j1, j2]*ZU[gt4, 3 + j1]]]*ZE[gt3, 3] + 
     conj[ZV[gt2, 1]]*(g2^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZU[gt4, j1]]*
        ZE[gt3, 1] + 2*Ye11*sum[j2, 1, 3, 
         sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt1, 3 + j1]]]*ZU[gt4, j2]]*
        ZE[gt3, 4]) + 2*Ye22*conj[ZV[gt2, 2]]*sum[j2, 1, 3, 
       sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt1, 3 + j1]]]*ZU[gt4, j2]]*
      ZE[gt3, 5] + 2*Ye33*conj[ZV[gt2, 3]]*sum[j2, 1, 3, 
       sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt1, 3 + j1]]]*ZU[gt4, j2]]*
      ZE[gt3, 6]), 1}}, {{Se[{gt1}], Se[{gt2}], conj[Se[{gt3}]], 
   conj[Se[{gt4}]]}, 
  {(-I/4)*(g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 1]]*ZE[gt3, 3]*ZE[gt4, 1] + 
     g2^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 1]]*ZE[gt3, 3]*ZE[gt4, 1] + 
     4*gp^2*Ql1*Ql3*conj[ZE[gt1, 3]]*conj[ZE[gt2, 1]]*ZE[gt3, 3]*ZE[gt4, 1] - 
     2*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 1]]*ZE[gt3, 4]*ZE[gt4, 1] + 
     4*gp^2*Qe1*Ql1*conj[ZE[gt1, 4]]*conj[ZE[gt2, 1]]*ZE[gt3, 4]*ZE[gt4, 1] + 
     4*Ye11*conj[Ye11]*conj[ZE[gt1, 4]]*conj[ZE[gt2, 1]]*ZE[gt3, 4]*
      ZE[gt4, 1] - 2*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 1]]*ZE[gt3, 5]*
      ZE[gt4, 1] + 4*gp^2*Qe2*Ql1*conj[ZE[gt1, 5]]*conj[ZE[gt2, 1]]*
      ZE[gt3, 5]*ZE[gt4, 1] + 4*Ye22*conj[Ye11]*conj[ZE[gt1, 4]]*
      conj[ZE[gt2, 2]]*ZE[gt3, 5]*ZE[gt4, 1] - 2*g1^2*conj[ZE[gt1, 6]]*
      conj[ZE[gt2, 1]]*ZE[gt3, 6]*ZE[gt4, 1] + 4*gp^2*Qe3*Ql1*
      conj[ZE[gt1, 6]]*conj[ZE[gt2, 1]]*ZE[gt3, 6]*ZE[gt4, 1] + 
     4*Ye33*conj[Ye11]*conj[ZE[gt1, 4]]*conj[ZE[gt2, 3]]*ZE[gt3, 6]*
      ZE[gt4, 1] + 4*Ye33*conj[Ye11]*conj[ZE[gt1, 3]]*conj[ZE[gt2, 4]]*
      ZE[gt3, 6]*ZE[gt4, 1] + g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 2]]*
      ZE[gt3, 3]*ZE[gt4, 2] + g2^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 2]]*
      ZE[gt3, 3]*ZE[gt4, 2] + 4*gp^2*Ql2*Ql3*conj[ZE[gt1, 3]]*
      conj[ZE[gt2, 2]]*ZE[gt3, 3]*ZE[gt4, 2] + 4*Ye11*conj[Ye22]*
      conj[ZE[gt1, 5]]*conj[ZE[gt2, 1]]*ZE[gt3, 4]*ZE[gt4, 2] - 
     2*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 2]]*ZE[gt3, 4]*ZE[gt4, 2] + 
     4*gp^2*Qe1*Ql2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 2]]*ZE[gt3, 4]*ZE[gt4, 2] - 
     2*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 2]]*ZE[gt3, 5]*ZE[gt4, 2] + 
     4*gp^2*Qe2*Ql2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 2]]*ZE[gt3, 5]*ZE[gt4, 2] + 
     4*Ye22*conj[Ye22]*conj[ZE[gt1, 5]]*conj[ZE[gt2, 2]]*ZE[gt3, 5]*
      ZE[gt4, 2] - 2*g1^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 2]]*ZE[gt3, 6]*
      ZE[gt4, 2] + 4*gp^2*Qe3*Ql2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 2]]*
      ZE[gt3, 6]*ZE[gt4, 2] + 4*Ye33*conj[Ye22]*conj[ZE[gt1, 5]]*
      conj[ZE[gt2, 3]]*ZE[gt3, 6]*ZE[gt4, 2] + 4*Ye33*conj[Ye22]*
      conj[ZE[gt1, 3]]*conj[ZE[gt2, 5]]*ZE[gt3, 6]*ZE[gt4, 2] + 
     g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 1]]*ZE[gt3, 1]*ZE[gt4, 3] + 
     g2^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 1]]*ZE[gt3, 1]*ZE[gt4, 3] + 
     4*gp^2*Ql1*Ql3*conj[ZE[gt1, 3]]*conj[ZE[gt2, 1]]*ZE[gt3, 1]*ZE[gt4, 3] + 
     g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 2]]*ZE[gt3, 2]*ZE[gt4, 3] + 
     g2^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 2]]*ZE[gt3, 2]*ZE[gt4, 3] + 
     4*gp^2*Ql2*Ql3*conj[ZE[gt1, 3]]*conj[ZE[gt2, 2]]*ZE[gt3, 2]*ZE[gt4, 3] + 
     2*g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 3] + 
     2*g2^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 3] + 
     8*gp^2*Ql3^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 3] + 
     4*Ye11*conj[Ye33]*conj[ZE[gt1, 6]]*conj[ZE[gt2, 1]]*ZE[gt3, 4]*
      ZE[gt4, 3] - 2*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 3]]*ZE[gt3, 4]*
      ZE[gt4, 3] + 4*gp^2*Qe1*Ql3*conj[ZE[gt1, 4]]*conj[ZE[gt2, 3]]*
      ZE[gt3, 4]*ZE[gt4, 3] - 2*g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 4]]*
      ZE[gt3, 4]*ZE[gt4, 3] + 4*gp^2*Qe1*Ql3*conj[ZE[gt1, 3]]*
      conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 3] + 4*Ye22*conj[Ye33]*
      conj[ZE[gt1, 6]]*conj[ZE[gt2, 2]]*ZE[gt3, 5]*ZE[gt4, 3] - 
     2*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 3]]*ZE[gt3, 5]*ZE[gt4, 3] + 
     4*gp^2*Qe2*Ql3*conj[ZE[gt1, 5]]*conj[ZE[gt2, 3]]*ZE[gt3, 5]*ZE[gt4, 3] - 
     2*g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 3] + 
     4*gp^2*Qe2*Ql3*conj[ZE[gt1, 3]]*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 3] - 
     2*g1^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 3]]*ZE[gt3, 6]*ZE[gt4, 3] + 
     4*gp^2*Qe3*Ql3*conj[ZE[gt1, 6]]*conj[ZE[gt2, 3]]*ZE[gt3, 6]*ZE[gt4, 3] + 
     4*Ye33*conj[Ye33]*conj[ZE[gt1, 6]]*conj[ZE[gt2, 3]]*ZE[gt3, 6]*
      ZE[gt4, 3] - 2*g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 6]]*ZE[gt3, 6]*
      ZE[gt4, 3] + 4*gp^2*Qe3*Ql3*conj[ZE[gt1, 3]]*conj[ZE[gt2, 6]]*
      ZE[gt3, 6]*ZE[gt4, 3] + 4*Ye33*conj[Ye33]*conj[ZE[gt1, 3]]*
      conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 3] - 2*g1^2*conj[ZE[gt1, 4]]*
      conj[ZE[gt2, 1]]*ZE[gt3, 1]*ZE[gt4, 4] + 4*gp^2*Qe1*Ql1*
      conj[ZE[gt1, 4]]*conj[ZE[gt2, 1]]*ZE[gt3, 1]*ZE[gt4, 4] + 
     4*Ye11*conj[Ye11]*conj[ZE[gt1, 4]]*conj[ZE[gt2, 1]]*ZE[gt3, 1]*
      ZE[gt4, 4] + 4*Ye11*conj[Ye22]*conj[ZE[gt1, 5]]*conj[ZE[gt2, 1]]*
      ZE[gt3, 2]*ZE[gt4, 4] - 2*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 2]]*
      ZE[gt3, 2]*ZE[gt4, 4] + 4*gp^2*Qe1*Ql2*conj[ZE[gt1, 4]]*
      conj[ZE[gt2, 2]]*ZE[gt3, 2]*ZE[gt4, 4] + 4*Ye11*conj[Ye33]*
      conj[ZE[gt1, 6]]*conj[ZE[gt2, 1]]*ZE[gt3, 3]*ZE[gt4, 4] - 
     2*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 4] + 
     4*gp^2*Qe1*Ql3*conj[ZE[gt1, 4]]*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 4] - 
     2*g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 4]]*ZE[gt3, 3]*ZE[gt4, 4] + 
     4*gp^2*Qe1*Ql3*conj[ZE[gt1, 3]]*conj[ZE[gt2, 4]]*ZE[gt3, 3]*ZE[gt4, 4] + 
     8*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 4] + 
     8*gp^2*Qe1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 4] + 
     4*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 4]]*ZE[gt3, 5]*ZE[gt4, 4] + 
     4*gp^2*Qe1*Qe2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 4]]*ZE[gt3, 5]*ZE[gt4, 4] + 
     4*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 4] + 
     4*gp^2*Qe1*Qe2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 4] + 
     4*g1^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 4]]*ZE[gt3, 6]*ZE[gt4, 4] + 
     4*gp^2*Qe1*Qe3*conj[ZE[gt1, 6]]*conj[ZE[gt2, 4]]*ZE[gt3, 6]*ZE[gt4, 4] + 
     4*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 4] + 
     4*gp^2*Qe1*Qe3*conj[ZE[gt1, 4]]*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 4] - 
     2*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 1]]*ZE[gt3, 1]*ZE[gt4, 5] + 
     4*gp^2*Qe2*Ql1*conj[ZE[gt1, 5]]*conj[ZE[gt2, 1]]*ZE[gt3, 1]*ZE[gt4, 5] + 
     4*Ye22*conj[Ye11]*conj[ZE[gt1, 4]]*conj[ZE[gt2, 2]]*ZE[gt3, 1]*
      ZE[gt4, 5] - 2*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 2]]*ZE[gt3, 2]*
      ZE[gt4, 5] + 4*gp^2*Qe2*Ql2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 2]]*
      ZE[gt3, 2]*ZE[gt4, 5] + 4*Ye22*conj[Ye22]*conj[ZE[gt1, 5]]*
      conj[ZE[gt2, 2]]*ZE[gt3, 2]*ZE[gt4, 5] + 4*Ye22*conj[Ye33]*
      conj[ZE[gt1, 6]]*conj[ZE[gt2, 2]]*ZE[gt3, 3]*ZE[gt4, 5] - 
     2*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 5] + 
     4*gp^2*Qe2*Ql3*conj[ZE[gt1, 5]]*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 5] - 
     2*g1^2*conj[ZE[gt1, 3]]*conj[ZE[gt2, 5]]*ZE[gt3, 3]*ZE[gt4, 5] + 
     4*gp^2*Qe2*Ql3*conj[ZE[gt1, 3]]*conj[ZE[gt2, 5]]*ZE[gt3, 3]*ZE[gt4, 5] + 
     4*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 5] + 
     4*gp^2*Qe1*Qe2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 5] + 
     4*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 5]]*ZE[gt3, 4]*ZE[gt4, 5] + 
     4*gp^2*Qe1*Qe2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 5]]*ZE[gt3, 4]*ZE[gt4, 5] + 
     8*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 5] + 
     8*gp^2*Qe2^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 5] + 
     4*g1^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 5]]*ZE[gt3, 6]*ZE[gt4, 5] + 
     4*gp^2*Qe2*Qe3*conj[ZE[gt1, 6]]*conj[ZE[gt2, 5]]*ZE[gt3, 6]*ZE[gt4, 5] + 
     4*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 5] + 
     4*gp^2*Qe2*Qe3*conj[ZE[gt1, 5]]*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 5] - 
     2*g1^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 1]]*ZE[gt3, 1]*ZE[gt4, 6] + 
     4*gp^2*Qe3*Ql1*conj[ZE[gt1, 6]]*conj[ZE[gt2, 1]]*ZE[gt3, 1]*ZE[gt4, 6] + 
     4*Ye33*conj[Ye11]*conj[ZE[gt1, 4]]*conj[ZE[gt2, 3]]*ZE[gt3, 1]*
      ZE[gt4, 6] + 4*Ye33*conj[Ye11]*conj[ZE[gt1, 3]]*conj[ZE[gt2, 4]]*
      ZE[gt3, 1]*ZE[gt4, 6] - 2*g1^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 2]]*
      ZE[gt3, 2]*ZE[gt4, 6] + 4*gp^2*Qe3*Ql2*conj[ZE[gt1, 6]]*
      conj[ZE[gt2, 2]]*ZE[gt3, 2]*ZE[gt4, 6] + 4*Ye33*conj[Ye22]*
      conj[ZE[gt1, 5]]*conj[ZE[gt2, 3]]*ZE[gt3, 2]*ZE[gt4, 6] + 
     4*Ye33*conj[Ye22]*conj[ZE[gt1, 3]]*conj[ZE[gt2, 5]]*ZE[gt3, 2]*
      ZE[gt4, 6] - 2*g1^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 3]]*ZE[gt3, 3]*
      ZE[gt4, 6] + 4*gp^2*Qe3*Ql3*conj[ZE[gt1, 6]]*conj[ZE[gt2, 3]]*
      ZE[gt3, 3]*ZE[gt4, 6] + 4*Ye33*conj[Ye33]*conj[ZE[gt1, 6]]*
      conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 6] - 2*g1^2*conj[ZE[gt1, 3]]*
      conj[ZE[gt2, 6]]*ZE[gt3, 3]*ZE[gt4, 6] + 4*gp^2*Qe3*Ql3*
      conj[ZE[gt1, 3]]*conj[ZE[gt2, 6]]*ZE[gt3, 3]*ZE[gt4, 6] + 
     4*Ye33*conj[Ye33]*conj[ZE[gt1, 3]]*conj[ZE[gt2, 6]]*ZE[gt3, 3]*
      ZE[gt4, 6] + 4*g1^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 4]]*ZE[gt3, 4]*
      ZE[gt4, 6] + 4*gp^2*Qe1*Qe3*conj[ZE[gt1, 6]]*conj[ZE[gt2, 4]]*
      ZE[gt3, 4]*ZE[gt4, 6] + 4*g1^2*conj[ZE[gt1, 4]]*conj[ZE[gt2, 6]]*
      ZE[gt3, 4]*ZE[gt4, 6] + 4*gp^2*Qe1*Qe3*conj[ZE[gt1, 4]]*
      conj[ZE[gt2, 6]]*ZE[gt3, 4]*ZE[gt4, 6] + 4*g1^2*conj[ZE[gt1, 6]]*
      conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 6] + 4*gp^2*Qe2*Qe3*
      conj[ZE[gt1, 6]]*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 6] + 
     4*g1^2*conj[ZE[gt1, 5]]*conj[ZE[gt2, 6]]*ZE[gt3, 5]*ZE[gt4, 6] + 
     4*gp^2*Qe2*Qe3*conj[ZE[gt1, 5]]*conj[ZE[gt2, 6]]*ZE[gt3, 5]*ZE[gt4, 6] + 
     8*g1^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 6] + 
     8*gp^2*Qe3^2*conj[ZE[gt1, 6]]*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 6] + 
     conj[ZE[gt1, 1]]*(2*(g1^2 + g2^2 + 4*gp^2*Ql1^2)*conj[ZE[gt2, 1]]*
        ZE[gt3, 1]*ZE[gt4, 1] + g1^2*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 1] + 
       g2^2*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 1] + 
       4*gp^2*Ql1*Ql3*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 1] - 
       2*g1^2*conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 1] + 
       4*gp^2*Qe1*Ql1*conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 1] + 
       4*Ye11*conj[Ye11]*conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 1] - 
       2*g1^2*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 1] + 
       4*gp^2*Qe2*Ql1*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 1] - 
       2*g1^2*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 1] + 
       4*gp^2*Qe3*Ql1*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 1] + 
       4*Ye11*conj[Ye22]*conj[ZE[gt2, 5]]*ZE[gt3, 4]*ZE[gt4, 2] + 
       (g1^2 + g2^2 + 4*gp^2*Ql1*Ql2)*conj[ZE[gt2, 2]]*
        (ZE[gt3, 2]*ZE[gt4, 1] + ZE[gt3, 1]*ZE[gt4, 2]) + 
       g1^2*conj[ZE[gt2, 3]]*ZE[gt3, 1]*ZE[gt4, 3] + g2^2*conj[ZE[gt2, 3]]*
        ZE[gt3, 1]*ZE[gt4, 3] + 4*gp^2*Ql1*Ql3*conj[ZE[gt2, 3]]*ZE[gt3, 1]*
        ZE[gt4, 3] + 4*Ye11*conj[Ye33]*conj[ZE[gt2, 6]]*ZE[gt3, 4]*
        ZE[gt4, 3] - 2*g1^2*conj[ZE[gt2, 4]]*ZE[gt3, 1]*ZE[gt4, 4] + 
       4*gp^2*Qe1*Ql1*conj[ZE[gt2, 4]]*ZE[gt3, 1]*ZE[gt4, 4] + 
       4*Ye11*conj[Ye11]*conj[ZE[gt2, 4]]*ZE[gt3, 1]*ZE[gt4, 4] + 
       4*Ye11*conj[Ye22]*conj[ZE[gt2, 5]]*ZE[gt3, 2]*ZE[gt4, 4] + 
       4*Ye11*conj[Ye33]*conj[ZE[gt2, 6]]*ZE[gt3, 3]*ZE[gt4, 4] - 
       2*g1^2*conj[ZE[gt2, 5]]*ZE[gt3, 1]*ZE[gt4, 5] + 
       4*gp^2*Qe2*Ql1*conj[ZE[gt2, 5]]*ZE[gt3, 1]*ZE[gt4, 5] - 
       2*g1^2*conj[ZE[gt2, 6]]*ZE[gt3, 1]*ZE[gt4, 6] + 
       4*gp^2*Qe3*Ql1*conj[ZE[gt2, 6]]*ZE[gt3, 1]*ZE[gt4, 6]) + 
     conj[ZE[gt1, 2]]*(2*g1^2*conj[ZE[gt2, 2]]*ZE[gt3, 2]*ZE[gt4, 2] + 
       2*g2^2*conj[ZE[gt2, 2]]*ZE[gt3, 2]*ZE[gt4, 2] + 
       8*gp^2*Ql2^2*conj[ZE[gt2, 2]]*ZE[gt3, 2]*ZE[gt4, 2] + 
       g1^2*conj[ZE[gt2, 3]]*ZE[gt3, 3]*ZE[gt4, 2] + g2^2*conj[ZE[gt2, 3]]*
        ZE[gt3, 3]*ZE[gt4, 2] + 4*gp^2*Ql2*Ql3*conj[ZE[gt2, 3]]*ZE[gt3, 3]*
        ZE[gt4, 2] - 2*g1^2*conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 2] + 
       4*gp^2*Qe1*Ql2*conj[ZE[gt2, 4]]*ZE[gt3, 4]*ZE[gt4, 2] - 
       2*g1^2*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 2] + 
       4*gp^2*Qe2*Ql2*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 2] + 
       4*Ye22*conj[Ye22]*conj[ZE[gt2, 5]]*ZE[gt3, 5]*ZE[gt4, 2] - 
       2*g1^2*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 2] + 
       4*gp^2*Qe3*Ql2*conj[ZE[gt2, 6]]*ZE[gt3, 6]*ZE[gt4, 2] + 
       (g1^2 + g2^2 + 4*gp^2*Ql1*Ql2)*conj[ZE[gt2, 1]]*
        (ZE[gt3, 2]*ZE[gt4, 1] + ZE[gt3, 1]*ZE[gt4, 2]) + 
       g1^2*conj[ZE[gt2, 3]]*ZE[gt3, 2]*ZE[gt4, 3] + g2^2*conj[ZE[gt2, 3]]*
        ZE[gt3, 2]*ZE[gt4, 3] + 4*gp^2*Ql2*Ql3*conj[ZE[gt2, 3]]*ZE[gt3, 2]*
        ZE[gt4, 3] + 4*Ye22*conj[Ye33]*conj[ZE[gt2, 6]]*ZE[gt3, 5]*
        ZE[gt4, 3] - 2*g1^2*conj[ZE[gt2, 4]]*ZE[gt3, 2]*ZE[gt4, 4] + 
       4*gp^2*Qe1*Ql2*conj[ZE[gt2, 4]]*ZE[gt3, 2]*ZE[gt4, 4] - 
       2*g1^2*conj[ZE[gt2, 5]]*ZE[gt3, 2]*ZE[gt4, 5] + 
       4*gp^2*Qe2*Ql2*conj[ZE[gt2, 5]]*ZE[gt3, 2]*ZE[gt4, 5] + 
       4*Ye22*conj[Ye22]*conj[ZE[gt2, 5]]*ZE[gt3, 2]*ZE[gt4, 5] + 
       4*Ye22*conj[Ye33]*conj[ZE[gt2, 6]]*ZE[gt3, 3]*ZE[gt4, 5] + 
       4*Ye22*conj[Ye11]*conj[ZE[gt2, 4]]*(ZE[gt3, 5]*ZE[gt4, 1] + 
         ZE[gt3, 1]*ZE[gt4, 5]) - 2*g1^2*conj[ZE[gt2, 6]]*ZE[gt3, 2]*
        ZE[gt4, 6] + 4*gp^2*Qe3*Ql2*conj[ZE[gt2, 6]]*ZE[gt3, 2]*ZE[gt4, 6])), 
   1}}, {{Se[{gt1}], Su[{gt2, ct2}], conj[Sd[{gt3, ct3}]], conj[Sv[{gt4}]]}, 
  {(-I/2)*Delta[ct2, ct3]*(2*conj[Ye11]*conj[ZE[gt1, 4]]*
      sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
         Yd[j1, j2]*ZD[gt3, 3 + j1]]]*ZV[gt4, 1] + g2^2*conj[ZE[gt1, 2]]*
      sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZD[gt3, j1]]*ZV[gt4, 2] + 
     2*conj[Ye22]*conj[ZE[gt1, 5]]*sum[j2, 1, 3, conj[ZU[gt2, j2]]*
        sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]]*ZV[gt4, 2] + 
     g2^2*conj[ZE[gt1, 3]]*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZD[gt3, j1]]*
      ZV[gt4, 3] + 2*conj[Ye33]*conj[ZE[gt1, 6]]*
      sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
         Yd[j1, j2]*ZD[gt3, 3 + j1]]]*ZV[gt4, 3] + 
     conj[ZE[gt1, 1]]*(g2^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZD[gt3, j1]]*
        ZV[gt4, 1] + 2*Yv11*sum[j2, 1, 3, 
         sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt2, 3 + j1]]]*ZD[gt3, j2]]*
        ZV[gt4, 4]) + 2*Yv22*conj[ZE[gt1, 2]]*sum[j2, 1, 3, 
       sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt2, 3 + j1]]]*ZD[gt3, j2]]*
      ZV[gt4, 5] + 2*Yv33*conj[ZE[gt1, 3]]*sum[j2, 1, 3, 
       sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt2, 3 + j1]]]*ZD[gt3, j2]]*
      ZV[gt4, 6]), 1}}, {{Se[{gt1}], Su[{gt2, ct2}], conj[Se[{gt3}]], 
   conj[Su[{gt4, ct4}]]}, {(I/12)*Delta[ct2, ct4]*
    (conj[ZE[gt1, 1]]*((g1^2 + 3*g2^2 - 12*gp^2*Ql1*Qq)*
        sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]] - 
       4*(g1^2 + 3*gp^2*Ql1*Qu)*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
          ZU[gt4, 3 + j1]])*ZE[gt3, 1] + conj[ZE[gt1, 2]]*
      ((g1^2 + 3*g2^2 - 12*gp^2*Ql2*Qq)*sum[j1, 1, 3, conj[ZU[gt2, j1]]*
          ZU[gt4, j1]] - 4*(g1^2 + 3*gp^2*Ql2*Qu)*sum[j1, 1, 3, 
         conj[ZU[gt2, 3 + j1]]*ZU[gt4, 3 + j1]])*ZE[gt3, 2] + 
     g1^2*conj[ZE[gt1, 3]]*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]]*
      ZE[gt3, 3] + 3*g2^2*conj[ZE[gt1, 3]]*sum[j1, 1, 3, 
       conj[ZU[gt2, j1]]*ZU[gt4, j1]]*ZE[gt3, 3] - 
     12*gp^2*Ql3*Qq*conj[ZE[gt1, 3]]*sum[j1, 1, 3, conj[ZU[gt2, j1]]*
        ZU[gt4, j1]]*ZE[gt3, 3] - 4*g1^2*conj[ZE[gt1, 3]]*
      sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt4, 3 + j1]]*ZE[gt3, 3] - 
     12*gp^2*Ql3*Qu*conj[ZE[gt1, 3]]*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
        ZU[gt4, 3 + j1]]*ZE[gt3, 3] - 2*g1^2*conj[ZE[gt1, 4]]*
      sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]]*ZE[gt3, 4] - 
     12*gp^2*Qe1*Qq*conj[ZE[gt1, 4]]*sum[j1, 1, 3, conj[ZU[gt2, j1]]*
        ZU[gt4, j1]]*ZE[gt3, 4] + 8*g1^2*conj[ZE[gt1, 4]]*
      sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt4, 3 + j1]]*ZE[gt3, 4] - 
     12*gp^2*Qe1*Qu*conj[ZE[gt1, 4]]*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
        ZU[gt4, 3 + j1]]*ZE[gt3, 4] - 2*g1^2*conj[ZE[gt1, 5]]*
      sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]]*ZE[gt3, 5] - 
     12*gp^2*Qe2*Qq*conj[ZE[gt1, 5]]*sum[j1, 1, 3, conj[ZU[gt2, j1]]*
        ZU[gt4, j1]]*ZE[gt3, 5] + 8*g1^2*conj[ZE[gt1, 5]]*
      sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt4, 3 + j1]]*ZE[gt3, 5] - 
     12*gp^2*Qe2*Qu*conj[ZE[gt1, 5]]*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
        ZU[gt4, 3 + j1]]*ZE[gt3, 5] - 2*g1^2*conj[ZE[gt1, 6]]*
      sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]]*ZE[gt3, 6] - 
     12*gp^2*Qe3*Qq*conj[ZE[gt1, 6]]*sum[j1, 1, 3, conj[ZU[gt2, j1]]*
        ZU[gt4, j1]]*ZE[gt3, 6] + 8*g1^2*conj[ZE[gt1, 6]]*
      sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt4, 3 + j1]]*ZE[gt3, 6] - 
     12*gp^2*Qe3*Qu*conj[ZE[gt1, 6]]*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
        ZU[gt4, 3 + j1]]*ZE[gt3, 6]), 1}}, 
 {{Se[{gt1}], Sv[{gt2}], conj[Se[{gt3}]], conj[Sv[{gt4}]]}, 
  {(-I/4)*(g1^2*conj[ZE[gt1, 3]]*conj[ZV[gt2, 1]]*ZE[gt3, 3]*ZV[gt4, 1] - 
     g2^2*conj[ZE[gt1, 3]]*conj[ZV[gt2, 1]]*ZE[gt3, 3]*ZV[gt4, 1] + 
     4*gp^2*Ql1*Ql3*conj[ZE[gt1, 3]]*conj[ZV[gt2, 1]]*ZE[gt3, 3]*ZV[gt4, 1] - 
     2*g1^2*conj[ZE[gt1, 4]]*conj[ZV[gt2, 1]]*ZE[gt3, 4]*ZV[gt4, 1] + 
     4*gp^2*Qe1*Ql1*conj[ZE[gt1, 4]]*conj[ZV[gt2, 1]]*ZE[gt3, 4]*ZV[gt4, 1] + 
     4*Ye11*conj[Ye11]*conj[ZE[gt1, 4]]*conj[ZV[gt2, 1]]*ZE[gt3, 4]*
      ZV[gt4, 1] - 2*g1^2*conj[ZE[gt1, 5]]*conj[ZV[gt2, 1]]*ZE[gt3, 5]*
      ZV[gt4, 1] + 4*gp^2*Qe2*Ql1*conj[ZE[gt1, 5]]*conj[ZV[gt2, 1]]*
      ZE[gt3, 5]*ZV[gt4, 1] + 4*Ye22*conj[Ye11]*conj[ZE[gt1, 4]]*
      conj[ZV[gt2, 2]]*ZE[gt3, 5]*ZV[gt4, 1] - 2*g1^2*conj[ZE[gt1, 6]]*
      conj[ZV[gt2, 1]]*ZE[gt3, 6]*ZV[gt4, 1] + 4*gp^2*Qe3*Ql1*
      conj[ZE[gt1, 6]]*conj[ZV[gt2, 1]]*ZE[gt3, 6]*ZV[gt4, 1] + 
     4*Ye33*conj[Ye11]*conj[ZE[gt1, 4]]*conj[ZV[gt2, 3]]*ZE[gt3, 6]*
      ZV[gt4, 1] + g1^2*conj[ZE[gt1, 3]]*conj[ZV[gt2, 2]]*ZE[gt3, 3]*
      ZV[gt4, 2] - g2^2*conj[ZE[gt1, 3]]*conj[ZV[gt2, 2]]*ZE[gt3, 3]*
      ZV[gt4, 2] + 4*gp^2*Ql2*Ql3*conj[ZE[gt1, 3]]*conj[ZV[gt2, 2]]*
      ZE[gt3, 3]*ZV[gt4, 2] + 4*Ye11*conj[Ye22]*conj[ZE[gt1, 5]]*
      conj[ZV[gt2, 1]]*ZE[gt3, 4]*ZV[gt4, 2] - 2*g1^2*conj[ZE[gt1, 4]]*
      conj[ZV[gt2, 2]]*ZE[gt3, 4]*ZV[gt4, 2] + 4*gp^2*Qe1*Ql2*
      conj[ZE[gt1, 4]]*conj[ZV[gt2, 2]]*ZE[gt3, 4]*ZV[gt4, 2] - 
     2*g1^2*conj[ZE[gt1, 5]]*conj[ZV[gt2, 2]]*ZE[gt3, 5]*ZV[gt4, 2] + 
     4*gp^2*Qe2*Ql2*conj[ZE[gt1, 5]]*conj[ZV[gt2, 2]]*ZE[gt3, 5]*ZV[gt4, 2] + 
     4*Ye22*conj[Ye22]*conj[ZE[gt1, 5]]*conj[ZV[gt2, 2]]*ZE[gt3, 5]*
      ZV[gt4, 2] - 2*g1^2*conj[ZE[gt1, 6]]*conj[ZV[gt2, 2]]*ZE[gt3, 6]*
      ZV[gt4, 2] + 4*gp^2*Qe3*Ql2*conj[ZE[gt1, 6]]*conj[ZV[gt2, 2]]*
      ZE[gt3, 6]*ZV[gt4, 2] + 4*Ye33*conj[Ye22]*conj[ZE[gt1, 5]]*
      conj[ZV[gt2, 3]]*ZE[gt3, 6]*ZV[gt4, 2] + 2*g2^2*conj[ZE[gt1, 3]]*
      conj[ZV[gt2, 1]]*ZE[gt3, 1]*ZV[gt4, 3] + 2*g2^2*conj[ZE[gt1, 3]]*
      conj[ZV[gt2, 2]]*ZE[gt3, 2]*ZV[gt4, 3] + g1^2*conj[ZE[gt1, 3]]*
      conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZV[gt4, 3] + g2^2*conj[ZE[gt1, 3]]*
      conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZV[gt4, 3] + 4*gp^2*Ql3^2*conj[ZE[gt1, 3]]*
      conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZV[gt4, 3] + 4*Ye11*conj[Ye33]*
      conj[ZE[gt1, 6]]*conj[ZV[gt2, 1]]*ZE[gt3, 4]*ZV[gt4, 3] - 
     2*g1^2*conj[ZE[gt1, 4]]*conj[ZV[gt2, 3]]*ZE[gt3, 4]*ZV[gt4, 3] + 
     4*gp^2*Qe1*Ql3*conj[ZE[gt1, 4]]*conj[ZV[gt2, 3]]*ZE[gt3, 4]*ZV[gt4, 3] + 
     4*Ye22*conj[Ye33]*conj[ZE[gt1, 6]]*conj[ZV[gt2, 2]]*ZE[gt3, 5]*
      ZV[gt4, 3] - 2*g1^2*conj[ZE[gt1, 5]]*conj[ZV[gt2, 3]]*ZE[gt3, 5]*
      ZV[gt4, 3] + 4*gp^2*Qe2*Ql3*conj[ZE[gt1, 5]]*conj[ZV[gt2, 3]]*
      ZE[gt3, 5]*ZV[gt4, 3] - 2*g1^2*conj[ZE[gt1, 6]]*conj[ZV[gt2, 3]]*
      ZE[gt3, 6]*ZV[gt4, 3] + 4*gp^2*Qe3*Ql3*conj[ZE[gt1, 6]]*
      conj[ZV[gt2, 3]]*ZE[gt3, 6]*ZV[gt4, 3] + 4*Ye33*conj[Ye33]*
      conj[ZE[gt1, 6]]*conj[ZV[gt2, 3]]*ZE[gt3, 6]*ZV[gt4, 3] + 
     4*gp^2*Ql3*Qv1*conj[ZE[gt1, 3]]*conj[ZV[gt2, 4]]*ZE[gt3, 3]*ZV[gt4, 4] + 
     4*gp^2*Qe1*Qv1*conj[ZE[gt1, 4]]*conj[ZV[gt2, 4]]*ZE[gt3, 4]*ZV[gt4, 4] + 
     4*gp^2*Qe2*Qv1*conj[ZE[gt1, 5]]*conj[ZV[gt2, 4]]*ZE[gt3, 5]*ZV[gt4, 4] + 
     4*gp^2*Qe3*Qv1*conj[ZE[gt1, 6]]*conj[ZV[gt2, 4]]*ZE[gt3, 6]*ZV[gt4, 4] + 
     4*gp^2*Ql3*Qv2*conj[ZE[gt1, 3]]*conj[ZV[gt2, 5]]*ZE[gt3, 3]*ZV[gt4, 5] + 
     4*gp^2*Qe1*Qv2*conj[ZE[gt1, 4]]*conj[ZV[gt2, 5]]*ZE[gt3, 4]*ZV[gt4, 5] + 
     4*gp^2*Qe2*Qv2*conj[ZE[gt1, 5]]*conj[ZV[gt2, 5]]*ZE[gt3, 5]*ZV[gt4, 5] + 
     4*gp^2*Qe3*Qv2*conj[ZE[gt1, 6]]*conj[ZV[gt2, 5]]*ZE[gt3, 6]*ZV[gt4, 5] + 
     4*Yv33*conj[Yv11]*conj[ZE[gt1, 3]]*conj[ZV[gt2, 4]]*ZE[gt3, 1]*
      ZV[gt4, 6] + 4*Yv33*conj[Yv22]*conj[ZE[gt1, 3]]*conj[ZV[gt2, 5]]*
      ZE[gt3, 2]*ZV[gt4, 6] + 4*gp^2*Ql3*Qv3*conj[ZE[gt1, 3]]*
      conj[ZV[gt2, 6]]*ZE[gt3, 3]*ZV[gt4, 6] + 4*Yv33*conj[Yv33]*
      conj[ZE[gt1, 3]]*conj[ZV[gt2, 6]]*ZE[gt3, 3]*ZV[gt4, 6] + 
     4*gp^2*Qe1*Qv3*conj[ZE[gt1, 4]]*conj[ZV[gt2, 6]]*ZE[gt3, 4]*ZV[gt4, 6] + 
     4*gp^2*Qe2*Qv3*conj[ZE[gt1, 5]]*conj[ZV[gt2, 6]]*ZE[gt3, 5]*ZV[gt4, 6] + 
     4*gp^2*Qe3*Qv3*conj[ZE[gt1, 6]]*conj[ZV[gt2, 6]]*ZE[gt3, 6]*ZV[gt4, 6] + 
     conj[ZE[gt1, 1]]*((g1^2 + g2^2 + 4*gp^2*Ql1^2)*conj[ZV[gt2, 1]]*
        ZE[gt3, 1]*ZV[gt4, 1] + 2*g2^2*conj[ZV[gt2, 3]]*ZE[gt3, 3]*
        ZV[gt4, 1] + conj[ZV[gt2, 2]]*(2*g2^2*ZE[gt3, 2]*ZV[gt4, 1] + 
         (g1^2 - g2^2 + 4*gp^2*Ql1*Ql2)*ZE[gt3, 1]*ZV[gt4, 2]) + 
       g1^2*conj[ZV[gt2, 3]]*ZE[gt3, 1]*ZV[gt4, 3] - g2^2*conj[ZV[gt2, 3]]*
        ZE[gt3, 1]*ZV[gt4, 3] + 4*gp^2*Ql1*Ql3*conj[ZV[gt2, 3]]*ZE[gt3, 1]*
        ZV[gt4, 3] + 4*gp^2*Ql1*Qv1*conj[ZV[gt2, 4]]*ZE[gt3, 1]*ZV[gt4, 4] + 
       4*Yv11*conj[Yv11]*conj[ZV[gt2, 4]]*ZE[gt3, 1]*ZV[gt4, 4] + 
       4*Yv11*conj[Yv22]*conj[ZV[gt2, 5]]*ZE[gt3, 2]*ZV[gt4, 4] + 
       4*Yv11*conj[Yv33]*conj[ZV[gt2, 6]]*ZE[gt3, 3]*ZV[gt4, 4] + 
       4*gp^2*Ql1*Qv2*conj[ZV[gt2, 5]]*ZE[gt3, 1]*ZV[gt4, 5] + 
       4*gp^2*Ql1*Qv3*conj[ZV[gt2, 6]]*ZE[gt3, 1]*ZV[gt4, 6]) + 
     conj[ZE[gt1, 2]]*((g1^2 + g2^2 + 4*gp^2*Ql2^2)*conj[ZV[gt2, 2]]*
        ZE[gt3, 2]*ZV[gt4, 2] + 2*g2^2*conj[ZV[gt2, 3]]*ZE[gt3, 3]*
        ZV[gt4, 2] + conj[ZV[gt2, 1]]*((g1^2 - g2^2 + 4*gp^2*Ql1*Ql2)*
          ZE[gt3, 2]*ZV[gt4, 1] + 2*g2^2*ZE[gt3, 1]*ZV[gt4, 2]) + 
       g1^2*conj[ZV[gt2, 3]]*ZE[gt3, 2]*ZV[gt4, 3] - g2^2*conj[ZV[gt2, 3]]*
        ZE[gt3, 2]*ZV[gt4, 3] + 4*gp^2*Ql2*Ql3*conj[ZV[gt2, 3]]*ZE[gt3, 2]*
        ZV[gt4, 3] + 4*gp^2*Ql2*Qv1*conj[ZV[gt2, 4]]*ZE[gt3, 2]*ZV[gt4, 4] + 
       4*Yv22*conj[Yv11]*conj[ZV[gt2, 4]]*ZE[gt3, 1]*ZV[gt4, 5] + 
       4*gp^2*Ql2*Qv2*conj[ZV[gt2, 5]]*ZE[gt3, 2]*ZV[gt4, 5] + 
       4*Yv22*conj[Yv22]*conj[ZV[gt2, 5]]*ZE[gt3, 2]*ZV[gt4, 5] + 
       4*Yv22*conj[Yv33]*conj[ZV[gt2, 6]]*ZE[gt3, 3]*ZV[gt4, 5] + 
       4*gp^2*Ql2*Qv3*conj[ZV[gt2, 6]]*ZE[gt3, 2]*ZV[gt4, 6])), 1}}, 
 {{Su[{gt1, ct1}], Su[{gt2, ct2}], conj[Su[{gt3, ct3}]], 
   conj[Su[{gt4, ct4}]]}, 
  {(-I/72)*(Delta[ct1, ct4]*Delta[ct2, ct3]*
      (g1^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt3, j2]] + 
       9*g2^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt3, j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt3, j2]] + 
       36*gp^2*Qq^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt3, j2]] - 
       4*g1^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt3, j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt3, j2]] + 
       36*gp^2*Qq*Qu*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt3, j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]]*
        (sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt3, j2]] - 
         sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt3, 3 + j2]]) - 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt4, 3 + j1]]*
        (sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt3, j2]] - 
         sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt3, 3 + j2]]) - 
       4*g1^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt3, 3 + j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt3, 3 + j2]] + 
       36*gp^2*Qq*Qu*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt3, 3 + j2]] + 
       16*g1^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt3, 3 + j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt3, 3 + j2]] + 
       36*gp^2*Qu^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt3, 3 + j2]] + 
       g1^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt4, j2]] + 
       9*g2^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt4, j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt4, j2]] + 
       36*gp^2*Qq^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt4, j2]] - 
       4*g1^2*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt4, j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt4, j2]] + 
       36*gp^2*Qq*Qu*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt4, j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       4*g1^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       36*gp^2*Qq*Qu*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       16*g1^2*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt4, 3 + j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       36*gp^2*Qu^2*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt4, 3 + j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       72*sum[j2, 1, 3, conj[ZU[gt1, j2]]*sum[j1, 1, 3, 
           Yu[j1, j2]*ZU[gt4, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yu[j3, j4]]*conj[ZU[gt2, 3 + j3]]]*ZU[gt3, j4]] + 
       72*sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
           Yu[j1, j2]*ZU[gt3, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yu[j3, j4]]*conj[ZU[gt1, 3 + j3]]]*
          ZU[gt4, j4]]) + Delta[ct1, ct3]*Delta[ct2, ct4]*
      (18*g3^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt3, j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt3, j2]] + 
       sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt4, j1]]*
        ((g1^2 + 9*g2^2 - 6*g3^2 + 36*gp^2*Qq^2)*sum[j2, 1, 3, 
           conj[ZU[gt1, j2]]*ZU[gt3, j2]] + 2*(-2*g1^2 + 3*g3^2 + 
           18*gp^2*Qq*Qu)*sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*
            ZU[gt3, 3 + j2]]) + sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
          ZU[gt4, 3 + j1]]*((-4*g1^2 + 6*g3^2 + 36*gp^2*Qq*Qu)*
          sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt3, j2]] + 
         2*(8*g1^2 - 3*g3^2 + 18*gp^2*Qu^2)*sum[j2, 1, 3, 
           conj[ZU[gt1, 3 + j2]]*ZU[gt3, 3 + j2]]) - 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt4, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt3, 3 + j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt4, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt3, 3 + j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt4, j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, j2]]*ZU[gt4, j2]] + 
       g1^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] + 
       9*g2^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] + 
       36*gp^2*Qq^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       4*g1^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] + 
       36*gp^2*Qq*Qu*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, j2]]*ZU[gt4, j2]] - 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       18*g3^2*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt1, 3 + j2]]*ZU[gt4, 3 + j2]] - 
       4*g1^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       36*gp^2*Qq*Qu*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       16*g1^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] - 
       6*g3^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       36*gp^2*Qu^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*
        sum[j2, 1, 3, conj[ZU[gt2, 3 + j2]]*ZU[gt4, 3 + j2]] + 
       72*sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
           Yu[j1, j2]*ZU[gt4, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yu[j3, j4]]*conj[ZU[gt1, 3 + j3]]]*ZU[gt3, j4]] + 
       72*sum[j2, 1, 3, conj[ZU[gt1, j2]]*sum[j1, 1, 3, 
           Yu[j1, j2]*ZU[gt3, 3 + j1]]]*sum[j4, 1, 3, 
         sum[j3, 1, 3, conj[Yu[j3, j4]]*conj[ZU[gt2, 3 + j3]]]*
          ZU[gt4, j4]])), 1}}, 
 {{Su[{gt1, ct1}], Sv[{gt2}], conj[Su[{gt3, ct3}]], conj[Sv[{gt4}]]}, 
  {(-I/12)*Delta[ct1, ct3]*(12*conj[Yv11]*conj[ZV[gt2, 4]]*
      sum[j2, 1, 3, conj[ZU[gt1, j2]]*sum[j1, 1, 3, 
         Yu[j1, j2]*ZU[gt3, 3 + j1]]]*ZV[gt4, 1] - g1^2*conj[ZV[gt2, 2]]*
      sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*ZV[gt4, 2] + 
     3*g2^2*conj[ZV[gt2, 2]]*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
      ZV[gt4, 2] + 12*gp^2*Ql2*Qq*conj[ZV[gt2, 2]]*
      sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*ZV[gt4, 2] + 
     4*g1^2*conj[ZV[gt2, 2]]*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*
        ZU[gt3, 3 + j1]]*ZV[gt4, 2] + 12*gp^2*Ql2*Qu*conj[ZV[gt2, 2]]*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*ZV[gt4, 2] + 
     12*conj[Yv22]*conj[ZV[gt2, 5]]*sum[j2, 1, 3, conj[ZU[gt1, j2]]*
        sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]]*ZV[gt4, 2] - 
     g1^2*conj[ZV[gt2, 3]]*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*
      ZV[gt4, 3] + 3*g2^2*conj[ZV[gt2, 3]]*sum[j1, 1, 3, 
       conj[ZU[gt1, j1]]*ZU[gt3, j1]]*ZV[gt4, 3] + 
     12*gp^2*Ql3*Qq*conj[ZV[gt2, 3]]*sum[j1, 1, 3, conj[ZU[gt1, j1]]*
        ZU[gt3, j1]]*ZV[gt4, 3] + 4*g1^2*conj[ZV[gt2, 3]]*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*ZV[gt4, 3] + 
     12*gp^2*Ql3*Qu*conj[ZV[gt2, 3]]*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*
        ZU[gt3, 3 + j1]]*ZV[gt4, 3] + 12*conj[Yv33]*conj[ZV[gt2, 6]]*
      sum[j2, 1, 3, conj[ZU[gt1, j2]]*sum[j1, 1, 3, 
         Yu[j1, j2]*ZU[gt3, 3 + j1]]]*ZV[gt4, 3] + 
     12*gp^2*Qq*Qv1*conj[ZV[gt2, 4]]*sum[j1, 1, 3, conj[ZU[gt1, j1]]*
        ZU[gt3, j1]]*ZV[gt4, 4] + 12*gp^2*Qu*Qv1*conj[ZV[gt2, 4]]*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt3, 3 + j1]]*ZV[gt4, 4] + 
     conj[ZV[gt2, 1]]*((-g1^2 + 3*(g2^2 + 4*gp^2*Ql1*Qq))*
        sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*ZV[gt4, 1] + 
       4*((g1^2 + 3*gp^2*Ql1*Qu)*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*
            ZU[gt3, 3 + j1]]*ZV[gt4, 1] + 3*Yv11*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt1, 3 + j1]]]*ZU[gt3, j2]]*
          ZV[gt4, 4])) + 12*gp^2*Qq*Qv2*conj[ZV[gt2, 5]]*
      sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*ZV[gt4, 5] + 
     12*gp^2*Qu*Qv2*conj[ZV[gt2, 5]]*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*
        ZU[gt3, 3 + j1]]*ZV[gt4, 5] + 12*Yv22*conj[ZV[gt2, 2]]*
      sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt1, 3 + j1]]]*
        ZU[gt3, j2]]*ZV[gt4, 5] + 12*gp^2*Qq*Qv3*conj[ZV[gt2, 6]]*
      sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt3, j1]]*ZV[gt4, 6] + 
     12*gp^2*Qu*Qv3*conj[ZV[gt2, 6]]*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*
        ZU[gt3, 3 + j1]]*ZV[gt4, 6] + 12*Yv33*conj[ZV[gt2, 3]]*
      sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt1, 3 + j1]]]*
        ZU[gt3, j2]]*ZV[gt4, 6]), 1}}, 
 {{Sv[{gt1}], Sv[{gt2}], conj[Sv[{gt3}]], conj[Sv[{gt4}]]}, 
  {(-I/4)*(g1^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 1]]*ZV[gt3, 3]*ZV[gt4, 1] + 
     g2^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 1]]*ZV[gt3, 3]*ZV[gt4, 1] + 
     4*gp^2*Ql1*Ql3*conj[ZV[gt1, 3]]*conj[ZV[gt2, 1]]*ZV[gt3, 3]*ZV[gt4, 1] + 
     4*gp^2*Ql1*Qv1*conj[ZV[gt1, 4]]*conj[ZV[gt2, 1]]*ZV[gt3, 4]*ZV[gt4, 1] + 
     4*Yv11*conj[Yv11]*conj[ZV[gt1, 4]]*conj[ZV[gt2, 1]]*ZV[gt3, 4]*
      ZV[gt4, 1] + 4*gp^2*Ql1*Qv2*conj[ZV[gt1, 5]]*conj[ZV[gt2, 1]]*
      ZV[gt3, 5]*ZV[gt4, 1] + 4*Yv22*conj[Yv11]*conj[ZV[gt1, 4]]*
      conj[ZV[gt2, 2]]*ZV[gt3, 5]*ZV[gt4, 1] + 4*gp^2*Ql1*Qv3*
      conj[ZV[gt1, 6]]*conj[ZV[gt2, 1]]*ZV[gt3, 6]*ZV[gt4, 1] + 
     4*Yv33*conj[Yv11]*conj[ZV[gt1, 4]]*conj[ZV[gt2, 3]]*ZV[gt3, 6]*
      ZV[gt4, 1] + 4*Yv33*conj[Yv11]*conj[ZV[gt1, 3]]*conj[ZV[gt2, 4]]*
      ZV[gt3, 6]*ZV[gt4, 1] + g1^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 2]]*
      ZV[gt3, 3]*ZV[gt4, 2] + g2^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 2]]*
      ZV[gt3, 3]*ZV[gt4, 2] + 4*gp^2*Ql2*Ql3*conj[ZV[gt1, 3]]*
      conj[ZV[gt2, 2]]*ZV[gt3, 3]*ZV[gt4, 2] + 4*Yv11*conj[Yv22]*
      conj[ZV[gt1, 5]]*conj[ZV[gt2, 1]]*ZV[gt3, 4]*ZV[gt4, 2] + 
     4*gp^2*Ql2*Qv1*conj[ZV[gt1, 4]]*conj[ZV[gt2, 2]]*ZV[gt3, 4]*ZV[gt4, 2] + 
     4*gp^2*Ql2*Qv2*conj[ZV[gt1, 5]]*conj[ZV[gt2, 2]]*ZV[gt3, 5]*ZV[gt4, 2] + 
     4*Yv22*conj[Yv22]*conj[ZV[gt1, 5]]*conj[ZV[gt2, 2]]*ZV[gt3, 5]*
      ZV[gt4, 2] + 4*gp^2*Ql2*Qv3*conj[ZV[gt1, 6]]*conj[ZV[gt2, 2]]*
      ZV[gt3, 6]*ZV[gt4, 2] + 4*Yv33*conj[Yv22]*conj[ZV[gt1, 5]]*
      conj[ZV[gt2, 3]]*ZV[gt3, 6]*ZV[gt4, 2] + 4*Yv33*conj[Yv22]*
      conj[ZV[gt1, 3]]*conj[ZV[gt2, 5]]*ZV[gt3, 6]*ZV[gt4, 2] + 
     g1^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 1]]*ZV[gt3, 1]*ZV[gt4, 3] + 
     g2^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 1]]*ZV[gt3, 1]*ZV[gt4, 3] + 
     4*gp^2*Ql1*Ql3*conj[ZV[gt1, 3]]*conj[ZV[gt2, 1]]*ZV[gt3, 1]*ZV[gt4, 3] + 
     g1^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 2]]*ZV[gt3, 2]*ZV[gt4, 3] + 
     g2^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 2]]*ZV[gt3, 2]*ZV[gt4, 3] + 
     4*gp^2*Ql2*Ql3*conj[ZV[gt1, 3]]*conj[ZV[gt2, 2]]*ZV[gt3, 2]*ZV[gt4, 3] + 
     2*g1^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 3] + 
     2*g2^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 3] + 
     8*gp^2*Ql3^2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 3] + 
     4*Yv11*conj[Yv33]*conj[ZV[gt1, 6]]*conj[ZV[gt2, 1]]*ZV[gt3, 4]*
      ZV[gt4, 3] + 4*gp^2*Ql3*Qv1*conj[ZV[gt1, 4]]*conj[ZV[gt2, 3]]*
      ZV[gt3, 4]*ZV[gt4, 3] + 4*gp^2*Ql3*Qv1*conj[ZV[gt1, 3]]*
      conj[ZV[gt2, 4]]*ZV[gt3, 4]*ZV[gt4, 3] + 4*Yv22*conj[Yv33]*
      conj[ZV[gt1, 6]]*conj[ZV[gt2, 2]]*ZV[gt3, 5]*ZV[gt4, 3] + 
     4*gp^2*Ql3*Qv2*conj[ZV[gt1, 5]]*conj[ZV[gt2, 3]]*ZV[gt3, 5]*ZV[gt4, 3] + 
     4*gp^2*Ql3*Qv2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 5]]*ZV[gt3, 5]*ZV[gt4, 3] + 
     4*gp^2*Ql3*Qv3*conj[ZV[gt1, 6]]*conj[ZV[gt2, 3]]*ZV[gt3, 6]*ZV[gt4, 3] + 
     4*Yv33*conj[Yv33]*conj[ZV[gt1, 6]]*conj[ZV[gt2, 3]]*ZV[gt3, 6]*
      ZV[gt4, 3] + 4*gp^2*Ql3*Qv3*conj[ZV[gt1, 3]]*conj[ZV[gt2, 6]]*
      ZV[gt3, 6]*ZV[gt4, 3] + 4*Yv33*conj[Yv33]*conj[ZV[gt1, 3]]*
      conj[ZV[gt2, 6]]*ZV[gt3, 6]*ZV[gt4, 3] + 4*gp^2*Ql1*Qv1*
      conj[ZV[gt1, 4]]*conj[ZV[gt2, 1]]*ZV[gt3, 1]*ZV[gt4, 4] + 
     4*Yv11*conj[Yv11]*conj[ZV[gt1, 4]]*conj[ZV[gt2, 1]]*ZV[gt3, 1]*
      ZV[gt4, 4] + 4*Yv11*conj[Yv22]*conj[ZV[gt1, 5]]*conj[ZV[gt2, 1]]*
      ZV[gt3, 2]*ZV[gt4, 4] + 4*gp^2*Ql2*Qv1*conj[ZV[gt1, 4]]*
      conj[ZV[gt2, 2]]*ZV[gt3, 2]*ZV[gt4, 4] + 4*Yv11*conj[Yv33]*
      conj[ZV[gt1, 6]]*conj[ZV[gt2, 1]]*ZV[gt3, 3]*ZV[gt4, 4] + 
     4*gp^2*Ql3*Qv1*conj[ZV[gt1, 4]]*conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 4] + 
     4*gp^2*Ql3*Qv1*conj[ZV[gt1, 3]]*conj[ZV[gt2, 4]]*ZV[gt3, 3]*ZV[gt4, 4] + 
     8*gp^2*Qv1^2*conj[ZV[gt1, 4]]*conj[ZV[gt2, 4]]*ZV[gt3, 4]*ZV[gt4, 4] + 
     4*gp^2*Qv1*Qv2*conj[ZV[gt1, 5]]*conj[ZV[gt2, 4]]*ZV[gt3, 5]*ZV[gt4, 4] + 
     4*gp^2*Qv1*Qv2*conj[ZV[gt1, 4]]*conj[ZV[gt2, 5]]*ZV[gt3, 5]*ZV[gt4, 4] + 
     4*gp^2*Qv1*Qv3*conj[ZV[gt1, 6]]*conj[ZV[gt2, 4]]*ZV[gt3, 6]*ZV[gt4, 4] + 
     4*gp^2*Qv1*Qv3*conj[ZV[gt1, 4]]*conj[ZV[gt2, 6]]*ZV[gt3, 6]*ZV[gt4, 4] + 
     4*gp^2*Ql1*Qv2*conj[ZV[gt1, 5]]*conj[ZV[gt2, 1]]*ZV[gt3, 1]*ZV[gt4, 5] + 
     4*Yv22*conj[Yv11]*conj[ZV[gt1, 4]]*conj[ZV[gt2, 2]]*ZV[gt3, 1]*
      ZV[gt4, 5] + 4*gp^2*Ql2*Qv2*conj[ZV[gt1, 5]]*conj[ZV[gt2, 2]]*
      ZV[gt3, 2]*ZV[gt4, 5] + 4*Yv22*conj[Yv22]*conj[ZV[gt1, 5]]*
      conj[ZV[gt2, 2]]*ZV[gt3, 2]*ZV[gt4, 5] + 4*Yv22*conj[Yv33]*
      conj[ZV[gt1, 6]]*conj[ZV[gt2, 2]]*ZV[gt3, 3]*ZV[gt4, 5] + 
     4*gp^2*Ql3*Qv2*conj[ZV[gt1, 5]]*conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 5] + 
     4*gp^2*Ql3*Qv2*conj[ZV[gt1, 3]]*conj[ZV[gt2, 5]]*ZV[gt3, 3]*ZV[gt4, 5] + 
     4*gp^2*Qv1*Qv2*conj[ZV[gt1, 5]]*conj[ZV[gt2, 4]]*ZV[gt3, 4]*ZV[gt4, 5] + 
     4*gp^2*Qv1*Qv2*conj[ZV[gt1, 4]]*conj[ZV[gt2, 5]]*ZV[gt3, 4]*ZV[gt4, 5] + 
     8*gp^2*Qv2^2*conj[ZV[gt1, 5]]*conj[ZV[gt2, 5]]*ZV[gt3, 5]*ZV[gt4, 5] + 
     4*gp^2*Qv2*Qv3*conj[ZV[gt1, 6]]*conj[ZV[gt2, 5]]*ZV[gt3, 6]*ZV[gt4, 5] + 
     4*gp^2*Qv2*Qv3*conj[ZV[gt1, 5]]*conj[ZV[gt2, 6]]*ZV[gt3, 6]*ZV[gt4, 5] + 
     4*gp^2*Ql1*Qv3*conj[ZV[gt1, 6]]*conj[ZV[gt2, 1]]*ZV[gt3, 1]*ZV[gt4, 6] + 
     4*Yv33*conj[Yv11]*conj[ZV[gt1, 4]]*conj[ZV[gt2, 3]]*ZV[gt3, 1]*
      ZV[gt4, 6] + 4*Yv33*conj[Yv11]*conj[ZV[gt1, 3]]*conj[ZV[gt2, 4]]*
      ZV[gt3, 1]*ZV[gt4, 6] + 4*gp^2*Ql2*Qv3*conj[ZV[gt1, 6]]*
      conj[ZV[gt2, 2]]*ZV[gt3, 2]*ZV[gt4, 6] + 4*Yv33*conj[Yv22]*
      conj[ZV[gt1, 5]]*conj[ZV[gt2, 3]]*ZV[gt3, 2]*ZV[gt4, 6] + 
     4*Yv33*conj[Yv22]*conj[ZV[gt1, 3]]*conj[ZV[gt2, 5]]*ZV[gt3, 2]*
      ZV[gt4, 6] + 4*gp^2*Ql3*Qv3*conj[ZV[gt1, 6]]*conj[ZV[gt2, 3]]*
      ZV[gt3, 3]*ZV[gt4, 6] + 4*Yv33*conj[Yv33]*conj[ZV[gt1, 6]]*
      conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 6] + 4*gp^2*Ql3*Qv3*
      conj[ZV[gt1, 3]]*conj[ZV[gt2, 6]]*ZV[gt3, 3]*ZV[gt4, 6] + 
     4*Yv33*conj[Yv33]*conj[ZV[gt1, 3]]*conj[ZV[gt2, 6]]*ZV[gt3, 3]*
      ZV[gt4, 6] + 4*gp^2*Qv1*Qv3*conj[ZV[gt1, 6]]*conj[ZV[gt2, 4]]*
      ZV[gt3, 4]*ZV[gt4, 6] + 4*gp^2*Qv1*Qv3*conj[ZV[gt1, 4]]*
      conj[ZV[gt2, 6]]*ZV[gt3, 4]*ZV[gt4, 6] + 4*gp^2*Qv2*Qv3*
      conj[ZV[gt1, 6]]*conj[ZV[gt2, 5]]*ZV[gt3, 5]*ZV[gt4, 6] + 
     4*gp^2*Qv2*Qv3*conj[ZV[gt1, 5]]*conj[ZV[gt2, 6]]*ZV[gt3, 5]*ZV[gt4, 6] + 
     8*gp^2*Qv3^2*conj[ZV[gt1, 6]]*conj[ZV[gt2, 6]]*ZV[gt3, 6]*ZV[gt4, 6] + 
     conj[ZV[gt1, 1]]*(2*(g1^2 + g2^2 + 4*gp^2*Ql1^2)*conj[ZV[gt2, 1]]*
        ZV[gt3, 1]*ZV[gt4, 1] + g1^2*conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 1] + 
       g2^2*conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 1] + 
       4*gp^2*Ql1*Ql3*conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 1] + 
       4*gp^2*Ql1*Qv1*conj[ZV[gt2, 4]]*ZV[gt3, 4]*ZV[gt4, 1] + 
       4*Yv11*conj[Yv11]*conj[ZV[gt2, 4]]*ZV[gt3, 4]*ZV[gt4, 1] + 
       4*gp^2*Ql1*Qv2*conj[ZV[gt2, 5]]*ZV[gt3, 5]*ZV[gt4, 1] + 
       4*gp^2*Ql1*Qv3*conj[ZV[gt2, 6]]*ZV[gt3, 6]*ZV[gt4, 1] + 
       4*Yv11*conj[Yv22]*conj[ZV[gt2, 5]]*ZV[gt3, 4]*ZV[gt4, 2] + 
       (g1^2 + g2^2 + 4*gp^2*Ql1*Ql2)*conj[ZV[gt2, 2]]*
        (ZV[gt3, 2]*ZV[gt4, 1] + ZV[gt3, 1]*ZV[gt4, 2]) + 
       g1^2*conj[ZV[gt2, 3]]*ZV[gt3, 1]*ZV[gt4, 3] + g2^2*conj[ZV[gt2, 3]]*
        ZV[gt3, 1]*ZV[gt4, 3] + 4*gp^2*Ql1*Ql3*conj[ZV[gt2, 3]]*ZV[gt3, 1]*
        ZV[gt4, 3] + 4*Yv11*conj[Yv33]*conj[ZV[gt2, 6]]*ZV[gt3, 4]*
        ZV[gt4, 3] + 4*gp^2*Ql1*Qv1*conj[ZV[gt2, 4]]*ZV[gt3, 1]*ZV[gt4, 4] + 
       4*Yv11*conj[Yv11]*conj[ZV[gt2, 4]]*ZV[gt3, 1]*ZV[gt4, 4] + 
       4*Yv11*conj[Yv22]*conj[ZV[gt2, 5]]*ZV[gt3, 2]*ZV[gt4, 4] + 
       4*Yv11*conj[Yv33]*conj[ZV[gt2, 6]]*ZV[gt3, 3]*ZV[gt4, 4] + 
       4*gp^2*Ql1*Qv2*conj[ZV[gt2, 5]]*ZV[gt3, 1]*ZV[gt4, 5] + 
       4*gp^2*Ql1*Qv3*conj[ZV[gt2, 6]]*ZV[gt3, 1]*ZV[gt4, 6]) + 
     conj[ZV[gt1, 2]]*(2*g1^2*conj[ZV[gt2, 2]]*ZV[gt3, 2]*ZV[gt4, 2] + 
       2*g2^2*conj[ZV[gt2, 2]]*ZV[gt3, 2]*ZV[gt4, 2] + 
       8*gp^2*Ql2^2*conj[ZV[gt2, 2]]*ZV[gt3, 2]*ZV[gt4, 2] + 
       g1^2*conj[ZV[gt2, 3]]*ZV[gt3, 3]*ZV[gt4, 2] + g2^2*conj[ZV[gt2, 3]]*
        ZV[gt3, 3]*ZV[gt4, 2] + 4*gp^2*Ql2*Ql3*conj[ZV[gt2, 3]]*ZV[gt3, 3]*
        ZV[gt4, 2] + 4*gp^2*Ql2*Qv1*conj[ZV[gt2, 4]]*ZV[gt3, 4]*ZV[gt4, 2] + 
       4*gp^2*Ql2*Qv2*conj[ZV[gt2, 5]]*ZV[gt3, 5]*ZV[gt4, 2] + 
       4*Yv22*conj[Yv22]*conj[ZV[gt2, 5]]*ZV[gt3, 5]*ZV[gt4, 2] + 
       4*gp^2*Ql2*Qv3*conj[ZV[gt2, 6]]*ZV[gt3, 6]*ZV[gt4, 2] + 
       (g1^2 + g2^2 + 4*gp^2*Ql1*Ql2)*conj[ZV[gt2, 1]]*
        (ZV[gt3, 2]*ZV[gt4, 1] + ZV[gt3, 1]*ZV[gt4, 2]) + 
       g1^2*conj[ZV[gt2, 3]]*ZV[gt3, 2]*ZV[gt4, 3] + g2^2*conj[ZV[gt2, 3]]*
        ZV[gt3, 2]*ZV[gt4, 3] + 4*gp^2*Ql2*Ql3*conj[ZV[gt2, 3]]*ZV[gt3, 2]*
        ZV[gt4, 3] + 4*Yv22*conj[Yv33]*conj[ZV[gt2, 6]]*ZV[gt3, 5]*
        ZV[gt4, 3] + 4*gp^2*Ql2*Qv1*conj[ZV[gt2, 4]]*ZV[gt3, 2]*ZV[gt4, 4] + 
       4*gp^2*Ql2*Qv2*conj[ZV[gt2, 5]]*ZV[gt3, 2]*ZV[gt4, 5] + 
       4*Yv22*conj[Yv22]*conj[ZV[gt2, 5]]*ZV[gt3, 2]*ZV[gt4, 5] + 
       4*Yv22*conj[Yv33]*conj[ZV[gt2, 6]]*ZV[gt3, 3]*ZV[gt4, 5] + 
       4*Yv22*conj[Yv11]*conj[ZV[gt2, 4]]*(ZV[gt3, 5]*ZV[gt4, 1] + 
         ZV[gt3, 1]*ZV[gt4, 5]) + 4*gp^2*Ql2*Qv3*conj[ZV[gt2, 6]]*ZV[gt3, 2]*
        ZV[gt4, 6])), 1}}, {{Ah[{gt1}], Ah[{gt2}], conj[VWm[{lt3}]], 
   VWm[{lt4}]}, {(I/2)*g2^2*(conj[ZA[gt1, 1]]*conj[ZA[gt2, 1]] + 
     conj[ZA[gt1, 2]]*conj[ZA[gt2, 2]]), g[lt3, lt4]}}, 
 {{Ah[{gt1}], Ah[{gt2}], VZ[{lt3}], VZ[{lt4}]}, 
  {(I/2)*(4*gp^2*Qs^2*conj[ZA[gt1, 3]]*conj[ZA[gt2, 3]]*Sin[ThetaWp]^2 + 
     conj[ZA[gt1, 1]]*conj[ZA[gt2, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])^2 + 
     conj[ZA[gt1, 2]]*conj[ZA[gt2, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])^2), 
   g[lt3, lt4]}}, {{Ah[{gt1}], Ah[{gt2}], VZ[{lt3}], VZp[{lt4}]}, 
  {(-I/2)*(-4*gp^2*Qs^2*conj[ZA[gt1, 3]]*conj[ZA[gt2, 3]]*Cos[ThetaWp]*
      Sin[ThetaWp] + conj[ZA[gt1, 1]]*conj[ZA[gt2, 1]]*
      (-2*g1*gp*QHd*Cos[ThetaWp]^2*Sin[ThetaW] + g2^2*Cos[ThetaW]^2*
        Cos[ThetaWp]*Sin[ThetaWp] + Cos[ThetaWp]*(-4*gp^2*QHd^2 + 
         g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 2*g1*gp*QHd*Sin[ThetaW]*
        Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*(-(gp*QHd*Cos[ThetaWp]^2) + 
         g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] + gp*QHd*Sin[ThetaWp]^2)) + 
     conj[ZA[gt1, 2]]*conj[ZA[gt2, 2]]*(2*g1*gp*QHu*Cos[ThetaWp]^2*
        Sin[ThetaW] + g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHu^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 
       2*g1*gp*QHu*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*QHu*Cos[ThetaWp]^2 + g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*QHu*Sin[ThetaWp]^2))), g[lt3, lt4]}}, 
 {{Ah[{gt1}], Ah[{gt2}], VZp[{lt3}], VZp[{lt4}]}, 
  {(I/2)*(4*gp^2*Qs^2*conj[ZA[gt1, 3]]*conj[ZA[gt2, 3]]*Cos[ThetaWp]^2 + 
     conj[ZA[gt1, 1]]*conj[ZA[gt2, 1]]*(-2*gp*QHd*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2 + 
     conj[ZA[gt1, 2]]*conj[ZA[gt2, 2]]*(2*gp*QHu*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2), g[lt3, lt4]}}, 
 {{Ah[{gt1}], Hpm[{gt2}], conj[VWm[{lt3}]], VP[{lt4}]}, 
  {-(g1*g2*Cos[ThetaW]*(conj[ZA[gt1, 1]]*ZP[gt2, 1] + 
       conj[ZA[gt1, 2]]*ZP[gt2, 2]))/2, g[lt3, lt4]}}, 
 {{Ah[{gt1}], Hpm[{gt2}], conj[VWm[{lt3}]], VZ[{lt4}]}, 
  {(g2*(conj[ZA[gt1, 1]]*(g1*Cos[ThetaWp]*Sin[ThetaW] + 
        2*gp*QHd*Sin[ThetaWp])*ZP[gt2, 1] + conj[ZA[gt1, 2]]*
       (g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])*ZP[gt2, 2]))/2, 
   g[lt3, lt4]}}, {{Ah[{gt1}], Hpm[{gt2}], conj[VWm[{lt3}]], VZp[{lt4}]}, 
  {(g2*(conj[ZA[gt1, 1]]*(2*gp*QHd*Cos[ThetaWp] - g1*Sin[ThetaW]*
         Sin[ThetaWp])*ZP[gt2, 1] - conj[ZA[gt1, 2]]*(2*gp*QHu*Cos[ThetaWp] + 
        g1*Sin[ThetaW]*Sin[ThetaWp])*ZP[gt2, 2]))/2, g[lt3, lt4]}}, 
 {{Ah[{gt1}], conj[Hpm[{gt2}]], VP[{lt3}], VWm[{lt4}]}, 
  {(g1*g2*Cos[ThetaW]*(conj[ZA[gt1, 1]]*ZP[gt2, 1] + 
      conj[ZA[gt1, 2]]*ZP[gt2, 2]))/2, g[lt3, lt4]}}, 
 {{Ah[{gt1}], conj[Hpm[{gt2}]], VWm[{lt3}], VZ[{lt4}]}, 
  {-(g2*(conj[ZA[gt1, 1]]*(g1*Cos[ThetaWp]*Sin[ThetaW] + 
         2*gp*QHd*Sin[ThetaWp])*ZP[gt2, 1] + conj[ZA[gt1, 2]]*
        (g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])*ZP[gt2, 2]))/2, 
   g[lt3, lt4]}}, {{Ah[{gt1}], conj[Hpm[{gt2}]], VWm[{lt3}], VZp[{lt4}]}, 
  {(g2*(conj[ZA[gt1, 1]]*(-2*gp*QHd*Cos[ThetaWp] + g1*Sin[ThetaW]*
         Sin[ThetaWp])*ZP[gt2, 1] + conj[ZA[gt1, 2]]*(2*gp*QHu*Cos[ThetaWp] + 
        g1*Sin[ThetaW]*Sin[ThetaWp])*ZP[gt2, 2]))/2, g[lt3, lt4]}}, 
 {{hh[{gt1}], hh[{gt2}], conj[VWm[{lt3}]], VWm[{lt4}]}, 
  {(I/2)*g2^2*(conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]] + 
     conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]), g[lt3, lt4]}}, 
 {{hh[{gt1}], hh[{gt2}], VZ[{lt3}], VZ[{lt4}]}, 
  {(I/2)*(4*gp^2*Qs^2*conj[ZH[gt1, 3]]*conj[ZH[gt2, 3]]*Sin[ThetaWp]^2 + 
     conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])^2 + 
     conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])^2), 
   g[lt3, lt4]}}, {{hh[{gt1}], hh[{gt2}], VZ[{lt3}], VZp[{lt4}]}, 
  {(-I/2)*(-4*gp^2*Qs^2*conj[ZH[gt1, 3]]*conj[ZH[gt2, 3]]*Cos[ThetaWp]*
      Sin[ThetaWp] + conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*
      (-2*g1*gp*QHd*Cos[ThetaWp]^2*Sin[ThetaW] + g2^2*Cos[ThetaW]^2*
        Cos[ThetaWp]*Sin[ThetaWp] + Cos[ThetaWp]*(-4*gp^2*QHd^2 + 
         g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 2*g1*gp*QHd*Sin[ThetaW]*
        Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*(-(gp*QHd*Cos[ThetaWp]^2) + 
         g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] + gp*QHd*Sin[ThetaWp]^2)) + 
     conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*(2*g1*gp*QHu*Cos[ThetaWp]^2*
        Sin[ThetaW] + g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHu^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 
       2*g1*gp*QHu*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*QHu*Cos[ThetaWp]^2 + g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*QHu*Sin[ThetaWp]^2))), g[lt3, lt4]}}, 
 {{hh[{gt1}], hh[{gt2}], VZp[{lt3}], VZp[{lt4}]}, 
  {(I/2)*(4*gp^2*Qs^2*conj[ZH[gt1, 3]]*conj[ZH[gt2, 3]]*Cos[ThetaWp]^2 + 
     conj[ZH[gt1, 1]]*conj[ZH[gt2, 1]]*(-2*gp*QHd*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2 + 
     conj[ZH[gt1, 2]]*conj[ZH[gt2, 2]]*(2*gp*QHu*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2), g[lt3, lt4]}}, 
 {{hh[{gt1}], Hpm[{gt2}], conj[VWm[{lt3}]], VP[{lt4}]}, 
  {(-I/2)*g1*g2*Cos[ThetaW]*(conj[ZH[gt1, 1]]*ZP[gt2, 1] - 
     conj[ZH[gt1, 2]]*ZP[gt2, 2]), g[lt3, lt4]}}, 
 {{hh[{gt1}], Hpm[{gt2}], conj[VWm[{lt3}]], VZ[{lt4}]}, 
  {(I/2)*g2*(conj[ZH[gt1, 1]]*(g1*Cos[ThetaWp]*Sin[ThetaW] + 
       2*gp*QHd*Sin[ThetaWp])*ZP[gt2, 1] + conj[ZH[gt1, 2]]*
      (-(g1*Cos[ThetaWp]*Sin[ThetaW]) + 2*gp*QHu*Sin[ThetaWp])*ZP[gt2, 2]), 
   g[lt3, lt4]}}, {{hh[{gt1}], Hpm[{gt2}], conj[VWm[{lt3}]], VZp[{lt4}]}, 
  {(I/2)*g2*(conj[ZH[gt1, 1]]*(2*gp*QHd*Cos[ThetaWp] - 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZP[gt2, 1] + conj[ZH[gt1, 2]]*
      (2*gp*QHu*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*ZP[gt2, 2]), 
   g[lt3, lt4]}}, {{hh[{gt1}], conj[Hpm[{gt2}]], VP[{lt3}], VWm[{lt4}]}, 
  {(-I/2)*g1*g2*Cos[ThetaW]*(conj[ZH[gt1, 1]]*ZP[gt2, 1] - 
     conj[ZH[gt1, 2]]*ZP[gt2, 2]), g[lt3, lt4]}}, 
 {{hh[{gt1}], conj[Hpm[{gt2}]], VWm[{lt3}], VZ[{lt4}]}, 
  {(I/2)*g2*(conj[ZH[gt1, 1]]*(g1*Cos[ThetaWp]*Sin[ThetaW] + 
       2*gp*QHd*Sin[ThetaWp])*ZP[gt2, 1] + conj[ZH[gt1, 2]]*
      (-(g1*Cos[ThetaWp]*Sin[ThetaW]) + 2*gp*QHu*Sin[ThetaWp])*ZP[gt2, 2]), 
   g[lt3, lt4]}}, {{hh[{gt1}], conj[Hpm[{gt2}]], VWm[{lt3}], VZp[{lt4}]}, 
  {(I/2)*g2*(conj[ZH[gt1, 1]]*(2*gp*QHd*Cos[ThetaWp] - 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZP[gt2, 1] + conj[ZH[gt1, 2]]*
      (2*gp*QHu*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*ZP[gt2, 2]), 
   g[lt3, lt4]}}, {{Hpm[{gt1}], conj[Hpm[{gt2}]], VP[{lt3}], VP[{lt4}]}, 
  {(I/2)*(g1*Cos[ThetaW] + g2*Sin[ThetaW])^2*(ZP[gt1, 1]*ZP[gt2, 1] + 
     ZP[gt1, 2]*ZP[gt2, 2]), g[lt3, lt4]}}, 
 {{Hpm[{gt1}], conj[Hpm[{gt2}]], VP[{lt3}], VZ[{lt4}]}, 
  {(-I/2)*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*
    ((-(g2*Cos[ThetaW]*Cos[ThetaWp]) + g1*Cos[ThetaWp]*Sin[ThetaW] + 
       2*gp*QHd*Sin[ThetaWp])*ZP[gt1, 1]*ZP[gt2, 1] + 
     (-(g2*Cos[ThetaW]*Cos[ThetaWp]) + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt1, 2]*ZP[gt2, 2]), g[lt3, lt4]}}, 
 {{Hpm[{gt1}], conj[Hpm[{gt2}]], VP[{lt3}], VZp[{lt4}]}, 
  {(I/2)*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*
    ((-2*gp*QHd*Cos[ThetaWp] + (-(g2*Cos[ThetaW]) + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt1, 1]*ZP[gt2, 1] + 
     (2*gp*QHu*Cos[ThetaWp] + (-(g2*Cos[ThetaW]) + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZP[gt1, 2]*ZP[gt2, 2]), g[lt3, lt4]}}, 
 {{Hpm[{gt1}], conj[Hpm[{gt2}]], conj[VWm[{lt3}]], VWm[{lt4}]}, 
  {(I/2)*g2^2*(ZP[gt1, 1]*ZP[gt2, 1] + ZP[gt1, 2]*ZP[gt2, 2]), g[lt3, lt4]}}, 
 {{Hpm[{gt1}], conj[Hpm[{gt2}]], VZ[{lt3}], VZ[{lt4}]}, 
  {(I/2)*((-(g2*Cos[ThetaW]*Cos[ThetaWp]) + g1*Cos[ThetaWp]*Sin[ThetaW] + 
        2*gp*QHd*Sin[ThetaWp])^2*ZP[gt1, 1]*ZP[gt2, 1] + 
     (g2*Cos[ThetaW]*Cos[ThetaWp] - g1*Cos[ThetaWp]*Sin[ThetaW] + 
        2*gp*QHu*Sin[ThetaWp])^2*ZP[gt1, 2]*ZP[gt2, 2]), g[lt3, lt4]}}, 
 {{Hpm[{gt1}], conj[Hpm[{gt2}]], VZ[{lt3}], VZp[{lt4}]}, 
  {(-I/2)*((-2*g1*gp*QHd*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHd^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*QHd*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*QHd*Cos[ThetaWp]^2 - g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*QHd*Sin[ThetaWp]^2))*ZP[gt1, 1]*ZP[gt2, 1] + 
     (2*g1*gp*QHu*Cos[ThetaWp]^2*Sin[ThetaW] + g2^2*Cos[ThetaW]^2*
        Cos[ThetaWp]*Sin[ThetaWp] + Cos[ThetaWp]*(-4*gp^2*QHu^2 + 
         g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 2*g1*gp*QHu*Sin[ThetaW]*
        Sin[ThetaWp]^2 - 2*g2*Cos[ThetaW]*(gp*QHu*Cos[ThetaWp]^2 + 
         g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - gp*QHu*Sin[ThetaWp]^2))*
      ZP[gt1, 2]*ZP[gt2, 2]), g[lt3, lt4]}}, 
 {{Hpm[{gt1}], conj[Hpm[{gt2}]], VZp[{lt3}], VZp[{lt4}]}, 
  {(I/2)*((2*gp*QHd*Cos[ThetaWp] + (g2*Cos[ThetaW] - g1*Sin[ThetaW])*
         Sin[ThetaWp])^2*ZP[gt1, 1]*ZP[gt2, 1] + 
     (2*gp*QHu*Cos[ThetaWp] + (-(g2*Cos[ThetaW]) + g1*Sin[ThetaW])*
         Sin[ThetaWp])^2*ZP[gt1, 2]*ZP[gt2, 2]), g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VG[{ct3, lt3}], VG[{ct4, lt4}]}, 
  {(I/4)*g3^2*Delta[gt1, gt2]*(sum[j1, 1, 3, Lam[ct3, j1, ct1]*
       Lam[ct4, ct2, j1]] + sum[j1, 1, 3, Lam[ct3, ct2, j1]*
       Lam[ct4, j1, ct1]]), g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VG[{ct3, lt3}], VP[{lt4}]}, 
  {(I/6)*g3*Lam[ct3, ct2, ct1]*((g1*Cos[ThetaW] - 3*g2*Sin[ThetaW])*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] - 
     2*g1*Cos[ThetaW]*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), 
   g[lt3, lt4]}}, {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VG[{ct3, lt3}], 
   VZ[{lt4}]}, {(-I/6)*g3*Lam[ct3, ct2, ct1]*
    ((3*g2*Cos[ThetaW]*Cos[ThetaWp] + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       6*gp*Qq*Sin[ThetaWp])*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] - 
     2*(g1*Cos[ThetaWp]*Sin[ThetaW] - 3*gp*Qd*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VG[{ct3, lt3}], VZp[{lt4}]}, 
  {(I/6)*g3*Lam[ct3, ct2, ct1]*
    ((6*gp*Qq*Cos[ThetaWp] + (3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] - 
     2*(3*gp*Qd*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Su[{gt2, ct2}]], conj[VWm[{lt3}]], VG[{ct4, lt4}]}, 
  {(I*g2*g3*Lam[ct4, ct2, ct1]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZU[gt2, j1]])/
    Sqrt[2], g[lt3, lt4]}}, {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], 
   VP[{lt3}], VP[{lt4}]}, {(I/18)*Delta[ct1, ct2]*
    ((g1*Cos[ThetaW] - 3*g2*Sin[ThetaW])^2*sum[j1, 1, 3, 
       conj[ZD[gt1, j1]]*ZD[gt2, j1]] + 4*g1^2*Cos[ThetaW]^2*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VP[{lt3}], VZ[{lt4}]}, 
  {(-I/18)*Delta[ct1, ct2]*((g1*Cos[ThetaW] - 3*g2*Sin[ThetaW])*
      (3*g2*Cos[ThetaW]*Cos[ThetaWp] + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       6*gp*Qq*Sin[ThetaWp])*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] + 
     4*g1*Cos[ThetaW]*(g1*Cos[ThetaWp]*Sin[ThetaW] - 3*gp*Qd*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VP[{lt3}], VZp[{lt4}]}, 
  {(I/18)*Delta[ct1, ct2]*((g1*Cos[ThetaW] - 3*g2*Sin[ThetaW])*
      (6*gp*Qq*Cos[ThetaWp] + (3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] + 
     4*g1*Cos[ThetaW]*(3*gp*Qd*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Su[{gt2, ct2}]], conj[VWm[{lt3}]], VP[{lt4}]}, 
  {((I/3)*g1*g2*Cos[ThetaW]*Delta[ct1, ct2]*sum[j1, 1, 3, 
      conj[ZD[gt1, j1]]*ZU[gt2, j1]])/Sqrt[2], g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], conj[VWm[{lt3}]], VWm[{lt4}]}, 
  {(I/2)*g2^2*Delta[ct1, ct2]*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]], 
   g[lt3, lt4]}}, {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VZ[{lt3}], 
   VZ[{lt4}]}, {(I/18)*Delta[ct1, ct2]*
    ((3*g2*Cos[ThetaW]*Cos[ThetaWp] + g1*Cos[ThetaWp]*Sin[ThetaW] - 
        6*gp*Qq*Sin[ThetaWp])^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*
        ZD[gt2, j1]] + 4*(g1*Cos[ThetaWp]*Sin[ThetaW] - 3*gp*Qd*Sin[ThetaWp])^
       2*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), 
   g[lt3, lt4]}}, {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VZ[{lt3}], 
   VZp[{lt4}]}, {(-I/18)*Delta[ct1, ct2]*
    ((6*g1*gp*Qq*Cos[ThetaWp]^2*Sin[ThetaW] + 9*g2^2*Cos[ThetaW]^2*
        Cos[ThetaWp]*Sin[ThetaWp] + Cos[ThetaWp]*(-36*gp^2*Qq^2 + 
         g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 6*g1*gp*Qq*Sin[ThetaW]*
        Sin[ThetaWp]^2 + 6*g2*Cos[ThetaW]*(3*gp*Qq*Cos[ThetaWp]^2 + 
         g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 3*gp*Qq*Sin[ThetaWp]^2))*
      sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] + 
     2*(6*g1*gp*Qd*Cos[ThetaWp]^2*Sin[ThetaW] + g1^2*Sin[ThetaW]^2*
        Sin[2*ThetaWp] - 3*gp*Qd*(2*g1*Sin[ThetaW]*Sin[ThetaWp]^2 + 
         3*gp*Qd*Sin[2*ThetaWp]))*sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
        ZD[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Su[{gt2, ct2}]], conj[VWm[{lt3}]], VZ[{lt4}]}, 
  {((-I/3)*g2*Delta[ct1, ct2]*(g1*Cos[ThetaWp]*Sin[ThetaW] - 
      6*gp*Qq*Sin[ThetaWp])*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZU[gt2, j1]])/
    Sqrt[2], g[lt3, lt4]}}, {{Sd[{gt1, ct1}], conj[Sd[{gt2, ct2}]], 
   VZp[{lt3}], VZp[{lt4}]}, {(I/18)*Delta[ct1, ct2]*
    ((6*gp*Qq*Cos[ThetaWp] + (3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*
         Sin[ThetaWp])^2*sum[j1, 1, 3, conj[ZD[gt1, j1]]*ZD[gt2, j1]] + 
     4*(3*gp*Qd*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])^2*
      sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*ZD[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Sd[{gt1, ct1}], conj[Su[{gt2, ct2}]], conj[VWm[{lt3}]], VZp[{lt4}]}, 
  {((I/3)*g2*Delta[ct1, ct2]*(6*gp*Qq*Cos[ThetaWp] + 
      g1*Sin[ThetaW]*Sin[ThetaWp])*sum[j1, 1, 3, conj[ZD[gt1, j1]]*
       ZU[gt2, j1]])/Sqrt[2], g[lt3, lt4]}}, 
 {{Se[{gt1}], conj[Se[{gt2}]], VP[{lt3}], VP[{lt4}]}, 
  {(I/2)*(conj[ZE[gt1, 1]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])^2*ZE[gt2, 1] + 
     conj[ZE[gt1, 2]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])^2*ZE[gt2, 2] + 
     g1^2*conj[ZE[gt1, 3]]*Cos[ThetaW]^2*ZE[gt2, 3] + 
     g2^2*conj[ZE[gt1, 3]]*Sin[ThetaW]^2*ZE[gt2, 3] + 
     g1*g2*conj[ZE[gt1, 3]]*Sin[2*ThetaW]*ZE[gt2, 3] + 
     4*g1^2*conj[ZE[gt1, 4]]*Cos[ThetaW]^2*ZE[gt2, 4] + 
     4*g1^2*conj[ZE[gt1, 5]]*Cos[ThetaW]^2*ZE[gt2, 5] + 
     4*g1^2*conj[ZE[gt1, 6]]*Cos[ThetaW]^2*ZE[gt2, 6]), g[lt3, lt4]}}, 
 {{Se[{gt1}], conj[Se[{gt2}]], VP[{lt3}], VZ[{lt4}]}, 
  {(-I/2)*(conj[ZE[gt1, 1]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*
      (-(g2*Cos[ThetaW]*Cos[ThetaWp]) + g1*Cos[ThetaWp]*Sin[ThetaW] + 
       2*gp*Ql1*Sin[ThetaWp])*ZE[gt2, 1] + conj[ZE[gt1, 2]]*
      (g1*Cos[ThetaW] + g2*Sin[ThetaW])*(-(g2*Cos[ThetaW]*Cos[ThetaWp]) + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql2*Sin[ThetaWp])*ZE[gt2, 2] - 
     g1*g2*conj[ZE[gt1, 3]]*Cos[ThetaW]^2*Cos[ThetaWp]*ZE[gt2, 3] + 
     g1^2*conj[ZE[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*Sin[ThetaW]*ZE[gt2, 3] - 
     g2^2*conj[ZE[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*Sin[ThetaW]*ZE[gt2, 3] + 
     g1*g2*conj[ZE[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaW]^2*ZE[gt2, 3] + 
     2*g1*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaW]*Sin[ThetaWp]*ZE[gt2, 3] + 
     2*g2*gp*Ql3*conj[ZE[gt1, 3]]*Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 3] + 
     4*g1^2*conj[ZE[gt1, 4]]*Cos[ThetaW]*Cos[ThetaWp]*Sin[ThetaW]*
      ZE[gt2, 4] - 4*g1*gp*Qe1*conj[ZE[gt1, 4]]*Cos[ThetaW]*Sin[ThetaWp]*
      ZE[gt2, 4] + 4*g1^2*conj[ZE[gt1, 5]]*Cos[ThetaW]*Cos[ThetaWp]*
      Sin[ThetaW]*ZE[gt2, 5] - 4*g1*gp*Qe2*conj[ZE[gt1, 5]]*Cos[ThetaW]*
      Sin[ThetaWp]*ZE[gt2, 5] + 4*g1^2*conj[ZE[gt1, 6]]*Cos[ThetaW]*
      Cos[ThetaWp]*Sin[ThetaW]*ZE[gt2, 6] - 4*g1*gp*Qe3*conj[ZE[gt1, 6]]*
      Cos[ThetaW]*Sin[ThetaWp]*ZE[gt2, 6]), g[lt3, lt4]}}, 
 {{Se[{gt1}], conj[Se[{gt2}]], VP[{lt3}], VZp[{lt4}]}, 
  {(I/2)*(conj[ZE[gt1, 1]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*
      (-2*gp*Ql1*Cos[ThetaWp] + (-(g2*Cos[ThetaW]) + g1*Sin[ThetaW])*
        Sin[ThetaWp])*ZE[gt2, 1] + conj[ZE[gt1, 2]]*
      (g1*Cos[ThetaW] + g2*Sin[ThetaW])*(-2*gp*Ql2*Cos[ThetaWp] - 
       g2*Cos[ThetaW]*Sin[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZE[gt2, 2] - 2*g1*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*
      ZE[gt2, 3] - 2*g2*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaW]*
      ZE[gt2, 3] - g1*g2*conj[ZE[gt1, 3]]*Cos[ThetaW]^2*Sin[ThetaWp]*
      ZE[gt2, 3] + g1^2*conj[ZE[gt1, 3]]*Cos[ThetaW]*Sin[ThetaW]*Sin[ThetaWp]*
      ZE[gt2, 3] - g2^2*conj[ZE[gt1, 3]]*Cos[ThetaW]*Sin[ThetaW]*Sin[ThetaWp]*
      ZE[gt2, 3] + g1*g2*conj[ZE[gt1, 3]]*Sin[ThetaW]^2*Sin[ThetaWp]*
      ZE[gt2, 3] + 4*g1*gp*Qe1*conj[ZE[gt1, 4]]*Cos[ThetaW]*Cos[ThetaWp]*
      ZE[gt2, 4] + 4*g1^2*conj[ZE[gt1, 4]]*Cos[ThetaW]*Sin[ThetaW]*
      Sin[ThetaWp]*ZE[gt2, 4] + 4*g1*gp*Qe2*conj[ZE[gt1, 5]]*Cos[ThetaW]*
      Cos[ThetaWp]*ZE[gt2, 5] + 4*g1^2*conj[ZE[gt1, 5]]*Cos[ThetaW]*
      Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 5] + 4*g1*gp*Qe3*conj[ZE[gt1, 6]]*
      Cos[ThetaW]*Cos[ThetaWp]*ZE[gt2, 6] + 4*g1^2*conj[ZE[gt1, 6]]*
      Cos[ThetaW]*Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 6]), g[lt3, lt4]}}, 
 {{Se[{gt1}], conj[Sv[{gt2}]], conj[VWm[{lt3}]], VP[{lt4}]}, 
  {((-I)*g1*g2*Cos[ThetaW]*(conj[ZE[gt1, 1]]*ZV[gt2, 1] + 
      conj[ZE[gt1, 2]]*ZV[gt2, 2] + conj[ZE[gt1, 3]]*ZV[gt2, 3]))/Sqrt[2], 
   g[lt3, lt4]}}, {{Se[{gt1}], conj[Se[{gt2}]], conj[VWm[{lt3}]], 
   VWm[{lt4}]}, {(I/2)*g2^2*(conj[ZE[gt1, 1]]*ZE[gt2, 1] + 
     conj[ZE[gt1, 2]]*ZE[gt2, 2] + conj[ZE[gt1, 3]]*ZE[gt2, 3]), 
   g[lt3, lt4]}}, {{Se[{gt1}], conj[Se[{gt2}]], VZ[{lt3}], VZ[{lt4}]}, 
  {(I/2)*(conj[ZE[gt1, 1]]*(-(g2*Cos[ThetaW]*Cos[ThetaWp]) + 
        g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql1*Sin[ThetaWp])^2*ZE[gt2, 1] + 
     conj[ZE[gt1, 2]]*(-(g2*Cos[ThetaW]*Cos[ThetaWp]) + 
        g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql2*Sin[ThetaWp])^2*ZE[gt2, 2] + 
     g2^2*conj[ZE[gt1, 3]]*Cos[ThetaW]^2*Cos[ThetaWp]^2*ZE[gt2, 3] - 
     2*g1*g2*conj[ZE[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]^2*Sin[ThetaW]*
      ZE[gt2, 3] + g1^2*conj[ZE[gt1, 3]]*Cos[ThetaWp]^2*Sin[ThetaW]^2*
      ZE[gt2, 3] - 4*g2*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*
      Sin[ThetaWp]*ZE[gt2, 3] + 4*g1*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaWp]*
      Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 3] + 4*gp^2*Ql3^2*conj[ZE[gt1, 3]]*
      Sin[ThetaWp]^2*ZE[gt2, 3] + 4*g1^2*conj[ZE[gt1, 4]]*Cos[ThetaWp]^2*
      Sin[ThetaW]^2*ZE[gt2, 4] - 8*g1*gp*Qe1*conj[ZE[gt1, 4]]*Cos[ThetaWp]*
      Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 4] + 4*gp^2*Qe1^2*conj[ZE[gt1, 4]]*
      Sin[ThetaWp]^2*ZE[gt2, 4] + 4*g1^2*conj[ZE[gt1, 5]]*Cos[ThetaWp]^2*
      Sin[ThetaW]^2*ZE[gt2, 5] - 8*g1*gp*Qe2*conj[ZE[gt1, 5]]*Cos[ThetaWp]*
      Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 5] + 4*gp^2*Qe2^2*conj[ZE[gt1, 5]]*
      Sin[ThetaWp]^2*ZE[gt2, 5] + 4*g1^2*conj[ZE[gt1, 6]]*Cos[ThetaWp]^2*
      Sin[ThetaW]^2*ZE[gt2, 6] - 8*g1*gp*Qe3*conj[ZE[gt1, 6]]*Cos[ThetaWp]*
      Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 6] + 4*gp^2*Qe3^2*conj[ZE[gt1, 6]]*
      Sin[ThetaWp]^2*ZE[gt2, 6]), g[lt3, lt4]}}, 
 {{Se[{gt1}], conj[Se[{gt2}]], VZ[{lt3}], VZp[{lt4}]}, 
  {(-I/2)*(conj[ZE[gt1, 1]]*(-2*g1*gp*Ql1*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*Ql1^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*Ql1*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*Ql1*Cos[ThetaWp]^2 - g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*Ql1*Sin[ThetaWp]^2))*ZE[gt2, 1] + conj[ZE[gt1, 2]]*
      (-2*g1*gp*Ql2*Cos[ThetaWp]^2*Sin[ThetaW] + g2^2*Cos[ThetaW]^2*
        Cos[ThetaWp]*Sin[ThetaWp] + Cos[ThetaWp]*(-4*gp^2*Ql2^2 + 
         g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 2*g1*gp*Ql2*Sin[ThetaW]*
        Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*(gp*Ql2*Cos[ThetaWp]^2 - 
         g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - gp*Ql2*Sin[ThetaWp]^2))*
      ZE[gt2, 2] + 2*g2*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]^2*
      ZE[gt2, 3] - 2*g1*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaWp]^2*Sin[ThetaW]*
      ZE[gt2, 3] - 4*gp^2*Ql3^2*conj[ZE[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaWp]*
      ZE[gt2, 3] + g2^2*conj[ZE[gt1, 3]]*Cos[ThetaW]^2*Cos[ThetaWp]*
      Sin[ThetaWp]*ZE[gt2, 3] - 2*g1*g2*conj[ZE[gt1, 3]]*Cos[ThetaW]*
      Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 3] + 
     g1^2*conj[ZE[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaW]^2*Sin[ThetaWp]*
      ZE[gt2, 3] - 2*g2*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaW]*Sin[ThetaWp]^2*
      ZE[gt2, 3] + 2*g1*gp*Ql3*conj[ZE[gt1, 3]]*Sin[ThetaW]*Sin[ThetaWp]^2*
      ZE[gt2, 3] + 4*g1*gp*Qe1*conj[ZE[gt1, 4]]*Cos[ThetaWp]^2*Sin[ThetaW]*
      ZE[gt2, 4] - 4*gp^2*Qe1^2*conj[ZE[gt1, 4]]*Cos[ThetaWp]*Sin[ThetaWp]*
      ZE[gt2, 4] + 4*g1^2*conj[ZE[gt1, 4]]*Cos[ThetaWp]*Sin[ThetaW]^2*
      Sin[ThetaWp]*ZE[gt2, 4] - 4*g1*gp*Qe1*conj[ZE[gt1, 4]]*Sin[ThetaW]*
      Sin[ThetaWp]^2*ZE[gt2, 4] + 4*g1*gp*Qe2*conj[ZE[gt1, 5]]*Cos[ThetaWp]^2*
      Sin[ThetaW]*ZE[gt2, 5] - 4*gp^2*Qe2^2*conj[ZE[gt1, 5]]*Cos[ThetaWp]*
      Sin[ThetaWp]*ZE[gt2, 5] + 4*g1^2*conj[ZE[gt1, 5]]*Cos[ThetaWp]*
      Sin[ThetaW]^2*Sin[ThetaWp]*ZE[gt2, 5] - 4*g1*gp*Qe2*conj[ZE[gt1, 5]]*
      Sin[ThetaW]*Sin[ThetaWp]^2*ZE[gt2, 5] + 4*g1*gp*Qe3*conj[ZE[gt1, 6]]*
      Cos[ThetaWp]^2*Sin[ThetaW]*ZE[gt2, 6] - 4*gp^2*Qe3^2*conj[ZE[gt1, 6]]*
      Cos[ThetaWp]*Sin[ThetaWp]*ZE[gt2, 6] + 4*g1^2*conj[ZE[gt1, 6]]*
      Cos[ThetaWp]*Sin[ThetaW]^2*Sin[ThetaWp]*ZE[gt2, 6] - 
     4*g1*gp*Qe3*conj[ZE[gt1, 6]]*Sin[ThetaW]*Sin[ThetaWp]^2*ZE[gt2, 6]), 
   g[lt3, lt4]}}, {{Se[{gt1}], conj[Sv[{gt2}]], conj[VWm[{lt3}]], VZ[{lt4}]}, 
  {(I*g2*(conj[ZE[gt1, 1]]*(g1*Cos[ThetaWp]*Sin[ThetaW] + 
        2*gp*Ql1*Sin[ThetaWp])*ZV[gt2, 1] + conj[ZE[gt1, 2]]*
       (g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql2*Sin[ThetaWp])*ZV[gt2, 2] + 
      conj[ZE[gt1, 3]]*(g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql3*Sin[ThetaWp])*
       ZV[gt2, 3]))/Sqrt[2], g[lt3, lt4]}}, 
 {{Se[{gt1}], conj[Se[{gt2}]], VZp[{lt3}], VZp[{lt4}]}, 
  {(I/2)*(conj[ZE[gt1, 1]]*(2*gp*Ql1*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])^2*ZE[gt2, 1] + 
     conj[ZE[gt1, 2]]*(2*gp*Ql2*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] - 
        g1*Sin[ThetaW]*Sin[ThetaWp])^2*ZE[gt2, 2] + 
     4*gp^2*Ql3^2*conj[ZE[gt1, 3]]*Cos[ThetaWp]^2*ZE[gt2, 3] + 
     4*g2*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*Sin[ThetaWp]*
      ZE[gt2, 3] - 4*g1*gp*Ql3*conj[ZE[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaW]*
      Sin[ThetaWp]*ZE[gt2, 3] + g2^2*conj[ZE[gt1, 3]]*Cos[ThetaW]^2*
      Sin[ThetaWp]^2*ZE[gt2, 3] - 2*g1*g2*conj[ZE[gt1, 3]]*Cos[ThetaW]*
      Sin[ThetaW]*Sin[ThetaWp]^2*ZE[gt2, 3] + g1^2*conj[ZE[gt1, 3]]*
      Sin[ThetaW]^2*Sin[ThetaWp]^2*ZE[gt2, 3] + 4*gp^2*Qe1^2*conj[ZE[gt1, 4]]*
      Cos[ThetaWp]^2*ZE[gt2, 4] + 8*g1*gp*Qe1*conj[ZE[gt1, 4]]*Cos[ThetaWp]*
      Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 4] + 4*g1^2*conj[ZE[gt1, 4]]*
      Sin[ThetaW]^2*Sin[ThetaWp]^2*ZE[gt2, 4] + 4*gp^2*Qe2^2*conj[ZE[gt1, 5]]*
      Cos[ThetaWp]^2*ZE[gt2, 5] + 8*g1*gp*Qe2*conj[ZE[gt1, 5]]*Cos[ThetaWp]*
      Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 5] + 4*g1^2*conj[ZE[gt1, 5]]*
      Sin[ThetaW]^2*Sin[ThetaWp]^2*ZE[gt2, 5] + 4*gp^2*Qe3^2*conj[ZE[gt1, 6]]*
      Cos[ThetaWp]^2*ZE[gt2, 6] + 8*g1*gp*Qe3*conj[ZE[gt1, 6]]*Cos[ThetaWp]*
      Sin[ThetaW]*Sin[ThetaWp]*ZE[gt2, 6] + 4*g1^2*conj[ZE[gt1, 6]]*
      Sin[ThetaW]^2*Sin[ThetaWp]^2*ZE[gt2, 6]), g[lt3, lt4]}}, 
 {{Se[{gt1}], conj[Sv[{gt2}]], conj[VWm[{lt3}]], VZp[{lt4}]}, 
  {(I*g2*(conj[ZE[gt1, 1]]*(2*gp*Ql1*Cos[ThetaWp] - g1*Sin[ThetaW]*
         Sin[ThetaWp])*ZV[gt2, 1] + conj[ZE[gt1, 2]]*(2*gp*Ql2*Cos[ThetaWp] - 
        g1*Sin[ThetaW]*Sin[ThetaWp])*ZV[gt2, 2] + conj[ZE[gt1, 3]]*
       (2*gp*Ql3*Cos[ThetaWp] - g1*Sin[ThetaW]*Sin[ThetaWp])*ZV[gt2, 3]))/
    Sqrt[2], g[lt3, lt4]}}, {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], 
   VG[{ct3, lt3}], VG[{ct4, lt4}]}, 
  {(I/4)*g3^2*Delta[gt1, gt2]*(sum[j1, 1, 3, Lam[ct3, j1, ct1]*
       Lam[ct4, ct2, j1]] + sum[j1, 1, 3, Lam[ct3, ct2, j1]*
       Lam[ct4, j1, ct1]]), g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VG[{ct3, lt3}], VP[{lt4}]}, 
  {(I/6)*g3*Lam[ct3, ct2, ct1]*((g1*Cos[ThetaW] + 3*g2*Sin[ThetaW])*
      sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] + 
     4*g1*Cos[ThetaW]*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), 
   g[lt3, lt4]}}, {{Su[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VG[{ct3, lt3}], 
   VWm[{lt4}]}, {(I*g2*g3*Lam[ct3, ct2, ct1]*sum[j1, 1, 3, 
      conj[ZU[gt1, j1]]*ZD[gt2, j1]])/Sqrt[2], g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VG[{ct3, lt3}], VZ[{lt4}]}, 
  {(I/6)*g3*Lam[ct3, ct2, ct1]*
    ((3*g2*Cos[ThetaW]*Cos[ThetaWp] - g1*Cos[ThetaWp]*Sin[ThetaW] + 
       6*gp*Qq*Sin[ThetaWp])*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] - 
     2*(2*g1*Cos[ThetaWp]*Sin[ThetaW] + 3*gp*Qu*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VG[{ct3, lt3}], VZp[{lt4}]}, 
  {(I/6)*g3*Lam[ct3, ct2, ct1]*
    ((6*gp*Qq*Cos[ThetaWp] + (-3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] + 
     2*(-3*gp*Qu*Cos[ThetaWp] + 2*g1*Sin[ThetaW]*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VP[{lt3}], VP[{lt4}]}, 
  {(I/18)*Delta[ct1, ct2]*((g1*Cos[ThetaW] + 3*g2*Sin[ThetaW])^2*
      sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] + 
     16*g1^2*Cos[ThetaW]^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*
        ZU[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VP[{lt3}], VWm[{lt4}]}, 
  {((I/3)*g1*g2*Cos[ThetaW]*Delta[ct1, ct2]*sum[j1, 1, 3, 
      conj[ZU[gt1, j1]]*ZD[gt2, j1]])/Sqrt[2], g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VP[{lt3}], VZ[{lt4}]}, 
  {(-I/18)*Delta[ct1, ct2]*((g1*Cos[ThetaW] + 3*g2*Sin[ThetaW])*
      (-3*g2*Cos[ThetaW]*Cos[ThetaWp] + g1*Cos[ThetaWp]*Sin[ThetaW] - 
       6*gp*Qq*Sin[ThetaWp])*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] + 
     8*g1*(g1*Cos[ThetaWp]*Sin[2*ThetaW] + 3*gp*Qu*Cos[ThetaW]*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VP[{lt3}], VZp[{lt4}]}, 
  {(I/18)*Delta[ct1, ct2]*((g1*Cos[ThetaW] + 3*g2*Sin[ThetaW])*
      (6*gp*Qq*Cos[ThetaWp] + (-3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*
        Sin[ThetaWp])*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] + 
     8*g1*(-3*gp*Qu*Cos[ThetaW]*Cos[ThetaWp] + g1*Sin[2*ThetaW]*Sin[ThetaWp])*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Sd[{gt2, ct2}]], VWm[{lt3}], VZ[{lt4}]}, 
  {((-I/3)*g2*Delta[ct1, ct2]*(g1*Cos[ThetaWp]*Sin[ThetaW] - 
      6*gp*Qq*Sin[ThetaWp])*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZD[gt2, j1]])/
    Sqrt[2], g[lt3, lt4]}}, {{Su[{gt1, ct1}], conj[Sd[{gt2, ct2}]], 
   VWm[{lt3}], VZp[{lt4}]}, 
  {((I/3)*g2*Delta[ct1, ct2]*(6*gp*Qq*Cos[ThetaWp] + 
      g1*Sin[ThetaW]*Sin[ThetaWp])*sum[j1, 1, 3, conj[ZU[gt1, j1]]*
       ZD[gt2, j1]])/Sqrt[2], g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], conj[VWm[{lt3}]], VWm[{lt4}]}, 
  {(I/2)*g2^2*Delta[ct1, ct2]*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]], 
   g[lt3, lt4]}}, {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VZ[{lt3}], 
   VZ[{lt4}]}, {(I/18)*Delta[ct1, ct2]*
    ((3*g2*Cos[ThetaW]*Cos[ThetaWp] - g1*Cos[ThetaWp]*Sin[ThetaW] + 
        6*gp*Qq*Sin[ThetaWp])^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*
        ZU[gt2, j1]] + 4*(2*g1*Cos[ThetaWp]*Sin[ThetaW] + 
        3*gp*Qu*Sin[ThetaWp])^2*sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*
        ZU[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VZ[{lt3}], VZp[{lt4}]}, 
  {(-I/18)*Delta[ct1, ct2]*((6*g1*gp*Qq*Cos[ThetaWp]^2*Sin[ThetaW] + 
       9*g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-36*gp^2*Qq^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 
       6*g1*gp*Qq*Sin[ThetaW]*Sin[ThetaWp]^2 - 6*g2*Cos[ThetaW]*
        (3*gp*Qq*Cos[ThetaWp]^2 + g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         3*gp*Qq*Sin[ThetaWp]^2))*sum[j1, 1, 3, conj[ZU[gt1, j1]]*
        ZU[gt2, j1]] - 2*(6*g1*gp*Qu*Sin[ThetaW - 2*ThetaWp] - 
       g1^2*Sin[2*(ThetaW - ThetaWp)] - 2*g1^2*Sin[2*ThetaWp] + 
       9*gp^2*Qu^2*Sin[2*ThetaWp] + g1^2*Sin[2*(ThetaW + ThetaWp)] + 
       6*g1*gp*Qu*Sin[ThetaW + 2*ThetaWp])*sum[j1, 1, 3, 
       conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Su[{gt1, ct1}], conj[Su[{gt2, ct2}]], VZp[{lt3}], VZp[{lt4}]}, 
  {(I/18)*Delta[ct1, ct2]*
    ((6*gp*Qq*Cos[ThetaWp] + (-3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*
         Sin[ThetaWp])^2*sum[j1, 1, 3, conj[ZU[gt1, j1]]*ZU[gt2, j1]] + 
     4*(3*gp*Qu*Cos[ThetaWp] - 2*g1*Sin[ThetaW]*Sin[ThetaWp])^2*
      sum[j1, 1, 3, conj[ZU[gt1, 3 + j1]]*ZU[gt2, 3 + j1]]), g[lt3, lt4]}}, 
 {{Sv[{gt1}], conj[Se[{gt2}]], VP[{lt3}], VWm[{lt4}]}, 
  {((-I)*g1*g2*Cos[ThetaW]*(conj[ZV[gt1, 1]]*ZE[gt2, 1] + 
      conj[ZV[gt1, 2]]*ZE[gt2, 2] + conj[ZV[gt1, 3]]*ZE[gt2, 3]))/Sqrt[2], 
   g[lt3, lt4]}}, {{Sv[{gt1}], conj[Se[{gt2}]], VWm[{lt3}], VZ[{lt4}]}, 
  {(I*g2*(conj[ZV[gt1, 1]]*(g1*Cos[ThetaWp]*Sin[ThetaW] + 
        2*gp*Ql1*Sin[ThetaWp])*ZE[gt2, 1] + conj[ZV[gt1, 2]]*
       (g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql2*Sin[ThetaWp])*ZE[gt2, 2] + 
      conj[ZV[gt1, 3]]*(g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql3*Sin[ThetaWp])*
       ZE[gt2, 3]))/Sqrt[2], g[lt3, lt4]}}, 
 {{Sv[{gt1}], conj[Se[{gt2}]], VWm[{lt3}], VZp[{lt4}]}, 
  {(I*g2*(conj[ZV[gt1, 1]]*(2*gp*Ql1*Cos[ThetaWp] - g1*Sin[ThetaW]*
         Sin[ThetaWp])*ZE[gt2, 1] + conj[ZV[gt1, 2]]*(2*gp*Ql2*Cos[ThetaWp] - 
        g1*Sin[ThetaW]*Sin[ThetaWp])*ZE[gt2, 2] + conj[ZV[gt1, 3]]*
       (2*gp*Ql3*Cos[ThetaWp] - g1*Sin[ThetaW]*Sin[ThetaWp])*ZE[gt2, 3]))/
    Sqrt[2], g[lt3, lt4]}}, {{Sv[{gt1}], conj[Sv[{gt2}]], conj[VWm[{lt3}]], 
   VWm[{lt4}]}, {(I/2)*g2^2*(conj[ZV[gt1, 1]]*ZV[gt2, 1] + 
     conj[ZV[gt1, 2]]*ZV[gt2, 2] + conj[ZV[gt1, 3]]*ZV[gt2, 3]), 
   g[lt3, lt4]}}, {{Sv[{gt1}], conj[Sv[{gt2}]], VZ[{lt3}], VZ[{lt4}]}, 
  {(I/2)*(conj[ZV[gt1, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql1*Sin[ThetaWp])^2*ZV[gt2, 1] + 
     conj[ZV[gt1, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + g1*Cos[ThetaWp]*
         Sin[ThetaW] + 2*gp*Ql2*Sin[ThetaWp])^2*ZV[gt2, 2] + 
     g2^2*conj[ZV[gt1, 3]]*Cos[ThetaW]^2*Cos[ThetaWp]^2*ZV[gt2, 3] + 
     g1^2*conj[ZV[gt1, 3]]*Cos[ThetaWp]^2*Sin[ThetaW]^2*ZV[gt2, 3] + 
     g1*g2*conj[ZV[gt1, 3]]*Cos[ThetaWp]^2*Sin[2*ThetaW]*ZV[gt2, 3] + 
     4*g2*gp*Ql3*conj[ZV[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*Sin[ThetaWp]*
      ZV[gt2, 3] + 4*g1*gp*Ql3*conj[ZV[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaW]*
      Sin[ThetaWp]*ZV[gt2, 3] + 4*gp^2*Ql3^2*conj[ZV[gt1, 3]]*Sin[ThetaWp]^2*
      ZV[gt2, 3] + 4*gp^2*Qv1^2*conj[ZV[gt1, 4]]*Sin[ThetaWp]^2*ZV[gt2, 4] + 
     4*gp^2*Qv2^2*conj[ZV[gt1, 5]]*Sin[ThetaWp]^2*ZV[gt2, 5] + 
     4*gp^2*Qv3^2*conj[ZV[gt1, 6]]*Sin[ThetaWp]^2*ZV[gt2, 6]), g[lt3, lt4]}}, 
 {{Sv[{gt1}], conj[Sv[{gt2}]], VZ[{lt3}], VZp[{lt4}]}, 
  {(-I/2)*(conj[ZV[gt1, 1]]*(-2*g1*gp*Ql1*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*Ql1^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*Ql1*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (-(gp*Ql1*Cos[ThetaWp]^2) + g1*Cos[ThetaWp]*Sin[ThetaW]*
          Sin[ThetaWp] + gp*Ql1*Sin[ThetaWp]^2))*ZV[gt2, 1] + 
     conj[ZV[gt1, 2]]*(-2*g1*gp*Ql2*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*Ql2^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*Ql2*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (-(gp*Ql2*Cos[ThetaWp]^2) + g1*Cos[ThetaWp]*Sin[ThetaW]*
          Sin[ThetaWp] + gp*Ql2*Sin[ThetaWp]^2))*ZV[gt2, 2] - 
     2*g2*gp*Ql3*conj[ZV[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]^2*ZV[gt2, 3] - 
     2*g1*gp*Ql3*conj[ZV[gt1, 3]]*Cos[ThetaWp]^2*Sin[ThetaW]*ZV[gt2, 3] - 
     4*gp^2*Ql3^2*conj[ZV[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaWp]*ZV[gt2, 3] + 
     g2^2*conj[ZV[gt1, 3]]*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp]*
      ZV[gt2, 3] + 2*g1*g2*conj[ZV[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*
      Sin[ThetaW]*Sin[ThetaWp]*ZV[gt2, 3] + g1^2*conj[ZV[gt1, 3]]*
      Cos[ThetaWp]*Sin[ThetaW]^2*Sin[ThetaWp]*ZV[gt2, 3] + 
     2*g2*gp*Ql3*conj[ZV[gt1, 3]]*Cos[ThetaW]*Sin[ThetaWp]^2*ZV[gt2, 3] + 
     2*g1*gp*Ql3*conj[ZV[gt1, 3]]*Sin[ThetaW]*Sin[ThetaWp]^2*ZV[gt2, 3] - 
     4*gp^2*Qv1^2*conj[ZV[gt1, 4]]*Cos[ThetaWp]*Sin[ThetaWp]*ZV[gt2, 4] - 
     4*gp^2*Qv2^2*conj[ZV[gt1, 5]]*Cos[ThetaWp]*Sin[ThetaWp]*ZV[gt2, 5] - 
     4*gp^2*Qv3^2*conj[ZV[gt1, 6]]*Cos[ThetaWp]*Sin[ThetaWp]*ZV[gt2, 6]), 
   g[lt3, lt4]}}, {{Sv[{gt1}], conj[Sv[{gt2}]], VZp[{lt3}], VZp[{lt4}]}, 
  {(I/2)*(conj[ZV[gt1, 1]]*(-2*gp*Ql1*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2*ZV[gt2, 1] + 
     conj[ZV[gt1, 2]]*(-2*gp*Ql2*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] + 
        g1*Sin[ThetaW]*Sin[ThetaWp])^2*ZV[gt2, 2] + 
     4*gp^2*Ql3^2*conj[ZV[gt1, 3]]*Cos[ThetaWp]^2*ZV[gt2, 3] - 
     4*g2*gp*Ql3*conj[ZV[gt1, 3]]*Cos[ThetaW]*Cos[ThetaWp]*Sin[ThetaWp]*
      ZV[gt2, 3] - 4*g1*gp*Ql3*conj[ZV[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaW]*
      Sin[ThetaWp]*ZV[gt2, 3] + g2^2*conj[ZV[gt1, 3]]*Cos[ThetaW]^2*
      Sin[ThetaWp]^2*ZV[gt2, 3] + g1^2*conj[ZV[gt1, 3]]*Sin[ThetaW]^2*
      Sin[ThetaWp]^2*ZV[gt2, 3] + g1*g2*conj[ZV[gt1, 3]]*Sin[2*ThetaW]*
      Sin[ThetaWp]^2*ZV[gt2, 3] + 4*gp^2*Qv1^2*conj[ZV[gt1, 4]]*
      Cos[ThetaWp]^2*ZV[gt2, 4] + 4*gp^2*Qv2^2*conj[ZV[gt1, 5]]*
      Cos[ThetaWp]^2*ZV[gt2, 5] + 4*gp^2*Qv3^2*conj[ZV[gt1, 6]]*
      Cos[ThetaWp]^2*ZV[gt2, 6]), g[lt3, lt4]}}, 
 {{VG[{ct1, lt1}], VG[{ct2, lt2}], VG[{ct3, lt3}], VG[{ct4, lt4}]}, 
  {(-I)*g3^2*(sum[j1, 1, 8, fSU3[ct1, ct4, j1]*fSU3[ct2, ct3, j1]] + 
     sum[j1, 1, 8, fSU3[ct1, ct3, j1]*fSU3[ct2, ct4, j1]]), 
   g[lt1, lt2]*g[lt3, lt4]}, 
  {I*g3^2*(sum[j1, 1, 8, fSU3[ct1, ct4, j1]*fSU3[ct2, ct3, j1]] - 
     sum[j1, 1, 8, fSU3[ct1, ct2, j1]*fSU3[ct3, ct4, j1]]), 
   g[lt1, lt3]*g[lt2, lt4]}, 
  {I*g3^2*(sum[j1, 1, 8, fSU3[ct1, ct3, j1]*fSU3[ct2, ct4, j1]] + 
     sum[j1, 1, 8, fSU3[ct1, ct2, j1]*fSU3[ct3, ct4, j1]]), 
   g[lt1, lt4]*g[lt2, lt3]}}, {{conj[VWm[{lt1}]], VP[{lt2}], VP[{lt3}], 
   VWm[{lt4}]}, {I*g2^2*Sin[ThetaW]^2, g[lt1, lt2]*g[lt3, lt4]}, 
  {I*g2^2*Sin[ThetaW]^2, g[lt1, lt3]*g[lt2, lt4]}, 
  {(-2*I)*g2^2*Sin[ThetaW]^2, g[lt1, lt4]*g[lt2, lt3]}}, 
 {{conj[VWm[{lt1}]], VP[{lt2}], VWm[{lt3}], VZ[{lt4}]}, 
  {I*g2^2*Cos[ThetaW]*Cos[ThetaWp]*Sin[ThetaW], g[lt1, lt2]*g[lt3, lt4]}, 
  {(-I)*g2^2*Cos[ThetaWp]*Sin[2*ThetaW], g[lt1, lt3]*g[lt2, lt4]}, 
  {I*g2^2*Cos[ThetaW]*Cos[ThetaWp]*Sin[ThetaW], g[lt1, lt4]*g[lt2, lt3]}}, 
 {{conj[VWm[{lt1}]], VP[{lt2}], VWm[{lt3}], VZp[{lt4}]}, 
  {(-I)*g2^2*Cos[ThetaW]*Sin[ThetaW]*Sin[ThetaWp], g[lt1, lt2]*g[lt3, lt4]}, 
  {I*g2^2*Sin[2*ThetaW]*Sin[ThetaWp], g[lt1, lt3]*g[lt2, lt4]}, 
  {(-I)*g2^2*Cos[ThetaW]*Sin[ThetaW]*Sin[ThetaWp], g[lt1, lt4]*g[lt2, lt3]}}, 
 {{conj[VWm[{lt1}]], conj[VWm[{lt2}]], VWm[{lt3}], VWm[{lt4}]}, 
  {(2*I)*g2^2, g[lt1, lt2]*g[lt3, lt4]}, 
  {(-I)*g2^2, g[lt1, lt3]*g[lt2, lt4]}, 
  {(-I)*g2^2, g[lt1, lt4]*g[lt2, lt3]}}, 
 {{conj[VWm[{lt1}]], VWm[{lt2}], VZ[{lt3}], VZ[{lt4}]}, 
  {(-2*I)*g2^2*Cos[ThetaW]^2*Cos[ThetaWp]^2, g[lt1, lt2]*g[lt3, lt4]}, 
  {I*g2^2*Cos[ThetaW]^2*Cos[ThetaWp]^2, g[lt1, lt3]*g[lt2, lt4]}, 
  {I*g2^2*Cos[ThetaW]^2*Cos[ThetaWp]^2, g[lt1, lt4]*g[lt2, lt3]}}, 
 {{conj[VWm[{lt1}]], VWm[{lt2}], VZ[{lt3}], VZp[{lt4}]}, 
  {I*g2^2*Cos[ThetaW]^2*Sin[2*ThetaWp], g[lt1, lt2]*g[lt3, lt4]}, 
  {(-I)*g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp], 
   g[lt1, lt3]*g[lt2, lt4]}, {(-I)*g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*
    Sin[ThetaWp], g[lt1, lt4]*g[lt2, lt3]}}, 
 {{conj[VWm[{lt1}]], VWm[{lt2}], VZp[{lt3}], VZp[{lt4}]}, 
  {(-2*I)*g2^2*Cos[ThetaW]^2*Sin[ThetaWp]^2, g[lt1, lt2]*g[lt3, lt4]}, 
  {I*g2^2*Cos[ThetaW]^2*Sin[ThetaWp]^2, g[lt1, lt3]*g[lt2, lt4]}, 
  {I*g2^2*Cos[ThetaW]^2*Sin[ThetaWp]^2, g[lt1, lt4]*g[lt2, lt3]}}}
