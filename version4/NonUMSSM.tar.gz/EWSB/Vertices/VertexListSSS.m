{{{Ah[{gt1}], Ah[{gt2}], Ah[{gt3}]}, 
  {-((conj[ZA[gt1, 3]]*(conj[ZA[gt2, 2]]*conj[ZA[gt3, 1]] + 
         conj[ZA[gt2, 1]]*conj[ZA[gt3, 2]]) + conj[ZA[gt1, 2]]*
        (conj[ZA[gt2, 3]]*conj[ZA[gt3, 1]] + conj[ZA[gt2, 1]]*
          conj[ZA[gt3, 3]]) + conj[ZA[gt1, 1]]*
        (conj[ZA[gt2, 3]]*conj[ZA[gt3, 2]] + conj[ZA[gt2, 2]]*
          conj[ZA[gt3, 3]]))*(conj[T[\[Lambda]]] - T[\[Lambda]]))/
    (2*Sqrt[2]), 1}}, {{Ah[{gt1}], Ah[{gt2}], hh[{gt3}]}, 
  {(-I/4)*(conj[ZA[gt1, 3]]*(Sqrt[2]*conj[T[\[Lambda]]]*
        (conj[ZA[gt2, 2]]*conj[ZH[gt3, 1]] + conj[ZA[gt2, 1]]*
          conj[ZH[gt3, 2]]) + 4*conj[ZA[gt2, 3]]*
        (vd*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] + 
         vu*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 2]] + 
         gp^2*Qs^2*vS*conj[ZH[gt3, 3]]) + 
       Sqrt[2]*(conj[ZA[gt2, 2]]*conj[ZH[gt3, 1]] + conj[ZA[gt2, 1]]*
          conj[ZH[gt3, 2]])*T[\[Lambda]]) + conj[ZA[gt1, 2]]*
      (conj[ZA[gt2, 2]]*(-(vd*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
            4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]]) + 
         (g1^2 + g2^2 + 4*gp^2*QHu^2)*vu*conj[ZH[gt3, 2]] + 
         4*vS*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]) + 
       Sqrt[2]*(conj[ZA[gt2, 3]]*conj[ZH[gt3, 1]] + conj[ZA[gt2, 1]]*
          conj[ZH[gt3, 3]])*(conj[T[\[Lambda]]] + T[\[Lambda]])) + 
     conj[ZA[gt1, 1]]*(conj[ZA[gt2, 1]]*((g1^2 + g2^2 + 4*gp^2*QHd^2)*vd*
          conj[ZH[gt3, 1]] - vu*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
           4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 2]] + 
         4*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]) + 
       Sqrt[2]*(conj[ZA[gt2, 3]]*conj[ZH[gt3, 2]] + conj[ZA[gt2, 2]]*
          conj[ZH[gt3, 3]])*(conj[T[\[Lambda]]] + T[\[Lambda]]))), 1}}, 
 {{Ah[{gt1}], hh[{gt2}], hh[{gt3}]}, 
  {((conj[ZA[gt1, 3]]*(conj[ZH[gt2, 2]]*conj[ZH[gt3, 1]] + 
        conj[ZH[gt2, 1]]*conj[ZH[gt3, 2]]) + conj[ZA[gt1, 2]]*
       (conj[ZH[gt2, 3]]*conj[ZH[gt3, 1]] + conj[ZH[gt2, 1]]*
         conj[ZH[gt3, 3]]) + conj[ZA[gt1, 1]]*
       (conj[ZH[gt2, 3]]*conj[ZH[gt3, 2]] + conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 3]]))*(conj[T[\[Lambda]]] - T[\[Lambda]]))/(2*Sqrt[2]), 
   1}}, {{Ah[{gt1}], Hpm[{gt2}], conj[Hpm[{gt3}]]}, 
  {(vu*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*conj[ZA[gt1, 1]]*
      (ZP[gt2, 2]*ZP[gt3, 1] - ZP[gt2, 1]*ZP[gt3, 2]) + 
     vd*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*conj[ZA[gt1, 2]]*
      (ZP[gt2, 2]*ZP[gt3, 1] - ZP[gt2, 1]*ZP[gt3, 2]) + 
     2*Sqrt[2]*conj[ZA[gt1, 3]]*(-(conj[T[\[Lambda]]]*ZP[gt2, 2]*
         ZP[gt3, 1]) + T[\[Lambda]]*ZP[gt2, 1]*ZP[gt3, 2]))/4, 1}}, 
 {{Ah[{gt1}], Sd[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {(Delta[ct2, ct3]*(conj[\[Lambda]]*(vS*conj[ZA[gt1, 2]] + 
        vu*conj[ZA[gt1, 3]])*sum[j2, 1, 3, conj[ZD[gt2, j2]]*
         sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]] - 
      \[Lambda]*(vS*conj[ZA[gt1, 2]] + vu*conj[ZA[gt1, 3]])*
       sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt2, 3 + j1]]]*
         ZD[gt3, j2]] + Sqrt[2]*conj[ZA[gt1, 1]]*
       (sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, ZD[gt3, 3 + j1]*
            T[Yd][j1, j2]]] - sum[j2, 1, 3, 
         sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*conj[T[Yd][j1, j2]]]*
          ZD[gt3, j2]])))/2, 1}}, {{Ah[{gt1}], Se[{gt2}], conj[Se[{gt3}]]}, 
  {(-(Sqrt[2]*conj[T[Ye11]]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 4]]*ZE[gt3, 1]) - 
     Sqrt[2]*conj[Tep]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 4]]*ZE[gt3, 1] - 
     vS*\[Lambda]*conj[Ye11]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 4]]*ZE[gt3, 1] - 
     vu*\[Lambda]*conj[Ye11]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 4]]*ZE[gt3, 1] - 
     Sqrt[2]*conj[T[Ye22]]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 5]]*ZE[gt3, 2] - 
     Sqrt[2]*conj[Tmup]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 5]]*ZE[gt3, 2] - 
     vS*\[Lambda]*conj[Ye22]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 5]]*ZE[gt3, 2] - 
     vu*\[Lambda]*conj[Ye22]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 5]]*ZE[gt3, 2] - 
     Sqrt[2]*conj[T[Ye33]]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 6]]*ZE[gt3, 3] - 
     vS*\[Lambda]*conj[Ye33]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 6]]*ZE[gt3, 3] - 
     vu*\[Lambda]*conj[Ye33]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 6]]*ZE[gt3, 3] + 
     Sqrt[2]*Tep*conj[ZA[gt1, 2]]*conj[ZE[gt2, 1]]*ZE[gt3, 4] + 
     vS*Ye11*conj[\[Lambda]]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 1]]*ZE[gt3, 4] + 
     vu*Ye11*conj[\[Lambda]]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 1]]*ZE[gt3, 4] + 
     Sqrt[2]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 1]]*T[Ye11]*ZE[gt3, 4] + 
     Sqrt[2]*Tmup*conj[ZA[gt1, 2]]*conj[ZE[gt2, 2]]*ZE[gt3, 5] + 
     vS*Ye22*conj[\[Lambda]]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 2]]*ZE[gt3, 5] + 
     vu*Ye22*conj[\[Lambda]]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 2]]*ZE[gt3, 5] + 
     Sqrt[2]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 2]]*T[Ye22]*ZE[gt3, 5] + 
     vS*Ye33*conj[\[Lambda]]*conj[ZA[gt1, 2]]*conj[ZE[gt2, 3]]*ZE[gt3, 6] + 
     vu*Ye33*conj[\[Lambda]]*conj[ZA[gt1, 3]]*conj[ZE[gt2, 3]]*ZE[gt3, 6] + 
     Sqrt[2]*conj[ZA[gt1, 1]]*conj[ZE[gt2, 3]]*T[Ye33]*ZE[gt3, 6])/2, 1}}, 
 {{Ah[{gt1}], Su[{gt2, ct2}], conj[Su[{gt3, ct3}]]}, 
  {(Delta[ct2, ct3]*(conj[\[Lambda]]*(vS*conj[ZA[gt1, 1]] + 
        vd*conj[ZA[gt1, 3]])*sum[j2, 1, 3, conj[ZU[gt2, j2]]*
         sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]] - 
      \[Lambda]*(vS*conj[ZA[gt1, 1]] + vd*conj[ZA[gt1, 3]])*
       sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt2, 3 + j1]]]*
         ZU[gt3, j2]] + Sqrt[2]*conj[ZA[gt1, 2]]*
       (sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, ZU[gt3, 3 + j1]*
            T[Yu][j1, j2]]] - sum[j2, 1, 3, 
         sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*conj[T[Yu][j1, j2]]]*
          ZU[gt3, j2]])))/2, 1}}, {{Ah[{gt1}], Sv[{gt2}], conj[Sv[{gt3}]]}, 
  {(-(Sqrt[2]*conj[T[Yv11]]*conj[ZA[gt1, 2]]*conj[ZV[gt2, 4]]*ZV[gt3, 1]) - 
     \[Lambda]*conj[Yv11]*(vS*conj[ZA[gt1, 1]] + vd*conj[ZA[gt1, 3]])*
      conj[ZV[gt2, 4]]*ZV[gt3, 1] - vS*\[Lambda]*conj[Yv22]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 5]]*ZV[gt3, 2] - Sqrt[2]*conj[T[Yv22]]*conj[ZA[gt1, 2]]*
      conj[ZV[gt2, 5]]*ZV[gt3, 2] - vd*\[Lambda]*conj[Yv22]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 5]]*ZV[gt3, 2] - vS*\[Lambda]*conj[Yv33]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 6]]*ZV[gt3, 3] - Sqrt[2]*conj[T[Yv33]]*conj[ZA[gt1, 2]]*
      conj[ZV[gt2, 6]]*ZV[gt3, 3] - vd*\[Lambda]*conj[Yv33]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 6]]*ZV[gt3, 3] + vS*Yv11*conj[\[Lambda]]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 1]]*ZV[gt3, 4] + vd*Yv11*conj[\[Lambda]]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 1]]*ZV[gt3, 4] + Sqrt[2]*conj[ZA[gt1, 2]]*conj[ZV[gt2, 1]]*
      T[Yv11]*ZV[gt3, 4] + vS*Yv22*conj[\[Lambda]]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 2]]*ZV[gt3, 5] + vd*Yv22*conj[\[Lambda]]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 2]]*ZV[gt3, 5] + Sqrt[2]*conj[ZA[gt1, 2]]*conj[ZV[gt2, 2]]*
      T[Yv22]*ZV[gt3, 5] + vS*Yv33*conj[\[Lambda]]*conj[ZA[gt1, 1]]*
      conj[ZV[gt2, 3]]*ZV[gt3, 6] + vd*Yv33*conj[\[Lambda]]*conj[ZA[gt1, 3]]*
      conj[ZV[gt2, 3]]*ZV[gt3, 6] + Sqrt[2]*conj[ZA[gt1, 2]]*conj[ZV[gt2, 3]]*
      T[Yv33]*ZV[gt3, 6])/2, 1}}, {{hh[{gt1}], hh[{gt2}], hh[{gt3}]}, 
  {(I/4)*(-(conj[ZH[gt1, 3]]*(-(Sqrt[2]*conj[T[\[Lambda]]]*conj[ZH[gt2, 2]]*
          conj[ZH[gt3, 1]]) + 4*gp^2*QHd*Qs*vd*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 1]] + 4*vd*\[Lambda]*conj[\[Lambda]]*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 1]] + 4*gp^2*QHu*Qs*vS*conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 2]] + 4*vS*\[Lambda]*conj[\[Lambda]]*conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 2]] + 4*gp^2*QHu*Qs*vu*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 2]] + 4*vu*\[Lambda]*conj[\[Lambda]]*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 2]] + 4*gp^2*QHu*Qs*vu*conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 3]] + 4*vu*\[Lambda]*conj[\[Lambda]]*conj[ZH[gt2, 2]]*
         conj[ZH[gt3, 3]] + 12*gp^2*Qs^2*vS*conj[ZH[gt2, 3]]*
         conj[ZH[gt3, 3]] - Sqrt[2]*conj[ZH[gt2, 2]]*conj[ZH[gt3, 1]]*
         T[\[Lambda]] + conj[ZH[gt2, 1]]*
         (4*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] - 
          Sqrt[2]*conj[T[\[Lambda]]]*conj[ZH[gt3, 2]] + 4*gp^2*QHd*Qs*vd*
           conj[ZH[gt3, 3]] + 4*vd*\[Lambda]*conj[\[Lambda]]*
           conj[ZH[gt3, 3]] - Sqrt[2]*conj[ZH[gt3, 2]]*T[\[Lambda]]))) + 
     conj[ZH[gt1, 2]]*(conj[ZH[gt2, 2]]*(vd*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
           4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] - 
         3*(g1^2 + g2^2 + 4*gp^2*QHu^2)*vu*conj[ZH[gt3, 2]] - 
         4*vS*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]]) + 
       conj[ZH[gt2, 3]]*(Sqrt[2]*conj[T[\[Lambda]]]*conj[ZH[gt3, 1]] - 
         4*vS*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 2]] - 
         4*gp^2*QHu*Qs*vu*conj[ZH[gt3, 3]] - 4*vu*\[Lambda]*conj[\[Lambda]]*
          conj[ZH[gt3, 3]] + Sqrt[2]*conj[ZH[gt3, 1]]*T[\[Lambda]]) + 
       conj[ZH[gt2, 1]]*(vu*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
           4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] + 
         vd*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
          conj[ZH[gt3, 2]] + Sqrt[2]*conj[ZH[gt3, 3]]*(conj[T[\[Lambda]]] + 
           T[\[Lambda]]))) + conj[ZH[gt1, 1]]*
      (-(conj[ZH[gt2, 1]]*(3*(g1^2 + g2^2 + 4*gp^2*QHd^2)*vd*
           conj[ZH[gt3, 1]] - vu*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
            4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 2]] + 
          4*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 3]])) + 
       conj[ZH[gt2, 3]]*(-4*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*
          conj[ZH[gt3, 1]] + Sqrt[2]*conj[T[\[Lambda]]]*conj[ZH[gt3, 2]] - 
         4*gp^2*QHd*Qs*vd*conj[ZH[gt3, 3]] - 4*vd*\[Lambda]*conj[\[Lambda]]*
          conj[ZH[gt3, 3]] + Sqrt[2]*conj[ZH[gt3, 2]]*T[\[Lambda]]) + 
       conj[ZH[gt2, 2]]*(vu*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 
           4*\[Lambda]*conj[\[Lambda]])*conj[ZH[gt3, 1]] + 
         vd*(g1^2 + g2^2 - 4*gp^2*QHd*QHu - 4*\[Lambda]*conj[\[Lambda]])*
          conj[ZH[gt3, 2]] + Sqrt[2]*conj[ZH[gt3, 3]]*(conj[T[\[Lambda]]] + 
           T[\[Lambda]])))), 1}}, {{hh[{gt1}], Hpm[{gt2}], conj[Hpm[{gt3}]]}, 
  {(-I/4)*(conj[ZH[gt1, 2]]*
      (ZP[gt2, 2]*(vd*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*ZP[gt3, 1] + 
         (g1^2 + g2^2 + 4*gp^2*QHu^2)*vu*ZP[gt3, 2]) + 
       ZP[gt2, 1]*((-g1^2 + g2^2 + 4*gp^2*QHd*QHu)*vu*ZP[gt3, 1] + 
         vd*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*ZP[gt3, 2])) + 
     conj[ZH[gt1, 1]]*(ZP[gt2, 2]*(vu*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*
          ZP[gt3, 1] + (-g1^2 + g2^2 + 4*gp^2*QHd*QHu)*vd*ZP[gt3, 2]) + 
       ZP[gt2, 1]*((g1^2 + g2^2 + 4*gp^2*QHd^2)*vd*ZP[gt3, 1] + 
         vu*(g2^2 - 2*\[Lambda]*conj[\[Lambda]])*ZP[gt3, 2])) + 
     2*conj[ZH[gt1, 3]]*(ZP[gt2, 2]*(Sqrt[2]*conj[T[\[Lambda]]]*ZP[gt3, 1] + 
         2*vS*(gp^2*QHu*Qs + \[Lambda]*conj[\[Lambda]])*ZP[gt3, 2]) + 
       ZP[gt2, 1]*(2*vS*(gp^2*QHd*Qs + \[Lambda]*conj[\[Lambda]])*
          ZP[gt3, 1] + Sqrt[2]*T[\[Lambda]]*ZP[gt3, 2]))), 1}}, 
 {{hh[{gt1}], Sd[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {(I/12)*Delta[ct2, ct3]*(6*conj[ZH[gt1, 3]]*
      (-2*gp^2*Qq*Qs*vS*sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]] - 
       2*gp^2*Qd*Qs*vS*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*ZD[gt3, 3 + j1]] + 
       vu*conj[\[Lambda]]*sum[j2, 1, 3, conj[ZD[gt2, j2]]*
          sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]] + 
       vu*\[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*
            conj[ZD[gt2, 3 + j1]]]*ZD[gt3, j2]]) - 
     conj[ZH[gt1, 2]]*((g1^2 + 3*(g2^2 + 4*gp^2*QHu*Qq))*vu*
        sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]] + 
       2*(g1^2 + 6*gp^2*Qd*QHu)*vu*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*
          ZD[gt3, 3 + j1]] - 6*vS*(conj[\[Lambda]]*sum[j2, 1, 3, 
           conj[ZD[gt2, j2]]*sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]] + 
         \[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*
              conj[ZD[gt2, 3 + j1]]]*ZD[gt3, j2]])) + 
     conj[ZH[gt1, 1]]*((g1^2 + 3*(g2^2 - 4*gp^2*QHd*Qq))*vd*
        sum[j1, 1, 3, conj[ZD[gt2, j1]]*ZD[gt3, j1]] + 
       2*(g1^2 - 6*gp^2*Qd*QHd)*vd*sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*
          ZD[gt3, 3 + j1]] - 
       6*(Sqrt[2]*sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, 
             ZD[gt3, 3 + j1]*T[Yd][j1, j2]]] + 
         Sqrt[2]*sum[j2, 1, 3, sum[j1, 1, 3, conj[ZD[gt2, 3 + j1]]*
              conj[T[Yd][j1, j2]]]*ZD[gt3, j2]] + 
         2*vd*(sum[j3, 1, 3, conj[ZD[gt2, 3 + j3]]*sum[j2, 1, 3, 
              sum[j1, 1, 3, conj[Yd[j3, j1]]*Yd[j2, j1]]*ZD[gt3, 3 + j2]]] + 
           sum[j3, 1, 3, sum[j2, 1, 3, conj[ZD[gt2, j2]]*sum[j1, 1, 3, 
                conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZD[gt3, j3]])))), 1}}, 
 {{hh[{gt1}], Se[{gt2}], conj[Se[{gt3}]]}, 
  {(-I/4)*(2*Sqrt[2]*conj[T[Ye11]]*conj[ZE[gt2, 4]]*conj[ZH[gt1, 1]]*
      ZE[gt3, 1] - 2*Sqrt[2]*conj[Tep]*conj[ZE[gt2, 4]]*conj[ZH[gt1, 2]]*
      ZE[gt3, 1] - 2*vS*\[Lambda]*conj[Ye11]*conj[ZE[gt2, 4]]*
      conj[ZH[gt1, 2]]*ZE[gt3, 1] - 2*vu*\[Lambda]*conj[Ye11]*
      conj[ZE[gt2, 4]]*conj[ZH[gt1, 3]]*ZE[gt3, 1] + 
     g1^2*vd*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] - 
     g2^2*vd*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] + 
     4*gp^2*QHd*Ql2*vd*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] + 
     4*vd*Ye22*conj[Ye22]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] + 
     2*Sqrt[2]*conj[T[Ye22]]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 1]]*ZE[gt3, 2] - 
     g1^2*vu*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] + 
     g2^2*vu*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] + 
     4*gp^2*QHu*Ql2*vu*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] - 
     2*Sqrt[2]*conj[Tmup]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] - 
     2*vS*\[Lambda]*conj[Ye22]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 2]]*ZE[gt3, 2] + 
     4*gp^2*Ql2*Qs*vS*conj[ZE[gt2, 2]]*conj[ZH[gt1, 3]]*ZE[gt3, 2] - 
     2*vu*\[Lambda]*conj[Ye22]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 3]]*ZE[gt3, 2] + 
     g1^2*vd*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] - 
     g2^2*vd*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] + 
     4*gp^2*QHd*Ql3*vd*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] + 
     4*vd*Ye33*conj[Ye33]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] + 
     2*Sqrt[2]*conj[T[Ye33]]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 1]]*ZE[gt3, 3] - 
     g1^2*vu*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZE[gt3, 3] + 
     g2^2*vu*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZE[gt3, 3] + 
     4*gp^2*QHu*Ql3*vu*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZE[gt3, 3] - 
     2*vS*\[Lambda]*conj[Ye33]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 2]]*ZE[gt3, 3] + 
     4*gp^2*Ql3*Qs*vS*conj[ZE[gt2, 3]]*conj[ZH[gt1, 3]]*ZE[gt3, 3] - 
     2*vu*\[Lambda]*conj[Ye33]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 3]]*ZE[gt3, 3] - 
     2*g1^2*vd*conj[ZE[gt2, 4]]*conj[ZH[gt1, 1]]*ZE[gt3, 4] + 
     4*gp^2*Qe1*QHd*vd*conj[ZE[gt2, 4]]*conj[ZH[gt1, 1]]*ZE[gt3, 4] + 
     4*vd*Ye11*conj[Ye11]*conj[ZE[gt2, 4]]*conj[ZH[gt1, 1]]*ZE[gt3, 4] + 
     2*g1^2*vu*conj[ZE[gt2, 4]]*conj[ZH[gt1, 2]]*ZE[gt3, 4] + 
     4*gp^2*Qe1*QHu*vu*conj[ZE[gt2, 4]]*conj[ZH[gt1, 2]]*ZE[gt3, 4] + 
     4*gp^2*Qe1*Qs*vS*conj[ZE[gt2, 4]]*conj[ZH[gt1, 3]]*ZE[gt3, 4] + 
     conj[ZE[gt2, 1]]*(2*conj[ZH[gt1, 3]]*(2*gp^2*Ql1*Qs*vS*ZE[gt3, 1] - 
         vu*Ye11*conj[\[Lambda]]*ZE[gt3, 4]) + conj[ZH[gt1, 2]]*
        ((-g1^2 + g2^2 + 4*gp^2*QHu*Ql1)*vu*ZE[gt3, 1] - 
         2*(Sqrt[2]*Tep + vS*Ye11*conj[\[Lambda]])*ZE[gt3, 4]) + 
       conj[ZH[gt1, 1]]*(vd*(g1^2 - g2^2 + 4*gp^2*QHd*Ql1 + 
           4*Ye11*conj[Ye11])*ZE[gt3, 1] + 2*Sqrt[2]*T[Ye11]*ZE[gt3, 4])) - 
     2*g1^2*vd*conj[ZE[gt2, 5]]*conj[ZH[gt1, 1]]*ZE[gt3, 5] + 
     4*gp^2*Qe2*QHd*vd*conj[ZE[gt2, 5]]*conj[ZH[gt1, 1]]*ZE[gt3, 5] + 
     4*vd*Ye22*conj[Ye22]*conj[ZE[gt2, 5]]*conj[ZH[gt1, 1]]*ZE[gt3, 5] - 
     2*Sqrt[2]*Tmup*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 5] - 
     2*vS*Ye22*conj[\[Lambda]]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 2]]*ZE[gt3, 5] + 
     2*g1^2*vu*conj[ZE[gt2, 5]]*conj[ZH[gt1, 2]]*ZE[gt3, 5] + 
     4*gp^2*Qe2*QHu*vu*conj[ZE[gt2, 5]]*conj[ZH[gt1, 2]]*ZE[gt3, 5] - 
     2*vu*Ye22*conj[\[Lambda]]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 3]]*ZE[gt3, 5] + 
     4*gp^2*Qe2*Qs*vS*conj[ZE[gt2, 5]]*conj[ZH[gt1, 3]]*ZE[gt3, 5] + 
     2*Sqrt[2]*conj[ZE[gt2, 2]]*conj[ZH[gt1, 1]]*T[Ye22]*ZE[gt3, 5] - 
     2*g1^2*vd*conj[ZE[gt2, 6]]*conj[ZH[gt1, 1]]*ZE[gt3, 6] + 
     4*gp^2*Qe3*QHd*vd*conj[ZE[gt2, 6]]*conj[ZH[gt1, 1]]*ZE[gt3, 6] + 
     4*vd*Ye33*conj[Ye33]*conj[ZE[gt2, 6]]*conj[ZH[gt1, 1]]*ZE[gt3, 6] - 
     2*vS*Ye33*conj[\[Lambda]]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 2]]*ZE[gt3, 6] + 
     2*g1^2*vu*conj[ZE[gt2, 6]]*conj[ZH[gt1, 2]]*ZE[gt3, 6] + 
     4*gp^2*Qe3*QHu*vu*conj[ZE[gt2, 6]]*conj[ZH[gt1, 2]]*ZE[gt3, 6] - 
     2*vu*Ye33*conj[\[Lambda]]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 3]]*ZE[gt3, 6] + 
     4*gp^2*Qe3*Qs*vS*conj[ZE[gt2, 6]]*conj[ZH[gt1, 3]]*ZE[gt3, 6] + 
     2*Sqrt[2]*conj[ZE[gt2, 3]]*conj[ZH[gt1, 1]]*T[Ye33]*ZE[gt3, 6]), 1}}, 
 {{hh[{gt1}], Su[{gt2, ct2}], conj[Su[{gt3, ct3}]]}, 
  {(I/12)*Delta[ct2, ct3]*(6*conj[ZH[gt1, 3]]*
      (-2*gp^2*Qq*Qs*vS*sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]] - 
       2*gp^2*Qs*Qu*vS*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*ZU[gt3, 3 + j1]] + 
       vd*conj[\[Lambda]]*sum[j2, 1, 3, conj[ZU[gt2, j2]]*
          sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]] + 
       vd*\[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
            conj[ZU[gt2, 3 + j1]]]*ZU[gt3, j2]]) + 
     conj[ZH[gt1, 1]]*((g1^2 - 3*(g2^2 + 4*gp^2*QHd*Qq))*vd*
        sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]] - 
       4*(g1^2 + 3*gp^2*QHd*Qu)*vd*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
          ZU[gt3, 3 + j1]] + 6*vS*(conj[\[Lambda]]*sum[j2, 1, 3, 
           conj[ZU[gt2, j2]]*sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]] + 
         \[Lambda]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*
              conj[ZU[gt2, 3 + j1]]]*ZU[gt3, j2]])) - 
     conj[ZH[gt1, 2]]*((g1^2 - 3*g2^2 + 12*gp^2*QHu*Qq)*vu*
        sum[j1, 1, 3, conj[ZU[gt2, j1]]*ZU[gt3, j1]] - 
       4*(g1^2 - 3*gp^2*QHu*Qu)*vu*sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
          ZU[gt3, 3 + j1]] + 
       6*(Sqrt[2]*sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
             ZU[gt3, 3 + j1]*T[Yu][j1, j2]]] + 
         Sqrt[2]*sum[j2, 1, 3, sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
              conj[T[Yu][j1, j2]]]*ZU[gt3, j2]] + 
         2*vu*(sum[j3, 1, 3, conj[ZU[gt2, 3 + j3]]*sum[j2, 1, 3, 
              sum[j1, 1, 3, conj[Yu[j3, j1]]*Yu[j2, j1]]*ZU[gt3, 3 + j2]]] + 
           sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, 
                conj[Yu[j1, j3]]*Yu[j1, j2]]]*ZU[gt3, j3]])))), 1}}, 
 {{hh[{gt1}], Sv[{gt2}], conj[Sv[{gt3}]]}, 
  {(-I/4)*(conj[ZH[gt1, 1]]*(-2*vS*\[Lambda]*conj[Yv11]*conj[ZV[gt2, 4]]*
        ZV[gt3, 1] + g1^2*vd*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 
       g2^2*vd*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 4*gp^2*QHd*Ql2*vd*
        conj[ZV[gt2, 2]]*ZV[gt3, 2] - 2*vS*\[Lambda]*conj[Yv22]*
        conj[ZV[gt2, 5]]*ZV[gt3, 2] + g1^2*vd*conj[ZV[gt2, 3]]*ZV[gt3, 3] + 
       g2^2*vd*conj[ZV[gt2, 3]]*ZV[gt3, 3] + 4*gp^2*QHd*Ql3*vd*
        conj[ZV[gt2, 3]]*ZV[gt3, 3] - 2*vS*\[Lambda]*conj[Yv33]*
        conj[ZV[gt2, 6]]*ZV[gt3, 3] + 4*gp^2*QHd*Qv1*vd*conj[ZV[gt2, 4]]*
        ZV[gt3, 4] + conj[ZV[gt2, 1]]*((g1^2 + g2^2 + 4*gp^2*QHd*Ql1)*vd*
          ZV[gt3, 1] - 2*vS*Yv11*conj[\[Lambda]]*ZV[gt3, 4]) - 
       2*vS*Yv22*conj[\[Lambda]]*conj[ZV[gt2, 2]]*ZV[gt3, 5] + 
       4*gp^2*QHd*Qv2*vd*conj[ZV[gt2, 5]]*ZV[gt3, 5] - 
       2*vS*Yv33*conj[\[Lambda]]*conj[ZV[gt2, 3]]*ZV[gt3, 6] + 
       4*gp^2*QHd*Qv3*vd*conj[ZV[gt2, 6]]*ZV[gt3, 6]) - 
     2*conj[ZH[gt1, 3]]*(vd*\[Lambda]*conj[Yv11]*conj[ZV[gt2, 4]]*
        ZV[gt3, 1] - 2*gp^2*Ql2*Qs*vS*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 
       vd*\[Lambda]*conj[Yv22]*conj[ZV[gt2, 5]]*ZV[gt3, 2] - 
       2*gp^2*Ql3*Qs*vS*conj[ZV[gt2, 3]]*ZV[gt3, 3] + vd*\[Lambda]*conj[Yv33]*
        conj[ZV[gt2, 6]]*ZV[gt3, 3] - 2*gp^2*Qs*Qv1*vS*conj[ZV[gt2, 4]]*
        ZV[gt3, 4] + conj[ZV[gt2, 1]]*(-2*gp^2*Ql1*Qs*vS*ZV[gt3, 1] + 
         vd*Yv11*conj[\[Lambda]]*ZV[gt3, 4]) + vd*Yv22*conj[\[Lambda]]*
        conj[ZV[gt2, 2]]*ZV[gt3, 5] - 2*gp^2*Qs*Qv2*vS*conj[ZV[gt2, 5]]*
        ZV[gt3, 5] + vd*Yv33*conj[\[Lambda]]*conj[ZV[gt2, 3]]*ZV[gt3, 6] - 
       2*gp^2*Qs*Qv3*vS*conj[ZV[gt2, 6]]*ZV[gt3, 6]) + 
     conj[ZH[gt1, 2]]*(2*Sqrt[2]*conj[T[Yv11]]*conj[ZV[gt2, 4]]*ZV[gt3, 1] - 
       g1^2*vu*conj[ZV[gt2, 2]]*ZV[gt3, 2] - g2^2*vu*conj[ZV[gt2, 2]]*
        ZV[gt3, 2] + 4*gp^2*QHu*Ql2*vu*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 
       4*vu*Yv22*conj[Yv22]*conj[ZV[gt2, 2]]*ZV[gt3, 2] + 
       2*Sqrt[2]*conj[T[Yv22]]*conj[ZV[gt2, 5]]*ZV[gt3, 2] - 
       g1^2*vu*conj[ZV[gt2, 3]]*ZV[gt3, 3] - g2^2*vu*conj[ZV[gt2, 3]]*
        ZV[gt3, 3] + 4*gp^2*QHu*Ql3*vu*conj[ZV[gt2, 3]]*ZV[gt3, 3] + 
       4*vu*Yv33*conj[Yv33]*conj[ZV[gt2, 3]]*ZV[gt3, 3] + 
       2*Sqrt[2]*conj[T[Yv33]]*conj[ZV[gt2, 6]]*ZV[gt3, 3] + 
       4*gp^2*QHu*Qv1*vu*conj[ZV[gt2, 4]]*ZV[gt3, 4] + 
       4*vu*Yv11*conj[Yv11]*conj[ZV[gt2, 4]]*ZV[gt3, 4] + 
       conj[ZV[gt2, 1]]*(-(vu*(g1^2 + g2^2 - 4*gp^2*QHu*Ql1 - 
            4*Yv11*conj[Yv11])*ZV[gt3, 1]) + 2*Sqrt[2]*T[Yv11]*ZV[gt3, 4]) + 
       4*gp^2*QHu*Qv2*vu*conj[ZV[gt2, 5]]*ZV[gt3, 5] + 
       4*vu*Yv22*conj[Yv22]*conj[ZV[gt2, 5]]*ZV[gt3, 5] + 
       2*Sqrt[2]*conj[ZV[gt2, 2]]*T[Yv22]*ZV[gt3, 5] + 
       4*gp^2*QHu*Qv3*vu*conj[ZV[gt2, 6]]*ZV[gt3, 6] + 
       4*vu*Yv33*conj[Yv33]*conj[ZV[gt2, 6]]*ZV[gt3, 6] + 
       2*Sqrt[2]*conj[ZV[gt2, 3]]*T[Yv33]*ZV[gt3, 6])), 1}}, 
 {{Hpm[{gt1}], Su[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {(-I/4)*Delta[ct2, ct3]*(Sqrt[2]*g2^2*sum[j1, 1, 3, 
       conj[ZU[gt2, j1]]*ZD[gt3, j1]]*(vd*ZP[gt1, 1] + vu*ZP[gt1, 2]) - 
     2*(2*sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, ZD[gt3, 3 + j1]*
            T[Yd][j1, j2]]]*ZP[gt1, 1] + Sqrt[2]*vS*\[Lambda]*
        sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j1, j2]]*conj[ZU[gt2, 3 + j1]]]*
          ZD[gt3, j2]]*ZP[gt1, 1] + Sqrt[2]*vu*sum[j3, 1, 3, 
         conj[ZU[gt2, 3 + j3]]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yu[j3, j1]]*
              Yd[j2, j1]]*ZD[gt3, 3 + j2]]]*ZP[gt1, 1] + 
       Sqrt[2]*vd*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZU[gt2, j2]]*
            sum[j1, 1, 3, conj[Yd[j1, j3]]*Yd[j1, j2]]]*ZD[gt3, j3]]*
        ZP[gt1, 1] + Sqrt[2]*vS*conj[\[Lambda]]*sum[j2, 1, 3, 
         conj[ZU[gt2, j2]]*sum[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]]*
        ZP[gt1, 2] + 2*sum[j2, 1, 3, sum[j1, 1, 3, conj[ZU[gt2, 3 + j1]]*
            conj[T[Yu][j1, j2]]]*ZD[gt3, j2]]*ZP[gt1, 2] + 
       Sqrt[2]*vd*sum[j3, 1, 3, conj[ZU[gt2, 3 + j3]]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yu[j3, j1]]*Yd[j2, j1]]*ZD[gt3, 3 + j2]]]*
        ZP[gt1, 2] + Sqrt[2]*vu*sum[j3, 1, 3, 
         sum[j2, 1, 3, conj[ZU[gt2, j2]]*sum[j1, 1, 3, conj[Yu[j1, j3]]*
              Yu[j1, j2]]]*ZD[gt3, j3]]*ZP[gt1, 2])), 1}}, 
 {{Hpm[{gt1}], Sv[{gt2}], conj[Se[{gt3}]]}, 
  {(-I/4)*(Sqrt[2]*g2^2*vd*conj[ZV[gt2, 2]]*ZE[gt3, 2]*ZP[gt1, 1] - 
     2*Sqrt[2]*vd*Ye22*conj[Ye22]*conj[ZV[gt2, 2]]*ZE[gt3, 2]*ZP[gt1, 1] - 
     2*Sqrt[2]*vS*\[Lambda]*conj[Yv22]*conj[ZV[gt2, 5]]*ZE[gt3, 2]*
      ZP[gt1, 1] + Sqrt[2]*g2^2*vd*conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZP[gt1, 1] - 
     2*Sqrt[2]*vd*Ye33*conj[Ye33]*conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZP[gt1, 1] - 
     2*Sqrt[2]*vS*\[Lambda]*conj[Yv33]*conj[ZV[gt2, 6]]*ZE[gt3, 3]*
      ZP[gt1, 1] - 2*Sqrt[2]*vu*Ye22*conj[Yv22]*conj[ZV[gt2, 5]]*ZE[gt3, 5]*
      ZP[gt1, 1] - 4*conj[ZV[gt2, 2]]*T[Ye22]*ZE[gt3, 5]*ZP[gt1, 1] - 
     2*Sqrt[2]*vu*Ye33*conj[Yv33]*conj[ZV[gt2, 6]]*ZE[gt3, 6]*ZP[gt1, 1] - 
     4*conj[ZV[gt2, 3]]*T[Ye33]*ZE[gt3, 6]*ZP[gt1, 1] - 
     4*conj[T[Yv11]]*conj[ZV[gt2, 4]]*ZE[gt3, 1]*ZP[gt1, 2] + 
     Sqrt[2]*g2^2*vu*conj[ZV[gt2, 2]]*ZE[gt3, 2]*ZP[gt1, 2] - 
     2*Sqrt[2]*vu*Yv22*conj[Yv22]*conj[ZV[gt2, 2]]*ZE[gt3, 2]*ZP[gt1, 2] - 
     4*conj[T[Yv22]]*conj[ZV[gt2, 5]]*ZE[gt3, 2]*ZP[gt1, 2] + 
     Sqrt[2]*g2^2*vu*conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZP[gt1, 2] - 
     2*Sqrt[2]*vu*Yv33*conj[Yv33]*conj[ZV[gt2, 3]]*ZE[gt3, 3]*ZP[gt1, 2] - 
     4*conj[T[Yv33]]*conj[ZV[gt2, 6]]*ZE[gt3, 3]*ZP[gt1, 2] - 
     4*Tmup*conj[ZV[gt2, 2]]*ZE[gt3, 5]*ZP[gt1, 2] - 
     2*Sqrt[2]*vS*Ye22*conj[\[Lambda]]*conj[ZV[gt2, 2]]*ZE[gt3, 5]*
      ZP[gt1, 2] - 2*Sqrt[2]*vd*Ye22*conj[Yv22]*conj[ZV[gt2, 5]]*ZE[gt3, 5]*
      ZP[gt1, 2] - 2*Sqrt[2]*vS*Ye33*conj[\[Lambda]]*conj[ZV[gt2, 3]]*
      ZE[gt3, 6]*ZP[gt1, 2] - 2*Sqrt[2]*vd*Ye33*conj[Yv33]*conj[ZV[gt2, 6]]*
      ZE[gt3, 6]*ZP[gt1, 2] - 2*Sqrt[2]*conj[Yv11]*conj[ZV[gt2, 4]]*
      (vS*\[Lambda]*ZE[gt3, 1]*ZP[gt1, 1] + Ye11*ZE[gt3, 4]*
        (vu*ZP[gt1, 1] + vd*ZP[gt1, 2])) + conj[ZV[gt2, 1]]*
      (Sqrt[2]*ZE[gt3, 1]*(vd*(g2^2 - 2*Ye11*conj[Ye11])*ZP[gt1, 1] + 
         vu*(g2^2 - 2*Yv11*conj[Yv11])*ZP[gt1, 2]) - 
       2*ZE[gt3, 4]*(2*T[Ye11]*ZP[gt1, 1] + 
         (2*Tep + Sqrt[2]*vS*Ye11*conj[\[Lambda]])*ZP[gt1, 2]))), 1}}, 
 {{Sd[{gt1, ct1}], conj[Hpm[{gt2}]], conj[Su[{gt3, ct3}]]}, 
  {(-I/4)*Delta[ct1, ct3]*(Sqrt[2]*g2^2*sum[j1, 1, 3, 
       conj[ZD[gt1, j1]]*ZU[gt3, j1]]*(vd*ZP[gt2, 1] + vu*ZP[gt2, 2]) - 
     2*(Sqrt[2]*vS*conj[\[Lambda]]*sum[j2, 1, 3, conj[ZD[gt1, j2]]*
          sum[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]]*ZP[gt2, 1] + 
       2*sum[j2, 1, 3, sum[j1, 1, 3, conj[ZD[gt1, 3 + j1]]*
            conj[T[Yd][j1, j2]]]*ZU[gt3, j2]]*ZP[gt2, 1] + 
       Sqrt[2]*vu*sum[j3, 1, 3, conj[ZD[gt1, 3 + j3]]*sum[j2, 1, 3, 
           sum[j1, 1, 3, conj[Yd[j3, j1]]*Yu[j2, j1]]*ZU[gt3, 3 + j2]]]*
        ZP[gt2, 1] + Sqrt[2]*vd*sum[j3, 1, 3, 
         sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, conj[Yd[j1, j3]]*
              Yd[j1, j2]]]*ZU[gt3, j3]]*ZP[gt2, 1] + 
       2*sum[j2, 1, 3, conj[ZD[gt1, j2]]*sum[j1, 1, 3, ZU[gt3, 3 + j1]*
            T[Yu][j1, j2]]]*ZP[gt2, 2] + Sqrt[2]*vS*\[Lambda]*
        sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j1, j2]]*conj[ZD[gt1, 3 + j1]]]*
          ZU[gt3, j2]]*ZP[gt2, 2] + Sqrt[2]*vd*sum[j3, 1, 3, 
         conj[ZD[gt1, 3 + j3]]*sum[j2, 1, 3, sum[j1, 1, 3, conj[Yd[j3, j1]]*
              Yu[j2, j1]]*ZU[gt3, 3 + j2]]]*ZP[gt2, 2] + 
       Sqrt[2]*vu*sum[j3, 1, 3, sum[j2, 1, 3, conj[ZD[gt1, j2]]*
            sum[j1, 1, 3, conj[Yu[j1, j3]]*Yu[j1, j2]]]*ZU[gt3, j3]]*
        ZP[gt2, 2])), 1}}, {{Se[{gt1}], conj[Hpm[{gt2}]], conj[Sv[{gt3}]]}, 
  {(I/4)*(4*conj[T[Ye11]]*conj[ZE[gt1, 4]]*ZP[gt2, 1]*ZV[gt3, 1] + 
     4*conj[Tep]*conj[ZE[gt1, 4]]*ZP[gt2, 2]*ZV[gt3, 1] + 
     2*Sqrt[2]*vS*\[Lambda]*conj[Ye11]*conj[ZE[gt1, 4]]*ZP[gt2, 2]*
      ZV[gt3, 1] - Sqrt[2]*g2^2*vd*conj[ZE[gt1, 2]]*ZP[gt2, 1]*ZV[gt3, 2] + 
     2*Sqrt[2]*vd*Ye22*conj[Ye22]*conj[ZE[gt1, 2]]*ZP[gt2, 1]*ZV[gt3, 2] + 
     4*conj[T[Ye22]]*conj[ZE[gt1, 5]]*ZP[gt2, 1]*ZV[gt3, 2] - 
     Sqrt[2]*g2^2*vu*conj[ZE[gt1, 2]]*ZP[gt2, 2]*ZV[gt3, 2] + 
     2*Sqrt[2]*vu*Yv22*conj[Yv22]*conj[ZE[gt1, 2]]*ZP[gt2, 2]*ZV[gt3, 2] + 
     4*conj[Tmup]*conj[ZE[gt1, 5]]*ZP[gt2, 2]*ZV[gt3, 2] + 
     2*Sqrt[2]*vS*\[Lambda]*conj[Ye22]*conj[ZE[gt1, 5]]*ZP[gt2, 2]*
      ZV[gt3, 2] - Sqrt[2]*g2^2*vd*conj[ZE[gt1, 3]]*ZP[gt2, 1]*ZV[gt3, 3] + 
     2*Sqrt[2]*vd*Ye33*conj[Ye33]*conj[ZE[gt1, 3]]*ZP[gt2, 1]*ZV[gt3, 3] + 
     4*conj[T[Ye33]]*conj[ZE[gt1, 6]]*ZP[gt2, 1]*ZV[gt3, 3] - 
     Sqrt[2]*g2^2*vu*conj[ZE[gt1, 3]]*ZP[gt2, 2]*ZV[gt3, 3] + 
     2*Sqrt[2]*vu*Yv33*conj[Yv33]*conj[ZE[gt1, 3]]*ZP[gt2, 2]*ZV[gt3, 3] + 
     2*Sqrt[2]*vS*\[Lambda]*conj[Ye33]*conj[ZE[gt1, 6]]*ZP[gt2, 2]*
      ZV[gt3, 3] + 2*Sqrt[2]*vu*Yv11*conj[Ye11]*conj[ZE[gt1, 4]]*ZP[gt2, 1]*
      ZV[gt3, 4] + 2*Sqrt[2]*vd*Yv11*conj[Ye11]*conj[ZE[gt1, 4]]*ZP[gt2, 2]*
      ZV[gt3, 4] + conj[ZE[gt1, 1]]*(Sqrt[2]*ZP[gt2, 1]*
        (-(vd*(g2^2 - 2*Ye11*conj[Ye11])*ZV[gt3, 1]) + 
         2*vS*Yv11*conj[\[Lambda]]*ZV[gt3, 4]) + 
       ZP[gt2, 2]*(-(Sqrt[2]*vu*(g2^2 - 2*Yv11*conj[Yv11])*ZV[gt3, 1]) + 
         4*T[Yv11]*ZV[gt3, 4])) + 2*Sqrt[2]*vS*Yv22*conj[\[Lambda]]*
      conj[ZE[gt1, 2]]*ZP[gt2, 1]*ZV[gt3, 5] + 2*Sqrt[2]*vu*Yv22*conj[Ye22]*
      conj[ZE[gt1, 5]]*ZP[gt2, 1]*ZV[gt3, 5] + 2*Sqrt[2]*vd*Yv22*conj[Ye22]*
      conj[ZE[gt1, 5]]*ZP[gt2, 2]*ZV[gt3, 5] + 4*conj[ZE[gt1, 2]]*T[Yv22]*
      ZP[gt2, 2]*ZV[gt3, 5] + 2*Sqrt[2]*vS*Yv33*conj[\[Lambda]]*
      conj[ZE[gt1, 3]]*ZP[gt2, 1]*ZV[gt3, 6] + 2*Sqrt[2]*vu*Yv33*conj[Ye33]*
      conj[ZE[gt1, 6]]*ZP[gt2, 1]*ZV[gt3, 6] + 2*Sqrt[2]*vd*Yv33*conj[Ye33]*
      conj[ZE[gt1, 6]]*ZP[gt2, 2]*ZV[gt3, 6] + 4*conj[ZE[gt1, 3]]*T[Yv33]*
      ZP[gt2, 2]*ZV[gt3, 6]), 1}}}
