{{{hh[{gt1}], conj[VWm[{lt2}]], VWm[{lt3}]}, 
  {(I/2)*g2^2*(vd*conj[ZH[gt1, 1]] + vu*conj[ZH[gt1, 2]]), g[lt2, lt3]}}, 
 {{hh[{gt1}], VZ[{lt2}], VZ[{lt3}]}, 
  {(I/2)*(4*gp^2*Qs^2*vS*conj[ZH[gt1, 3]]*Sin[ThetaWp]^2 + 
     vd*conj[ZH[gt1, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])^2 + 
     vu*conj[ZH[gt1, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
        g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])^2), 
   g[lt2, lt3]}}, {{hh[{gt1}], VZ[{lt2}], VZp[{lt3}]}, 
  {(-I/2)*(-4*gp^2*Qs^2*vS*conj[ZH[gt1, 3]]*Cos[ThetaWp]*Sin[ThetaWp] + 
     vd*conj[ZH[gt1, 1]]*(-2*g1*gp*QHd*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHd^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] + 
       2*g1*gp*QHd*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (-(gp*QHd*Cos[ThetaWp]^2) + g1*Cos[ThetaWp]*Sin[ThetaW]*
          Sin[ThetaWp] + gp*QHd*Sin[ThetaWp]^2)) + 
     vu*conj[ZH[gt1, 2]]*(2*g1*gp*QHu*Cos[ThetaWp]^2*Sin[ThetaW] + 
       g2^2*Cos[ThetaW]^2*Cos[ThetaWp]*Sin[ThetaWp] + 
       Cos[ThetaWp]*(-4*gp^2*QHu^2 + g1^2*Sin[ThetaW]^2)*Sin[ThetaWp] - 
       2*g1*gp*QHu*Sin[ThetaW]*Sin[ThetaWp]^2 + 2*g2*Cos[ThetaW]*
        (gp*QHu*Cos[ThetaWp]^2 + g1*Cos[ThetaWp]*Sin[ThetaW]*Sin[ThetaWp] - 
         gp*QHu*Sin[ThetaWp]^2))), g[lt2, lt3]}}, 
 {{hh[{gt1}], VZp[{lt2}], VZp[{lt3}]}, 
  {(I/2)*(4*gp^2*Qs^2*vS*conj[ZH[gt1, 3]]*Cos[ThetaWp]^2 + 
     vd*conj[ZH[gt1, 1]]*(-2*gp*QHd*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2 + 
     vu*conj[ZH[gt1, 2]]*(2*gp*QHu*Cos[ThetaWp] + 
        (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])^2), g[lt2, lt3]}}, 
 {{Hpm[{gt1}], conj[VWm[{lt2}]], VP[{lt3}]}, 
  {(-I/2)*g1*g2*Cos[ThetaW]*(vd*ZP[gt1, 1] - vu*ZP[gt1, 2]), g[lt2, lt3]}}, 
 {{Hpm[{gt1}], conj[VWm[{lt2}]], VZ[{lt3}]}, 
  {(I/2)*g2*(vd*(g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*
      ZP[gt1, 1] + vu*(-(g1*Cos[ThetaWp]*Sin[ThetaW]) + 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt1, 2]), g[lt2, lt3]}}, 
 {{Hpm[{gt1}], conj[VWm[{lt2}]], VZp[{lt3}]}, 
  {(I/2)*g2*(vd*(2*gp*QHd*Cos[ThetaWp] - g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZP[gt1, 1] + vu*(2*gp*QHu*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZP[gt1, 2]), g[lt2, lt3]}}, {{conj[Hpm[{gt1}]], VP[{lt2}], VWm[{lt3}]}, 
  {(-I/2)*g1*g2*Cos[ThetaW]*(vd*ZP[gt1, 1] - vu*ZP[gt1, 2]), g[lt2, lt3]}}, 
 {{conj[Hpm[{gt1}]], VWm[{lt2}], VZ[{lt3}]}, 
  {(I/2)*g2*(vd*(g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*
      ZP[gt1, 1] + vu*(-(g1*Cos[ThetaWp]*Sin[ThetaW]) + 
       2*gp*QHu*Sin[ThetaWp])*ZP[gt1, 2]), g[lt2, lt3]}}, 
 {{conj[Hpm[{gt1}]], VWm[{lt2}], VZp[{lt3}]}, 
  {(I/2)*g2*(vd*(2*gp*QHd*Cos[ThetaWp] - g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZP[gt1, 1] + vu*(2*gp*QHu*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZP[gt1, 2]), g[lt2, lt3]}}}
