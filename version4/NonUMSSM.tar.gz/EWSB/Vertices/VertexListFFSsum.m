{{{bar[Cha[{gt1}]], Cha[{gt2}], Ah[{gt3}]}, 
  {-((g2*conj[UM[gt2, 1]]*conj[UP[gt1, 2]]*conj[ZA[gt3, 2]] + 
      conj[UM[gt2, 2]]*(g2*conj[UP[gt1, 1]]*conj[ZA[gt3, 1]] - 
        \[Lambda]*conj[UP[gt1, 2]]*conj[ZA[gt3, 3]]))/Sqrt[2]), PL}, 
  {(g2*conj[ZA[gt3, 1]]*UM[gt1, 2]*UP[gt2, 1] + 
     (g2*conj[ZA[gt3, 2]]*UM[gt1, 1] - conj[\[Lambda]]*conj[ZA[gt3, 3]]*
        UM[gt1, 2])*UP[gt2, 2])/Sqrt[2], PR}}, 
 {{Chi[{gt1}], Chi[{gt2}], Ah[{gt3}]}, 
  {(-(conj[ZA[gt3, 3]]*(2*gp*Qs*conj[ZN[gt1, 6]]*conj[ZN[gt2, 1]] + 
        Sqrt[2]*\[Lambda]*conj[ZN[gt1, 5]]*conj[ZN[gt2, 4]] + 
        Sqrt[2]*\[Lambda]*conj[ZN[gt1, 4]]*conj[ZN[gt2, 5]] + 
        2*gp*Qs*conj[ZN[gt1, 1]]*conj[ZN[gt2, 6]])) - 
     conj[ZA[gt3, 2]]*(conj[ZN[gt1, 5]]*(2*gp*QHu*conj[ZN[gt2, 1]] + 
         g1*conj[ZN[gt2, 2]] - g2*conj[ZN[gt2, 3]]) + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 6]]*conj[ZN[gt2, 4]] + 
       2*gp*QHu*conj[ZN[gt1, 1]]*conj[ZN[gt2, 5]] + g1*conj[ZN[gt1, 2]]*
        conj[ZN[gt2, 5]] - g2*conj[ZN[gt1, 3]]*conj[ZN[gt2, 5]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 4]]*conj[ZN[gt2, 6]]) - 
     conj[ZA[gt3, 1]]*(conj[ZN[gt1, 4]]*(2*gp*QHd*conj[ZN[gt2, 1]] - 
         g1*conj[ZN[gt2, 2]] + g2*conj[ZN[gt2, 3]]) + 
       2*gp*QHd*conj[ZN[gt1, 1]]*conj[ZN[gt2, 4]] - g1*conj[ZN[gt1, 2]]*
        conj[ZN[gt2, 4]] + g2*conj[ZN[gt1, 3]]*conj[ZN[gt2, 4]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 6]]*conj[ZN[gt2, 5]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 5]]*conj[ZN[gt2, 6]]))/2, PL}, 
  {(conj[ZA[gt3, 3]]*(2*gp*Qs*ZN[gt1, 6]*ZN[gt2, 1] + Sqrt[2]*conj[\[Lambda]]*
        (ZN[gt1, 5]*ZN[gt2, 4] + ZN[gt1, 4]*ZN[gt2, 5]) + 
       2*gp*Qs*ZN[gt1, 1]*ZN[gt2, 6]) + conj[ZA[gt3, 1]]*
      (ZN[gt1, 4]*(2*gp*QHd*ZN[gt2, 1] - g1*ZN[gt2, 2] + g2*ZN[gt2, 3]) + 
       2*gp*QHd*ZN[gt1, 1]*ZN[gt2, 4] - g1*ZN[gt1, 2]*ZN[gt2, 4] + 
       g2*ZN[gt1, 3]*ZN[gt2, 4] + Sqrt[2]*conj[\[Lambda]]*ZN[gt1, 6]*
        ZN[gt2, 5] + Sqrt[2]*conj[\[Lambda]]*ZN[gt1, 5]*ZN[gt2, 6]) + 
     conj[ZA[gt3, 2]]*(ZN[gt1, 5]*(2*gp*QHu*ZN[gt2, 1] + g1*ZN[gt2, 2] - 
         g2*ZN[gt2, 3]) + (2*gp*QHu*ZN[gt1, 1] + g1*ZN[gt1, 2] - 
         g2*ZN[gt1, 3])*ZN[gt2, 5] + Sqrt[2]*conj[\[Lambda]]*
        (ZN[gt1, 6]*ZN[gt2, 4] + ZN[gt1, 4]*ZN[gt2, 6])))/2, PR}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], Ah[{gt3}]}, 
  {(conj[ZA[gt3, 1]]*Delta[ct1, ct2]*sumExp[j2, 1, 3, 
      conj[ZDL[gt2, j2]]*sumExp[j1, 1, 3, conj[ZDR[gt1, j1]]*Yd[j1, j2]]])/
    Sqrt[2], PL}, 
  {-((conj[ZA[gt3, 1]]*Delta[ct1, ct2]*sumExp[j2, 1, 3, 
       sumExp[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*ZDL[gt1, j2]])/
     Sqrt[2]), PR}}, {{bar[Fe[{gt1}]], Fe[{gt2}], Ah[{gt3}]}, 
  {(conj[ZA[gt3, 1]]*(Ye11*conj[ZEL[gt2, 1]]*conj[ZER[gt1, 1]] + 
      Ye22*conj[ZEL[gt2, 2]]*conj[ZER[gt1, 2]] + Ye33*conj[ZEL[gt2, 3]]*
       conj[ZER[gt1, 3]]))/Sqrt[2], PL}, 
  {-((conj[ZA[gt3, 1]]*(conj[Ye11]*ZEL[gt1, 1]*ZER[gt2, 1] + 
       conj[Ye22]*ZEL[gt1, 2]*ZER[gt2, 2] + conj[Ye33]*ZEL[gt1, 3]*
        ZER[gt2, 3]))/Sqrt[2]), PR}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], Ah[{gt3}]}, 
  {(conj[ZA[gt3, 2]]*Delta[ct1, ct2]*sumExp[j2, 1, 3, 
      conj[ZUL[gt2, j2]]*sumExp[j1, 1, 3, conj[ZUR[gt1, j1]]*Yu[j1, j2]]])/
    Sqrt[2], PL}, 
  {-((conj[ZA[gt3, 2]]*Delta[ct1, ct2]*sumExp[j2, 1, 3, 
       sumExp[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*ZUL[gt1, j2]])/
     Sqrt[2]), PR}}, {{bar[Fv[{gt1}]], Fv[{gt2}], Ah[{gt3}]}, 
  {(conj[ZA[gt3, 2]]*(Yv11*conj[ZVL[gt2, 1]]*conj[ZVR[gt1, 1]] + 
      Yv22*conj[ZVL[gt2, 2]]*conj[ZVR[gt1, 2]] + Yv33*conj[ZVL[gt2, 3]]*
       conj[ZVR[gt1, 3]]))/Sqrt[2], PL}, 
  {-((conj[ZA[gt3, 2]]*(conj[Yv11]*ZVL[gt1, 1]*ZVR[gt2, 1] + 
       conj[Yv22]*ZVL[gt1, 2]*ZVR[gt2, 2] + conj[Yv33]*ZVL[gt1, 3]*
        ZVR[gt2, 3]))/Sqrt[2]), PR}}, 
 {{Chi[{gt1}], Cha[{gt2}], conj[Hpm[{gt3}]]}, 
  {I*(-(g2*conj[UM[gt2, 1]]*conj[ZN[gt1, 4]]*ZP[gt3, 1]) + 
     conj[UM[gt2, 2]]*(-(Sqrt[2]*gp*QHd*conj[ZN[gt1, 1]]*ZP[gt3, 1]) + 
       (g1*conj[ZN[gt1, 2]]*ZP[gt3, 1])/Sqrt[2] + 
       (g2*conj[ZN[gt1, 3]]*ZP[gt3, 1])/Sqrt[2] - \[Lambda]*conj[ZN[gt1, 6]]*
        ZP[gt3, 2])), PL}, 
  {I*(-(conj[\[Lambda]]*UP[gt2, 2]*ZN[gt1, 6]*ZP[gt3, 1]) - 
     ((Sqrt[2]*UP[gt2, 2]*(2*gp*QHu*ZN[gt1, 1] + g1*ZN[gt1, 2] + 
          g2*ZN[gt1, 3]) + 2*g2*UP[gt2, 1]*ZN[gt1, 5])*ZP[gt3, 2])/2), PR}}, 
 {{Cha[{gt1}], Fu[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {I*Delta[ct2, ct3]*(-(g2*conj[UM[gt1, 1]]*sumExp[j1, 1, 3, 
        conj[ZUL[gt2, j1]]*ZD[gt3, j1]]) + conj[UM[gt1, 2]]*
      sumExp[j2, 1, 3, conj[ZUL[gt2, j2]]*sumExp[j1, 1, 3, 
         Yd[j1, j2]*ZD[gt3, 3 + j1]]]), PL}, 
  {I*Delta[ct2, ct3]*sumExp[j2, 1, 3, 
     sumExp[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*ZD[gt3, j2]]*UP[gt1, 2], 
   PR}}, {{Cha[{gt1}], Fv[{gt2}], conj[Se[{gt3}]]}, 
  {I*(-(g2*conj[UM[gt1, 1]]*(conj[ZVL[gt2, 1]]*ZE[gt3, 1] + 
        conj[ZVL[gt2, 2]]*ZE[gt3, 2] + conj[ZVL[gt2, 3]]*ZE[gt3, 3])) + 
     conj[UM[gt1, 2]]*(Ye11*conj[ZVL[gt2, 1]]*ZE[gt3, 4] + 
       Ye22*conj[ZVL[gt2, 2]]*ZE[gt3, 5] + Ye33*conj[ZVL[gt2, 3]]*
        ZE[gt3, 6])), PL}, {I*UP[gt1, 2]*(conj[Yv11]*ZE[gt3, 1]*ZVR[gt2, 1] + 
     conj[Yv22]*ZE[gt3, 2]*ZVR[gt2, 2] + conj[Yv33]*ZE[gt3, 3]*ZVR[gt2, 3]), 
   PR}}, {{bar[Cha[{gt1}]], Cha[{gt2}], hh[{gt3}]}, 
  {((-I)*(g2*conj[UM[gt2, 1]]*conj[UP[gt1, 2]]*conj[ZH[gt3, 2]] + 
      conj[UM[gt2, 2]]*(g2*conj[UP[gt1, 1]]*conj[ZH[gt3, 1]] + 
        \[Lambda]*conj[UP[gt1, 2]]*conj[ZH[gt3, 3]])))/Sqrt[2], PL}, 
  {((-I)*(g2*conj[ZH[gt3, 1]]*UM[gt1, 2]*UP[gt2, 1] + 
      (g2*conj[ZH[gt3, 2]]*UM[gt1, 1] + conj[\[Lambda]]*conj[ZH[gt3, 3]]*
         UM[gt1, 2])*UP[gt2, 2]))/Sqrt[2], PR}}, 
 {{bar[Fd[{gt1, ct1}]], Cha[{gt2}], Su[{gt3, ct3}]}, 
  {I*conj[UM[gt2, 2]]*Delta[ct1, ct3]*sumExp[j2, 1, 3, 
     conj[ZU[gt3, j2]]*sumExp[j1, 1, 3, conj[ZDR[gt1, j1]]*Yd[j1, j2]]], PL}, 
  {I*Delta[ct1, ct3]*(-(g2*sumExp[j1, 1, 3, conj[ZU[gt3, j1]]*ZDL[gt1, j1]]*
       UP[gt2, 1]) + sumExp[j2, 1, 3, sumExp[j1, 1, 3, conj[Yu[j1, j2]]*
          conj[ZU[gt3, 3 + j1]]]*ZDL[gt1, j2]]*UP[gt2, 2]), PR}}, 
 {{bar[Fe[{gt1}]], Cha[{gt2}], Sv[{gt3}]}, 
  {I*conj[UM[gt2, 2]]*(Ye11*conj[ZER[gt1, 1]]*conj[ZV[gt3, 1]] + 
     Ye22*conj[ZER[gt1, 2]]*conj[ZV[gt3, 2]] + Ye33*conj[ZER[gt1, 3]]*
      conj[ZV[gt3, 3]]), PL}, 
  {I*(-(g2*conj[ZV[gt3, 1]]*UP[gt2, 1]*ZEL[gt1, 1]) + 
     conj[Yv11]*conj[ZV[gt3, 4]]*UP[gt2, 2]*ZEL[gt1, 1] - 
     g2*conj[ZV[gt3, 2]]*UP[gt2, 1]*ZEL[gt1, 2] + conj[Yv22]*conj[ZV[gt3, 5]]*
      UP[gt2, 2]*ZEL[gt1, 2] - g2*conj[ZV[gt3, 3]]*UP[gt2, 1]*ZEL[gt1, 3] + 
     conj[Yv33]*conj[ZV[gt3, 6]]*UP[gt2, 2]*ZEL[gt1, 3]), PR}}, 
 {{Chi[{gt1}], Chi[{gt2}], hh[{gt3}]}, 
  {(I/2)*(conj[ZH[gt3, 3]]*(-2*gp*Qs*conj[ZN[gt1, 6]]*conj[ZN[gt2, 1]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 5]]*conj[ZN[gt2, 4]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 4]]*conj[ZN[gt2, 5]] - 
       2*gp*Qs*conj[ZN[gt1, 1]]*conj[ZN[gt2, 6]]) + 
     conj[ZH[gt3, 2]]*(conj[ZN[gt1, 5]]*(-2*gp*QHu*conj[ZN[gt2, 1]] - 
         g1*conj[ZN[gt2, 2]] + g2*conj[ZN[gt2, 3]]) + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 6]]*conj[ZN[gt2, 4]] - 
       2*gp*QHu*conj[ZN[gt1, 1]]*conj[ZN[gt2, 5]] - g1*conj[ZN[gt1, 2]]*
        conj[ZN[gt2, 5]] + g2*conj[ZN[gt1, 3]]*conj[ZN[gt2, 5]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 4]]*conj[ZN[gt2, 6]]) + 
     conj[ZH[gt3, 1]]*(conj[ZN[gt1, 4]]*(-2*gp*QHd*conj[ZN[gt2, 1]] + 
         g1*conj[ZN[gt2, 2]] - g2*conj[ZN[gt2, 3]]) - 
       2*gp*QHd*conj[ZN[gt1, 1]]*conj[ZN[gt2, 4]] + g1*conj[ZN[gt1, 2]]*
        conj[ZN[gt2, 4]] - g2*conj[ZN[gt1, 3]]*conj[ZN[gt2, 4]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 6]]*conj[ZN[gt2, 5]] + 
       Sqrt[2]*\[Lambda]*conj[ZN[gt1, 5]]*conj[ZN[gt2, 6]])), PL}, 
  {(I/2)*(conj[ZH[gt3, 3]]*(-2*gp*Qs*ZN[gt1, 6]*ZN[gt2, 1] + 
       Sqrt[2]*conj[\[Lambda]]*(ZN[gt1, 5]*ZN[gt2, 4] + 
         ZN[gt1, 4]*ZN[gt2, 5]) - 2*gp*Qs*ZN[gt1, 1]*ZN[gt2, 6]) + 
     conj[ZH[gt3, 1]]*(ZN[gt1, 4]*(-2*gp*QHd*ZN[gt2, 1] + g1*ZN[gt2, 2] - 
         g2*ZN[gt2, 3]) - 2*gp*QHd*ZN[gt1, 1]*ZN[gt2, 4] + 
       g1*ZN[gt1, 2]*ZN[gt2, 4] - g2*ZN[gt1, 3]*ZN[gt2, 4] + 
       Sqrt[2]*conj[\[Lambda]]*ZN[gt1, 6]*ZN[gt2, 5] + 
       Sqrt[2]*conj[\[Lambda]]*ZN[gt1, 5]*ZN[gt2, 6]) + 
     conj[ZH[gt3, 2]]*(ZN[gt1, 5]*(-2*gp*QHu*ZN[gt2, 1] - g1*ZN[gt2, 2] + 
         g2*ZN[gt2, 3]) + (-2*gp*QHu*ZN[gt1, 1] - g1*ZN[gt1, 2] + 
         g2*ZN[gt1, 3])*ZN[gt2, 5] + Sqrt[2]*conj[\[Lambda]]*
        (ZN[gt1, 6]*ZN[gt2, 4] + ZN[gt1, 4]*ZN[gt2, 6]))), PR}}, 
 {{Chi[{gt1}], Fd[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {(-I/6)*Delta[ct2, ct3]*(6*Sqrt[2]*gp*Qq*conj[ZN[gt1, 1]]*
      sumExp[j1, 1, 3, conj[ZDL[gt2, j1]]*ZD[gt3, j1]] + 
     Sqrt[2]*g1*conj[ZN[gt1, 2]]*sumExp[j1, 1, 3, conj[ZDL[gt2, j1]]*
        ZD[gt3, j1]] - 3*Sqrt[2]*g2*conj[ZN[gt1, 3]]*
      sumExp[j1, 1, 3, conj[ZDL[gt2, j1]]*ZD[gt3, j1]] + 
     6*conj[ZN[gt1, 4]]*sumExp[j2, 1, 3, conj[ZDL[gt2, j2]]*
        sumExp[j1, 1, 3, Yd[j1, j2]*ZD[gt3, 3 + j1]]]), PL}, 
  {(-I/3)*Delta[ct2, ct3]*
    (Sqrt[2]*sumExp[j1, 1, 3, ZD[gt3, 3 + j1]*ZDR[gt2, j1]]*
      (3*gp*Qd*ZN[gt1, 1] + g1*ZN[gt1, 2]) + 
     3*sumExp[j2, 1, 3, sumExp[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*
        ZD[gt3, j2]]*ZN[gt1, 4]), PR}}, 
 {{Chi[{gt1}], Fe[{gt2}], conj[Se[{gt3}]]}, 
  {(I/2)*(conj[ZEL[gt2, 1]]*(-2*Sqrt[2]*gp*Ql1*conj[ZN[gt1, 1]]*ZE[gt3, 1] + 
       Sqrt[2]*g1*conj[ZN[gt1, 2]]*ZE[gt3, 1] + Sqrt[2]*g2*conj[ZN[gt1, 3]]*
        ZE[gt3, 1] - 2*Ye11*conj[ZN[gt1, 4]]*ZE[gt3, 4]) + 
     conj[ZEL[gt2, 2]]*(-2*Sqrt[2]*gp*Ql2*conj[ZN[gt1, 1]]*ZE[gt3, 2] + 
       Sqrt[2]*g1*conj[ZN[gt1, 2]]*ZE[gt3, 2] + Sqrt[2]*g2*conj[ZN[gt1, 3]]*
        ZE[gt3, 2] - 2*Ye22*conj[ZN[gt1, 4]]*ZE[gt3, 5]) + 
     conj[ZEL[gt2, 3]]*(-2*Sqrt[2]*gp*Ql3*conj[ZN[gt1, 1]]*ZE[gt3, 3] + 
       Sqrt[2]*g1*conj[ZN[gt1, 2]]*ZE[gt3, 3] + Sqrt[2]*g2*conj[ZN[gt1, 3]]*
        ZE[gt3, 3] - 2*Ye33*conj[ZN[gt1, 4]]*ZE[gt3, 6])), PL}, 
  {I*(-(Sqrt[2]*gp*Qe3*ZE[gt3, 6]*ZER[gt2, 3]*ZN[gt1, 1]) - 
     Sqrt[2]*g1*ZE[gt3, 6]*ZER[gt2, 3]*ZN[gt1, 2] - 
     Sqrt[2]*ZE[gt3, 4]*ZER[gt2, 1]*(gp*Qe1*ZN[gt1, 1] + g1*ZN[gt1, 2]) - 
     Sqrt[2]*ZE[gt3, 5]*ZER[gt2, 2]*(gp*Qe2*ZN[gt1, 1] + g1*ZN[gt1, 2]) - 
     conj[Ye11]*ZE[gt3, 1]*ZER[gt2, 1]*ZN[gt1, 4] - 
     conj[Ye22]*ZE[gt3, 2]*ZER[gt2, 2]*ZN[gt1, 4] - 
     conj[Ye33]*ZE[gt3, 3]*ZER[gt2, 3]*ZN[gt1, 4]), PR}}, 
 {{Chi[{gt1}], Fu[{gt2, ct2}], conj[Su[{gt3, ct3}]]}, 
  {(-I/6)*Delta[ct2, ct3]*(6*Sqrt[2]*gp*Qq*conj[ZN[gt1, 1]]*
      sumExp[j1, 1, 3, conj[ZUL[gt2, j1]]*ZU[gt3, j1]] + 
     Sqrt[2]*g1*conj[ZN[gt1, 2]]*sumExp[j1, 1, 3, conj[ZUL[gt2, j1]]*
        ZU[gt3, j1]] + 3*Sqrt[2]*g2*conj[ZN[gt1, 3]]*
      sumExp[j1, 1, 3, conj[ZUL[gt2, j1]]*ZU[gt3, j1]] + 
     6*conj[ZN[gt1, 5]]*sumExp[j2, 1, 3, conj[ZUL[gt2, j2]]*
        sumExp[j1, 1, 3, Yu[j1, j2]*ZU[gt3, 3 + j1]]]), PL}, 
  {(-I/3)*Delta[ct2, ct3]*
    (Sqrt[2]*sumExp[j1, 1, 3, ZU[gt3, 3 + j1]*ZUR[gt2, j1]]*
      (3*gp*Qu*ZN[gt1, 1] - 2*g1*ZN[gt1, 2]) + 
     3*sumExp[j2, 1, 3, sumExp[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*
        ZU[gt3, j2]]*ZN[gt1, 5]), PR}}, 
 {{Chi[{gt1}], Fv[{gt2}], conj[Sv[{gt3}]]}, 
  {(I/2)*(-(Sqrt[2]*g2*conj[ZN[gt1, 3]]*conj[ZVL[gt2, 1]]*ZV[gt3, 1]) - 
     Sqrt[2]*g2*conj[ZN[gt1, 3]]*conj[ZVL[gt2, 2]]*ZV[gt3, 2] - 
     Sqrt[2]*g2*conj[ZN[gt1, 3]]*conj[ZVL[gt2, 3]]*ZV[gt3, 3] + 
     Sqrt[2]*g1*conj[ZN[gt1, 2]]*(conj[ZVL[gt2, 1]]*ZV[gt3, 1] + 
       conj[ZVL[gt2, 2]]*ZV[gt3, 2] + conj[ZVL[gt2, 3]]*ZV[gt3, 3]) - 
     2*Sqrt[2]*gp*conj[ZN[gt1, 1]]*(Ql1*conj[ZVL[gt2, 1]]*ZV[gt3, 1] + 
       Ql2*conj[ZVL[gt2, 2]]*ZV[gt3, 2] + Ql3*conj[ZVL[gt2, 3]]*ZV[gt3, 3]) - 
     2*Yv11*conj[ZN[gt1, 5]]*conj[ZVL[gt2, 1]]*ZV[gt3, 4] - 
     2*Yv22*conj[ZN[gt1, 5]]*conj[ZVL[gt2, 2]]*ZV[gt3, 5] - 
     2*Yv33*conj[ZN[gt1, 5]]*conj[ZVL[gt2, 3]]*ZV[gt3, 6]), PL}, 
  {I*(-(conj[Yv11]*ZN[gt1, 5]*ZV[gt3, 1]*ZVR[gt2, 1]) - 
     ZN[gt1, 5]*(conj[Yv22]*ZV[gt3, 2]*ZVR[gt2, 2] + conj[Yv33]*ZV[gt3, 3]*
        ZVR[gt2, 3]) - Sqrt[2]*gp*ZN[gt1, 1]*(Qv1*ZV[gt3, 4]*ZVR[gt2, 1] + 
       Qv2*ZV[gt3, 5]*ZVR[gt2, 2] + Qv3*ZV[gt3, 6]*ZVR[gt2, 3])), PR}}, 
 {{bar[Cha[{gt1}]], Chi[{gt2}], Hpm[{gt3}]}, 
  {I*(-(g2*conj[UP[gt1, 1]]*conj[ZN[gt2, 5]]*ZP[gt3, 2]) - 
     (conj[UP[gt1, 2]]*(2*\[Lambda]*conj[ZN[gt2, 6]]*ZP[gt3, 1] + 
        Sqrt[2]*(2*gp*QHu*conj[ZN[gt2, 1]] + g1*conj[ZN[gt2, 2]] + 
          g2*conj[ZN[gt2, 3]])*ZP[gt3, 2]))/2), PL}, 
  {I*(-(g2*UM[gt1, 1]*ZN[gt2, 4]*ZP[gt3, 1]) + 
     UM[gt1, 2]*(-(Sqrt[2]*gp*QHd*ZN[gt2, 1]*ZP[gt3, 1]) + 
       (g1*ZN[gt2, 2]*ZP[gt3, 1])/Sqrt[2] + (g2*ZN[gt2, 3]*ZP[gt3, 1])/
        Sqrt[2] - conj[\[Lambda]]*ZN[gt2, 6]*ZP[gt3, 2])), PR}}, 
 {{bar[Fd[{gt1, ct1}]], Chi[{gt2}], Sd[{gt3, ct3}]}, 
  {(-I/3)*Delta[ct1, ct3]*(3*Sqrt[2]*gp*Qd*conj[ZN[gt2, 1]]*
      sumExp[j1, 1, 3, conj[ZD[gt3, 3 + j1]]*conj[ZDR[gt1, j1]]] + 
     Sqrt[2]*g1*conj[ZN[gt2, 2]]*sumExp[j1, 1, 3, conj[ZD[gt3, 3 + j1]]*
        conj[ZDR[gt1, j1]]] + 3*conj[ZN[gt2, 4]]*sumExp[j2, 1, 3, 
       conj[ZD[gt3, j2]]*sumExp[j1, 1, 3, conj[ZDR[gt1, j1]]*Yd[j1, j2]]]), 
   PL}, {(-I/6)*Delta[ct1, ct3]*
    (Sqrt[2]*sumExp[j1, 1, 3, conj[ZD[gt3, j1]]*ZDL[gt1, j1]]*
      (6*gp*Qq*ZN[gt2, 1] + g1*ZN[gt2, 2] - 3*g2*ZN[gt2, 3]) + 
     6*sumExp[j2, 1, 3, sumExp[j1, 1, 3, conj[Yd[j1, j2]]*
          conj[ZD[gt3, 3 + j1]]]*ZDL[gt1, j2]]*ZN[gt2, 4]), PR}}, 
 {{bar[Fe[{gt1}]], Chi[{gt2}], Se[{gt3}]}, 
  {I*(-(Sqrt[2]*gp*Qe3*conj[ZE[gt3, 6]]*conj[ZER[gt1, 3]]*conj[ZN[gt2, 1]]) - 
     Sqrt[2]*g1*conj[ZE[gt3, 6]]*conj[ZER[gt1, 3]]*conj[ZN[gt2, 2]] - 
     Sqrt[2]*conj[ZE[gt3, 4]]*conj[ZER[gt1, 1]]*(gp*Qe1*conj[ZN[gt2, 1]] + 
       g1*conj[ZN[gt2, 2]]) - Sqrt[2]*conj[ZE[gt3, 5]]*conj[ZER[gt1, 2]]*
      (gp*Qe2*conj[ZN[gt2, 1]] + g1*conj[ZN[gt2, 2]]) - 
     Ye11*conj[ZE[gt3, 1]]*conj[ZER[gt1, 1]]*conj[ZN[gt2, 4]] - 
     Ye22*conj[ZE[gt3, 2]]*conj[ZER[gt1, 2]]*conj[ZN[gt2, 4]] - 
     Ye33*conj[ZE[gt3, 3]]*conj[ZER[gt1, 3]]*conj[ZN[gt2, 4]]), PL}, 
  {(I/2)*(-2*Sqrt[2]*gp*Ql3*conj[ZE[gt3, 3]]*ZEL[gt1, 3]*ZN[gt2, 1] + 
     Sqrt[2]*g1*conj[ZE[gt3, 3]]*ZEL[gt1, 3]*ZN[gt2, 2] + 
     Sqrt[2]*g2*conj[ZE[gt3, 3]]*ZEL[gt1, 3]*ZN[gt2, 3] + 
     Sqrt[2]*conj[ZE[gt3, 1]]*ZEL[gt1, 1]*(-2*gp*Ql1*ZN[gt2, 1] + 
       g1*ZN[gt2, 2] + g2*ZN[gt2, 3]) + Sqrt[2]*conj[ZE[gt3, 2]]*ZEL[gt1, 2]*
      (-2*gp*Ql2*ZN[gt2, 1] + g1*ZN[gt2, 2] + g2*ZN[gt2, 3]) - 
     2*conj[Ye11]*conj[ZE[gt3, 4]]*ZEL[gt1, 1]*ZN[gt2, 4] - 
     2*conj[Ye22]*conj[ZE[gt3, 5]]*ZEL[gt1, 2]*ZN[gt2, 4] - 
     2*conj[Ye33]*conj[ZE[gt3, 6]]*ZEL[gt1, 3]*ZN[gt2, 4]), PR}}, 
 {{bar[Fu[{gt1, ct1}]], Chi[{gt2}], Su[{gt3, ct3}]}, 
  {(-I/3)*Delta[ct1, ct3]*(3*Sqrt[2]*gp*Qu*conj[ZN[gt2, 1]]*
      sumExp[j1, 1, 3, conj[ZU[gt3, 3 + j1]]*conj[ZUR[gt1, j1]]] - 
     2*Sqrt[2]*g1*conj[ZN[gt2, 2]]*sumExp[j1, 1, 3, conj[ZU[gt3, 3 + j1]]*
        conj[ZUR[gt1, j1]]] + 3*conj[ZN[gt2, 5]]*sumExp[j2, 1, 3, 
       conj[ZU[gt3, j2]]*sumExp[j1, 1, 3, conj[ZUR[gt1, j1]]*Yu[j1, j2]]]), 
   PL}, {(-I/6)*Delta[ct1, ct3]*
    (Sqrt[2]*sumExp[j1, 1, 3, conj[ZU[gt3, j1]]*ZUL[gt1, j1]]*
      (6*gp*Qq*ZN[gt2, 1] + g1*ZN[gt2, 2] + 3*g2*ZN[gt2, 3]) + 
     6*sumExp[j2, 1, 3, sumExp[j1, 1, 3, conj[Yu[j1, j2]]*
          conj[ZU[gt3, 3 + j1]]]*ZUL[gt1, j2]]*ZN[gt2, 5]), PR}}, 
 {{bar[Fv[{gt1}]], Chi[{gt2}], Sv[{gt3}]}, 
  {I*(-(conj[ZN[gt2, 5]]*(Yv11*conj[ZV[gt3, 1]]*conj[ZVR[gt1, 1]] + 
        Yv22*conj[ZV[gt3, 2]]*conj[ZVR[gt1, 2]] + Yv33*conj[ZV[gt3, 3]]*
         conj[ZVR[gt1, 3]])) - Sqrt[2]*gp*conj[ZN[gt2, 1]]*
      (Qv1*conj[ZV[gt3, 4]]*conj[ZVR[gt1, 1]] + Qv2*conj[ZV[gt3, 5]]*
        conj[ZVR[gt1, 2]] + Qv3*conj[ZV[gt3, 6]]*conj[ZVR[gt1, 3]])), PL}, 
  {(I/2)*(Sqrt[2]*conj[ZV[gt3, 1]]*(-2*gp*Ql1*ZN[gt2, 1] + g1*ZN[gt2, 2] - 
       g2*ZN[gt2, 3])*ZVL[gt1, 1] - 2*conj[Yv11]*conj[ZV[gt3, 4]]*ZN[gt2, 5]*
      ZVL[gt1, 1] - 2*Sqrt[2]*gp*Ql2*conj[ZV[gt3, 2]]*ZN[gt2, 1]*
      ZVL[gt1, 2] + Sqrt[2]*g1*conj[ZV[gt3, 2]]*ZN[gt2, 2]*ZVL[gt1, 2] - 
     Sqrt[2]*g2*conj[ZV[gt3, 2]]*ZN[gt2, 3]*ZVL[gt1, 2] - 
     2*conj[Yv22]*conj[ZV[gt3, 5]]*ZN[gt2, 5]*ZVL[gt1, 2] - 
     2*Sqrt[2]*gp*Ql3*conj[ZV[gt3, 3]]*ZN[gt2, 1]*ZVL[gt1, 3] + 
     Sqrt[2]*g1*conj[ZV[gt3, 3]]*ZN[gt2, 2]*ZVL[gt1, 3] - 
     Sqrt[2]*g2*conj[ZV[gt3, 3]]*ZN[gt2, 3]*ZVL[gt1, 3] - 
     2*conj[Yv33]*conj[ZV[gt3, 6]]*ZN[gt2, 5]*ZVL[gt1, 3]), PR}}, 
 {{Glu[{ct1}], Fd[{gt2, ct2}], conj[Sd[{gt3, ct3}]]}, 
  {((-I)*g3*PhaseGlu*Lam[ct1, ct3, ct2]*sumExp[j1, 1, 3, 
      conj[ZDL[gt2, j1]]*ZD[gt3, j1]])/Sqrt[2], PL}, 
  {(I*g3*conj[PhaseGlu]*Lam[ct1, ct3, ct2]*sumExp[j1, 1, 3, 
      ZD[gt3, 3 + j1]*ZDR[gt2, j1]])/Sqrt[2], PR}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], hh[{gt3}]}, 
  {((-I)*conj[ZH[gt3, 1]]*Delta[ct1, ct2]*sumExp[j2, 1, 3, 
      conj[ZDL[gt2, j2]]*sumExp[j1, 1, 3, conj[ZDR[gt1, j1]]*Yd[j1, j2]]])/
    Sqrt[2], PL}, {((-I)*conj[ZH[gt3, 1]]*Delta[ct1, ct2]*
     sumExp[j2, 1, 3, sumExp[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*
       ZDL[gt1, j2]])/Sqrt[2], PR}}, 
 {{bar[Cha[{gt1}]], Fd[{gt2, ct2}], conj[Su[{gt3, ct3}]]}, 
  {I*Delta[ct2, ct3]*(-(g2*conj[UP[gt1, 1]]*sumExp[j1, 1, 3, 
        conj[ZDL[gt2, j1]]*ZU[gt3, j1]]) + conj[UP[gt1, 2]]*
      sumExp[j2, 1, 3, conj[ZDL[gt2, j2]]*sumExp[j1, 1, 3, 
         Yu[j1, j2]*ZU[gt3, 3 + j1]]]), PL}, 
  {I*Delta[ct2, ct3]*sumExp[j2, 1, 3, 
     sumExp[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*ZU[gt3, j2]]*UM[gt1, 2], 
   PR}}, {{bar[Fu[{gt1, ct1}]], Fd[{gt2, ct2}], conj[Hpm[{gt3}]]}, 
  {I*Delta[ct1, ct2]*sumExp[j2, 1, 3, conj[ZDL[gt2, j2]]*
      sumExp[j1, 1, 3, conj[ZUR[gt1, j1]]*Yu[j1, j2]]]*ZP[gt3, 2], PL}, 
  {I*Delta[ct1, ct2]*sumExp[j2, 1, 3, 
     sumExp[j1, 1, 3, conj[Yd[j1, j2]]*ZDR[gt2, j1]]*ZUL[gt1, j2]]*
    ZP[gt3, 1], PR}}, {{bar[Fe[{gt1}]], Fe[{gt2}], hh[{gt3}]}, 
  {((-I)*(Ye11*conj[ZEL[gt2, 1]]*conj[ZER[gt1, 1]] + 
      Ye22*conj[ZEL[gt2, 2]]*conj[ZER[gt1, 2]] + Ye33*conj[ZEL[gt2, 3]]*
       conj[ZER[gt1, 3]])*conj[ZH[gt3, 1]])/Sqrt[2], PL}, 
  {((-I)*conj[ZH[gt3, 1]]*(conj[Ye11]*ZEL[gt1, 1]*ZER[gt2, 1] + 
      conj[Ye22]*ZEL[gt1, 2]*ZER[gt2, 2] + conj[Ye33]*ZEL[gt1, 3]*
       ZER[gt2, 3]))/Sqrt[2], PR}}, 
 {{bar[Cha[{gt1}]], Fe[{gt2}], conj[Sv[{gt3}]]}, 
  {I*(-(g2*conj[UP[gt1, 1]]*(conj[ZEL[gt2, 1]]*ZV[gt3, 1] + 
        conj[ZEL[gt2, 2]]*ZV[gt3, 2] + conj[ZEL[gt2, 3]]*ZV[gt3, 3])) + 
     conj[UP[gt1, 2]]*(Yv11*conj[ZEL[gt2, 1]]*ZV[gt3, 4] + 
       Yv22*conj[ZEL[gt2, 2]]*ZV[gt3, 5] + Yv33*conj[ZEL[gt2, 3]]*
        ZV[gt3, 6])), PL}, {I*UM[gt1, 2]*(conj[Ye11]*ZER[gt2, 1]*ZV[gt3, 1] + 
     conj[Ye22]*ZER[gt2, 2]*ZV[gt3, 2] + conj[Ye33]*ZER[gt2, 3]*ZV[gt3, 3]), 
   PR}}, {{bar[Fv[{gt1}]], Fe[{gt2}], conj[Hpm[{gt3}]]}, 
  {I*(Yv11*conj[ZEL[gt2, 1]]*conj[ZVR[gt1, 1]] + Yv22*conj[ZEL[gt2, 2]]*
      conj[ZVR[gt1, 2]] + Yv33*conj[ZEL[gt2, 3]]*conj[ZVR[gt1, 3]])*
    ZP[gt3, 2], PL}, {I*ZP[gt3, 1]*(conj[Ye11]*ZER[gt2, 1]*ZVL[gt1, 1] + 
     conj[Ye22]*ZER[gt2, 2]*ZVL[gt1, 2] + conj[Ye33]*ZER[gt2, 3]*
      ZVL[gt1, 3]), PR}}, {{Glu[{ct1}], Fu[{gt2, ct2}], 
   conj[Su[{gt3, ct3}]]}, {((-I)*g3*PhaseGlu*Lam[ct1, ct3, ct2]*
     sumExp[j1, 1, 3, conj[ZUL[gt2, j1]]*ZU[gt3, j1]])/Sqrt[2], PL}, 
  {(I*g3*conj[PhaseGlu]*Lam[ct1, ct3, ct2]*sumExp[j1, 1, 3, 
      ZU[gt3, 3 + j1]*ZUR[gt2, j1]])/Sqrt[2], PR}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], hh[{gt3}]}, 
  {((-I)*conj[ZH[gt3, 2]]*Delta[ct1, ct2]*sumExp[j2, 1, 3, 
      conj[ZUL[gt2, j2]]*sumExp[j1, 1, 3, conj[ZUR[gt1, j1]]*Yu[j1, j2]]])/
    Sqrt[2], PL}, {((-I)*conj[ZH[gt3, 2]]*Delta[ct1, ct2]*
     sumExp[j2, 1, 3, sumExp[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*
       ZUL[gt1, j2]])/Sqrt[2], PR}}, 
 {{bar[Fd[{gt1, ct1}]], Fu[{gt2, ct2}], Hpm[{gt3}]}, 
  {I*Delta[ct1, ct2]*sumExp[j2, 1, 3, conj[ZUL[gt2, j2]]*
      sumExp[j1, 1, 3, conj[ZDR[gt1, j1]]*Yd[j1, j2]]]*ZP[gt3, 1], PL}, 
  {I*Delta[ct1, ct2]*sumExp[j2, 1, 3, 
     sumExp[j1, 1, 3, conj[Yu[j1, j2]]*ZUR[gt2, j1]]*ZDL[gt1, j2]]*
    ZP[gt3, 2], PR}}, {{bar[Fv[{gt1}]], Fv[{gt2}], hh[{gt3}]}, 
  {((-I)*conj[ZH[gt3, 2]]*(Yv11*conj[ZVL[gt2, 1]]*conj[ZVR[gt1, 1]] + 
      Yv22*conj[ZVL[gt2, 2]]*conj[ZVR[gt1, 2]] + Yv33*conj[ZVL[gt2, 3]]*
       conj[ZVR[gt1, 3]]))/Sqrt[2], PL}, 
  {((-I)*conj[ZH[gt3, 2]]*(conj[Yv11]*ZVL[gt1, 1]*ZVR[gt2, 1] + 
      conj[Yv22]*ZVL[gt1, 2]*ZVR[gt2, 2] + conj[Yv33]*ZVL[gt1, 3]*
       ZVR[gt2, 3]))/Sqrt[2], PR}}, {{bar[Fe[{gt1}]], Fv[{gt2}], Hpm[{gt3}]}, 
  {I*(Ye11*conj[ZER[gt1, 1]]*conj[ZVL[gt2, 1]] + Ye22*conj[ZER[gt1, 2]]*
      conj[ZVL[gt2, 2]] + Ye33*conj[ZER[gt1, 3]]*conj[ZVL[gt2, 3]])*
    ZP[gt3, 1], PL}, {I*ZP[gt3, 2]*(conj[Yv11]*ZEL[gt1, 1]*ZVR[gt2, 1] + 
     conj[Yv22]*ZEL[gt1, 2]*ZVR[gt2, 2] + conj[Yv33]*ZEL[gt1, 3]*
      ZVR[gt2, 3]), PR}}, {{bar[Fd[{gt1, ct1}]], Glu[{ct2}], Sd[{gt3, ct3}]}, 
  {(I*g3*PhaseGlu*Lam[ct2, ct1, ct3]*sumExp[j1, 1, 3, 
      conj[ZD[gt3, 3 + j1]]*conj[ZDR[gt1, j1]]])/Sqrt[2], PL}, 
  {((-I)*g3*conj[PhaseGlu]*Lam[ct2, ct1, ct3]*sumExp[j1, 1, 3, 
      conj[ZD[gt3, j1]]*ZDL[gt1, j1]])/Sqrt[2], PR}}, 
 {{bar[Fu[{gt1, ct1}]], Glu[{ct2}], Su[{gt3, ct3}]}, 
  {(I*g3*PhaseGlu*Lam[ct2, ct1, ct3]*sumExp[j1, 1, 3, 
      conj[ZU[gt3, 3 + j1]]*conj[ZUR[gt1, j1]]])/Sqrt[2], PL}, 
  {((-I)*g3*conj[PhaseGlu]*Lam[ct2, ct1, ct3]*sumExp[j1, 1, 3, 
      conj[ZU[gt3, j1]]*ZUL[gt1, j1]])/Sqrt[2], PR}}, 
 {{bar[Cha[{gt1}]], bar[Fu[{gt2, ct2}]], Sd[{gt3, ct3}]}, 
  {I*conj[UP[gt1, 2]]*Delta[ct2, ct3]*sumExp[j2, 1, 3, 
     conj[ZD[gt3, j2]]*sumExp[j1, 1, 3, conj[ZUR[gt2, j1]]*Yu[j1, j2]]], PL}, 
  {I*Delta[ct2, ct3]*(-(g2*sumExp[j1, 1, 3, conj[ZD[gt3, j1]]*ZUL[gt2, j1]]*
       UM[gt1, 1]) + sumExp[j2, 1, 3, sumExp[j1, 1, 3, conj[Yd[j1, j2]]*
          conj[ZD[gt3, 3 + j1]]]*ZUL[gt2, j2]]*UM[gt1, 2]), PR}}, 
 {{bar[Cha[{gt1}]], bar[Fv[{gt2}]], Se[{gt3}]}, 
  {I*conj[UP[gt1, 2]]*(Yv11*conj[ZE[gt3, 1]]*conj[ZVR[gt2, 1]] + 
     Yv22*conj[ZE[gt3, 2]]*conj[ZVR[gt2, 2]] + Yv33*conj[ZE[gt3, 3]]*
      conj[ZVR[gt2, 3]]), PL}, 
  {I*(-(g2*conj[ZE[gt3, 1]]*UM[gt1, 1]*ZVL[gt2, 1]) + 
     conj[Ye11]*conj[ZE[gt3, 4]]*UM[gt1, 2]*ZVL[gt2, 1] - 
     g2*conj[ZE[gt3, 2]]*UM[gt1, 1]*ZVL[gt2, 2] + conj[Ye22]*conj[ZE[gt3, 5]]*
      UM[gt1, 2]*ZVL[gt2, 2] - g2*conj[ZE[gt3, 3]]*UM[gt1, 1]*ZVL[gt2, 3] + 
     conj[Ye33]*conj[ZE[gt3, 6]]*UM[gt1, 2]*ZVL[gt2, 3]), PR}}}
