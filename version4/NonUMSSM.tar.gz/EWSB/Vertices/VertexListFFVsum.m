{{{Chi[{gt1}], Cha[{gt2}], conj[VWm[{lt3}]]}, 
  {(-I/2)*g2*(2*conj[UM[gt2, 1]]*ZN[gt1, 3] + Sqrt[2]*conj[UM[gt2, 2]]*
      ZN[gt1, 4]), LorentzProduct[gamma[lt3], PL]}, 
  {(-I/2)*g2*(2*conj[ZN[gt1, 3]]*UP[gt2, 1] - Sqrt[2]*conj[ZN[gt1, 5]]*
      UP[gt2, 2]), LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Cha[{gt1}]], Cha[{gt2}], VP[{lt3}]}, 
  {(I/2)*(2*g2*conj[UM[gt2, 1]]*Sin[ThetaW]*UM[gt1, 1] + 
     conj[UM[gt2, 2]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*UM[gt1, 2]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(I/2)*(2*g2*conj[UP[gt1, 1]]*Sin[ThetaW]*UP[gt2, 1] + 
     conj[UP[gt1, 2]]*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*UP[gt2, 2]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Cha[{gt1}]], Cha[{gt2}], VZ[{lt3}]}, 
  {(I/2)*(2*g2*conj[UM[gt2, 1]]*Cos[ThetaW]*Cos[ThetaWp]*UM[gt1, 1] + 
     conj[UM[gt2, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHd*Sin[ThetaWp])*UM[gt1, 2]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(I/2)*(2*g2*conj[UP[gt1, 1]]*Cos[ThetaW]*Cos[ThetaWp]*UP[gt2, 1] + 
     conj[UP[gt1, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHu*Sin[ThetaWp])*UP[gt2, 2]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Cha[{gt1}]], Cha[{gt2}], VZp[{lt3}]}, 
  {(-I/2)*(2*g2*conj[UM[gt2, 1]]*Cos[ThetaW]*Sin[ThetaWp]*UM[gt1, 1] + 
     conj[UM[gt2, 2]]*(2*gp*QHd*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*UM[gt1, 2]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(-I/2)*(2*g2*conj[UP[gt1, 1]]*Cos[ThetaW]*Sin[ThetaWp]*UP[gt2, 1] + 
     conj[UP[gt1, 2]]*(-2*gp*QHu*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*UP[gt2, 2]), 
   LorentzProduct[gamma[lt3], PR]}}, {{Chi[{gt1}], Chi[{gt2}], VZ[{lt3}]}, 
  {(-I/2)*(conj[ZN[gt2, 4]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*ZN[gt1, 4] - 
     conj[ZN[gt2, 5]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])*ZN[gt1, 5] + 
     2*gp*Qs*conj[ZN[gt2, 6]]*Sin[ThetaWp]*ZN[gt1, 6]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(I/2)*(conj[ZN[gt1, 4]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*QHd*Sin[ThetaWp])*ZN[gt2, 4] - 
     conj[ZN[gt1, 5]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*QHu*Sin[ThetaWp])*ZN[gt2, 5] + 
     2*gp*Qs*conj[ZN[gt1, 6]]*Sin[ThetaWp]*ZN[gt2, 6]), 
   LorentzProduct[gamma[lt3], PR]}}, {{Chi[{gt1}], Chi[{gt2}], VZp[{lt3}]}, 
  {(-I/2)*(conj[ZN[gt2, 4]]*(2*gp*QHd*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZN[gt1, 4] + 
     conj[ZN[gt2, 5]]*(2*gp*QHu*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] + 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZN[gt1, 5] + 2*gp*Qs*conj[ZN[gt2, 6]]*
      Cos[ThetaWp]*ZN[gt1, 6]), LorentzProduct[gamma[lt3], PL]}, 
  {(I/2)*(conj[ZN[gt1, 4]]*(2*gp*QHd*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZN[gt2, 4] + 
     conj[ZN[gt1, 5]]*(2*gp*QHu*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] + 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZN[gt2, 5] + 2*gp*Qs*conj[ZN[gt1, 6]]*
      Cos[ThetaWp]*ZN[gt2, 6]), LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Cha[{gt1}]], Chi[{gt2}], VWm[{lt3}]}, 
  {(-I/2)*g2*(2*conj[ZN[gt2, 3]]*UM[gt1, 1] + Sqrt[2]*conj[ZN[gt2, 4]]*
      UM[gt1, 2]), LorentzProduct[gamma[lt3], PL]}, 
  {(-I/2)*g2*(2*conj[UP[gt1, 1]]*ZN[gt2, 3] - Sqrt[2]*conj[UP[gt1, 2]]*
      ZN[gt2, 5]), LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], VG[{ct3, lt3}]}, 
  {(-I/2)*g3*Lam[ct3, ct1, ct2]*sumExp[j1, 1, 3, conj[ZDL[gt2, j1]]*
      ZDL[gt1, j1]], LorentzProduct[gamma[lt3], PL]}, 
  {(-I/2)*g3*Lam[ct3, ct1, ct2]*sumExp[j1, 1, 3, conj[ZDR[gt1, j1]]*
      ZDR[gt2, j1]], LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], VP[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*(g1*Cos[ThetaW] - 3*g2*Sin[ThetaW])*
    sumExp[j1, 1, 3, conj[ZDL[gt2, j1]]*ZDL[gt1, j1]], 
   LorentzProduct[gamma[lt3], PL]}, {(I/3)*g1*Cos[ThetaW]*Delta[ct1, ct2]*
    sumExp[j1, 1, 3, conj[ZDR[gt1, j1]]*ZDR[gt2, j1]], 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], VZ[{lt3}]}, 
  {(I/6)*Delta[ct1, ct2]*(3*g2*Cos[ThetaW]*Cos[ThetaWp] + 
     g1*Cos[ThetaWp]*Sin[ThetaW] - 6*gp*Qq*Sin[ThetaWp])*
    sumExp[j1, 1, 3, conj[ZDL[gt2, j1]]*ZDL[gt1, j1]], 
   LorentzProduct[gamma[lt3], PL]}, 
  {(-I/3)*Delta[ct1, ct2]*(g1*Cos[ThetaWp]*Sin[ThetaW] - 
     3*gp*Qd*Sin[ThetaWp])*sumExp[j1, 1, 3, conj[ZDR[gt1, j1]]*ZDR[gt2, j1]], 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fd[{gt2, ct2}], VZp[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*(6*gp*Qq*Cos[ThetaWp] + 
     (3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*
    sumExp[j1, 1, 3, conj[ZDL[gt2, j1]]*ZDL[gt1, j1]], 
   LorentzProduct[gamma[lt3], PL]}, 
  {(I/3)*Delta[ct1, ct2]*(3*gp*Qd*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
    sumExp[j1, 1, 3, conj[ZDR[gt1, j1]]*ZDR[gt2, j1]], 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fu[{gt1, ct1}]], Fd[{gt2, ct2}], conj[VWm[{lt3}]]}, 
  {((-I)*g2*Delta[ct1, ct2]*sumExp[j1, 1, 3, conj[ZDL[gt2, j1]]*
       ZUL[gt1, j1]])/Sqrt[2], LorentzProduct[gamma[lt3], PL]}, {0, PR}}, 
 {{bar[Fe[{gt1}]], Fe[{gt2}], VP[{lt3}]}, 
  {(I/2)*(g1*Cos[ThetaW] + g2*Sin[ThetaW])*(conj[ZEL[gt2, 1]]*ZEL[gt1, 1] + 
     conj[ZEL[gt2, 2]]*ZEL[gt1, 2] + conj[ZEL[gt2, 3]]*ZEL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {I*g1*Cos[ThetaW]*(conj[ZER[gt1, 1]]*ZER[gt2, 1] + 
     conj[ZER[gt1, 2]]*ZER[gt2, 2] + conj[ZER[gt1, 3]]*ZER[gt2, 3]), 
   LorentzProduct[gamma[lt3], PR]}}, {{bar[Fe[{gt1}]], Fe[{gt2}], VZ[{lt3}]}, 
  {(I/2)*(conj[ZEL[gt2, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*Ql1*Sin[ThetaWp])*ZEL[gt1, 1] + 
     conj[ZEL[gt2, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*Ql2*Sin[ThetaWp])*ZEL[gt1, 2] + 
     conj[ZEL[gt2, 3]]*(g2*Cos[ThetaW]*Cos[ThetaWp] - 
       g1*Cos[ThetaWp]*Sin[ThetaW] - 2*gp*Ql3*Sin[ThetaWp])*ZEL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {(-I)*(conj[ZER[gt1, 1]]*(g1*Cos[ThetaWp]*Sin[ThetaW] - 
       gp*Qe1*Sin[ThetaWp])*ZER[gt2, 1] + conj[ZER[gt1, 2]]*
      (g1*Cos[ThetaWp]*Sin[ThetaW] - gp*Qe2*Sin[ThetaWp])*ZER[gt2, 2] + 
     conj[ZER[gt1, 3]]*(g1*Cos[ThetaWp]*Sin[ThetaW] - gp*Qe3*Sin[ThetaWp])*
      ZER[gt2, 3]), LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fe[{gt1}]], Fe[{gt2}], VZp[{lt3}]}, 
  {(-I/2)*(conj[ZEL[gt2, 1]]*(2*gp*Ql1*Cos[ThetaWp] + 
       (g2*Cos[ThetaW] - g1*Sin[ThetaW])*Sin[ThetaWp])*ZEL[gt1, 1] + 
     conj[ZEL[gt2, 2]]*(2*gp*Ql2*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] - 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZEL[gt1, 2] + 
     conj[ZEL[gt2, 3]]*(2*gp*Ql3*Cos[ThetaWp] + g2*Cos[ThetaW]*Sin[ThetaWp] - 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZEL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {I*(conj[ZER[gt1, 1]]*(gp*Qe1*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZER[gt2, 1] + conj[ZER[gt1, 2]]*(gp*Qe2*Cos[ThetaWp] + 
       g1*Sin[ThetaW]*Sin[ThetaWp])*ZER[gt2, 2] + 
     conj[ZER[gt1, 3]]*(gp*Qe3*Cos[ThetaWp] + g1*Sin[ThetaW]*Sin[ThetaWp])*
      ZER[gt2, 3]), LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fv[{gt1}]], Fe[{gt2}], conj[VWm[{lt3}]]}, 
  {((-I)*g2*(conj[ZEL[gt2, 1]]*ZVL[gt1, 1] + conj[ZEL[gt2, 2]]*ZVL[gt1, 2] + 
      conj[ZEL[gt2, 3]]*ZVL[gt1, 3]))/Sqrt[2], LorentzProduct[gamma[lt3], 
    PL]}, {0, PR}}, {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], VG[{ct3, lt3}]}, 
  {(-I/2)*g3*Lam[ct3, ct1, ct2]*sumExp[j1, 1, 3, conj[ZUL[gt2, j1]]*
      ZUL[gt1, j1]], LorentzProduct[gamma[lt3], PL]}, 
  {(-I/2)*g3*Lam[ct3, ct1, ct2]*sumExp[j1, 1, 3, conj[ZUR[gt1, j1]]*
      ZUR[gt2, j1]], LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], VP[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*(g1*Cos[ThetaW] + 3*g2*Sin[ThetaW])*
    sumExp[j1, 1, 3, conj[ZUL[gt2, j1]]*ZUL[gt1, j1]], 
   LorentzProduct[gamma[lt3], PL]}, 
  {((-2*I)/3)*g1*Cos[ThetaW]*Delta[ct1, ct2]*sumExp[j1, 1, 3, 
     conj[ZUR[gt1, j1]]*ZUR[gt2, j1]], LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fd[{gt1, ct1}]], Fu[{gt2, ct2}], VWm[{lt3}]}, 
  {((-I)*g2*Delta[ct1, ct2]*sumExp[j1, 1, 3, conj[ZUL[gt2, j1]]*
       ZDL[gt1, j1]])/Sqrt[2], LorentzProduct[gamma[lt3], PL]}, {0, PR}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], VZ[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*(3*g2*Cos[ThetaW]*Cos[ThetaWp] - 
     g1*Cos[ThetaWp]*Sin[ThetaW] + 6*gp*Qq*Sin[ThetaWp])*
    sumExp[j1, 1, 3, conj[ZUL[gt2, j1]]*ZUL[gt1, j1]], 
   LorentzProduct[gamma[lt3], PL]}, 
  {(I/3)*Delta[ct1, ct2]*(2*g1*Cos[ThetaWp]*Sin[ThetaW] + 
     3*gp*Qu*Sin[ThetaWp])*sumExp[j1, 1, 3, conj[ZUR[gt1, j1]]*ZUR[gt2, j1]], 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fu[{gt1, ct1}]], Fu[{gt2, ct2}], VZp[{lt3}]}, 
  {(-I/6)*Delta[ct1, ct2]*(6*gp*Qq*Cos[ThetaWp] + 
     (-3*g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*
    sumExp[j1, 1, 3, conj[ZUL[gt2, j1]]*ZUL[gt1, j1]], 
   LorentzProduct[gamma[lt3], PL]}, 
  {(I/3)*Delta[ct1, ct2]*(3*gp*Qu*Cos[ThetaWp] - 2*g1*Sin[ThetaW]*
      Sin[ThetaWp])*sumExp[j1, 1, 3, conj[ZUR[gt1, j1]]*ZUR[gt2, j1]], 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fe[{gt1}]], Fv[{gt2}], VWm[{lt3}]}, 
  {((-I)*g2*(conj[ZVL[gt2, 1]]*ZEL[gt1, 1] + conj[ZVL[gt2, 2]]*ZEL[gt1, 2] + 
      conj[ZVL[gt2, 3]]*ZEL[gt1, 3]))/Sqrt[2], LorentzProduct[gamma[lt3], 
    PL]}, {0, PR}}, {{bar[Fv[{gt1}]], Fv[{gt2}], VZ[{lt3}]}, 
  {(-I/2)*(conj[ZVL[gt2, 1]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql1*Sin[ThetaWp])*ZVL[gt1, 1] + 
     conj[ZVL[gt2, 2]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql2*Sin[ThetaWp])*ZVL[gt1, 2] + 
     conj[ZVL[gt2, 3]]*(g2*Cos[ThetaW]*Cos[ThetaWp] + 
       g1*Cos[ThetaWp]*Sin[ThetaW] + 2*gp*Ql3*Sin[ThetaWp])*ZVL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {I*gp*Sin[ThetaWp]*(Qv1*conj[ZVR[gt1, 1]]*ZVR[gt2, 1] + 
     Qv2*conj[ZVR[gt1, 2]]*ZVR[gt2, 2] + Qv3*conj[ZVR[gt1, 3]]*ZVR[gt2, 3]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{bar[Fv[{gt1}]], Fv[{gt2}], VZp[{lt3}]}, 
  {(-I/2)*(conj[ZVL[gt2, 1]]*(2*gp*Ql1*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZVL[gt1, 1] + 
     conj[ZVL[gt2, 2]]*(2*gp*Ql2*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZVL[gt1, 2] + 
     conj[ZVL[gt2, 3]]*(2*gp*Ql3*Cos[ThetaWp] - 
       (g2*Cos[ThetaW] + g1*Sin[ThetaW])*Sin[ThetaWp])*ZVL[gt1, 3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {I*gp*Cos[ThetaWp]*(Qv1*conj[ZVR[gt1, 1]]*ZVR[gt2, 1] + 
     Qv2*conj[ZVR[gt1, 2]]*ZVR[gt2, 2] + Qv3*conj[ZVR[gt1, 3]]*ZVR[gt2, 3]), 
   LorentzProduct[gamma[lt3], PR]}}, 
 {{Glu[{ct1}], Glu[{ct2}], VG[{ct3, lt3}]}, 
  {-(g3*PhaseGlu*conj[PhaseGlu]*fSU3[ct1, ct2, ct3]), 
   LorentzProduct[gamma[lt3], PL]}, 
  {-(g3*PhaseGlu*conj[PhaseGlu]*fSU3[ct1, ct2, ct3]), 
   LorentzProduct[gamma[lt3], PR]}}}
