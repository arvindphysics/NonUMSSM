{{hh, A0[Mass2[gWm]]*Cp[Uhh[{gO1}], bar[gWm], gWm] + 
   A0[Mass2[gWmC]]*Cp[Uhh[{gO1}], bar[gWmC], gWmC] + 
   A0[Mass2[gZ]]*Cp[Uhh[{gO1}], bar[gZ], gZ] + 
   A0[Mass2[gZp]]*Cp[Uhh[{gO1}], bar[gZp], gZp] + 
   4*Cp[Uhh[{gO1}], conj[VWm], VWm]*(A0[Mass2[VWm]] - (rMS*Mass2[VWm])/2) + 
   2*Cp[Uhh[{gO1}], VZ, VZ]*(A0[Mass2[VZ]] - (rMS*Mass2[VZ])/2) + 
   2*Cp[Uhh[{gO1}], VZp, VZp]*(A0[Mass2[VZp]] - (rMS*Mass2[VZp])/2) - 
   sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*Cp[Uhh[{gO1}], conj[Hpm[{gI1}]], 
      Hpm[{gI1}]]] + 2*sum[gI1, 1, 2, A0[Mass2[Cha[{gI1}]]]*Mass[Cha[{gI1}]]*
      (Cp[Uhh[{gO1}], bar[Cha[{gI1}]], Cha[{gI1}]][PL] + 
       Cp[Uhh[{gO1}], bar[Cha[{gI1}]], Cha[{gI1}]][PR])] - 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[Uhh[{gO1}], Ah[{gI1}], Ah[{gI1}]]]/
    2 - sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*Cp[Uhh[{gO1}], hh[{gI1}], 
       hh[{gI1}]]]/2 + 6*sum[gI1, 1, 3, A0[Mass2[Fd[{gI1}]]]*Mass[Fd[{gI1}]]*
      (Cp[Uhh[{gO1}], bar[Fd[{gI1}]], Fd[{gI1}]][PL] + 
       Cp[Uhh[{gO1}], bar[Fd[{gI1}]], Fd[{gI1}]][PR])] + 
   2*sum[gI1, 1, 3, A0[Mass2[Fe[{gI1}]]]*Mass[Fe[{gI1}]]*
      (Cp[Uhh[{gO1}], bar[Fe[{gI1}]], Fe[{gI1}]][PL] + 
       Cp[Uhh[{gO1}], bar[Fe[{gI1}]], Fe[{gI1}]][PR])] + 
   6*sum[gI1, 1, 3, A0[Mass2[Fu[{gI1}]]]*Mass[Fu[{gI1}]]*
      (Cp[Uhh[{gO1}], bar[Fu[{gI1}]], Fu[{gI1}]][PL] + 
       Cp[Uhh[{gO1}], bar[Fu[{gI1}]], Fu[{gI1}]][PR])] + 
   2*sum[gI1, 1, 3, A0[Mass2[Fv[{gI1}]]]*Mass[Fv[{gI1}]]*
      (Cp[Uhh[{gO1}], bar[Fv[{gI1}]], Fv[{gI1}]][PL] + 
       Cp[Uhh[{gO1}], bar[Fv[{gI1}]], Fv[{gI1}]][PR])] - 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[Uhh[{gO1}], conj[Sd[{gI1}]], 
       Sd[{gI1}]]] - sum[gI1, 1, 6, A0[Mass2[Se[{gI1}]]]*
     Cp[Uhh[{gO1}], conj[Se[{gI1}]], Se[{gI1}]]] - 
   3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*Cp[Uhh[{gO1}], conj[Su[{gI1}]], 
       Su[{gI1}]]] - sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*
     Cp[Uhh[{gO1}], conj[Sv[{gI1}]], Sv[{gI1}]]] + 
   sum[gI1, 1, 6, A0[Mass2[Chi[{gI1}]]]*Mass[Chi[{gI1}]]*
     (Cp[Uhh[{gO1}], Chi[{gI1}], Chi[{gI1}]][PL] + 
      Cp[Uhh[{gO1}], Chi[{gI1}], Chi[{gI1}]][PR])]}}
