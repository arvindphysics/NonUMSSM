{{Glu, "MGlu", {MassG}, MassG, MassG, FermionMassSymm}, 
 {VG, 0, {}, 0, 0, VectorMass}, {VP, 0, {g1, g2, vd, vu, ThetaW}, 0, 0, 
  VectorMass}, {VZ, "MVZ", {g1, g2, gp, QHd, QHu, Qs, vd, vu, vS, ThetaW, 
   ThetaWp}, (g2^2*(vd^2 + vu^2)*Cos[ThetaW]^2*Cos[ThetaWp]^2 + 
    g1*(vd^2 + vu^2)*Cos[ThetaWp]^2*Sin[ThetaW]*(2*g2*Cos[ThetaW] + 
      g1*Sin[ThetaW]) + 4*gp^2*(QHd^2*vd^2 + Qs^2*vS^2 + QHu^2*vu^2)*
     Sin[ThetaWp]^2 + 2*g2*gp*(QHd*vd^2 - QHu*vu^2)*Cos[ThetaW]*
     Sin[2*ThetaWp] + 2*g1*gp*(QHd*vd^2 - QHu*vu^2)*Sin[ThetaW]*
     Sin[2*ThetaWp])/4, (g2^2*(vd^2 + vu^2)*Cos[ThetaW]^2*Cos[ThetaWp]^2 + 
    g1*(vd^2 + vu^2)*Cos[ThetaWp]^2*Sin[ThetaW]*(2*g2*Cos[ThetaW] + 
      g1*Sin[ThetaW]) + 4*gp^2*(QHd^2*vd^2 + Qs^2*vS^2 + QHu^2*vu^2)*
     Sin[ThetaWp]^2 + 2*g2*gp*(QHd*vd^2 - QHu*vu^2)*Cos[ThetaW]*
     Sin[2*ThetaWp] + 2*g1*gp*(QHd*vd^2 - QHu*vu^2)*Sin[ThetaW]*
     Sin[2*ThetaWp])/4, VectorMass}, 
 {VZp, "MVZp", {g1, g2, gp, QHd, QHu, Qs, vd, vu, vS, ThetaW, ThetaWp}, 
  (4*gp^2*(QHd^2*vd^2 + Qs^2*vS^2 + QHu^2*vu^2)*Cos[ThetaWp]^2 + 
    (vd^2 + vu^2)*(g2*Cos[ThetaW] + g1*Sin[ThetaW])^2*Sin[ThetaWp]^2 - 
    2*gp*(QHd*vd^2 - QHu*vu^2)*(g2*Cos[ThetaW] + g1*Sin[ThetaW])*
     Sin[2*ThetaWp])/4, (4*gp^2*(QHd^2*vd^2 + Qs^2*vS^2 + QHu^2*vu^2)*
     Cos[ThetaWp]^2 + (vd^2 + vu^2)*(g2*Cos[ThetaW] + g1*Sin[ThetaW])^2*
     Sin[ThetaWp]^2 - 2*gp*(QHd*vd^2 - QHu*vu^2)*(g2*Cos[ThetaW] + 
      g1*Sin[ThetaW])*Sin[2*ThetaWp])/4, VectorMass}, 
 {VWm, "MVWm", {g2, vd, vu}, (g2^2*(vd^2 + vu^2))/4, (g2^2*(vd^2 + vu^2))/4, 
  VectorMass}}
