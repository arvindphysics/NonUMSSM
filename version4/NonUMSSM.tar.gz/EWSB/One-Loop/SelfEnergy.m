{{Sd, 4*Cp[USd[{gO1}], conj[USd[{gO2}]], conj[VWm], VWm]*
    (A0[Mass2[VWm]] - (rMS*Mass2[VWm])/2) + 
   2*Cp[USd[{gO1}], conj[USd[{gO2}]], VZ, VZ]*(A0[Mass2[VZ]] - 
     (rMS*Mass2[VZ])/2) + 2*Cp[USd[{gO1}], conj[USd[{gO2}]], VZp, VZp]*
    (A0[Mass2[VZp]] - (rMS*Mass2[VZp])/2) - 
   sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*Cp[USd[{gO1}], conj[USd[{gO2}]], 
      conj[Hpm[{gI1}]], Hpm[{gI1}]]] - 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[USd[{gO1}], conj[USd[{gO2}]], 
       Ah[{gI1}], Ah[{gI1}]]]/2 - 
   sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*Cp[USd[{gO1}], conj[USd[{gO2}]], 
       hh[{gI1}], hh[{gI1}]]]/2 - 
   2*sum[gI1, 1, 3, Mass[Fu[{gI1}]]*sum[gI2, 1, 2, 
       B0[p^2, Mass2[Fu[{gI1}]], Mass2[Cha[{gI2}]]]*Mass[Cha[{gI2}]]*
        (conj[Cp[conj[USd[{gO2}]], Fu[{gI1}], Cha[{gI2}]][PR]]*
          Cp[conj[USd[{gO1}]], Fu[{gI1}], Cha[{gI2}]][PL] + 
         conj[Cp[conj[USd[{gO2}]], Fu[{gI1}], Cha[{gI2}]][PL]]*
          Cp[conj[USd[{gO1}]], Fu[{gI1}], Cha[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 2, G0[p^2, Mass2[Fu[{gI1}]], Mass2[Cha[{gI2}]]]*
      (conj[Cp[conj[USd[{gO2}]], Fu[{gI1}], Cha[{gI2}]][PL]]*
        Cp[conj[USd[{gO1}]], Fu[{gI1}], Cha[{gI2}]][PL] + 
       conj[Cp[conj[USd[{gO2}]], Fu[{gI1}], Cha[{gI2}]][PR]]*
        Cp[conj[USd[{gO1}]], Fu[{gI1}], Cha[{gI2}]][PR])]] - 
   2*sum[gI1, 1, 3, Mass[Fd[{gI1}]]*sum[gI2, 1, 6, 
       B0[p^2, Mass2[Fd[{gI1}]], Mass2[Chi[{gI2}]]]*Mass[Chi[{gI2}]]*
        (conj[Cp[conj[USd[{gO2}]], Fd[{gI1}], Chi[{gI2}]][PR]]*
          Cp[conj[USd[{gO1}]], Fd[{gI1}], Chi[{gI2}]][PL] + 
         conj[Cp[conj[USd[{gO2}]], Fd[{gI1}], Chi[{gI2}]][PL]]*
          Cp[conj[USd[{gO1}]], Fd[{gI1}], Chi[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 6, G0[p^2, Mass2[Fd[{gI1}]], Mass2[Chi[{gI2}]]]*
      (conj[Cp[conj[USd[{gO2}]], Fd[{gI1}], Chi[{gI2}]][PL]]*
        Cp[conj[USd[{gO1}]], Fd[{gI1}], Chi[{gI2}]][PL] + 
       conj[Cp[conj[USd[{gO2}]], Fd[{gI1}], Chi[{gI2}]][PR]]*
        Cp[conj[USd[{gO1}]], Fd[{gI1}], Chi[{gI2}]][PR])]] - 
   C*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[USd[{gO1}], conj[USd[{gO2}]], 
       conj[Sd[{gI1}]], Sd[{gI1}]]] - sum[gI1, 1, 6, 
    A0[Mass2[Se[{gI1}]]]*Cp[USd[{gO1}], conj[USd[{gO2}]], conj[Se[{gI1}]], 
      Se[{gI1}]]] - C*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*
      Cp[USd[{gO1}], conj[USd[{gO2}]], conj[Su[{gI1}]], Su[{gI1}]]] - 
   sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*Cp[USd[{gO1}], conj[USd[{gO2}]], 
      conj[Sv[{gI1}]], Sv[{gI1}]]] + sum[gI1, 1, 6, 
    sum[gI2, 1, 2, B0[p^2, Mass2[Su[{gI1}]], Mass2[Hpm[{gI2}]]]*
      conj[Cp[conj[USd[{gO2}]], Su[{gI1}], Hpm[{gI2}]]]*
      Cp[conj[USd[{gO1}]], Su[{gI1}], Hpm[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Sd[{gI1}]], Mass2[Ah[{gI2}]]]*
      conj[Cp[conj[USd[{gO2}]], Sd[{gI1}], Ah[{gI2}]]]*
      Cp[conj[USd[{gO1}]], Sd[{gI1}], Ah[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Sd[{gI1}]], Mass2[hh[{gI2}]]]*
      conj[Cp[conj[USd[{gO2}]], Sd[{gI1}], hh[{gI2}]]]*
      Cp[conj[USd[{gO1}]], Sd[{gI1}], hh[{gI2}]]]] - 
   (8*Mass[Glu]*sum[gI2, 1, 3, B0[p^2, Mass2[Glu], Mass2[Fd[{gI2}]]]*
       Mass[Fd[{gI2}]]*(conj[Cp[conj[USd[{gO2}]], Glu[{1}], Fd[{gI2}]][PR]]*
         Cp[conj[USd[{gO1}]], Glu[{1}], Fd[{gI2}]][PL] + 
        conj[Cp[conj[USd[{gO2}]], Glu[{1}], Fd[{gI2}]][PL]]*
         Cp[conj[USd[{gO1}]], Glu[{1}], Fd[{gI2}]][PR])])/3 + 
   (4*sum[gI2, 1, 3, G0[p^2, Mass2[Glu], Mass2[Fd[{gI2}]]]*
       (conj[Cp[conj[USd[{gO2}]], Glu[{1}], Fd[{gI2}]][PL]]*
         Cp[conj[USd[{gO1}]], Glu[{1}], Fd[{gI2}]][PL] + 
        conj[Cp[conj[USd[{gO2}]], Glu[{1}], Fd[{gI2}]][PR]]*
         Cp[conj[USd[{gO1}]], Glu[{1}], Fd[{gI2}]][PR])])/3 + 
   (4*sum[gI2, 1, 6, conj[Cp[conj[USd[{gO2}]], VG, Sd[{gI2}]]]*
       Cp[conj[USd[{gO1}]], VG, Sd[{gI2}]]*F0[p^2, Mass2[Sd[{gI2}]], 0]])/3 + 
   sum[gI2, 1, 6, conj[Cp[conj[USd[{gO2}]], VP, Sd[{gI2}]]]*
     Cp[conj[USd[{gO1}]], VP, Sd[{gI2}]]*F0[p^2, Mass2[Sd[{gI2}]], 0]] + 
   sum[gI2, 1, 6, conj[Cp[conj[USd[{gO2}]], VZ, Sd[{gI2}]]]*
     Cp[conj[USd[{gO1}]], VZ, Sd[{gI2}]]*F0[p^2, Mass2[Sd[{gI2}]], 
      Mass2[VZ]]] + sum[gI2, 1, 6, conj[Cp[conj[USd[{gO2}]], VZp, Sd[{gI2}]]]*
     Cp[conj[USd[{gO1}]], VZp, Sd[{gI2}]]*F0[p^2, Mass2[Sd[{gI2}]], 
      Mass2[VZp]]] + sum[gI2, 1, 6, 
    conj[Cp[conj[USd[{gO2}]], VWm, Su[{gI2}]]]*Cp[conj[USd[{gO1}]], VWm, 
      Su[{gI2}]]*F0[p^2, Mass2[Su[{gI2}]], Mass2[VWm]]]}, 
 {Sv, 4*Cp[USv[{gO1}], conj[USv[{gO2}]], conj[VWm], VWm]*
    (A0[Mass2[VWm]] - (rMS*Mass2[VWm])/2) + 
   2*Cp[USv[{gO1}], conj[USv[{gO2}]], VZ, VZ]*(A0[Mass2[VZ]] - 
     (rMS*Mass2[VZ])/2) + 2*Cp[USv[{gO1}], conj[USv[{gO2}]], VZp, VZp]*
    (A0[Mass2[VZp]] - (rMS*Mass2[VZp])/2) - 
   sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*Cp[USv[{gO1}], conj[USv[{gO2}]], 
      conj[Hpm[{gI1}]], Hpm[{gI1}]]] - 
   2*sum[gI1, 1, 2, Mass[Cha[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Cha[{gI1}]], Mass2[Fe[{gI2}]]]*Mass[Fe[{gI2}]]*
        (conj[Cp[conj[USv[{gO2}]], bar[Cha[{gI1}]], Fe[{gI2}]][PR]]*
          Cp[conj[USv[{gO1}]], bar[Cha[{gI1}]], Fe[{gI2}]][PL] + 
         conj[Cp[conj[USv[{gO2}]], bar[Cha[{gI1}]], Fe[{gI2}]][PL]]*
          Cp[conj[USv[{gO1}]], bar[Cha[{gI1}]], Fe[{gI2}]][PR])]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 3, G0[p^2, Mass2[Cha[{gI1}]], Mass2[Fe[{gI2}]]]*
      (conj[Cp[conj[USv[{gO2}]], bar[Cha[{gI1}]], Fe[{gI2}]][PL]]*
        Cp[conj[USv[{gO1}]], bar[Cha[{gI1}]], Fe[{gI2}]][PL] + 
       conj[Cp[conj[USv[{gO2}]], bar[Cha[{gI1}]], Fe[{gI2}]][PR]]*
        Cp[conj[USv[{gO1}]], bar[Cha[{gI1}]], Fe[{gI2}]][PR])]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 6, B0[p^2, Mass2[Hpm[{gI1}]], Mass2[Se[{gI2}]]]*
      conj[Cp[conj[USv[{gO2}]], conj[Hpm[{gI1}]], Se[{gI2}]]]*
      Cp[conj[USv[{gO1}]], conj[Hpm[{gI1}]], Se[{gI2}]]]] - 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[USv[{gO1}], conj[USv[{gO2}]], 
       Ah[{gI1}], Ah[{gI1}]]]/2 - 
   sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*Cp[USv[{gO1}], conj[USv[{gO2}]], 
       hh[{gI1}], hh[{gI1}]]]/2 - 
   2*sum[gI1, 1, 3, Mass[Fv[{gI1}]]*sum[gI2, 1, 6, 
       B0[p^2, Mass2[Fv[{gI1}]], Mass2[Chi[{gI2}]]]*Mass[Chi[{gI2}]]*
        (conj[Cp[conj[USv[{gO2}]], Fv[{gI1}], Chi[{gI2}]][PR]]*
          Cp[conj[USv[{gO1}]], Fv[{gI1}], Chi[{gI2}]][PL] + 
         conj[Cp[conj[USv[{gO2}]], Fv[{gI1}], Chi[{gI2}]][PL]]*
          Cp[conj[USv[{gO1}]], Fv[{gI1}], Chi[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 6, G0[p^2, Mass2[Fv[{gI1}]], Mass2[Chi[{gI2}]]]*
      (conj[Cp[conj[USv[{gO2}]], Fv[{gI1}], Chi[{gI2}]][PL]]*
        Cp[conj[USv[{gO1}]], Fv[{gI1}], Chi[{gI2}]][PL] + 
       conj[Cp[conj[USv[{gO2}]], Fv[{gI1}], Chi[{gI2}]][PR]]*
        Cp[conj[USv[{gO1}]], Fv[{gI1}], Chi[{gI2}]][PR])]] - 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[USv[{gO1}], conj[USv[{gO2}]], 
       conj[Sd[{gI1}]], Sd[{gI1}]]] - sum[gI1, 1, 6, 
    A0[Mass2[Se[{gI1}]]]*Cp[USv[{gO1}], conj[USv[{gO2}]], conj[Se[{gI1}]], 
      Se[{gI1}]]] - 3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*
      Cp[USv[{gO1}], conj[USv[{gO2}]], conj[Su[{gI1}]], Su[{gI1}]]] - 
   sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*Cp[USv[{gO1}], conj[USv[{gO2}]], 
      conj[Sv[{gI1}]], Sv[{gI1}]]] + sum[gI1, 1, 6, 
    sum[gI2, 1, 3, B0[p^2, Mass2[Sv[{gI1}]], Mass2[Ah[{gI2}]]]*
      conj[Cp[conj[USv[{gO2}]], Sv[{gI1}], Ah[{gI2}]]]*
      Cp[conj[USv[{gO1}]], Sv[{gI1}], Ah[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Sv[{gI1}]], Mass2[hh[{gI2}]]]*
      conj[Cp[conj[USv[{gO2}]], Sv[{gI1}], hh[{gI2}]]]*
      Cp[conj[USv[{gO1}]], Sv[{gI1}], hh[{gI2}]]]] + 
   sum[gI2, 1, 6, conj[Cp[conj[USv[{gO2}]], conj[VWm], Se[{gI2}]]]*
     Cp[conj[USv[{gO1}]], conj[VWm], Se[{gI2}]]*F0[p^2, Mass2[Se[{gI2}]], 
      Mass2[VWm]]] + sum[gI2, 1, 6, conj[Cp[conj[USv[{gO2}]], VZ, Sv[{gI2}]]]*
     Cp[conj[USv[{gO1}]], VZ, Sv[{gI2}]]*F0[p^2, Mass2[Sv[{gI2}]], 
      Mass2[VZ]]] + sum[gI2, 1, 6, conj[Cp[conj[USv[{gO2}]], VZp, Sv[{gI2}]]]*
     Cp[conj[USv[{gO1}]], VZp, Sv[{gI2}]]*F0[p^2, Mass2[Sv[{gI2}]], 
      Mass2[VZp]]]}, 
 {Fv, {sum[gI1, 1, 2, sum[gI2, 1, 3, B0[p^2, Mass2[Fe[{gI2}]], 
        Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFv[{gO2}]], conj[Hpm[{gI1}]], 
          Fe[{gI2}]][PL]]*Mass[Fe[{gI2}]]*
       Cp[bar[UFv[{gO1}]], conj[Hpm[{gI1}]], Fe[{gI2}]][PR]]] + 
    sum[gI1, 1, 2, Mass[Cha[{gI1}]]*sum[gI2, 1, 6, 
       B0[p^2, Mass2[Cha[{gI1}]], Mass2[Se[{gI2}]]]*
        conj[Cp[bar[UFv[{gO2}]], bar[Cha[{gI1}]], Se[{gI2}]][PL]]*
        Cp[bar[UFv[{gO1}]], bar[Cha[{gI1}]], Se[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, Mass[Fv[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fv[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFv[{gO2}]], Fv[{gI1}], Ah[{gI2}]][PL]]*
        Cp[bar[UFv[{gO1}]], Fv[{gI1}], Ah[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B0[p^2, Mass2[Fv[{gI2}]], Mass2[hh[{gI1}]]]*
       conj[Cp[bar[UFv[{gO2}]], hh[{gI1}], Fv[{gI2}]][PL]]*Mass[Fv[{gI2}]]*
       Cp[bar[UFv[{gO1}]], hh[{gI1}], Fv[{gI2}]][PR]]] + 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Chi[{gI2}]], 
        Mass2[Sv[{gI1}]]]*conj[Cp[bar[UFv[{gO2}]], Sv[{gI1}], Chi[{gI2}]][
         PL]]*Mass[Chi[{gI2}]]*Cp[bar[UFv[{gO1}]], Sv[{gI1}], Chi[{gI2}]][
        PR]]] - 4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fv[{gI2}]], 
         Mass2[VZ]])*conj[Cp[bar[UFv[{gO2}]], VZ, Fv[{gI2}]][PR]]*
       Mass[Fv[{gI2}]]*Cp[bar[UFv[{gO1}]], VZ, Fv[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fv[{gI2}]], Mass2[VZp]])*
       conj[Cp[bar[UFv[{gO2}]], VZp, Fv[{gI2}]][PR]]*Mass[Fv[{gI2}]]*
       Cp[bar[UFv[{gO1}]], VZp, Fv[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fe[{gI2}]], Mass2[VWm]])*
       conj[Cp[bar[UFv[{gO2}]], conj[VWm], Fe[{gI2}]][PR]]*Mass[Fe[{gI2}]]*
       Cp[bar[UFv[{gO1}]], conj[VWm], Fe[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Fe[{gI2}]], 
          Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFv[{gO2}]], conj[Hpm[{gI1}]], 
            Fe[{gI2}]][PR]]*Cp[bar[UFv[{gO1}]], conj[Hpm[{gI1}]], Fe[{gI2}]][
          PR]]]/2 - sum[gI1, 1, 2, sum[gI2, 1, 6, 
       B1[p^2, Mass2[Cha[{gI1}]], Mass2[Se[{gI2}]]]*
        conj[Cp[bar[UFv[{gO2}]], bar[Cha[{gI1}]], Se[{gI2}]][PR]]*
        Cp[bar[UFv[{gO1}]], bar[Cha[{gI1}]], Se[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fv[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFv[{gO2}]], Fv[{gI1}], Ah[{gI2}]][PR]]*
        Cp[bar[UFv[{gO1}]], Fv[{gI1}], Ah[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fv[{gI2}]], Mass2[hh[{gI1}]]]*
        conj[Cp[bar[UFv[{gO2}]], hh[{gI1}], Fv[{gI2}]][PR]]*
        Cp[bar[UFv[{gO1}]], hh[{gI1}], Fv[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Sv[{gI1}]]]*conj[Cp[bar[UFv[{gO2}]], Sv[{gI1}], Chi[{gI2}]][
          PR]]*Cp[bar[UFv[{gO1}]], Sv[{gI1}], Chi[{gI2}]][PR]]]/2 - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fv[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UFv[{gO2}]], VZ, Fv[{gI2}]][PL]]*
      Cp[bar[UFv[{gO1}]], VZ, Fv[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fv[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UFv[{gO2}]], VZp, Fv[{gI2}]][PL]]*
      Cp[bar[UFv[{gO1}]], VZp, Fv[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fe[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UFv[{gO2}]], conj[VWm], Fe[{gI2}]][PL]]*
      Cp[bar[UFv[{gO1}]], conj[VWm], Fe[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Fe[{gI2}]], 
          Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFv[{gO2}]], conj[Hpm[{gI1}]], 
            Fe[{gI2}]][PL]]*Cp[bar[UFv[{gO1}]], conj[Hpm[{gI1}]], Fe[{gI2}]][
          PL]]]/2 - sum[gI1, 1, 2, sum[gI2, 1, 6, 
       B1[p^2, Mass2[Cha[{gI1}]], Mass2[Se[{gI2}]]]*
        conj[Cp[bar[UFv[{gO2}]], bar[Cha[{gI1}]], Se[{gI2}]][PL]]*
        Cp[bar[UFv[{gO1}]], bar[Cha[{gI1}]], Se[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fv[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFv[{gO2}]], Fv[{gI1}], Ah[{gI2}]][PL]]*
        Cp[bar[UFv[{gO1}]], Fv[{gI1}], Ah[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fv[{gI2}]], Mass2[hh[{gI1}]]]*
        conj[Cp[bar[UFv[{gO2}]], hh[{gI1}], Fv[{gI2}]][PL]]*
        Cp[bar[UFv[{gO1}]], hh[{gI1}], Fv[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Sv[{gI1}]]]*conj[Cp[bar[UFv[{gO2}]], Sv[{gI1}], Chi[{gI2}]][
          PL]]*Cp[bar[UFv[{gO1}]], Sv[{gI1}], Chi[{gI2}]][PL]]]/2 - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fv[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UFv[{gO2}]], VZ, Fv[{gI2}]][PR]]*
      Cp[bar[UFv[{gO1}]], VZ, Fv[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fv[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UFv[{gO2}]], VZp, Fv[{gI2}]][PR]]*
      Cp[bar[UFv[{gO1}]], VZp, Fv[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fe[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UFv[{gO2}]], conj[VWm], Fe[{gI2}]][PR]]*
      Cp[bar[UFv[{gO1}]], conj[VWm], Fe[{gI2}]][PR]]}}, 
 {Su, 4*Cp[USu[{gO1}], conj[USu[{gO2}]], conj[VWm], VWm]*
    (A0[Mass2[VWm]] - (rMS*Mass2[VWm])/2) + 
   2*Cp[USu[{gO1}], conj[USu[{gO2}]], VZ, VZ]*(A0[Mass2[VZ]] - 
     (rMS*Mass2[VZ])/2) + 2*Cp[USu[{gO1}], conj[USu[{gO2}]], VZp, VZp]*
    (A0[Mass2[VZp]] - (rMS*Mass2[VZp])/2) - 
   sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*Cp[USu[{gO1}], conj[USu[{gO2}]], 
      conj[Hpm[{gI1}]], Hpm[{gI1}]]] - 
   2*sum[gI1, 1, 2, Mass[Cha[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Cha[{gI1}]], Mass2[Fd[{gI2}]]]*Mass[Fd[{gI2}]]*
        (conj[Cp[conj[USu[{gO2}]], bar[Cha[{gI1}]], Fd[{gI2}]][PR]]*
          Cp[conj[USu[{gO1}]], bar[Cha[{gI1}]], Fd[{gI2}]][PL] + 
         conj[Cp[conj[USu[{gO2}]], bar[Cha[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[conj[USu[{gO1}]], bar[Cha[{gI1}]], Fd[{gI2}]][PR])]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 3, G0[p^2, Mass2[Cha[{gI1}]], Mass2[Fd[{gI2}]]]*
      (conj[Cp[conj[USu[{gO2}]], bar[Cha[{gI1}]], Fd[{gI2}]][PL]]*
        Cp[conj[USu[{gO1}]], bar[Cha[{gI1}]], Fd[{gI2}]][PL] + 
       conj[Cp[conj[USu[{gO2}]], bar[Cha[{gI1}]], Fd[{gI2}]][PR]]*
        Cp[conj[USu[{gO1}]], bar[Cha[{gI1}]], Fd[{gI2}]][PR])]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 6, B0[p^2, Mass2[Hpm[{gI1}]], Mass2[Sd[{gI2}]]]*
      conj[Cp[conj[USu[{gO2}]], conj[Hpm[{gI1}]], Sd[{gI2}]]]*
      Cp[conj[USu[{gO1}]], conj[Hpm[{gI1}]], Sd[{gI2}]]]] - 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[USu[{gO1}], conj[USu[{gO2}]], 
       Ah[{gI1}], Ah[{gI1}]]]/2 - 
   sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*Cp[USu[{gO1}], conj[USu[{gO2}]], 
       hh[{gI1}], hh[{gI1}]]]/2 - 
   2*sum[gI1, 1, 3, Mass[Fu[{gI1}]]*sum[gI2, 1, 6, 
       B0[p^2, Mass2[Fu[{gI1}]], Mass2[Chi[{gI2}]]]*Mass[Chi[{gI2}]]*
        (conj[Cp[conj[USu[{gO2}]], Fu[{gI1}], Chi[{gI2}]][PR]]*
          Cp[conj[USu[{gO1}]], Fu[{gI1}], Chi[{gI2}]][PL] + 
         conj[Cp[conj[USu[{gO2}]], Fu[{gI1}], Chi[{gI2}]][PL]]*
          Cp[conj[USu[{gO1}]], Fu[{gI1}], Chi[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 6, G0[p^2, Mass2[Fu[{gI1}]], Mass2[Chi[{gI2}]]]*
      (conj[Cp[conj[USu[{gO2}]], Fu[{gI1}], Chi[{gI2}]][PL]]*
        Cp[conj[USu[{gO1}]], Fu[{gI1}], Chi[{gI2}]][PL] + 
       conj[Cp[conj[USu[{gO2}]], Fu[{gI1}], Chi[{gI2}]][PR]]*
        Cp[conj[USu[{gO1}]], Fu[{gI1}], Chi[{gI2}]][PR])]] - 
   C*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[USu[{gO1}], conj[USu[{gO2}]], 
       conj[Sd[{gI1}]], Sd[{gI1}]]] - sum[gI1, 1, 6, 
    A0[Mass2[Se[{gI1}]]]*Cp[USu[{gO1}], conj[USu[{gO2}]], conj[Se[{gI1}]], 
      Se[{gI1}]]] - C*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*
      Cp[USu[{gO1}], conj[USu[{gO2}]], conj[Su[{gI1}]], Su[{gI1}]]] - 
   sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*Cp[USu[{gO1}], conj[USu[{gO2}]], 
      conj[Sv[{gI1}]], Sv[{gI1}]]] + sum[gI1, 1, 6, 
    sum[gI2, 1, 3, B0[p^2, Mass2[Su[{gI1}]], Mass2[Ah[{gI2}]]]*
      conj[Cp[conj[USu[{gO2}]], Su[{gI1}], Ah[{gI2}]]]*
      Cp[conj[USu[{gO1}]], Su[{gI1}], Ah[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Su[{gI1}]], Mass2[hh[{gI2}]]]*
      conj[Cp[conj[USu[{gO2}]], Su[{gI1}], hh[{gI2}]]]*
      Cp[conj[USu[{gO1}]], Su[{gI1}], hh[{gI2}]]]] - 
   (8*Mass[Glu]*sum[gI2, 1, 3, B0[p^2, Mass2[Glu], Mass2[Fu[{gI2}]]]*
       Mass[Fu[{gI2}]]*(conj[Cp[conj[USu[{gO2}]], Glu[{1}], Fu[{gI2}]][PR]]*
         Cp[conj[USu[{gO1}]], Glu[{1}], Fu[{gI2}]][PL] + 
        conj[Cp[conj[USu[{gO2}]], Glu[{1}], Fu[{gI2}]][PL]]*
         Cp[conj[USu[{gO1}]], Glu[{1}], Fu[{gI2}]][PR])])/3 + 
   (4*sum[gI2, 1, 3, G0[p^2, Mass2[Glu], Mass2[Fu[{gI2}]]]*
       (conj[Cp[conj[USu[{gO2}]], Glu[{1}], Fu[{gI2}]][PL]]*
         Cp[conj[USu[{gO1}]], Glu[{1}], Fu[{gI2}]][PL] + 
        conj[Cp[conj[USu[{gO2}]], Glu[{1}], Fu[{gI2}]][PR]]*
         Cp[conj[USu[{gO1}]], Glu[{1}], Fu[{gI2}]][PR])])/3 + 
   sum[gI2, 1, 6, conj[Cp[conj[USu[{gO2}]], conj[VWm], Sd[{gI2}]]]*
     Cp[conj[USu[{gO1}]], conj[VWm], Sd[{gI2}]]*F0[p^2, Mass2[Sd[{gI2}]], 
      Mass2[VWm]]] + 
   (4*sum[gI2, 1, 6, conj[Cp[conj[USu[{gO2}]], VG, Su[{gI2}]]]*
       Cp[conj[USu[{gO1}]], VG, Su[{gI2}]]*F0[p^2, Mass2[Su[{gI2}]], 0]])/3 + 
   sum[gI2, 1, 6, conj[Cp[conj[USu[{gO2}]], VP, Su[{gI2}]]]*
     Cp[conj[USu[{gO1}]], VP, Su[{gI2}]]*F0[p^2, Mass2[Su[{gI2}]], 0]] + 
   sum[gI2, 1, 6, conj[Cp[conj[USu[{gO2}]], VZ, Su[{gI2}]]]*
     Cp[conj[USu[{gO1}]], VZ, Su[{gI2}]]*F0[p^2, Mass2[Su[{gI2}]], 
      Mass2[VZ]]] + sum[gI2, 1, 6, conj[Cp[conj[USu[{gO2}]], VZp, Su[{gI2}]]]*
     Cp[conj[USu[{gO1}]], VZp, Su[{gI2}]]*F0[p^2, Mass2[Su[{gI2}]], 
      Mass2[VZp]]]}, {Se, 4*Cp[USe[{gO1}], conj[USe[{gO2}]], conj[VWm], VWm]*
    (A0[Mass2[VWm]] - (rMS*Mass2[VWm])/2) + 
   2*Cp[USe[{gO1}], conj[USe[{gO2}]], VZ, VZ]*(A0[Mass2[VZ]] - 
     (rMS*Mass2[VZ])/2) + 2*Cp[USe[{gO1}], conj[USe[{gO2}]], VZp, VZp]*
    (A0[Mass2[VZp]] - (rMS*Mass2[VZp])/2) - 
   sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*Cp[USe[{gO1}], conj[USe[{gO2}]], 
      conj[Hpm[{gI1}]], Hpm[{gI1}]]] - 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[USe[{gO1}], conj[USe[{gO2}]], 
       Ah[{gI1}], Ah[{gI1}]]]/2 - 
   sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*Cp[USe[{gO1}], conj[USe[{gO2}]], 
       hh[{gI1}], hh[{gI1}]]]/2 - 
   2*sum[gI1, 1, 3, Mass[Fv[{gI1}]]*sum[gI2, 1, 2, 
       B0[p^2, Mass2[Fv[{gI1}]], Mass2[Cha[{gI2}]]]*Mass[Cha[{gI2}]]*
        (conj[Cp[conj[USe[{gO2}]], Fv[{gI1}], Cha[{gI2}]][PR]]*
          Cp[conj[USe[{gO1}]], Fv[{gI1}], Cha[{gI2}]][PL] + 
         conj[Cp[conj[USe[{gO2}]], Fv[{gI1}], Cha[{gI2}]][PL]]*
          Cp[conj[USe[{gO1}]], Fv[{gI1}], Cha[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 2, G0[p^2, Mass2[Fv[{gI1}]], Mass2[Cha[{gI2}]]]*
      (conj[Cp[conj[USe[{gO2}]], Fv[{gI1}], Cha[{gI2}]][PL]]*
        Cp[conj[USe[{gO1}]], Fv[{gI1}], Cha[{gI2}]][PL] + 
       conj[Cp[conj[USe[{gO2}]], Fv[{gI1}], Cha[{gI2}]][PR]]*
        Cp[conj[USe[{gO1}]], Fv[{gI1}], Cha[{gI2}]][PR])]] - 
   2*sum[gI1, 1, 3, Mass[Fe[{gI1}]]*sum[gI2, 1, 6, 
       B0[p^2, Mass2[Fe[{gI1}]], Mass2[Chi[{gI2}]]]*Mass[Chi[{gI2}]]*
        (conj[Cp[conj[USe[{gO2}]], Fe[{gI1}], Chi[{gI2}]][PR]]*
          Cp[conj[USe[{gO1}]], Fe[{gI1}], Chi[{gI2}]][PL] + 
         conj[Cp[conj[USe[{gO2}]], Fe[{gI1}], Chi[{gI2}]][PL]]*
          Cp[conj[USe[{gO1}]], Fe[{gI1}], Chi[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 6, G0[p^2, Mass2[Fe[{gI1}]], Mass2[Chi[{gI2}]]]*
      (conj[Cp[conj[USe[{gO2}]], Fe[{gI1}], Chi[{gI2}]][PL]]*
        Cp[conj[USe[{gO1}]], Fe[{gI1}], Chi[{gI2}]][PL] + 
       conj[Cp[conj[USe[{gO2}]], Fe[{gI1}], Chi[{gI2}]][PR]]*
        Cp[conj[USe[{gO1}]], Fe[{gI1}], Chi[{gI2}]][PR])]] - 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[USe[{gO1}], conj[USe[{gO2}]], 
       conj[Sd[{gI1}]], Sd[{gI1}]]] - sum[gI1, 1, 6, 
    A0[Mass2[Se[{gI1}]]]*Cp[USe[{gO1}], conj[USe[{gO2}]], conj[Se[{gI1}]], 
      Se[{gI1}]]] - 3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*
      Cp[USe[{gO1}], conj[USe[{gO2}]], conj[Su[{gI1}]], Su[{gI1}]]] - 
   sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*Cp[USe[{gO1}], conj[USe[{gO2}]], 
      conj[Sv[{gI1}]], Sv[{gI1}]]] + sum[gI1, 1, 6, 
    sum[gI2, 1, 2, B0[p^2, Mass2[Sv[{gI1}]], Mass2[Hpm[{gI2}]]]*
      conj[Cp[conj[USe[{gO2}]], Sv[{gI1}], Hpm[{gI2}]]]*
      Cp[conj[USe[{gO1}]], Sv[{gI1}], Hpm[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Se[{gI1}]], Mass2[Ah[{gI2}]]]*
      conj[Cp[conj[USe[{gO2}]], Se[{gI1}], Ah[{gI2}]]]*
      Cp[conj[USe[{gO1}]], Se[{gI1}], Ah[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Se[{gI1}]], Mass2[hh[{gI2}]]]*
      conj[Cp[conj[USe[{gO2}]], Se[{gI1}], hh[{gI2}]]]*
      Cp[conj[USe[{gO1}]], Se[{gI1}], hh[{gI2}]]]] + 
   sum[gI2, 1, 6, conj[Cp[conj[USe[{gO2}]], VP, Se[{gI2}]]]*
     Cp[conj[USe[{gO1}]], VP, Se[{gI2}]]*F0[p^2, Mass2[Se[{gI2}]], 0]] + 
   sum[gI2, 1, 6, conj[Cp[conj[USe[{gO2}]], VZ, Se[{gI2}]]]*
     Cp[conj[USe[{gO1}]], VZ, Se[{gI2}]]*F0[p^2, Mass2[Se[{gI2}]], 
      Mass2[VZ]]] + sum[gI2, 1, 6, conj[Cp[conj[USe[{gO2}]], VZp, Se[{gI2}]]]*
     Cp[conj[USe[{gO1}]], VZp, Se[{gI2}]]*F0[p^2, Mass2[Se[{gI2}]], 
      Mass2[VZp]]] + sum[gI2, 1, 6, 
    conj[Cp[conj[USe[{gO2}]], VWm, Sv[{gI2}]]]*Cp[conj[USe[{gO1}]], VWm, 
      Sv[{gI2}]]*F0[p^2, Mass2[Sv[{gI2}]], Mass2[VWm]]]}, 
 {hh, 2*(-rMS/2 + B0[p^2, Mass2[VZ], Mass2[VZ]])*conj[Cp[Uhh[{gO2}], VZ, VZ]]*
    Cp[Uhh[{gO1}], VZ, VZ] + 4*(-rMS/2 + B0[p^2, Mass2[VZ], Mass2[VZp]])*
    conj[Cp[Uhh[{gO2}], VZp, VZ]]*Cp[Uhh[{gO1}], VZp, VZ] + 
   2*(-rMS/2 + B0[p^2, Mass2[VZp], Mass2[VZp]])*
    conj[Cp[Uhh[{gO2}], VZp, VZp]]*Cp[Uhh[{gO1}], VZp, VZp] + 
   4*(-rMS/2 + B0[p^2, Mass2[VWm], Mass2[VWm]])*
    conj[Cp[Uhh[{gO2}], conj[VWm], VWm]]*Cp[Uhh[{gO1}], conj[VWm], VWm] - 
   B0[p^2, Mass2[gWm], Mass2[gWm]]*Cp[Uhh[{gO1}], bar[gWm], gWm]*
    Cp[Uhh[{gO2}], bar[gWm], gWm] - B0[p^2, Mass2[gWmC], Mass2[gWmC]]*
    Cp[Uhh[{gO1}], bar[gWmC], gWmC]*Cp[Uhh[{gO2}], bar[gWmC], gWmC] - 
   B0[p^2, Mass2[gZ], Mass2[gZ]]*Cp[Uhh[{gO1}], bar[gZ], gZ]*
    Cp[Uhh[{gO2}], bar[gZ], gZ] - 2*B0[p^2, Mass2[gZ], Mass2[gZp]]*
    Cp[Uhh[{gO1}], bar[gZp], gZ]*Cp[Uhh[{gO2}], bar[gZp], gZ] - 
   B0[p^2, Mass2[gZp], Mass2[gZp]]*Cp[Uhh[{gO1}], bar[gZp], gZp]*
    Cp[Uhh[{gO2}], bar[gZp], gZp] + 4*Cp[Uhh[{gO1}], Uhh[{gO2}], conj[VWm], 
     VWm]*(A0[Mass2[VWm]] - (rMS*Mass2[VWm])/2) + 
   2*Cp[Uhh[{gO1}], Uhh[{gO2}], VZ, VZ]*(A0[Mass2[VZ]] - (rMS*Mass2[VZ])/2) + 
   2*Cp[Uhh[{gO1}], Uhh[{gO2}], VZp, VZp]*(A0[Mass2[VZp]] - 
     (rMS*Mass2[VZp])/2) - sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*
     Cp[Uhh[{gO1}], Uhh[{gO2}], conj[Hpm[{gI1}]], Hpm[{gI1}]]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 2, B0[p^2, Mass2[Hpm[{gI1}]], 
       Mass2[Hpm[{gI2}]]]*conj[Cp[Uhh[{gO2}], conj[Hpm[{gI1}]], Hpm[{gI2}]]]*
      Cp[Uhh[{gO1}], conj[Hpm[{gI1}]], Hpm[{gI2}]]]] - 
   2*sum[gI1, 1, 2, Mass[Cha[{gI1}]]*sum[gI2, 1, 2, 
       B0[p^2, Mass2[Cha[{gI1}]], Mass2[Cha[{gI2}]]]*Mass[Cha[{gI2}]]*
        (conj[Cp[Uhh[{gO2}], bar[Cha[{gI1}]], Cha[{gI2}]][PR]]*
          Cp[Uhh[{gO1}], bar[Cha[{gI1}]], Cha[{gI2}]][PL] + 
         conj[Cp[Uhh[{gO2}], bar[Cha[{gI1}]], Cha[{gI2}]][PL]]*
          Cp[Uhh[{gO1}], bar[Cha[{gI1}]], Cha[{gI2}]][PR])]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 2, G0[p^2, Mass2[Cha[{gI1}]], 
       Mass2[Cha[{gI2}]]]*(conj[Cp[Uhh[{gO2}], bar[Cha[{gI1}]], Cha[{gI2}]][
          PL]]*Cp[Uhh[{gO1}], bar[Cha[{gI1}]], Cha[{gI2}]][PL] + 
       conj[Cp[Uhh[{gO2}], bar[Cha[{gI1}]], Cha[{gI2}]][PR]]*
        Cp[Uhh[{gO1}], bar[Cha[{gI1}]], Cha[{gI2}]][PR])]] - 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[Uhh[{gO1}], Uhh[{gO2}], Ah[{gI1}], 
       Ah[{gI1}]]]/2 - sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*
      Cp[Uhh[{gO1}], Uhh[{gO2}], hh[{gI1}], hh[{gI1}]]]/2 + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, B0[p^2, Mass2[Ah[{gI1}]], Mass2[Ah[{gI2}]]]*
       conj[Cp[Uhh[{gO2}], Ah[{gI1}], Ah[{gI2}]]]*Cp[Uhh[{gO1}], Ah[{gI1}], 
        Ah[{gI2}]]]]/2 + sum[gI1, 1, 3, sum[gI2, 1, 3, 
     B0[p^2, Mass2[hh[{gI1}]], Mass2[Ah[{gI2}]]]*
      conj[Cp[Uhh[{gO2}], hh[{gI1}], Ah[{gI2}]]]*Cp[Uhh[{gO1}], hh[{gI1}], 
       Ah[{gI2}]]]] + sum[gI1, 1, 3, sum[gI2, 1, 3, 
      B0[p^2, Mass2[hh[{gI1}]], Mass2[hh[{gI2}]]]*
       conj[Cp[Uhh[{gO2}], hh[{gI1}], hh[{gI2}]]]*Cp[Uhh[{gO1}], hh[{gI1}], 
        hh[{gI2}]]]]/2 - 6*sum[gI1, 1, 3, Mass[Fd[{gI1}]]*
      sum[gI2, 1, 3, B0[p^2, Mass2[Fd[{gI1}]], Mass2[Fd[{gI2}]]]*
        Mass[Fd[{gI2}]]*(conj[Cp[Uhh[{gO2}], bar[Fd[{gI1}]], Fd[{gI2}]][PR]]*
          Cp[Uhh[{gO1}], bar[Fd[{gI1}]], Fd[{gI2}]][PL] + 
         conj[Cp[Uhh[{gO2}], bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[Uhh[{gO1}], bar[Fd[{gI1}]], Fd[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fd[{gI1}]], 
        Mass2[Fd[{gI2}]]]*(conj[Cp[Uhh[{gO2}], bar[Fd[{gI1}]], Fd[{gI2}]][
           PL]]*Cp[Uhh[{gO1}], bar[Fd[{gI1}]], Fd[{gI2}]][PL] + 
        conj[Cp[Uhh[{gO2}], bar[Fd[{gI1}]], Fd[{gI2}]][PR]]*
         Cp[Uhh[{gO1}], bar[Fd[{gI1}]], Fd[{gI2}]][PR])]] - 
   2*sum[gI1, 1, 3, Mass[Fe[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*Mass[Fe[{gI2}]]*
        (conj[Cp[Uhh[{gO2}], bar[Fe[{gI1}]], Fe[{gI2}]][PR]]*
          Cp[Uhh[{gO1}], bar[Fe[{gI1}]], Fe[{gI2}]][PL] + 
         conj[Cp[Uhh[{gO2}], bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
          Cp[Uhh[{gO1}], bar[Fe[{gI1}]], Fe[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*
      (conj[Cp[Uhh[{gO2}], bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
        Cp[Uhh[{gO1}], bar[Fe[{gI1}]], Fe[{gI2}]][PL] + 
       conj[Cp[Uhh[{gO2}], bar[Fe[{gI1}]], Fe[{gI2}]][PR]]*
        Cp[Uhh[{gO1}], bar[Fe[{gI1}]], Fe[{gI2}]][PR])]] - 
   6*sum[gI1, 1, 3, Mass[Fu[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fu[{gI1}]], Mass2[Fu[{gI2}]]]*Mass[Fu[{gI2}]]*
        (conj[Cp[Uhh[{gO2}], bar[Fu[{gI1}]], Fu[{gI2}]][PR]]*
          Cp[Uhh[{gO1}], bar[Fu[{gI1}]], Fu[{gI2}]][PL] + 
         conj[Cp[Uhh[{gO2}], bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[Uhh[{gO1}], bar[Fu[{gI1}]], Fu[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fu[{gI1}]], 
        Mass2[Fu[{gI2}]]]*(conj[Cp[Uhh[{gO2}], bar[Fu[{gI1}]], Fu[{gI2}]][
           PL]]*Cp[Uhh[{gO1}], bar[Fu[{gI1}]], Fu[{gI2}]][PL] + 
        conj[Cp[Uhh[{gO2}], bar[Fu[{gI1}]], Fu[{gI2}]][PR]]*
         Cp[Uhh[{gO1}], bar[Fu[{gI1}]], Fu[{gI2}]][PR])]] - 
   2*sum[gI1, 1, 3, Mass[Fv[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fv[{gI1}]], Mass2[Fv[{gI2}]]]*Mass[Fv[{gI2}]]*
        (conj[Cp[Uhh[{gO2}], bar[Fv[{gI1}]], Fv[{gI2}]][PR]]*
          Cp[Uhh[{gO1}], bar[Fv[{gI1}]], Fv[{gI2}]][PL] + 
         conj[Cp[Uhh[{gO2}], bar[Fv[{gI1}]], Fv[{gI2}]][PL]]*
          Cp[Uhh[{gO1}], bar[Fv[{gI1}]], Fv[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fv[{gI1}]], Mass2[Fv[{gI2}]]]*
      (conj[Cp[Uhh[{gO2}], bar[Fv[{gI1}]], Fv[{gI2}]][PL]]*
        Cp[Uhh[{gO1}], bar[Fv[{gI1}]], Fv[{gI2}]][PL] + 
       conj[Cp[Uhh[{gO2}], bar[Fv[{gI1}]], Fv[{gI2}]][PR]]*
        Cp[Uhh[{gO1}], bar[Fv[{gI1}]], Fv[{gI2}]][PR])]] - 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[Uhh[{gO1}], Uhh[{gO2}], 
       conj[Sd[{gI1}]], Sd[{gI1}]]] - sum[gI1, 1, 6, 
    A0[Mass2[Se[{gI1}]]]*Cp[Uhh[{gO1}], Uhh[{gO2}], conj[Se[{gI1}]], 
      Se[{gI1}]]] - 3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*
      Cp[Uhh[{gO1}], Uhh[{gO2}], conj[Su[{gI1}]], Su[{gI1}]]] - 
   sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*Cp[Uhh[{gO1}], Uhh[{gO2}], 
      conj[Sv[{gI1}]], Sv[{gI1}]]] + 
   3*sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Sd[{gI1}]], 
        Mass2[Sd[{gI2}]]]*conj[Cp[Uhh[{gO2}], conj[Sd[{gI1}]], Sd[{gI2}]]]*
       Cp[Uhh[{gO1}], conj[Sd[{gI1}]], Sd[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Se[{gI1}]], Mass2[Se[{gI2}]]]*
      conj[Cp[Uhh[{gO2}], conj[Se[{gI1}]], Se[{gI2}]]]*
      Cp[Uhh[{gO1}], conj[Se[{gI1}]], Se[{gI2}]]]] + 
   3*sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Su[{gI1}]], 
        Mass2[Su[{gI2}]]]*conj[Cp[Uhh[{gO2}], conj[Su[{gI1}]], Su[{gI2}]]]*
       Cp[Uhh[{gO1}], conj[Su[{gI1}]], Su[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Sv[{gI1}]], Mass2[Sv[{gI2}]]]*
      conj[Cp[Uhh[{gO2}], conj[Sv[{gI1}]], Sv[{gI2}]]]*
      Cp[Uhh[{gO1}], conj[Sv[{gI1}]], Sv[{gI2}]]]] - 
   sum[gI1, 1, 6, Mass[Chi[{gI1}]]*sum[gI2, 1, 6, 
      B0[p^2, Mass2[Chi[{gI1}]], Mass2[Chi[{gI2}]]]*Mass[Chi[{gI2}]]*
       (conj[Cp[Uhh[{gO2}], Chi[{gI1}], Chi[{gI2}]][PR]]*
         Cp[Uhh[{gO1}], Chi[{gI1}], Chi[{gI2}]][PL] + 
        conj[Cp[Uhh[{gO2}], Chi[{gI1}], Chi[{gI2}]][PL]]*
         Cp[Uhh[{gO1}], Chi[{gI1}], Chi[{gI2}]][PR])]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 6, G0[p^2, Mass2[Chi[{gI1}]], 
        Mass2[Chi[{gI2}]]]*(conj[Cp[Uhh[{gO2}], Chi[{gI1}], Chi[{gI2}]][PL]]*
         Cp[Uhh[{gO1}], Chi[{gI1}], Chi[{gI2}]][PL] + 
        conj[Cp[Uhh[{gO2}], Chi[{gI1}], Chi[{gI2}]][PR]]*
         Cp[Uhh[{gO1}], Chi[{gI1}], Chi[{gI2}]][PR])]]/2 + 
   2*sum[gI2, 1, 2, conj[Cp[Uhh[{gO2}], conj[VWm], Hpm[{gI2}]]]*
      Cp[Uhh[{gO1}], conj[VWm], Hpm[{gI2}]]*F0[p^2, Mass2[Hpm[{gI2}]], 
       Mass2[VWm]]] + sum[gI2, 1, 3, conj[Cp[Uhh[{gO2}], VZ, Ah[{gI2}]]]*
     Cp[Uhh[{gO1}], VZ, Ah[{gI2}]]*F0[p^2, Mass2[Ah[{gI2}]], Mass2[VZ]]] + 
   sum[gI2, 1, 3, conj[Cp[Uhh[{gO2}], VZp, Ah[{gI2}]]]*
     Cp[Uhh[{gO1}], VZp, Ah[{gI2}]]*F0[p^2, Mass2[Ah[{gI2}]], Mass2[VZp]]]}, 
 {Ah, -(B0[p^2, Mass2[gWm], Mass2[gWm]]*Cp[UAh[{gO1}], bar[gWm], gWm]*
     Cp[UAh[{gO2}], bar[gWm], gWm]) - B0[p^2, Mass2[gWmC], Mass2[gWmC]]*
    Cp[UAh[{gO1}], bar[gWmC], gWmC]*Cp[UAh[{gO2}], bar[gWmC], gWmC] + 
   4*Cp[UAh[{gO1}], UAh[{gO2}], conj[VWm], VWm]*(A0[Mass2[VWm]] - 
     (rMS*Mass2[VWm])/2) + 2*Cp[UAh[{gO1}], UAh[{gO2}], VZ, VZ]*
    (A0[Mass2[VZ]] - (rMS*Mass2[VZ])/2) + 
   2*Cp[UAh[{gO1}], UAh[{gO2}], VZp, VZp]*(A0[Mass2[VZp]] - 
     (rMS*Mass2[VZp])/2) - sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*
     Cp[UAh[{gO1}], UAh[{gO2}], conj[Hpm[{gI1}]], Hpm[{gI1}]]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 2, B0[p^2, Mass2[Hpm[{gI1}]], 
       Mass2[Hpm[{gI2}]]]*conj[Cp[UAh[{gO2}], conj[Hpm[{gI1}]], Hpm[{gI2}]]]*
      Cp[UAh[{gO1}], conj[Hpm[{gI1}]], Hpm[{gI2}]]]] - 
   2*sum[gI1, 1, 2, Mass[Cha[{gI1}]]*sum[gI2, 1, 2, 
       B0[p^2, Mass2[Cha[{gI1}]], Mass2[Cha[{gI2}]]]*Mass[Cha[{gI2}]]*
        (conj[Cp[UAh[{gO2}], bar[Cha[{gI1}]], Cha[{gI2}]][PR]]*
          Cp[UAh[{gO1}], bar[Cha[{gI1}]], Cha[{gI2}]][PL] + 
         conj[Cp[UAh[{gO2}], bar[Cha[{gI1}]], Cha[{gI2}]][PL]]*
          Cp[UAh[{gO1}], bar[Cha[{gI1}]], Cha[{gI2}]][PR])]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 2, G0[p^2, Mass2[Cha[{gI1}]], 
       Mass2[Cha[{gI2}]]]*(conj[Cp[UAh[{gO2}], bar[Cha[{gI1}]], Cha[{gI2}]][
          PL]]*Cp[UAh[{gO1}], bar[Cha[{gI1}]], Cha[{gI2}]][PL] + 
       conj[Cp[UAh[{gO2}], bar[Cha[{gI1}]], Cha[{gI2}]][PR]]*
        Cp[UAh[{gO1}], bar[Cha[{gI1}]], Cha[{gI2}]][PR])]] - 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[UAh[{gO1}], UAh[{gO2}], Ah[{gI1}], 
       Ah[{gI1}]]]/2 - sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*
      Cp[UAh[{gO1}], UAh[{gO2}], hh[{gI1}], hh[{gI1}]]]/2 + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, B0[p^2, Mass2[Ah[{gI1}]], Mass2[Ah[{gI2}]]]*
       conj[Cp[UAh[{gO2}], Ah[{gI1}], Ah[{gI2}]]]*Cp[UAh[{gO1}], Ah[{gI1}], 
        Ah[{gI2}]]]]/2 + sum[gI1, 1, 3, sum[gI2, 1, 3, 
     B0[p^2, Mass2[hh[{gI1}]], Mass2[Ah[{gI2}]]]*
      conj[Cp[UAh[{gO2}], hh[{gI1}], Ah[{gI2}]]]*Cp[UAh[{gO1}], hh[{gI1}], 
       Ah[{gI2}]]]] + sum[gI1, 1, 3, sum[gI2, 1, 3, 
      B0[p^2, Mass2[hh[{gI1}]], Mass2[hh[{gI2}]]]*
       conj[Cp[UAh[{gO2}], hh[{gI1}], hh[{gI2}]]]*Cp[UAh[{gO1}], hh[{gI1}], 
        hh[{gI2}]]]]/2 - 6*sum[gI1, 1, 3, Mass[Fd[{gI1}]]*
      sum[gI2, 1, 3, B0[p^2, Mass2[Fd[{gI1}]], Mass2[Fd[{gI2}]]]*
        Mass[Fd[{gI2}]]*(conj[Cp[UAh[{gO2}], bar[Fd[{gI1}]], Fd[{gI2}]][PR]]*
          Cp[UAh[{gO1}], bar[Fd[{gI1}]], Fd[{gI2}]][PL] + 
         conj[Cp[UAh[{gO2}], bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[UAh[{gO1}], bar[Fd[{gI1}]], Fd[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fd[{gI1}]], 
        Mass2[Fd[{gI2}]]]*(conj[Cp[UAh[{gO2}], bar[Fd[{gI1}]], Fd[{gI2}]][
           PL]]*Cp[UAh[{gO1}], bar[Fd[{gI1}]], Fd[{gI2}]][PL] + 
        conj[Cp[UAh[{gO2}], bar[Fd[{gI1}]], Fd[{gI2}]][PR]]*
         Cp[UAh[{gO1}], bar[Fd[{gI1}]], Fd[{gI2}]][PR])]] - 
   2*sum[gI1, 1, 3, Mass[Fe[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*Mass[Fe[{gI2}]]*
        (conj[Cp[UAh[{gO2}], bar[Fe[{gI1}]], Fe[{gI2}]][PR]]*
          Cp[UAh[{gO1}], bar[Fe[{gI1}]], Fe[{gI2}]][PL] + 
         conj[Cp[UAh[{gO2}], bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
          Cp[UAh[{gO1}], bar[Fe[{gI1}]], Fe[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*
      (conj[Cp[UAh[{gO2}], bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
        Cp[UAh[{gO1}], bar[Fe[{gI1}]], Fe[{gI2}]][PL] + 
       conj[Cp[UAh[{gO2}], bar[Fe[{gI1}]], Fe[{gI2}]][PR]]*
        Cp[UAh[{gO1}], bar[Fe[{gI1}]], Fe[{gI2}]][PR])]] - 
   6*sum[gI1, 1, 3, Mass[Fu[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fu[{gI1}]], Mass2[Fu[{gI2}]]]*Mass[Fu[{gI2}]]*
        (conj[Cp[UAh[{gO2}], bar[Fu[{gI1}]], Fu[{gI2}]][PR]]*
          Cp[UAh[{gO1}], bar[Fu[{gI1}]], Fu[{gI2}]][PL] + 
         conj[Cp[UAh[{gO2}], bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[UAh[{gO1}], bar[Fu[{gI1}]], Fu[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fu[{gI1}]], 
        Mass2[Fu[{gI2}]]]*(conj[Cp[UAh[{gO2}], bar[Fu[{gI1}]], Fu[{gI2}]][
           PL]]*Cp[UAh[{gO1}], bar[Fu[{gI1}]], Fu[{gI2}]][PL] + 
        conj[Cp[UAh[{gO2}], bar[Fu[{gI1}]], Fu[{gI2}]][PR]]*
         Cp[UAh[{gO1}], bar[Fu[{gI1}]], Fu[{gI2}]][PR])]] - 
   2*sum[gI1, 1, 3, Mass[Fv[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fv[{gI1}]], Mass2[Fv[{gI2}]]]*Mass[Fv[{gI2}]]*
        (conj[Cp[UAh[{gO2}], bar[Fv[{gI1}]], Fv[{gI2}]][PR]]*
          Cp[UAh[{gO1}], bar[Fv[{gI1}]], Fv[{gI2}]][PL] + 
         conj[Cp[UAh[{gO2}], bar[Fv[{gI1}]], Fv[{gI2}]][PL]]*
          Cp[UAh[{gO1}], bar[Fv[{gI1}]], Fv[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fv[{gI1}]], Mass2[Fv[{gI2}]]]*
      (conj[Cp[UAh[{gO2}], bar[Fv[{gI1}]], Fv[{gI2}]][PL]]*
        Cp[UAh[{gO1}], bar[Fv[{gI1}]], Fv[{gI2}]][PL] + 
       conj[Cp[UAh[{gO2}], bar[Fv[{gI1}]], Fv[{gI2}]][PR]]*
        Cp[UAh[{gO1}], bar[Fv[{gI1}]], Fv[{gI2}]][PR])]] - 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[UAh[{gO1}], UAh[{gO2}], 
       conj[Sd[{gI1}]], Sd[{gI1}]]] - sum[gI1, 1, 6, 
    A0[Mass2[Se[{gI1}]]]*Cp[UAh[{gO1}], UAh[{gO2}], conj[Se[{gI1}]], 
      Se[{gI1}]]] - 3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*
      Cp[UAh[{gO1}], UAh[{gO2}], conj[Su[{gI1}]], Su[{gI1}]]] - 
   sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*Cp[UAh[{gO1}], UAh[{gO2}], 
      conj[Sv[{gI1}]], Sv[{gI1}]]] + 
   3*sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Sd[{gI1}]], 
        Mass2[Sd[{gI2}]]]*conj[Cp[UAh[{gO2}], conj[Sd[{gI1}]], Sd[{gI2}]]]*
       Cp[UAh[{gO1}], conj[Sd[{gI1}]], Sd[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Se[{gI1}]], Mass2[Se[{gI2}]]]*
      conj[Cp[UAh[{gO2}], conj[Se[{gI1}]], Se[{gI2}]]]*
      Cp[UAh[{gO1}], conj[Se[{gI1}]], Se[{gI2}]]]] + 
   3*sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Su[{gI1}]], 
        Mass2[Su[{gI2}]]]*conj[Cp[UAh[{gO2}], conj[Su[{gI1}]], Su[{gI2}]]]*
       Cp[UAh[{gO1}], conj[Su[{gI1}]], Su[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Sv[{gI1}]], Mass2[Sv[{gI2}]]]*
      conj[Cp[UAh[{gO2}], conj[Sv[{gI1}]], Sv[{gI2}]]]*
      Cp[UAh[{gO1}], conj[Sv[{gI1}]], Sv[{gI2}]]]] - 
   sum[gI1, 1, 6, Mass[Chi[{gI1}]]*sum[gI2, 1, 6, 
      B0[p^2, Mass2[Chi[{gI1}]], Mass2[Chi[{gI2}]]]*Mass[Chi[{gI2}]]*
       (conj[Cp[UAh[{gO2}], Chi[{gI1}], Chi[{gI2}]][PR]]*
         Cp[UAh[{gO1}], Chi[{gI1}], Chi[{gI2}]][PL] + 
        conj[Cp[UAh[{gO2}], Chi[{gI1}], Chi[{gI2}]][PL]]*
         Cp[UAh[{gO1}], Chi[{gI1}], Chi[{gI2}]][PR])]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 6, G0[p^2, Mass2[Chi[{gI1}]], 
        Mass2[Chi[{gI2}]]]*(conj[Cp[UAh[{gO2}], Chi[{gI1}], Chi[{gI2}]][PL]]*
         Cp[UAh[{gO1}], Chi[{gI1}], Chi[{gI2}]][PL] + 
        conj[Cp[UAh[{gO2}], Chi[{gI1}], Chi[{gI2}]][PR]]*
         Cp[UAh[{gO1}], Chi[{gI1}], Chi[{gI2}]][PR])]]/2 + 
   2*sum[gI2, 1, 2, conj[Cp[UAh[{gO2}], conj[VWm], Hpm[{gI2}]]]*
      Cp[UAh[{gO1}], conj[VWm], Hpm[{gI2}]]*F0[p^2, Mass2[Hpm[{gI2}]], 
       Mass2[VWm]]] + sum[gI2, 1, 3, conj[Cp[UAh[{gO2}], VZ, hh[{gI2}]]]*
     Cp[UAh[{gO1}], VZ, hh[{gI2}]]*F0[p^2, Mass2[hh[{gI2}]], Mass2[VZ]]] + 
   sum[gI2, 1, 3, conj[Cp[UAh[{gO2}], VZp, hh[{gI2}]]]*
     Cp[UAh[{gO1}], VZp, hh[{gI2}]]*F0[p^2, Mass2[hh[{gI2}]], Mass2[VZp]]]}, 
 {Hpm, 4*(-rMS/2 + B0[p^2, 0, Mass2[VWm]])*
    conj[Cp[conj[UHpm[{gO2}]], VWm, VP]]*Cp[conj[UHpm[{gO1}]], VWm, VP] + 
   4*(-rMS/2 + B0[p^2, Mass2[VWm], Mass2[VZ]])*
    conj[Cp[conj[UHpm[{gO2}]], VZ, VWm]]*Cp[conj[UHpm[{gO1}]], VZ, VWm] + 
   4*(-rMS/2 + B0[p^2, Mass2[VWm], Mass2[VZp]])*
    conj[Cp[conj[UHpm[{gO2}]], VZp, VWm]]*Cp[conj[UHpm[{gO1}]], VZp, VWm] - 
   B0[p^2, Mass2[gZ], Mass2[gWmC]]*Cp[conj[UHpm[{gO1}]], bar[gWmC], gZ]*
    Cp[UHpm[{gO2}], gWmC, bar[gZ]] - B0[p^2, Mass2[gZp], Mass2[gWmC]]*
    Cp[conj[UHpm[{gO1}]], bar[gWmC], gZp]*Cp[UHpm[{gO2}], gWmC, bar[gZp]] - 
   B0[p^2, Mass2[gWm], Mass2[gZ]]*Cp[conj[UHpm[{gO1}]], bar[gZ], gWm]*
    Cp[UHpm[{gO2}], gZ, bar[gWm]] - B0[p^2, Mass2[gWm], Mass2[gZp]]*
    Cp[conj[UHpm[{gO1}]], bar[gZp], gWm]*Cp[UHpm[{gO2}], gZp, bar[gWm]] + 
   4*Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], conj[VWm], VWm]*
    (A0[Mass2[VWm]] - (rMS*Mass2[VWm])/2) + 
   2*Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], VZ, VZ]*
    (A0[Mass2[VZ]] - (rMS*Mass2[VZ])/2) + 
   2*Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], VZp, VZp]*
    (A0[Mass2[VZp]] - (rMS*Mass2[VZp])/2) - 
   sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], 
      conj[Hpm[{gI1}]], Hpm[{gI1}]]] + sum[gI1, 1, 2, 
    sum[gI2, 1, 3, B0[p^2, Mass2[Hpm[{gI1}]], Mass2[Ah[{gI2}]]]*
      conj[Cp[conj[UHpm[{gO2}]], Hpm[{gI1}], Ah[{gI2}]]]*
      Cp[conj[UHpm[{gO1}]], Hpm[{gI1}], Ah[{gI2}]]]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 3, B0[p^2, Mass2[Hpm[{gI1}]], Mass2[hh[{gI2}]]]*
      conj[Cp[conj[UHpm[{gO2}]], Hpm[{gI1}], hh[{gI2}]]]*
      Cp[conj[UHpm[{gO1}]], Hpm[{gI1}], hh[{gI2}]]]] - 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], 
       Ah[{gI1}], Ah[{gI1}]]]/2 - 
   sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], 
       hh[{gI1}], hh[{gI1}]]]/2 - 
   6*sum[gI1, 1, 3, Mass[Fu[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fu[{gI1}]], Mass2[Fd[{gI2}]]]*Mass[Fd[{gI2}]]*
        (conj[Cp[conj[UHpm[{gO2}]], bar[Fu[{gI1}]], Fd[{gI2}]][PR]]*
          Cp[conj[UHpm[{gO1}]], bar[Fu[{gI1}]], Fd[{gI2}]][PL] + 
         conj[Cp[conj[UHpm[{gO2}]], bar[Fu[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[conj[UHpm[{gO1}]], bar[Fu[{gI1}]], Fd[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fu[{gI1}]], 
        Mass2[Fd[{gI2}]]]*(conj[Cp[conj[UHpm[{gO2}]], bar[Fu[{gI1}]], 
            Fd[{gI2}]][PL]]*Cp[conj[UHpm[{gO1}]], bar[Fu[{gI1}]], Fd[{gI2}]][
          PL] + conj[Cp[conj[UHpm[{gO2}]], bar[Fu[{gI1}]], Fd[{gI2}]][PR]]*
         Cp[conj[UHpm[{gO1}]], bar[Fu[{gI1}]], Fd[{gI2}]][PR])]] - 
   2*sum[gI1, 1, 3, Mass[Fv[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fv[{gI1}]], Mass2[Fe[{gI2}]]]*Mass[Fe[{gI2}]]*
        (conj[Cp[conj[UHpm[{gO2}]], bar[Fv[{gI1}]], Fe[{gI2}]][PR]]*
          Cp[conj[UHpm[{gO1}]], bar[Fv[{gI1}]], Fe[{gI2}]][PL] + 
         conj[Cp[conj[UHpm[{gO2}]], bar[Fv[{gI1}]], Fe[{gI2}]][PL]]*
          Cp[conj[UHpm[{gO1}]], bar[Fv[{gI1}]], Fe[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, G0[p^2, Mass2[Fv[{gI1}]], Mass2[Fe[{gI2}]]]*
      (conj[Cp[conj[UHpm[{gO2}]], bar[Fv[{gI1}]], Fe[{gI2}]][PL]]*
        Cp[conj[UHpm[{gO1}]], bar[Fv[{gI1}]], Fe[{gI2}]][PL] + 
       conj[Cp[conj[UHpm[{gO2}]], bar[Fv[{gI1}]], Fe[{gI2}]][PR]]*
        Cp[conj[UHpm[{gO1}]], bar[Fv[{gI1}]], Fe[{gI2}]][PR])]] - 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], 
       conj[Sd[{gI1}]], Sd[{gI1}]]] - sum[gI1, 1, 6, 
    A0[Mass2[Se[{gI1}]]]*Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], conj[Se[{gI1}]], 
      Se[{gI1}]]] - 3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*
      Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], conj[Su[{gI1}]], Su[{gI1}]]] - 
   sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*Cp[UHpm[{gO1}], conj[UHpm[{gO2}]], 
      conj[Sv[{gI1}]], Sv[{gI1}]]] - 
   2*sum[gI1, 1, 6, Mass[Chi[{gI1}]]*sum[gI2, 1, 2, 
       B0[p^2, Mass2[Chi[{gI1}]], Mass2[Cha[{gI2}]]]*Mass[Cha[{gI2}]]*
        (conj[Cp[conj[UHpm[{gO2}]], Chi[{gI1}], Cha[{gI2}]][PR]]*
          Cp[conj[UHpm[{gO1}]], Chi[{gI1}], Cha[{gI2}]][PL] + 
         conj[Cp[conj[UHpm[{gO2}]], Chi[{gI1}], Cha[{gI2}]][PL]]*
          Cp[conj[UHpm[{gO1}]], Chi[{gI1}], Cha[{gI2}]][PR])]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 2, G0[p^2, Mass2[Chi[{gI1}]], 
       Mass2[Cha[{gI2}]]]*(conj[Cp[conj[UHpm[{gO2}]], Chi[{gI1}], Cha[{gI2}]][
          PL]]*Cp[conj[UHpm[{gO1}]], Chi[{gI1}], Cha[{gI2}]][PL] + 
       conj[Cp[conj[UHpm[{gO2}]], Chi[{gI1}], Cha[{gI2}]][PR]]*
        Cp[conj[UHpm[{gO1}]], Chi[{gI1}], Cha[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Su[{gI1}]], 
        Mass2[Sd[{gI2}]]]*conj[Cp[conj[UHpm[{gO2}]], conj[Su[{gI1}]], 
         Sd[{gI2}]]]*Cp[conj[UHpm[{gO1}]], conj[Su[{gI1}]], Sd[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Sv[{gI1}]], Mass2[Se[{gI2}]]]*
      conj[Cp[conj[UHpm[{gO2}]], conj[Sv[{gI1}]], Se[{gI2}]]]*
      Cp[conj[UHpm[{gO1}]], conj[Sv[{gI1}]], Se[{gI2}]]]] + 
   sum[gI2, 1, 2, conj[Cp[conj[UHpm[{gO2}]], VP, Hpm[{gI2}]]]*
     Cp[conj[UHpm[{gO1}]], VP, Hpm[{gI2}]]*F0[p^2, Mass2[Hpm[{gI2}]], 0]] + 
   sum[gI2, 1, 2, conj[Cp[conj[UHpm[{gO2}]], VZ, Hpm[{gI2}]]]*
     Cp[conj[UHpm[{gO1}]], VZ, Hpm[{gI2}]]*F0[p^2, Mass2[Hpm[{gI2}]], 
      Mass2[VZ]]] + sum[gI2, 1, 2, 
    conj[Cp[conj[UHpm[{gO2}]], VZp, Hpm[{gI2}]]]*Cp[conj[UHpm[{gO1}]], VZp, 
      Hpm[{gI2}]]*F0[p^2, Mass2[Hpm[{gI2}]], Mass2[VZp]]] + 
   sum[gI2, 1, 3, conj[Cp[conj[UHpm[{gO2}]], VWm, Ah[{gI2}]]]*
     Cp[conj[UHpm[{gO1}]], VWm, Ah[{gI2}]]*F0[p^2, Mass2[Ah[{gI2}]], 
      Mass2[VWm]]] + sum[gI2, 1, 3, 
    conj[Cp[conj[UHpm[{gO2}]], VWm, hh[{gI2}]]]*Cp[conj[UHpm[{gO1}]], VWm, 
      hh[{gI2}]]*F0[p^2, Mass2[hh[{gI2}]], Mass2[VWm]]]}, 
 {L0, {sum[gI1, 1, 2, Mass[Cha[{gI1}]]*sum[gI2, 1, 2, 
       B0[p^2, Mass2[Cha[{gI1}]], Mass2[Hpm[{gI2}]]]*
        conj[Cp[UChi[{gO2}], bar[Cha[{gI1}]], Hpm[{gI2}]][PL]]*
        Cp[UChi[{gO1}], bar[Cha[{gI1}]], Hpm[{gI2}]][PR]]] + 
    sum[gI1, 1, 2, sum[gI2, 1, 2, B0[p^2, Mass2[Cha[{gI2}]], 
        Mass2[Hpm[{gI1}]]]*conj[Cp[UChi[{gO2}], conj[Hpm[{gI1}]], Cha[{gI2}]][
         PL]]*Mass[Cha[{gI2}]]*Cp[UChi[{gO1}], conj[Hpm[{gI1}]], Cha[{gI2}]][
        PR]]] - 4*sum[gI1, 1, 2, (-rMS/2 + B0[p^2, Mass2[Cha[{gI1}]], 
         Mass2[VWm]])*conj[Cp[UChi[{gO2}], bar[Cha[{gI1}]], VWm][PR]]*
       Mass[Cha[{gI1}]]*Cp[UChi[{gO1}], bar[Cha[{gI1}]], VWm][PL]] + 
    3*sum[gI1, 1, 3, Mass[Fd[{gI1}]]*sum[gI2, 1, 6, 
        B0[p^2, Mass2[Fd[{gI1}]], Mass2[Sd[{gI2}]]]*
         conj[Cp[UChi[{gO2}], bar[Fd[{gI1}]], Sd[{gI2}]][PL]]*
         Cp[UChi[{gO1}], bar[Fd[{gI1}]], Sd[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, Mass[Fe[{gI1}]]*sum[gI2, 1, 6, 
       B0[p^2, Mass2[Fe[{gI1}]], Mass2[Se[{gI2}]]]*
        conj[Cp[UChi[{gO2}], bar[Fe[{gI1}]], Se[{gI2}]][PL]]*
        Cp[UChi[{gO1}], bar[Fe[{gI1}]], Se[{gI2}]][PR]]] + 
    3*sum[gI1, 1, 3, Mass[Fu[{gI1}]]*sum[gI2, 1, 6, 
        B0[p^2, Mass2[Fu[{gI1}]], Mass2[Su[{gI2}]]]*
         conj[Cp[UChi[{gO2}], bar[Fu[{gI1}]], Su[{gI2}]][PL]]*
         Cp[UChi[{gO1}], bar[Fu[{gI1}]], Su[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, Mass[Fv[{gI1}]]*sum[gI2, 1, 6, 
       B0[p^2, Mass2[Fv[{gI1}]], Mass2[Sv[{gI2}]]]*
        conj[Cp[UChi[{gO2}], bar[Fv[{gI1}]], Sv[{gI2}]][PL]]*
        Cp[UChi[{gO1}], bar[Fv[{gI1}]], Sv[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, sum[gI2, 1, 6, B0[p^2, Mass2[Chi[{gI2}]], 
        Mass2[hh[{gI1}]]]*conj[Cp[UChi[{gO2}], hh[{gI1}], Chi[{gI2}]][PL]]*
       Mass[Chi[{gI2}]]*Cp[UChi[{gO1}], hh[{gI1}], Chi[{gI2}]][PR]]] + 
    sum[gI1, 1, 6, Mass[Chi[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Chi[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[UChi[{gO2}], Chi[{gI1}], Ah[{gI2}]][PL]]*
        Cp[UChi[{gO1}], Chi[{gI1}], Ah[{gI2}]][PR]]] + 
    3*sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Fd[{gI2}]], 
         Mass2[Sd[{gI1}]]]*conj[Cp[UChi[{gO2}], conj[Sd[{gI1}]], Fd[{gI2}]][
          PL]]*Mass[Fd[{gI2}]]*Cp[UChi[{gO1}], conj[Sd[{gI1}]], Fd[{gI2}]][
         PR]]] + sum[gI1, 1, 6, sum[gI2, 1, 3, 
      B0[p^2, Mass2[Fe[{gI2}]], Mass2[Se[{gI1}]]]*
       conj[Cp[UChi[{gO2}], conj[Se[{gI1}]], Fe[{gI2}]][PL]]*Mass[Fe[{gI2}]]*
       Cp[UChi[{gO1}], conj[Se[{gI1}]], Fe[{gI2}]][PR]]] + 
    3*sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Fu[{gI2}]], 
         Mass2[Su[{gI1}]]]*conj[Cp[UChi[{gO2}], conj[Su[{gI1}]], Fu[{gI2}]][
          PL]]*Mass[Fu[{gI2}]]*Cp[UChi[{gO1}], conj[Su[{gI1}]], Fu[{gI2}]][
         PR]]] + sum[gI1, 1, 6, sum[gI2, 1, 3, 
      B0[p^2, Mass2[Fv[{gI2}]], Mass2[Sv[{gI1}]]]*
       conj[Cp[UChi[{gO2}], conj[Sv[{gI1}]], Fv[{gI2}]][PL]]*Mass[Fv[{gI2}]]*
       Cp[UChi[{gO1}], conj[Sv[{gI1}]], Fv[{gI2}]][PR]]] - 
    4*sum[gI2, 1, 2, (-rMS/2 + B0[p^2, Mass2[Cha[{gI2}]], Mass2[VWm]])*
       conj[Cp[UChi[{gO2}], conj[VWm], Cha[{gI2}]][PR]]*Mass[Cha[{gI2}]]*
       Cp[UChi[{gO1}], conj[VWm], Cha[{gI2}]][PL]] - 
    4*sum[gI2, 1, 6, (-rMS/2 + B0[p^2, Mass2[Chi[{gI2}]], Mass2[VZ]])*
       conj[Cp[UChi[{gO2}], VZ, Chi[{gI2}]][PR]]*Mass[Chi[{gI2}]]*
       Cp[UChi[{gO1}], VZ, Chi[{gI2}]][PL]] - 
    4*sum[gI2, 1, 6, (-rMS/2 + B0[p^2, Mass2[Chi[{gI2}]], Mass2[VZp]])*
       conj[Cp[UChi[{gO2}], VZp, Chi[{gI2}]][PR]]*Mass[Chi[{gI2}]]*
       Cp[UChi[{gO1}], VZp, Chi[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 2, B1[p^2, Mass2[Cha[{gI1}]], 
          Mass2[Hpm[{gI2}]]]*conj[Cp[UChi[{gO2}], bar[Cha[{gI1}]], 
            Hpm[{gI2}]][PR]]*Cp[UChi[{gO1}], bar[Cha[{gI1}]], Hpm[{gI2}]][
          PR]]]/2 - sum[gI1, 1, 2, sum[gI2, 1, 2, 
       B1[p^2, Mass2[Cha[{gI2}]], Mass2[Hpm[{gI1}]]]*
        conj[Cp[UChi[{gO2}], conj[Hpm[{gI1}]], Cha[{gI2}]][PR]]*
        Cp[UChi[{gO1}], conj[Hpm[{gI1}]], Cha[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI1}]], Mass2[VWm]])*
      conj[Cp[UChi[{gO2}], bar[Cha[{gI1}]], VWm][PL]]*
      Cp[UChi[{gO1}], bar[Cha[{gI1}]], VWm][PL]] - 
    (3*sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fd[{gI1}]], 
          Mass2[Sd[{gI2}]]]*conj[Cp[UChi[{gO2}], bar[Fd[{gI1}]], Sd[{gI2}]][
           PR]]*Cp[UChi[{gO1}], bar[Fd[{gI1}]], Sd[{gI2}]][PR]]])/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fe[{gI1}]], Mass2[Se[{gI2}]]]*
        conj[Cp[UChi[{gO2}], bar[Fe[{gI1}]], Se[{gI2}]][PR]]*
        Cp[UChi[{gO1}], bar[Fe[{gI1}]], Se[{gI2}]][PR]]]/2 - 
    (3*sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fu[{gI1}]], 
          Mass2[Su[{gI2}]]]*conj[Cp[UChi[{gO2}], bar[Fu[{gI1}]], Su[{gI2}]][
           PR]]*Cp[UChi[{gO1}], bar[Fu[{gI1}]], Su[{gI2}]][PR]]])/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fv[{gI1}]], Mass2[Sv[{gI2}]]]*
        conj[Cp[UChi[{gO2}], bar[Fv[{gI1}]], Sv[{gI2}]][PR]]*
        Cp[UChi[{gO1}], bar[Fv[{gI1}]], Sv[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[hh[{gI1}]]]*conj[Cp[UChi[{gO2}], hh[{gI1}], Chi[{gI2}]][PR]]*
        Cp[UChi[{gO1}], hh[{gI1}], Chi[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Chi[{gI1}]], 
         Mass2[Ah[{gI2}]]]*conj[Cp[UChi[{gO2}], Chi[{gI1}], Ah[{gI2}]][PR]]*
        Cp[UChi[{gO1}], Chi[{gI1}], Ah[{gI2}]][PR]]]/2 - 
    (3*sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], 
          Mass2[Sd[{gI1}]]]*conj[Cp[UChi[{gO2}], conj[Sd[{gI1}]], Fd[{gI2}]][
           PR]]*Cp[UChi[{gO1}], conj[Sd[{gI1}]], Fd[{gI2}]][PR]]])/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fe[{gI2}]], Mass2[Se[{gI1}]]]*
        conj[Cp[UChi[{gO2}], conj[Se[{gI1}]], Fe[{gI2}]][PR]]*
        Cp[UChi[{gO1}], conj[Se[{gI1}]], Fe[{gI2}]][PR]]]/2 - 
    (3*sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI2}]], 
          Mass2[Su[{gI1}]]]*conj[Cp[UChi[{gO2}], conj[Su[{gI1}]], Fu[{gI2}]][
           PR]]*Cp[UChi[{gO1}], conj[Su[{gI1}]], Fu[{gI2}]][PR]]])/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fv[{gI2}]], Mass2[Sv[{gI1}]]]*
        conj[Cp[UChi[{gO2}], conj[Sv[{gI1}]], Fv[{gI2}]][PR]]*
        Cp[UChi[{gO1}], conj[Sv[{gI1}]], Fv[{gI2}]][PR]]]/2 - 
    sum[gI2, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI2}]], Mass2[VWm]])*
      conj[Cp[UChi[{gO2}], conj[VWm], Cha[{gI2}]][PL]]*
      Cp[UChi[{gO1}], conj[VWm], Cha[{gI2}]][PL]] - 
    sum[gI2, 1, 6, (rMS/2 + B1[p^2, Mass2[Chi[{gI2}]], Mass2[VZ]])*
      conj[Cp[UChi[{gO2}], VZ, Chi[{gI2}]][PL]]*
      Cp[UChi[{gO1}], VZ, Chi[{gI2}]][PL]] - sum[gI2, 1, 6, 
     (rMS/2 + B1[p^2, Mass2[Chi[{gI2}]], Mass2[VZp]])*
      conj[Cp[UChi[{gO2}], VZp, Chi[{gI2}]][PL]]*
      Cp[UChi[{gO1}], VZp, Chi[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 2, B1[p^2, Mass2[Cha[{gI1}]], 
          Mass2[Hpm[{gI2}]]]*conj[Cp[UChi[{gO2}], bar[Cha[{gI1}]], 
            Hpm[{gI2}]][PL]]*Cp[UChi[{gO1}], bar[Cha[{gI1}]], Hpm[{gI2}]][
          PL]]]/2 - sum[gI1, 1, 2, sum[gI2, 1, 2, 
       B1[p^2, Mass2[Cha[{gI2}]], Mass2[Hpm[{gI1}]]]*
        conj[Cp[UChi[{gO2}], conj[Hpm[{gI1}]], Cha[{gI2}]][PL]]*
        Cp[UChi[{gO1}], conj[Hpm[{gI1}]], Cha[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI1}]], Mass2[VWm]])*
      conj[Cp[UChi[{gO2}], bar[Cha[{gI1}]], VWm][PR]]*
      Cp[UChi[{gO1}], bar[Cha[{gI1}]], VWm][PR]] - 
    (3*sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fd[{gI1}]], 
          Mass2[Sd[{gI2}]]]*conj[Cp[UChi[{gO2}], bar[Fd[{gI1}]], Sd[{gI2}]][
           PL]]*Cp[UChi[{gO1}], bar[Fd[{gI1}]], Sd[{gI2}]][PL]]])/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fe[{gI1}]], Mass2[Se[{gI2}]]]*
        conj[Cp[UChi[{gO2}], bar[Fe[{gI1}]], Se[{gI2}]][PL]]*
        Cp[UChi[{gO1}], bar[Fe[{gI1}]], Se[{gI2}]][PL]]]/2 - 
    (3*sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fu[{gI1}]], 
          Mass2[Su[{gI2}]]]*conj[Cp[UChi[{gO2}], bar[Fu[{gI1}]], Su[{gI2}]][
           PL]]*Cp[UChi[{gO1}], bar[Fu[{gI1}]], Su[{gI2}]][PL]]])/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fv[{gI1}]], Mass2[Sv[{gI2}]]]*
        conj[Cp[UChi[{gO2}], bar[Fv[{gI1}]], Sv[{gI2}]][PL]]*
        Cp[UChi[{gO1}], bar[Fv[{gI1}]], Sv[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[hh[{gI1}]]]*conj[Cp[UChi[{gO2}], hh[{gI1}], Chi[{gI2}]][PL]]*
        Cp[UChi[{gO1}], hh[{gI1}], Chi[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Chi[{gI1}]], 
         Mass2[Ah[{gI2}]]]*conj[Cp[UChi[{gO2}], Chi[{gI1}], Ah[{gI2}]][PL]]*
        Cp[UChi[{gO1}], Chi[{gI1}], Ah[{gI2}]][PL]]]/2 - 
    (3*sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], 
          Mass2[Sd[{gI1}]]]*conj[Cp[UChi[{gO2}], conj[Sd[{gI1}]], Fd[{gI2}]][
           PL]]*Cp[UChi[{gO1}], conj[Sd[{gI1}]], Fd[{gI2}]][PL]]])/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fe[{gI2}]], Mass2[Se[{gI1}]]]*
        conj[Cp[UChi[{gO2}], conj[Se[{gI1}]], Fe[{gI2}]][PL]]*
        Cp[UChi[{gO1}], conj[Se[{gI1}]], Fe[{gI2}]][PL]]]/2 - 
    (3*sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI2}]], 
          Mass2[Su[{gI1}]]]*conj[Cp[UChi[{gO2}], conj[Su[{gI1}]], Fu[{gI2}]][
           PL]]*Cp[UChi[{gO1}], conj[Su[{gI1}]], Fu[{gI2}]][PL]]])/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fv[{gI2}]], Mass2[Sv[{gI1}]]]*
        conj[Cp[UChi[{gO2}], conj[Sv[{gI1}]], Fv[{gI2}]][PL]]*
        Cp[UChi[{gO1}], conj[Sv[{gI1}]], Fv[{gI2}]][PL]]]/2 - 
    sum[gI2, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI2}]], Mass2[VWm]])*
      conj[Cp[UChi[{gO2}], conj[VWm], Cha[{gI2}]][PR]]*
      Cp[UChi[{gO1}], conj[VWm], Cha[{gI2}]][PR]] - 
    sum[gI2, 1, 6, (rMS/2 + B1[p^2, Mass2[Chi[{gI2}]], Mass2[VZ]])*
      conj[Cp[UChi[{gO2}], VZ, Chi[{gI2}]][PR]]*
      Cp[UChi[{gO1}], VZ, Chi[{gI2}]][PR]] - sum[gI2, 1, 6, 
     (rMS/2 + B1[p^2, Mass2[Chi[{gI2}]], Mass2[VZp]])*
      conj[Cp[UChi[{gO2}], VZp, Chi[{gI2}]][PR]]*
      Cp[UChi[{gO1}], VZp, Chi[{gI2}]][PR]]}}, 
 {Cha, {sum[gI1, 1, 2, Mass[Cha[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Cha[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UCha[{gO2}]], Cha[{gI1}], Ah[{gI2}]][PL]]*
        Cp[bar[UCha[{gO1}]], Cha[{gI1}], Ah[{gI2}]][PR]]] + 
    sum[gI1, 1, 2, sum[gI2, 1, 6, B0[p^2, Mass2[Chi[{gI2}]], 
        Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UCha[{gO2}]], Hpm[{gI1}], Chi[{gI2}]][
         PL]]*Mass[Chi[{gI2}]]*Cp[bar[UCha[{gO1}]], Hpm[{gI1}], Chi[{gI2}]][
        PR]]] + sum[gI1, 1, 3, sum[gI2, 1, 2, 
      B0[p^2, Mass2[Cha[{gI2}]], Mass2[hh[{gI1}]]]*
       conj[Cp[bar[UCha[{gO2}]], hh[{gI1}], Cha[{gI2}]][PL]]*Mass[Cha[{gI2}]]*
       Cp[bar[UCha[{gO1}]], hh[{gI1}], Cha[{gI2}]][PR]]] + 
    3*sum[gI1, 1, 3, Mass[Fu[{gI1}]]*sum[gI2, 1, 6, 
        B0[p^2, Mass2[Fu[{gI1}]], Mass2[Sd[{gI2}]]]*
         conj[Cp[bar[UCha[{gO2}]], bar[Fu[{gI1}]], Sd[{gI2}]][PL]]*
         Cp[bar[UCha[{gO1}]], bar[Fu[{gI1}]], Sd[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, Mass[Fv[{gI1}]]*sum[gI2, 1, 6, 
       B0[p^2, Mass2[Fv[{gI1}]], Mass2[Se[{gI2}]]]*
        conj[Cp[bar[UCha[{gO2}]], bar[Fv[{gI1}]], Se[{gI2}]][PL]]*
        Cp[bar[UCha[{gO1}]], bar[Fv[{gI1}]], Se[{gI2}]][PR]]] + 
    3*sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Fd[{gI2}]], 
         Mass2[Su[{gI1}]]]*conj[Cp[bar[UCha[{gO2}]], conj[Su[{gI1}]], 
           Fd[{gI2}]][PL]]*Mass[Fd[{gI2}]]*Cp[bar[UCha[{gO1}]], 
          conj[Su[{gI1}]], Fd[{gI2}]][PR]]] + 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Fe[{gI2}]], Mass2[Sv[{gI1}]]]*
       conj[Cp[bar[UCha[{gO2}]], conj[Sv[{gI1}]], Fe[{gI2}]][PL]]*
       Mass[Fe[{gI2}]]*Cp[bar[UCha[{gO1}]], conj[Sv[{gI1}]], Fe[{gI2}]][
        PR]]] - 4*sum[gI2, 1, 2, (-rMS/2 + B0[p^2, Mass2[Cha[{gI2}]], 0])*
       conj[Cp[bar[UCha[{gO2}]], VP, Cha[{gI2}]][PR]]*Mass[Cha[{gI2}]]*
       Cp[bar[UCha[{gO1}]], VP, Cha[{gI2}]][PL]] - 
    4*sum[gI2, 1, 2, (-rMS/2 + B0[p^2, Mass2[Cha[{gI2}]], Mass2[VZ]])*
       conj[Cp[bar[UCha[{gO2}]], VZ, Cha[{gI2}]][PR]]*Mass[Cha[{gI2}]]*
       Cp[bar[UCha[{gO1}]], VZ, Cha[{gI2}]][PL]] - 
    4*sum[gI2, 1, 2, (-rMS/2 + B0[p^2, Mass2[Cha[{gI2}]], Mass2[VZp]])*
       conj[Cp[bar[UCha[{gO2}]], VZp, Cha[{gI2}]][PR]]*Mass[Cha[{gI2}]]*
       Cp[bar[UCha[{gO1}]], VZp, Cha[{gI2}]][PL]] - 
    4*sum[gI2, 1, 6, (-rMS/2 + B0[p^2, Mass2[Chi[{gI2}]], Mass2[VWm]])*
       conj[Cp[bar[UCha[{gO2}]], VWm, Chi[{gI2}]][PR]]*Mass[Chi[{gI2}]]*
       Cp[bar[UCha[{gO1}]], VWm, Chi[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Cha[{gI1}]], 
          Mass2[Ah[{gI2}]]]*conj[Cp[bar[UCha[{gO2}]], Cha[{gI1}], Ah[{gI2}]][
           PR]]*Cp[bar[UCha[{gO1}]], Cha[{gI1}], Ah[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 2, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UCha[{gO2}]], Hpm[{gI1}], Chi[{gI2}]][
          PR]]*Cp[bar[UCha[{gO1}]], Hpm[{gI1}], Chi[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 2, B1[p^2, Mass2[Cha[{gI2}]], 
         Mass2[hh[{gI1}]]]*conj[Cp[bar[UCha[{gO2}]], hh[{gI1}], Cha[{gI2}]][
          PR]]*Cp[bar[UCha[{gO1}]], hh[{gI1}], Cha[{gI2}]][PR]]]/2 - 
    (3*sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fu[{gI1}]], 
          Mass2[Sd[{gI2}]]]*conj[Cp[bar[UCha[{gO2}]], bar[Fu[{gI1}]], 
            Sd[{gI2}]][PR]]*Cp[bar[UCha[{gO1}]], bar[Fu[{gI1}]], Sd[{gI2}]][
          PR]]])/2 - sum[gI1, 1, 3, sum[gI2, 1, 6, 
       B1[p^2, Mass2[Fv[{gI1}]], Mass2[Se[{gI2}]]]*
        conj[Cp[bar[UCha[{gO2}]], bar[Fv[{gI1}]], Se[{gI2}]][PR]]*
        Cp[bar[UCha[{gO1}]], bar[Fv[{gI1}]], Se[{gI2}]][PR]]]/2 - 
    (3*sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], 
          Mass2[Su[{gI1}]]]*conj[Cp[bar[UCha[{gO2}]], conj[Su[{gI1}]], 
            Fd[{gI2}]][PR]]*Cp[bar[UCha[{gO1}]], conj[Su[{gI1}]], Fd[{gI2}]][
          PR]]])/2 - sum[gI1, 1, 6, sum[gI2, 1, 3, 
       B1[p^2, Mass2[Fe[{gI2}]], Mass2[Sv[{gI1}]]]*
        conj[Cp[bar[UCha[{gO2}]], conj[Sv[{gI1}]], Fe[{gI2}]][PR]]*
        Cp[bar[UCha[{gO1}]], conj[Sv[{gI1}]], Fe[{gI2}]][PR]]]/2 - 
    sum[gI2, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI2}]], 0])*
      conj[Cp[bar[UCha[{gO2}]], VP, Cha[{gI2}]][PL]]*
      Cp[bar[UCha[{gO1}]], VP, Cha[{gI2}]][PL]] - 
    sum[gI2, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UCha[{gO2}]], VZ, Cha[{gI2}]][PL]]*
      Cp[bar[UCha[{gO1}]], VZ, Cha[{gI2}]][PL]] - 
    sum[gI2, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UCha[{gO2}]], VZp, Cha[{gI2}]][PL]]*
      Cp[bar[UCha[{gO1}]], VZp, Cha[{gI2}]][PL]] - 
    sum[gI2, 1, 6, (rMS/2 + B1[p^2, Mass2[Chi[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UCha[{gO2}]], VWm, Chi[{gI2}]][PL]]*
      Cp[bar[UCha[{gO1}]], VWm, Chi[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Cha[{gI1}]], 
          Mass2[Ah[{gI2}]]]*conj[Cp[bar[UCha[{gO2}]], Cha[{gI1}], Ah[{gI2}]][
           PL]]*Cp[bar[UCha[{gO1}]], Cha[{gI1}], Ah[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 2, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UCha[{gO2}]], Hpm[{gI1}], Chi[{gI2}]][
          PL]]*Cp[bar[UCha[{gO1}]], Hpm[{gI1}], Chi[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 2, B1[p^2, Mass2[Cha[{gI2}]], 
         Mass2[hh[{gI1}]]]*conj[Cp[bar[UCha[{gO2}]], hh[{gI1}], Cha[{gI2}]][
          PL]]*Cp[bar[UCha[{gO1}]], hh[{gI1}], Cha[{gI2}]][PL]]]/2 - 
    (3*sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fu[{gI1}]], 
          Mass2[Sd[{gI2}]]]*conj[Cp[bar[UCha[{gO2}]], bar[Fu[{gI1}]], 
            Sd[{gI2}]][PL]]*Cp[bar[UCha[{gO1}]], bar[Fu[{gI1}]], Sd[{gI2}]][
          PL]]])/2 - sum[gI1, 1, 3, sum[gI2, 1, 6, 
       B1[p^2, Mass2[Fv[{gI1}]], Mass2[Se[{gI2}]]]*
        conj[Cp[bar[UCha[{gO2}]], bar[Fv[{gI1}]], Se[{gI2}]][PL]]*
        Cp[bar[UCha[{gO1}]], bar[Fv[{gI1}]], Se[{gI2}]][PL]]]/2 - 
    (3*sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], 
          Mass2[Su[{gI1}]]]*conj[Cp[bar[UCha[{gO2}]], conj[Su[{gI1}]], 
            Fd[{gI2}]][PL]]*Cp[bar[UCha[{gO1}]], conj[Su[{gI1}]], Fd[{gI2}]][
          PL]]])/2 - sum[gI1, 1, 6, sum[gI2, 1, 3, 
       B1[p^2, Mass2[Fe[{gI2}]], Mass2[Sv[{gI1}]]]*
        conj[Cp[bar[UCha[{gO2}]], conj[Sv[{gI1}]], Fe[{gI2}]][PL]]*
        Cp[bar[UCha[{gO1}]], conj[Sv[{gI1}]], Fe[{gI2}]][PL]]]/2 - 
    sum[gI2, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI2}]], 0])*
      conj[Cp[bar[UCha[{gO2}]], VP, Cha[{gI2}]][PR]]*
      Cp[bar[UCha[{gO1}]], VP, Cha[{gI2}]][PR]] - 
    sum[gI2, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UCha[{gO2}]], VZ, Cha[{gI2}]][PR]]*
      Cp[bar[UCha[{gO1}]], VZ, Cha[{gI2}]][PR]] - 
    sum[gI2, 1, 2, (rMS/2 + B1[p^2, Mass2[Cha[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UCha[{gO2}]], VZp, Cha[{gI2}]][PR]]*
      Cp[bar[UCha[{gO1}]], VZp, Cha[{gI2}]][PR]] - 
    sum[gI2, 1, 6, (rMS/2 + B1[p^2, Mass2[Chi[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UCha[{gO2}]], VWm, Chi[{gI2}]][PR]]*
      Cp[bar[UCha[{gO1}]], VWm, Chi[{gI2}]][PR]]}}, 
 {Fe, {sum[gI1, 1, 2, sum[gI2, 1, 3, B0[p^2, Mass2[Fv[{gI2}]], 
        Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFe[{gO2}]], Hpm[{gI1}], Fv[{gI2}]][
         PL]]*Mass[Fv[{gI2}]]*Cp[bar[UFe[{gO1}]], Hpm[{gI1}], Fv[{gI2}]][
        PR]]] + sum[gI1, 1, 3, Mass[Fe[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fe[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFe[{gO2}]], Fe[{gI1}], Ah[{gI2}]][PL]]*
        Cp[bar[UFe[{gO1}]], Fe[{gI1}], Ah[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B0[p^2, Mass2[Fe[{gI2}]], Mass2[hh[{gI1}]]]*
       conj[Cp[bar[UFe[{gO2}]], hh[{gI1}], Fe[{gI2}]][PL]]*Mass[Fe[{gI2}]]*
       Cp[bar[UFe[{gO1}]], hh[{gI1}], Fe[{gI2}]][PR]]] + 
    sum[gI1, 1, 6, sum[gI2, 1, 2, B0[p^2, Mass2[Cha[{gI2}]], 
        Mass2[Sv[{gI1}]]]*conj[Cp[bar[UFe[{gO2}]], Sv[{gI1}], Cha[{gI2}]][
         PL]]*Mass[Cha[{gI2}]]*Cp[bar[UFe[{gO1}]], Sv[{gI1}], Cha[{gI2}]][
        PR]]] + sum[gI1, 1, 6, sum[gI2, 1, 6, 
      B0[p^2, Mass2[Chi[{gI2}]], Mass2[Se[{gI1}]]]*
       conj[Cp[bar[UFe[{gO2}]], Se[{gI1}], Chi[{gI2}]][PL]]*Mass[Chi[{gI2}]]*
       Cp[bar[UFe[{gO1}]], Se[{gI1}], Chi[{gI2}]][PR]]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fe[{gI2}]], 0])*
       conj[Cp[bar[UFe[{gO2}]], VP, Fe[{gI2}]][PR]]*Mass[Fe[{gI2}]]*
       Cp[bar[UFe[{gO1}]], VP, Fe[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fv[{gI2}]], Mass2[VWm]])*
       conj[Cp[bar[UFe[{gO2}]], VWm, Fv[{gI2}]][PR]]*Mass[Fv[{gI2}]]*
       Cp[bar[UFe[{gO1}]], VWm, Fv[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fe[{gI2}]], Mass2[VZ]])*
       conj[Cp[bar[UFe[{gO2}]], VZ, Fe[{gI2}]][PR]]*Mass[Fe[{gI2}]]*
       Cp[bar[UFe[{gO1}]], VZ, Fe[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fe[{gI2}]], Mass2[VZp]])*
       conj[Cp[bar[UFe[{gO2}]], VZp, Fe[{gI2}]][PR]]*Mass[Fe[{gI2}]]*
       Cp[bar[UFe[{gO1}]], VZp, Fe[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Fv[{gI2}]], 
          Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFe[{gO2}]], Hpm[{gI1}], Fv[{gI2}]][
           PR]]*Cp[bar[UFe[{gO1}]], Hpm[{gI1}], Fv[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fe[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFe[{gO2}]], Fe[{gI1}], Ah[{gI2}]][PR]]*
        Cp[bar[UFe[{gO1}]], Fe[{gI1}], Ah[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fe[{gI2}]], Mass2[hh[{gI1}]]]*
        conj[Cp[bar[UFe[{gO2}]], hh[{gI1}], Fe[{gI2}]][PR]]*
        Cp[bar[UFe[{gO1}]], hh[{gI1}], Fe[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 2, B1[p^2, Mass2[Cha[{gI2}]], 
         Mass2[Sv[{gI1}]]]*conj[Cp[bar[UFe[{gO2}]], Sv[{gI1}], Cha[{gI2}]][
          PR]]*Cp[bar[UFe[{gO1}]], Sv[{gI1}], Cha[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Se[{gI1}]]]*conj[Cp[bar[UFe[{gO2}]], Se[{gI1}], Chi[{gI2}]][
          PR]]*Cp[bar[UFe[{gO1}]], Se[{gI1}], Chi[{gI2}]][PR]]]/2 - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fe[{gI2}]], 0])*
      conj[Cp[bar[UFe[{gO2}]], VP, Fe[{gI2}]][PL]]*
      Cp[bar[UFe[{gO1}]], VP, Fe[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fv[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UFe[{gO2}]], VWm, Fv[{gI2}]][PL]]*
      Cp[bar[UFe[{gO1}]], VWm, Fv[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fe[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UFe[{gO2}]], VZ, Fe[{gI2}]][PL]]*
      Cp[bar[UFe[{gO1}]], VZ, Fe[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fe[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UFe[{gO2}]], VZp, Fe[{gI2}]][PL]]*
      Cp[bar[UFe[{gO1}]], VZp, Fe[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Fv[{gI2}]], 
          Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFe[{gO2}]], Hpm[{gI1}], Fv[{gI2}]][
           PL]]*Cp[bar[UFe[{gO1}]], Hpm[{gI1}], Fv[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fe[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFe[{gO2}]], Fe[{gI1}], Ah[{gI2}]][PL]]*
        Cp[bar[UFe[{gO1}]], Fe[{gI1}], Ah[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fe[{gI2}]], Mass2[hh[{gI1}]]]*
        conj[Cp[bar[UFe[{gO2}]], hh[{gI1}], Fe[{gI2}]][PL]]*
        Cp[bar[UFe[{gO1}]], hh[{gI1}], Fe[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 2, B1[p^2, Mass2[Cha[{gI2}]], 
         Mass2[Sv[{gI1}]]]*conj[Cp[bar[UFe[{gO2}]], Sv[{gI1}], Cha[{gI2}]][
          PL]]*Cp[bar[UFe[{gO1}]], Sv[{gI1}], Cha[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Se[{gI1}]]]*conj[Cp[bar[UFe[{gO2}]], Se[{gI1}], Chi[{gI2}]][
          PL]]*Cp[bar[UFe[{gO1}]], Se[{gI1}], Chi[{gI2}]][PL]]]/2 - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fe[{gI2}]], 0])*
      conj[Cp[bar[UFe[{gO2}]], VP, Fe[{gI2}]][PR]]*
      Cp[bar[UFe[{gO1}]], VP, Fe[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fv[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UFe[{gO2}]], VWm, Fv[{gI2}]][PR]]*
      Cp[bar[UFe[{gO1}]], VWm, Fv[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fe[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UFe[{gO2}]], VZ, Fe[{gI2}]][PR]]*
      Cp[bar[UFe[{gO1}]], VZ, Fe[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fe[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UFe[{gO2}]], VZp, Fe[{gI2}]][PR]]*
      Cp[bar[UFe[{gO1}]], VZp, Fe[{gI2}]][PR]]}}, 
 {Fd, {sum[gI1, 1, 2, sum[gI2, 1, 3, B0[p^2, Mass2[Fu[{gI2}]], 
        Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFd[{gO2}]], Hpm[{gI1}], Fu[{gI2}]][
         PL]]*Mass[Fu[{gI2}]]*Cp[bar[UFd[{gO1}]], Hpm[{gI1}], Fu[{gI2}]][
        PR]]] + sum[gI1, 1, 3, Mass[Fd[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fd[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFd[{gO2}]], Fd[{gI1}], Ah[{gI2}]][PL]]*
        Cp[bar[UFd[{gO1}]], Fd[{gI1}], Ah[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B0[p^2, Mass2[Fd[{gI2}]], Mass2[hh[{gI1}]]]*
       conj[Cp[bar[UFd[{gO2}]], hh[{gI1}], Fd[{gI2}]][PL]]*Mass[Fd[{gI2}]]*
       Cp[bar[UFd[{gO1}]], hh[{gI1}], Fd[{gI2}]][PR]]] + 
    sum[gI1, 1, 6, sum[gI2, 1, 2, B0[p^2, Mass2[Cha[{gI2}]], 
        Mass2[Su[{gI1}]]]*conj[Cp[bar[UFd[{gO2}]], Su[{gI1}], Cha[{gI2}]][
         PL]]*Mass[Cha[{gI2}]]*Cp[bar[UFd[{gO1}]], Su[{gI1}], Cha[{gI2}]][
        PR]]] + sum[gI1, 1, 6, sum[gI2, 1, 6, 
      B0[p^2, Mass2[Chi[{gI2}]], Mass2[Sd[{gI1}]]]*
       conj[Cp[bar[UFd[{gO2}]], Sd[{gI1}], Chi[{gI2}]][PL]]*Mass[Chi[{gI2}]]*
       Cp[bar[UFd[{gO1}]], Sd[{gI1}], Chi[{gI2}]][PR]]] + 
    (4*Mass[Glu]*sum[gI1, 1, 6, B0[p^2, Mass2[Glu], Mass2[Sd[{gI1}]]]*
        conj[Cp[bar[UFd[{gO2}]], Sd[{gI1}], Glu[{1}]][PL]]*
        Cp[bar[UFd[{gO1}]], Sd[{gI1}], Glu[{1}]][PR]])/3 - 
    (16*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fd[{gI2}]], 0])*
        conj[Cp[bar[UFd[{gO2}]], VG, Fd[{gI2}]][PR]]*Mass[Fd[{gI2}]]*
        Cp[bar[UFd[{gO1}]], VG, Fd[{gI2}]][PL]])/3 - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fd[{gI2}]], 0])*
       conj[Cp[bar[UFd[{gO2}]], VP, Fd[{gI2}]][PR]]*Mass[Fd[{gI2}]]*
       Cp[bar[UFd[{gO1}]], VP, Fd[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fu[{gI2}]], Mass2[VWm]])*
       conj[Cp[bar[UFd[{gO2}]], VWm, Fu[{gI2}]][PR]]*Mass[Fu[{gI2}]]*
       Cp[bar[UFd[{gO1}]], VWm, Fu[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fd[{gI2}]], Mass2[VZ]])*
       conj[Cp[bar[UFd[{gO2}]], VZ, Fd[{gI2}]][PR]]*Mass[Fd[{gI2}]]*
       Cp[bar[UFd[{gO1}]], VZ, Fd[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fd[{gI2}]], Mass2[VZp]])*
       conj[Cp[bar[UFd[{gO2}]], VZp, Fd[{gI2}]][PR]]*Mass[Fd[{gI2}]]*
       Cp[bar[UFd[{gO1}]], VZp, Fd[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI2}]], 
          Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFd[{gO2}]], Hpm[{gI1}], Fu[{gI2}]][
           PR]]*Cp[bar[UFd[{gO1}]], Hpm[{gI1}], Fu[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFd[{gO2}]], Fd[{gI1}], Ah[{gI2}]][PR]]*
        Cp[bar[UFd[{gO1}]], Fd[{gI1}], Ah[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], Mass2[hh[{gI1}]]]*
        conj[Cp[bar[UFd[{gO2}]], hh[{gI1}], Fd[{gI2}]][PR]]*
        Cp[bar[UFd[{gO1}]], hh[{gI1}], Fd[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 2, B1[p^2, Mass2[Cha[{gI2}]], 
         Mass2[Su[{gI1}]]]*conj[Cp[bar[UFd[{gO2}]], Su[{gI1}], Cha[{gI2}]][
          PR]]*Cp[bar[UFd[{gO1}]], Su[{gI1}], Cha[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Sd[{gI1}]]]*conj[Cp[bar[UFd[{gO2}]], Sd[{gI1}], Chi[{gI2}]][
          PR]]*Cp[bar[UFd[{gO1}]], Sd[{gI1}], Chi[{gI2}]][PR]]]/2 - 
    (2*sum[gI1, 1, 6, B1[p^2, Mass2[Glu], Mass2[Sd[{gI1}]]]*
        conj[Cp[bar[UFd[{gO2}]], Sd[{gI1}], Glu[{1}]][PR]]*
        Cp[bar[UFd[{gO1}]], Sd[{gI1}], Glu[{1}]][PR]])/3 - 
    (4*sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], 0])*
        conj[Cp[bar[UFd[{gO2}]], VG, Fd[{gI2}]][PL]]*
        Cp[bar[UFd[{gO1}]], VG, Fd[{gI2}]][PL]])/3 - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], 0])*
      conj[Cp[bar[UFd[{gO2}]], VP, Fd[{gI2}]][PL]]*
      Cp[bar[UFd[{gO1}]], VP, Fd[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UFd[{gO2}]], VWm, Fu[{gI2}]][PL]]*
      Cp[bar[UFd[{gO1}]], VWm, Fu[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UFd[{gO2}]], VZ, Fd[{gI2}]][PL]]*
      Cp[bar[UFd[{gO1}]], VZ, Fd[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UFd[{gO2}]], VZp, Fd[{gI2}]][PL]]*
      Cp[bar[UFd[{gO1}]], VZp, Fd[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI2}]], 
          Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFd[{gO2}]], Hpm[{gI1}], Fu[{gI2}]][
           PL]]*Cp[bar[UFd[{gO1}]], Hpm[{gI1}], Fu[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFd[{gO2}]], Fd[{gI1}], Ah[{gI2}]][PL]]*
        Cp[bar[UFd[{gO1}]], Fd[{gI1}], Ah[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], Mass2[hh[{gI1}]]]*
        conj[Cp[bar[UFd[{gO2}]], hh[{gI1}], Fd[{gI2}]][PL]]*
        Cp[bar[UFd[{gO1}]], hh[{gI1}], Fd[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 2, B1[p^2, Mass2[Cha[{gI2}]], 
         Mass2[Su[{gI1}]]]*conj[Cp[bar[UFd[{gO2}]], Su[{gI1}], Cha[{gI2}]][
          PL]]*Cp[bar[UFd[{gO1}]], Su[{gI1}], Cha[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Sd[{gI1}]]]*conj[Cp[bar[UFd[{gO2}]], Sd[{gI1}], Chi[{gI2}]][
          PL]]*Cp[bar[UFd[{gO1}]], Sd[{gI1}], Chi[{gI2}]][PL]]]/2 - 
    (2*sum[gI1, 1, 6, B1[p^2, Mass2[Glu], Mass2[Sd[{gI1}]]]*
        conj[Cp[bar[UFd[{gO2}]], Sd[{gI1}], Glu[{1}]][PL]]*
        Cp[bar[UFd[{gO1}]], Sd[{gI1}], Glu[{1}]][PL]])/3 - 
    (4*sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], 0])*
        conj[Cp[bar[UFd[{gO2}]], VG, Fd[{gI2}]][PR]]*
        Cp[bar[UFd[{gO1}]], VG, Fd[{gI2}]][PR]])/3 - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], 0])*
      conj[Cp[bar[UFd[{gO2}]], VP, Fd[{gI2}]][PR]]*
      Cp[bar[UFd[{gO1}]], VP, Fd[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UFd[{gO2}]], VWm, Fu[{gI2}]][PR]]*
      Cp[bar[UFd[{gO1}]], VWm, Fu[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UFd[{gO2}]], VZ, Fd[{gI2}]][PR]]*
      Cp[bar[UFd[{gO1}]], VZ, Fd[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UFd[{gO2}]], VZp, Fd[{gI2}]][PR]]*
      Cp[bar[UFd[{gO1}]], VZp, Fd[{gI2}]][PR]]}}, 
 {Fu, {sum[gI1, 1, 2, sum[gI2, 1, 3, B0[p^2, Mass2[Fd[{gI2}]], 
        Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFu[{gO2}]], conj[Hpm[{gI1}]], 
          Fd[{gI2}]][PL]]*Mass[Fd[{gI2}]]*
       Cp[bar[UFu[{gO1}]], conj[Hpm[{gI1}]], Fd[{gI2}]][PR]]] + 
    sum[gI1, 1, 2, Mass[Cha[{gI1}]]*sum[gI2, 1, 6, 
       B0[p^2, Mass2[Cha[{gI1}]], Mass2[Sd[{gI2}]]]*
        conj[Cp[bar[UFu[{gO2}]], bar[Cha[{gI1}]], Sd[{gI2}]][PL]]*
        Cp[bar[UFu[{gO1}]], bar[Cha[{gI1}]], Sd[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, Mass[Fu[{gI1}]]*sum[gI2, 1, 3, 
       B0[p^2, Mass2[Fu[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFu[{gO2}]], Fu[{gI1}], Ah[{gI2}]][PL]]*
        Cp[bar[UFu[{gO1}]], Fu[{gI1}], Ah[{gI2}]][PR]]] + 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B0[p^2, Mass2[Fu[{gI2}]], Mass2[hh[{gI1}]]]*
       conj[Cp[bar[UFu[{gO2}]], hh[{gI1}], Fu[{gI2}]][PL]]*Mass[Fu[{gI2}]]*
       Cp[bar[UFu[{gO1}]], hh[{gI1}], Fu[{gI2}]][PR]]] + 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B0[p^2, Mass2[Chi[{gI2}]], 
        Mass2[Su[{gI1}]]]*conj[Cp[bar[UFu[{gO2}]], Su[{gI1}], Chi[{gI2}]][
         PL]]*Mass[Chi[{gI2}]]*Cp[bar[UFu[{gO1}]], Su[{gI1}], Chi[{gI2}]][
        PR]]] + (4*Mass[Glu]*sum[gI1, 1, 6, 
       B0[p^2, Mass2[Glu], Mass2[Su[{gI1}]]]*
        conj[Cp[bar[UFu[{gO2}]], Su[{gI1}], Glu[{1}]][PL]]*
        Cp[bar[UFu[{gO1}]], Su[{gI1}], Glu[{1}]][PR]])/3 - 
    (16*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fu[{gI2}]], 0])*
        conj[Cp[bar[UFu[{gO2}]], VG, Fu[{gI2}]][PR]]*Mass[Fu[{gI2}]]*
        Cp[bar[UFu[{gO1}]], VG, Fu[{gI2}]][PL]])/3 - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fu[{gI2}]], 0])*
       conj[Cp[bar[UFu[{gO2}]], VP, Fu[{gI2}]][PR]]*Mass[Fu[{gI2}]]*
       Cp[bar[UFu[{gO1}]], VP, Fu[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fu[{gI2}]], Mass2[VZ]])*
       conj[Cp[bar[UFu[{gO2}]], VZ, Fu[{gI2}]][PR]]*Mass[Fu[{gI2}]]*
       Cp[bar[UFu[{gO1}]], VZ, Fu[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fu[{gI2}]], Mass2[VZp]])*
       conj[Cp[bar[UFu[{gO2}]], VZp, Fu[{gI2}]][PR]]*Mass[Fu[{gI2}]]*
       Cp[bar[UFu[{gO1}]], VZp, Fu[{gI2}]][PL]] - 
    4*sum[gI2, 1, 3, (-rMS/2 + B0[p^2, Mass2[Fd[{gI2}]], Mass2[VWm]])*
       conj[Cp[bar[UFu[{gO2}]], conj[VWm], Fd[{gI2}]][PR]]*Mass[Fd[{gI2}]]*
       Cp[bar[UFu[{gO1}]], conj[VWm], Fd[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], 
          Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFu[{gO2}]], conj[Hpm[{gI1}]], 
            Fd[{gI2}]][PR]]*Cp[bar[UFu[{gO1}]], conj[Hpm[{gI1}]], Fd[{gI2}]][
          PR]]]/2 - sum[gI1, 1, 2, sum[gI2, 1, 6, 
       B1[p^2, Mass2[Cha[{gI1}]], Mass2[Sd[{gI2}]]]*
        conj[Cp[bar[UFu[{gO2}]], bar[Cha[{gI1}]], Sd[{gI2}]][PR]]*
        Cp[bar[UFu[{gO1}]], bar[Cha[{gI1}]], Sd[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFu[{gO2}]], Fu[{gI1}], Ah[{gI2}]][PR]]*
        Cp[bar[UFu[{gO1}]], Fu[{gI1}], Ah[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI2}]], Mass2[hh[{gI1}]]]*
        conj[Cp[bar[UFu[{gO2}]], hh[{gI1}], Fu[{gI2}]][PR]]*
        Cp[bar[UFu[{gO1}]], hh[{gI1}], Fu[{gI2}]][PR]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Su[{gI1}]]]*conj[Cp[bar[UFu[{gO2}]], Su[{gI1}], Chi[{gI2}]][
          PR]]*Cp[bar[UFu[{gO1}]], Su[{gI1}], Chi[{gI2}]][PR]]]/2 - 
    (2*sum[gI1, 1, 6, B1[p^2, Mass2[Glu], Mass2[Su[{gI1}]]]*
        conj[Cp[bar[UFu[{gO2}]], Su[{gI1}], Glu[{1}]][PR]]*
        Cp[bar[UFu[{gO1}]], Su[{gI1}], Glu[{1}]][PR]])/3 - 
    (4*sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], 0])*
        conj[Cp[bar[UFu[{gO2}]], VG, Fu[{gI2}]][PL]]*
        Cp[bar[UFu[{gO1}]], VG, Fu[{gI2}]][PL]])/3 - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], 0])*
      conj[Cp[bar[UFu[{gO2}]], VP, Fu[{gI2}]][PL]]*
      Cp[bar[UFu[{gO1}]], VP, Fu[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UFu[{gO2}]], VZ, Fu[{gI2}]][PL]]*
      Cp[bar[UFu[{gO1}]], VZ, Fu[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UFu[{gO2}]], VZp, Fu[{gI2}]][PL]]*
      Cp[bar[UFu[{gO1}]], VZp, Fu[{gI2}]][PL]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UFu[{gO2}]], conj[VWm], Fd[{gI2}]][PL]]*
      Cp[bar[UFu[{gO1}]], conj[VWm], Fd[{gI2}]][PL]], 
   -sum[gI1, 1, 2, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], 
          Mass2[Hpm[{gI1}]]]*conj[Cp[bar[UFu[{gO2}]], conj[Hpm[{gI1}]], 
            Fd[{gI2}]][PL]]*Cp[bar[UFu[{gO1}]], conj[Hpm[{gI1}]], Fd[{gI2}]][
          PL]]]/2 - sum[gI1, 1, 2, sum[gI2, 1, 6, 
       B1[p^2, Mass2[Cha[{gI1}]], Mass2[Sd[{gI2}]]]*
        conj[Cp[bar[UFu[{gO2}]], bar[Cha[{gI1}]], Sd[{gI2}]][PL]]*
        Cp[bar[UFu[{gO1}]], bar[Cha[{gI1}]], Sd[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI1}]], Mass2[Ah[{gI2}]]]*
        conj[Cp[bar[UFu[{gO2}]], Fu[{gI1}], Ah[{gI2}]][PL]]*
        Cp[bar[UFu[{gO1}]], Fu[{gI1}], Ah[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 3, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI2}]], Mass2[hh[{gI1}]]]*
        conj[Cp[bar[UFu[{gO2}]], hh[{gI1}], Fu[{gI2}]][PL]]*
        Cp[bar[UFu[{gO1}]], hh[{gI1}], Fu[{gI2}]][PL]]]/2 - 
    sum[gI1, 1, 6, sum[gI2, 1, 6, B1[p^2, Mass2[Chi[{gI2}]], 
         Mass2[Su[{gI1}]]]*conj[Cp[bar[UFu[{gO2}]], Su[{gI1}], Chi[{gI2}]][
          PL]]*Cp[bar[UFu[{gO1}]], Su[{gI1}], Chi[{gI2}]][PL]]]/2 - 
    (2*sum[gI1, 1, 6, B1[p^2, Mass2[Glu], Mass2[Su[{gI1}]]]*
        conj[Cp[bar[UFu[{gO2}]], Su[{gI1}], Glu[{1}]][PL]]*
        Cp[bar[UFu[{gO1}]], Su[{gI1}], Glu[{1}]][PL]])/3 - 
    (4*sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], 0])*
        conj[Cp[bar[UFu[{gO2}]], VG, Fu[{gI2}]][PR]]*
        Cp[bar[UFu[{gO1}]], VG, Fu[{gI2}]][PR]])/3 - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], 0])*
      conj[Cp[bar[UFu[{gO2}]], VP, Fu[{gI2}]][PR]]*
      Cp[bar[UFu[{gO1}]], VP, Fu[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], Mass2[VZ]])*
      conj[Cp[bar[UFu[{gO2}]], VZ, Fu[{gI2}]][PR]]*
      Cp[bar[UFu[{gO1}]], VZ, Fu[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fu[{gI2}]], Mass2[VZp]])*
      conj[Cp[bar[UFu[{gO2}]], VZp, Fu[{gI2}]][PR]]*
      Cp[bar[UFu[{gO1}]], VZp, Fu[{gI2}]][PR]] - 
    sum[gI2, 1, 3, (rMS/2 + B1[p^2, Mass2[Fd[{gI2}]], Mass2[VWm]])*
      conj[Cp[bar[UFu[{gO2}]], conj[VWm], Fd[{gI2}]][PR]]*
      Cp[bar[UFu[{gO1}]], conj[VWm], Fd[{gI2}]][PR]]}}, 
 {Glu, {sum[gI1, 1, 3, Mass[Fd[{gI1}]]*sum[gI2, 1, 6, 
        B0[p^2, Mass2[Fd[{gI1}]], Mass2[Sd[{gI2}]]]*
         conj[Cp[Glu[{gO2}], bar[Fd[{gI1}]], Sd[{gI2}]][PL]]*
         Cp[Glu[{gO1}], bar[Fd[{gI1}]], Sd[{gI2}]][PR]]]/2 + 
    sum[gI1, 1, 3, Mass[Fu[{gI1}]]*sum[gI2, 1, 6, 
        B0[p^2, Mass2[Fu[{gI1}]], Mass2[Su[{gI2}]]]*
         conj[Cp[Glu[{gO2}], bar[Fu[{gI1}]], Su[{gI2}]][PL]]*
         Cp[Glu[{gO1}], bar[Fu[{gI1}]], Su[{gI2}]][PR]]]/2 + 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Fd[{gI2}]], Mass2[Sd[{gI1}]]]*
        conj[Cp[Glu[{gO2}], conj[Sd[{gI1}]], Fd[{gI2}]][PL]]*Mass[Fd[{gI2}]]*
        Cp[Glu[{gO1}], conj[Sd[{gI1}]], Fd[{gI2}]][PR]]]/2 + 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B0[p^2, Mass2[Fu[{gI2}]], Mass2[Su[{gI1}]]]*
        conj[Cp[Glu[{gO2}], conj[Su[{gI1}]], Fu[{gI2}]][PL]]*Mass[Fu[{gI2}]]*
        Cp[Glu[{gO1}], conj[Su[{gI1}]], Fu[{gI2}]][PR]]]/2 - 
    12*(-rMS/2 + B0[p^2, Mass2[Glu], 0])*conj[Cp[Glu[{gO2}], VG, Glu[{1}]][
       PR]]*Mass[Glu]*Cp[Glu[{gO1}], VG, Glu[{1}]][PL], 
   -sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fd[{gI1}]], Mass2[Sd[{gI2}]]]*
         conj[Cp[Glu[{gO2}], bar[Fd[{gI1}]], Sd[{gI2}]][PR]]*
         Cp[Glu[{gO1}], bar[Fd[{gI1}]], Sd[{gI2}]][PR]]]/4 - 
    sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fu[{gI1}]], Mass2[Su[{gI2}]]]*
        conj[Cp[Glu[{gO2}], bar[Fu[{gI1}]], Su[{gI2}]][PR]]*
        Cp[Glu[{gO1}], bar[Fu[{gI1}]], Su[{gI2}]][PR]]]/4 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], Mass2[Sd[{gI1}]]]*
        conj[Cp[Glu[{gO2}], conj[Sd[{gI1}]], Fd[{gI2}]][PR]]*
        Cp[Glu[{gO1}], conj[Sd[{gI1}]], Fd[{gI2}]][PR]]]/4 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI2}]], Mass2[Su[{gI1}]]]*
        conj[Cp[Glu[{gO2}], conj[Su[{gI1}]], Fu[{gI2}]][PR]]*
        Cp[Glu[{gO1}], conj[Su[{gI1}]], Fu[{gI2}]][PR]]]/4 - 
    3*(rMS/2 + B1[p^2, Mass2[Glu], 0])*conj[Cp[Glu[{gO2}], VG, Glu[{1}]][PL]]*
     Cp[Glu[{gO1}], VG, Glu[{1}]][PL], 
   -sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fd[{gI1}]], Mass2[Sd[{gI2}]]]*
         conj[Cp[Glu[{gO2}], bar[Fd[{gI1}]], Sd[{gI2}]][PL]]*
         Cp[Glu[{gO1}], bar[Fd[{gI1}]], Sd[{gI2}]][PL]]]/4 - 
    sum[gI1, 1, 3, sum[gI2, 1, 6, B1[p^2, Mass2[Fu[{gI1}]], Mass2[Su[{gI2}]]]*
        conj[Cp[Glu[{gO2}], bar[Fu[{gI1}]], Su[{gI2}]][PL]]*
        Cp[Glu[{gO1}], bar[Fu[{gI1}]], Su[{gI2}]][PL]]]/4 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fd[{gI2}]], Mass2[Sd[{gI1}]]]*
        conj[Cp[Glu[{gO2}], conj[Sd[{gI1}]], Fd[{gI2}]][PL]]*
        Cp[Glu[{gO1}], conj[Sd[{gI1}]], Fd[{gI2}]][PL]]]/4 - 
    sum[gI1, 1, 6, sum[gI2, 1, 3, B1[p^2, Mass2[Fu[{gI2}]], Mass2[Su[{gI1}]]]*
        conj[Cp[Glu[{gO2}], conj[Su[{gI1}]], Fu[{gI2}]][PL]]*
        Cp[Glu[{gO1}], conj[Su[{gI1}]], Fu[{gI2}]][PL]]]/4 - 
    3*(rMS/2 + B1[p^2, Mass2[Glu], 0])*conj[Cp[Glu[{gO2}], VG, Glu[{1}]][PR]]*
     Cp[Glu[{gO1}], VG, Glu[{1}]][PR]}}, 
 {VG, (-3*((2*p^2*rMS)/3 + 2*A0[0] + 4*p^2*B0[p^2, 0, 0] + 10*B00[p^2, 0, 0])*
     conj[Cp[VG, VG, VG]]*Cp[VG, VG, VG])/2 + 
   3*B00[p^2, Mass2[gG], Mass2[gG]]*conj[Cp[VG, bar[gG], gG]]*
    Cp[VG, bar[gG], gG] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, 4*B0[p^2, Mass2[Fd[{gI1}]], 
         Mass2[Fd[{gI2}]]]*Mass[Fd[{gI1}]]*Mass[Fd[{gI2}]]*
        Re[conj[Cp[VG, bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[VG, bar[Fd[{gI1}]], Fd[{gI2}]][PR]] + 
       H0[p^2, Mass2[Fd[{gI1}]], Mass2[Fd[{gI2}]]]*
        (conj[Cp[VG, bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[VG, bar[Fd[{gI1}]], Fd[{gI2}]][PL] + 
         conj[Cp[VG, bar[Fd[{gI1}]], Fd[{gI2}]][PR]]*
          Cp[VG, bar[Fd[{gI1}]], Fd[{gI2}]][PR])]]/2 + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, 4*B0[p^2, Mass2[Fu[{gI1}]], 
         Mass2[Fu[{gI2}]]]*Mass[Fu[{gI1}]]*Mass[Fu[{gI2}]]*
        Re[conj[Cp[VG, bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[VG, bar[Fu[{gI1}]], Fu[{gI2}]][PR]] + 
       H0[p^2, Mass2[Fu[{gI1}]], Mass2[Fu[{gI2}]]]*
        (conj[Cp[VG, bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[VG, bar[Fu[{gI1}]], Fu[{gI2}]][PL] + 
         conj[Cp[VG, bar[Fu[{gI1}]], Fu[{gI2}]][PR]]*
          Cp[VG, bar[Fu[{gI1}]], Fu[{gI2}]][PR])]]/2 + 
   999*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[VG, VG, conj[Sd[{gI1}]], 
       Sd[{gI1}]]] + 999*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*
      Cp[VG, VG, conj[Su[{gI1}]], Su[{gI1}]]] - 
   2*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Sd[{gI1}]], 
        Mass2[Sd[{gI2}]]]*conj[Cp[VG, conj[Sd[{gI1}]], Sd[{gI2}]]]*
       Cp[VG, conj[Sd[{gI1}]], Sd[{gI2}]]]] - 
   2*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Su[{gI1}]], 
        Mass2[Su[{gI2}]]]*conj[Cp[VG, conj[Su[{gI1}]], Su[{gI2}]]]*
       Cp[VG, conj[Su[{gI1}]], Su[{gI2}]]]] + 
   (3*(4*B0[p^2, Mass2[Glu], Mass2[Glu]]*Mass[Glu]^2*
       Re[conj[Cp[VG, Glu[{1}], Glu[{1}]][PL]]*Cp[VG, Glu[{1}], Glu[{1}]][
          PR]] + H0[p^2, Mass2[Glu], Mass2[Glu]]*
       (conj[Cp[VG, Glu[{1}], Glu[{1}]][PL]]*Cp[VG, Glu[{1}], Glu[{1}]][PL] + 
        conj[Cp[VG, Glu[{1}], Glu[{1}]][PR]]*Cp[VG, Glu[{1}], Glu[{1}]][
          PR])))/2 - (A0[0]*(4*Cp[VG, VG, VG, VG][1] + 
      Cp[VG, VG, VG, VG][2] + Cp[VG, VG, VG, VG][3]))/2}, 
 {VP, B00[p^2, Mass2[gWm], Mass2[gWm]]*conj[Cp[VP, bar[gWm], gWm]]*
    Cp[VP, bar[gWm], gWm] + B00[p^2, Mass2[gWmC], Mass2[gWmC]]*
    conj[Cp[VP, bar[gWmC], gWmC]]*Cp[VP, bar[gWmC], gWmC] - 
   conj[Cp[VP, conj[VWm], VWm]]*Cp[VP, conj[VWm], VWm]*
    (2*A0[Mass2[VWm]] + 10*B00[p^2, Mass2[VWm], Mass2[VWm]] - 
     2*rMS*(-p^2/3 + 2*Mass2[VWm]) + B0[p^2, Mass2[VWm], Mass2[VWm]]*
      (4*p^2 + 2*Mass2[VWm])) + sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*
     Cp[VP, VP, conj[Hpm[{gI1}]], Hpm[{gI1}]]] - 
   4*sum[gI1, 1, 2, sum[gI2, 1, 2, B00[p^2, Mass2[Hpm[{gI1}]], 
        Mass2[Hpm[{gI2}]]]*conj[Cp[VP, conj[Hpm[{gI1}]], Hpm[{gI2}]]]*
       Cp[VP, conj[Hpm[{gI1}]], Hpm[{gI2}]]]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 2, 
     4*B0[p^2, Mass2[Cha[{gI1}]], Mass2[Cha[{gI2}]]]*Mass[Cha[{gI1}]]*
       Mass[Cha[{gI2}]]*Re[conj[Cp[VP, bar[Cha[{gI1}]], Cha[{gI2}]][PL]]*
         Cp[VP, bar[Cha[{gI1}]], Cha[{gI2}]][PR]] + 
      H0[p^2, Mass2[Cha[{gI1}]], Mass2[Cha[{gI2}]]]*
       (conj[Cp[VP, bar[Cha[{gI1}]], Cha[{gI2}]][PL]]*
         Cp[VP, bar[Cha[{gI1}]], Cha[{gI2}]][PL] + 
        conj[Cp[VP, bar[Cha[{gI1}]], Cha[{gI2}]][PR]]*
         Cp[VP, bar[Cha[{gI1}]], Cha[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, 
      4*B0[p^2, Mass2[Fd[{gI1}]], Mass2[Fd[{gI2}]]]*Mass[Fd[{gI1}]]*
        Mass[Fd[{gI2}]]*Re[conj[Cp[VP, bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[VP, bar[Fd[{gI1}]], Fd[{gI2}]][PR]] + 
       H0[p^2, Mass2[Fd[{gI1}]], Mass2[Fd[{gI2}]]]*
        (conj[Cp[VP, bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[VP, bar[Fd[{gI1}]], Fd[{gI2}]][PL] + 
         conj[Cp[VP, bar[Fd[{gI1}]], Fd[{gI2}]][PR]]*
          Cp[VP, bar[Fd[{gI1}]], Fd[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, 
     4*B0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*Mass[Fe[{gI1}]]*
       Mass[Fe[{gI2}]]*Re[conj[Cp[VP, bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
         Cp[VP, bar[Fe[{gI1}]], Fe[{gI2}]][PR]] + 
      H0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*
       (conj[Cp[VP, bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
         Cp[VP, bar[Fe[{gI1}]], Fe[{gI2}]][PL] + 
        conj[Cp[VP, bar[Fe[{gI1}]], Fe[{gI2}]][PR]]*
         Cp[VP, bar[Fe[{gI1}]], Fe[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, 
      4*B0[p^2, Mass2[Fu[{gI1}]], Mass2[Fu[{gI2}]]]*Mass[Fu[{gI1}]]*
        Mass[Fu[{gI2}]]*Re[conj[Cp[VP, bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[VP, bar[Fu[{gI1}]], Fu[{gI2}]][PR]] + 
       H0[p^2, Mass2[Fu[{gI1}]], Mass2[Fu[{gI2}]]]*
        (conj[Cp[VP, bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[VP, bar[Fu[{gI1}]], Fu[{gI2}]][PL] + 
         conj[Cp[VP, bar[Fu[{gI1}]], Fu[{gI2}]][PR]]*
          Cp[VP, bar[Fu[{gI1}]], Fu[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[VP, VP, conj[Sd[{gI1}]], 
       Sd[{gI1}]]] + sum[gI1, 1, 6, A0[Mass2[Se[{gI1}]]]*
     Cp[VP, VP, conj[Se[{gI1}]], Se[{gI1}]]] + 
   3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*Cp[VP, VP, conj[Su[{gI1}]], 
       Su[{gI1}]]] - 12*sum[gI1, 1, 6, sum[gI2, 1, 6, 
      B00[p^2, Mass2[Sd[{gI1}]], Mass2[Sd[{gI2}]]]*
       conj[Cp[VP, conj[Sd[{gI1}]], Sd[{gI2}]]]*Cp[VP, conj[Sd[{gI1}]], 
        Sd[{gI2}]]]] - 4*sum[gI1, 1, 6, sum[gI2, 1, 6, 
      B00[p^2, Mass2[Se[{gI1}]], Mass2[Se[{gI2}]]]*
       conj[Cp[VP, conj[Se[{gI1}]], Se[{gI2}]]]*Cp[VP, conj[Se[{gI1}]], 
        Se[{gI2}]]]] - 12*sum[gI1, 1, 6, sum[gI2, 1, 6, 
      B00[p^2, Mass2[Su[{gI1}]], Mass2[Su[{gI2}]]]*
       conj[Cp[VP, conj[Su[{gI1}]], Su[{gI2}]]]*Cp[VP, conj[Su[{gI1}]], 
        Su[{gI2}]]]] + 
   2*sum[gI2, 1, 2, B0[p^2, Mass2[VWm], Mass2[Hpm[{gI2}]]]*
      conj[Cp[VP, conj[VWm], Hpm[{gI2}]]]*Cp[VP, conj[VWm], Hpm[{gI2}]]] + 
   2*rMS*Mass2[VWm]*Cp[VP, VP, conj[VWm], VWm][1] - 
   A0[Mass2[VWm]]*(4*Cp[VP, VP, conj[VWm], VWm][1] + 
     Cp[VP, VP, conj[VWm], VWm][2] + Cp[VP, VP, conj[VWm], VWm][3])}, 
 {VZ, B00[p^2, Mass2[gWm], Mass2[gWm]]*conj[Cp[VZ, bar[gWm], gWm]]*
    Cp[VZ, bar[gWm], gWm] + B00[p^2, Mass2[gWmC], Mass2[gWmC]]*
    conj[Cp[VZ, bar[gWmC], gWmC]]*Cp[VZ, bar[gWmC], gWmC] - 
   conj[Cp[VZ, conj[VWm], VWm]]*Cp[VZ, conj[VWm], VWm]*
    (2*A0[Mass2[VWm]] + 10*B00[p^2, Mass2[VWm], Mass2[VWm]] - 
     2*rMS*(-p^2/3 + 2*Mass2[VWm]) + B0[p^2, Mass2[VWm], Mass2[VWm]]*
      (4*p^2 + 2*Mass2[VWm])) + sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*
     Cp[VZ, VZ, conj[Hpm[{gI1}]], Hpm[{gI1}]]] - 
   4*sum[gI1, 1, 2, sum[gI2, 1, 2, B00[p^2, Mass2[Hpm[{gI1}]], 
        Mass2[Hpm[{gI2}]]]*conj[Cp[VZ, conj[Hpm[{gI1}]], Hpm[{gI2}]]]*
       Cp[VZ, conj[Hpm[{gI1}]], Hpm[{gI2}]]]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 2, 
     4*B0[p^2, Mass2[Cha[{gI1}]], Mass2[Cha[{gI2}]]]*Mass[Cha[{gI1}]]*
       Mass[Cha[{gI2}]]*Re[conj[Cp[VZ, bar[Cha[{gI1}]], Cha[{gI2}]][PL]]*
         Cp[VZ, bar[Cha[{gI1}]], Cha[{gI2}]][PR]] + 
      H0[p^2, Mass2[Cha[{gI1}]], Mass2[Cha[{gI2}]]]*
       (conj[Cp[VZ, bar[Cha[{gI1}]], Cha[{gI2}]][PL]]*
         Cp[VZ, bar[Cha[{gI1}]], Cha[{gI2}]][PL] + 
        conj[Cp[VZ, bar[Cha[{gI1}]], Cha[{gI2}]][PR]]*
         Cp[VZ, bar[Cha[{gI1}]], Cha[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[VZ, VZ, Ah[{gI1}], Ah[{gI1}]]]/2 + 
   sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*Cp[VZ, VZ, hh[{gI1}], hh[{gI1}]]]/2 - 
   4*sum[gI1, 1, 3, sum[gI2, 1, 3, B00[p^2, Mass2[Ah[{gI2}]], 
        Mass2[hh[{gI1}]]]*conj[Cp[VZ, hh[{gI1}], Ah[{gI2}]]]*
       Cp[VZ, hh[{gI1}], Ah[{gI2}]]]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, 
      4*B0[p^2, Mass2[Fd[{gI1}]], Mass2[Fd[{gI2}]]]*Mass[Fd[{gI1}]]*
        Mass[Fd[{gI2}]]*Re[conj[Cp[VZ, bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[VZ, bar[Fd[{gI1}]], Fd[{gI2}]][PR]] + 
       H0[p^2, Mass2[Fd[{gI1}]], Mass2[Fd[{gI2}]]]*
        (conj[Cp[VZ, bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[VZ, bar[Fd[{gI1}]], Fd[{gI2}]][PL] + 
         conj[Cp[VZ, bar[Fd[{gI1}]], Fd[{gI2}]][PR]]*
          Cp[VZ, bar[Fd[{gI1}]], Fd[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, 
     4*B0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*Mass[Fe[{gI1}]]*
       Mass[Fe[{gI2}]]*Re[conj[Cp[VZ, bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
         Cp[VZ, bar[Fe[{gI1}]], Fe[{gI2}]][PR]] + 
      H0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*
       (conj[Cp[VZ, bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
         Cp[VZ, bar[Fe[{gI1}]], Fe[{gI2}]][PL] + 
        conj[Cp[VZ, bar[Fe[{gI1}]], Fe[{gI2}]][PR]]*
         Cp[VZ, bar[Fe[{gI1}]], Fe[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, 
      4*B0[p^2, Mass2[Fu[{gI1}]], Mass2[Fu[{gI2}]]]*Mass[Fu[{gI1}]]*
        Mass[Fu[{gI2}]]*Re[conj[Cp[VZ, bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[VZ, bar[Fu[{gI1}]], Fu[{gI2}]][PR]] + 
       H0[p^2, Mass2[Fu[{gI1}]], Mass2[Fu[{gI2}]]]*
        (conj[Cp[VZ, bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[VZ, bar[Fu[{gI1}]], Fu[{gI2}]][PL] + 
         conj[Cp[VZ, bar[Fu[{gI1}]], Fu[{gI2}]][PR]]*
          Cp[VZ, bar[Fu[{gI1}]], Fu[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, 
     4*B0[p^2, Mass2[Fv[{gI1}]], Mass2[Fv[{gI2}]]]*Mass[Fv[{gI1}]]*
       Mass[Fv[{gI2}]]*Re[conj[Cp[VZ, bar[Fv[{gI1}]], Fv[{gI2}]][PL]]*
         Cp[VZ, bar[Fv[{gI1}]], Fv[{gI2}]][PR]] + 
      H0[p^2, Mass2[Fv[{gI1}]], Mass2[Fv[{gI2}]]]*
       (conj[Cp[VZ, bar[Fv[{gI1}]], Fv[{gI2}]][PL]]*
         Cp[VZ, bar[Fv[{gI1}]], Fv[{gI2}]][PL] + 
        conj[Cp[VZ, bar[Fv[{gI1}]], Fv[{gI2}]][PR]]*
         Cp[VZ, bar[Fv[{gI1}]], Fv[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[VZ, VZ, conj[Sd[{gI1}]], 
       Sd[{gI1}]]] + sum[gI1, 1, 6, A0[Mass2[Se[{gI1}]]]*
     Cp[VZ, VZ, conj[Se[{gI1}]], Se[{gI1}]]] + 
   3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*Cp[VZ, VZ, conj[Su[{gI1}]], 
       Su[{gI1}]]] + sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*
     Cp[VZ, VZ, conj[Sv[{gI1}]], Sv[{gI1}]]] - 
   12*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Sd[{gI1}]], 
        Mass2[Sd[{gI2}]]]*conj[Cp[VZ, conj[Sd[{gI1}]], Sd[{gI2}]]]*
       Cp[VZ, conj[Sd[{gI1}]], Sd[{gI2}]]]] - 
   4*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Se[{gI1}]], 
        Mass2[Se[{gI2}]]]*conj[Cp[VZ, conj[Se[{gI1}]], Se[{gI2}]]]*
       Cp[VZ, conj[Se[{gI1}]], Se[{gI2}]]]] - 
   12*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Su[{gI1}]], 
        Mass2[Su[{gI2}]]]*conj[Cp[VZ, conj[Su[{gI1}]], Su[{gI2}]]]*
       Cp[VZ, conj[Su[{gI1}]], Su[{gI2}]]]] - 
   4*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Sv[{gI1}]], 
        Mass2[Sv[{gI2}]]]*conj[Cp[VZ, conj[Sv[{gI1}]], Sv[{gI2}]]]*
       Cp[VZ, conj[Sv[{gI1}]], Sv[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 6, 4*B0[p^2, Mass2[Chi[{gI1}]], 
         Mass2[Chi[{gI2}]]]*Mass[Chi[{gI1}]]*Mass[Chi[{gI2}]]*
        Re[conj[Cp[VZ, Chi[{gI1}], Chi[{gI2}]][PL]]*
          Cp[VZ, Chi[{gI1}], Chi[{gI2}]][PR]] + 
       H0[p^2, Mass2[Chi[{gI1}]], Mass2[Chi[{gI2}]]]*
        (conj[Cp[VZ, Chi[{gI1}], Chi[{gI2}]][PL]]*
          Cp[VZ, Chi[{gI1}], Chi[{gI2}]][PL] + 
         conj[Cp[VZ, Chi[{gI1}], Chi[{gI2}]][PR]]*
          Cp[VZ, Chi[{gI1}], Chi[{gI2}]][PR])]]/2 + 
   2*sum[gI2, 1, 2, B0[p^2, Mass2[VWm], Mass2[Hpm[{gI2}]]]*
      conj[Cp[VZ, conj[VWm], Hpm[{gI2}]]]*Cp[VZ, conj[VWm], Hpm[{gI2}]]] + 
   sum[gI2, 1, 3, B0[p^2, Mass2[VZ], Mass2[hh[{gI2}]]]*
     conj[Cp[VZ, VZ, hh[{gI2}]]]*Cp[VZ, VZ, hh[{gI2}]]] + 
   sum[gI2, 1, 3, B0[p^2, Mass2[VZp], Mass2[hh[{gI2}]]]*
     conj[Cp[VZ, VZp, hh[{gI2}]]]*Cp[VZ, VZp, hh[{gI2}]]] + 
   2*rMS*Mass2[VWm]*Cp[VZ, VZ, conj[VWm], VWm][1] - 
   A0[Mass2[VWm]]*(4*Cp[VZ, VZ, conj[VWm], VWm][1] + 
     Cp[VZ, VZ, conj[VWm], VWm][2] + Cp[VZ, VZ, conj[VWm], VWm][3])}, 
 {VZp, B00[p^2, Mass2[gWm], Mass2[gWm]]*conj[Cp[VZp, bar[gWm], gWm]]*
    Cp[VZp, bar[gWm], gWm] + B00[p^2, Mass2[gWmC], Mass2[gWmC]]*
    conj[Cp[VZp, bar[gWmC], gWmC]]*Cp[VZp, bar[gWmC], gWmC] - 
   conj[Cp[VZp, conj[VWm], VWm]]*Cp[VZp, conj[VWm], VWm]*
    (2*A0[Mass2[VWm]] + 10*B00[p^2, Mass2[VWm], Mass2[VWm]] - 
     2*rMS*(-p^2/3 + 2*Mass2[VWm]) + B0[p^2, Mass2[VWm], Mass2[VWm]]*
      (4*p^2 + 2*Mass2[VWm])) + sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*
     Cp[VZp, VZp, conj[Hpm[{gI1}]], Hpm[{gI1}]]] - 
   4*sum[gI1, 1, 2, sum[gI2, 1, 2, B00[p^2, Mass2[Hpm[{gI1}]], 
        Mass2[Hpm[{gI2}]]]*conj[Cp[VZp, conj[Hpm[{gI1}]], Hpm[{gI2}]]]*
       Cp[VZp, conj[Hpm[{gI1}]], Hpm[{gI2}]]]] + 
   sum[gI1, 1, 2, sum[gI2, 1, 2, 
     4*B0[p^2, Mass2[Cha[{gI1}]], Mass2[Cha[{gI2}]]]*Mass[Cha[{gI1}]]*
       Mass[Cha[{gI2}]]*Re[conj[Cp[VZp, bar[Cha[{gI1}]], Cha[{gI2}]][PL]]*
         Cp[VZp, bar[Cha[{gI1}]], Cha[{gI2}]][PR]] + 
      H0[p^2, Mass2[Cha[{gI1}]], Mass2[Cha[{gI2}]]]*
       (conj[Cp[VZp, bar[Cha[{gI1}]], Cha[{gI2}]][PL]]*
         Cp[VZp, bar[Cha[{gI1}]], Cha[{gI2}]][PL] + 
        conj[Cp[VZp, bar[Cha[{gI1}]], Cha[{gI2}]][PR]]*
         Cp[VZp, bar[Cha[{gI1}]], Cha[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*Cp[VZp, VZp, Ah[{gI1}], Ah[{gI1}]]]/
    2 + sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*Cp[VZp, VZp, hh[{gI1}], 
       hh[{gI1}]]]/2 - 4*sum[gI1, 1, 3, sum[gI2, 1, 3, 
      B00[p^2, Mass2[Ah[{gI2}]], Mass2[hh[{gI1}]]]*
       conj[Cp[VZp, hh[{gI1}], Ah[{gI2}]]]*Cp[VZp, hh[{gI1}], Ah[{gI2}]]]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, 
      4*B0[p^2, Mass2[Fd[{gI1}]], Mass2[Fd[{gI2}]]]*Mass[Fd[{gI1}]]*
        Mass[Fd[{gI2}]]*Re[conj[Cp[VZp, bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[VZp, bar[Fd[{gI1}]], Fd[{gI2}]][PR]] + 
       H0[p^2, Mass2[Fd[{gI1}]], Mass2[Fd[{gI2}]]]*
        (conj[Cp[VZp, bar[Fd[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[VZp, bar[Fd[{gI1}]], Fd[{gI2}]][PL] + 
         conj[Cp[VZp, bar[Fd[{gI1}]], Fd[{gI2}]][PR]]*
          Cp[VZp, bar[Fd[{gI1}]], Fd[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, 
     4*B0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*Mass[Fe[{gI1}]]*
       Mass[Fe[{gI2}]]*Re[conj[Cp[VZp, bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
         Cp[VZp, bar[Fe[{gI1}]], Fe[{gI2}]][PR]] + 
      H0[p^2, Mass2[Fe[{gI1}]], Mass2[Fe[{gI2}]]]*
       (conj[Cp[VZp, bar[Fe[{gI1}]], Fe[{gI2}]][PL]]*
         Cp[VZp, bar[Fe[{gI1}]], Fe[{gI2}]][PL] + 
        conj[Cp[VZp, bar[Fe[{gI1}]], Fe[{gI2}]][PR]]*
         Cp[VZp, bar[Fe[{gI1}]], Fe[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 3, sum[gI2, 1, 3, 
      4*B0[p^2, Mass2[Fu[{gI1}]], Mass2[Fu[{gI2}]]]*Mass[Fu[{gI1}]]*
        Mass[Fu[{gI2}]]*Re[conj[Cp[VZp, bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[VZp, bar[Fu[{gI1}]], Fu[{gI2}]][PR]] + 
       H0[p^2, Mass2[Fu[{gI1}]], Mass2[Fu[{gI2}]]]*
        (conj[Cp[VZp, bar[Fu[{gI1}]], Fu[{gI2}]][PL]]*
          Cp[VZp, bar[Fu[{gI1}]], Fu[{gI2}]][PL] + 
         conj[Cp[VZp, bar[Fu[{gI1}]], Fu[{gI2}]][PR]]*
          Cp[VZp, bar[Fu[{gI1}]], Fu[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, 
     4*B0[p^2, Mass2[Fv[{gI1}]], Mass2[Fv[{gI2}]]]*Mass[Fv[{gI1}]]*
       Mass[Fv[{gI2}]]*Re[conj[Cp[VZp, bar[Fv[{gI1}]], Fv[{gI2}]][PL]]*
         Cp[VZp, bar[Fv[{gI1}]], Fv[{gI2}]][PR]] + 
      H0[p^2, Mass2[Fv[{gI1}]], Mass2[Fv[{gI2}]]]*
       (conj[Cp[VZp, bar[Fv[{gI1}]], Fv[{gI2}]][PL]]*
         Cp[VZp, bar[Fv[{gI1}]], Fv[{gI2}]][PL] + 
        conj[Cp[VZp, bar[Fv[{gI1}]], Fv[{gI2}]][PR]]*
         Cp[VZp, bar[Fv[{gI1}]], Fv[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[VZp, VZp, conj[Sd[{gI1}]], 
       Sd[{gI1}]]] + sum[gI1, 1, 6, A0[Mass2[Se[{gI1}]]]*
     Cp[VZp, VZp, conj[Se[{gI1}]], Se[{gI1}]]] + 
   3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*Cp[VZp, VZp, conj[Su[{gI1}]], 
       Su[{gI1}]]] + sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*
     Cp[VZp, VZp, conj[Sv[{gI1}]], Sv[{gI1}]]] - 
   12*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Sd[{gI1}]], 
        Mass2[Sd[{gI2}]]]*conj[Cp[VZp, conj[Sd[{gI1}]], Sd[{gI2}]]]*
       Cp[VZp, conj[Sd[{gI1}]], Sd[{gI2}]]]] - 
   4*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Se[{gI1}]], 
        Mass2[Se[{gI2}]]]*conj[Cp[VZp, conj[Se[{gI1}]], Se[{gI2}]]]*
       Cp[VZp, conj[Se[{gI1}]], Se[{gI2}]]]] - 
   12*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Su[{gI1}]], 
        Mass2[Su[{gI2}]]]*conj[Cp[VZp, conj[Su[{gI1}]], Su[{gI2}]]]*
       Cp[VZp, conj[Su[{gI1}]], Su[{gI2}]]]] - 
   4*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Sv[{gI1}]], 
        Mass2[Sv[{gI2}]]]*conj[Cp[VZp, conj[Sv[{gI1}]], Sv[{gI2}]]]*
       Cp[VZp, conj[Sv[{gI1}]], Sv[{gI2}]]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 6, 4*B0[p^2, Mass2[Chi[{gI1}]], 
         Mass2[Chi[{gI2}]]]*Mass[Chi[{gI1}]]*Mass[Chi[{gI2}]]*
        Re[conj[Cp[VZp, Chi[{gI1}], Chi[{gI2}]][PL]]*
          Cp[VZp, Chi[{gI1}], Chi[{gI2}]][PR]] + 
       H0[p^2, Mass2[Chi[{gI1}]], Mass2[Chi[{gI2}]]]*
        (conj[Cp[VZp, Chi[{gI1}], Chi[{gI2}]][PL]]*
          Cp[VZp, Chi[{gI1}], Chi[{gI2}]][PL] + 
         conj[Cp[VZp, Chi[{gI1}], Chi[{gI2}]][PR]]*
          Cp[VZp, Chi[{gI1}], Chi[{gI2}]][PR])]]/2 + 
   2*sum[gI2, 1, 2, B0[p^2, Mass2[VWm], Mass2[Hpm[{gI2}]]]*
      conj[Cp[VZp, conj[VWm], Hpm[{gI2}]]]*Cp[VZp, conj[VWm], Hpm[{gI2}]]] + 
   sum[gI2, 1, 3, B0[p^2, Mass2[VZ], Mass2[hh[{gI2}]]]*
     conj[Cp[VZp, VZ, hh[{gI2}]]]*Cp[VZp, VZ, hh[{gI2}]]] + 
   sum[gI2, 1, 3, B0[p^2, Mass2[VZp], Mass2[hh[{gI2}]]]*
     conj[Cp[VZp, VZp, hh[{gI2}]]]*Cp[VZp, VZp, hh[{gI2}]]] + 
   2*rMS*Mass2[VWm]*Cp[VZp, VZp, conj[VWm], VWm][1] - 
   A0[Mass2[VWm]]*(4*Cp[VZp, VZp, conj[VWm], VWm][1] + 
     Cp[VZp, VZp, conj[VWm], VWm][2] + Cp[VZp, VZp, conj[VWm], VWm][3])}, 
 {VWm, B00[p^2, Mass2[gWm], Mass2[gP]]*conj[Cp[conj[VWm], bar[gP], gWm]]*
    Cp[conj[VWm], bar[gP], gWm] + B00[p^2, Mass2[gP], Mass2[gWmC]]*
    conj[Cp[conj[VWm], bar[gWmC], gP]]*Cp[conj[VWm], bar[gWmC], gP] + 
   B00[p^2, Mass2[gZ], Mass2[gWmC]]*conj[Cp[conj[VWm], bar[gWmC], gZ]]*
    Cp[conj[VWm], bar[gWmC], gZ] + B00[p^2, Mass2[gZp], Mass2[gWmC]]*
    conj[Cp[conj[VWm], bar[gWmC], gZp]]*Cp[conj[VWm], bar[gWmC], gZp] + 
   B00[p^2, Mass2[gWm], Mass2[gZ]]*conj[Cp[conj[VWm], bar[gZ], gWm]]*
    Cp[conj[VWm], bar[gZ], gWm] + B00[p^2, Mass2[gWm], Mass2[gZp]]*
    conj[Cp[conj[VWm], bar[gZp], gWm]]*Cp[conj[VWm], bar[gZp], gWm] - 
   conj[Cp[conj[VWm], VWm, VP]]*Cp[conj[VWm], VWm, VP]*
    (A0[0] + A0[Mass2[VWm]] + 10*B00[p^2, Mass2[VWm], 0] - 
     2*rMS*(-p^2/3 + Mass2[VWm]) + B0[p^2, Mass2[VWm], 0]*
      (4*p^2 + Mass2[VWm])) - conj[Cp[conj[VWm], VZ, VWm]]*
    Cp[conj[VWm], VZ, VWm]*(A0[Mass2[VWm]] + A0[Mass2[VZ]] + 
     10*B00[p^2, Mass2[VZ], Mass2[VWm]] - 
     2*rMS*(-p^2/3 + Mass2[VWm] + Mass2[VZ]) + B0[p^2, Mass2[VZ], Mass2[VWm]]*
      (4*p^2 + Mass2[VWm] + Mass2[VZ])) - conj[Cp[conj[VWm], VZp, VWm]]*
    Cp[conj[VWm], VZp, VWm]*(A0[Mass2[VWm]] + A0[Mass2[VZp]] + 
     10*B00[p^2, Mass2[VZp], Mass2[VWm]] - 
     2*rMS*(-p^2/3 + Mass2[VWm] + Mass2[VZp]) + 
     B0[p^2, Mass2[VZp], Mass2[VWm]]*(4*p^2 + Mass2[VWm] + Mass2[VZp])) + 
   sum[gI1, 1, 2, A0[Mass2[Hpm[{gI1}]]]*Cp[VWm, conj[VWm], conj[Hpm[{gI1}]], 
      Hpm[{gI1}]]] - 4*sum[gI1, 1, 2, sum[gI2, 1, 3, 
      B00[p^2, Mass2[Ah[{gI2}]], Mass2[Hpm[{gI1}]]]*
       conj[Cp[conj[VWm], Hpm[{gI1}], Ah[{gI2}]]]*Cp[conj[VWm], Hpm[{gI1}], 
        Ah[{gI2}]]]] - 4*sum[gI1, 1, 2, sum[gI2, 1, 3, 
      B00[p^2, Mass2[hh[{gI2}]], Mass2[Hpm[{gI1}]]]*
       conj[Cp[conj[VWm], Hpm[{gI1}], hh[{gI2}]]]*Cp[conj[VWm], Hpm[{gI1}], 
        hh[{gI2}]]]] + sum[gI1, 1, 3, A0[Mass2[Ah[{gI1}]]]*
      Cp[VWm, conj[VWm], Ah[{gI1}], Ah[{gI1}]]]/2 + 
   sum[gI1, 1, 3, A0[Mass2[hh[{gI1}]]]*Cp[VWm, conj[VWm], hh[{gI1}], 
       hh[{gI1}]]]/2 + 3*sum[gI1, 1, 3, sum[gI2, 1, 3, 
      4*B0[p^2, Mass2[Fu[{gI1}]], Mass2[Fd[{gI2}]]]*Mass[Fd[{gI2}]]*
        Mass[Fu[{gI1}]]*Re[conj[Cp[conj[VWm], bar[Fu[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[conj[VWm], bar[Fu[{gI1}]], Fd[{gI2}]][PR]] + 
       H0[p^2, Mass2[Fu[{gI1}]], Mass2[Fd[{gI2}]]]*
        (conj[Cp[conj[VWm], bar[Fu[{gI1}]], Fd[{gI2}]][PL]]*
          Cp[conj[VWm], bar[Fu[{gI1}]], Fd[{gI2}]][PL] + 
         conj[Cp[conj[VWm], bar[Fu[{gI1}]], Fd[{gI2}]][PR]]*
          Cp[conj[VWm], bar[Fu[{gI1}]], Fd[{gI2}]][PR])]] + 
   sum[gI1, 1, 3, sum[gI2, 1, 3, 
     4*B0[p^2, Mass2[Fv[{gI1}]], Mass2[Fe[{gI2}]]]*Mass[Fe[{gI2}]]*
       Mass[Fv[{gI1}]]*Re[conj[Cp[conj[VWm], bar[Fv[{gI1}]], Fe[{gI2}]][PL]]*
         Cp[conj[VWm], bar[Fv[{gI1}]], Fe[{gI2}]][PR]] + 
      H0[p^2, Mass2[Fv[{gI1}]], Mass2[Fe[{gI2}]]]*
       (conj[Cp[conj[VWm], bar[Fv[{gI1}]], Fe[{gI2}]][PL]]*
         Cp[conj[VWm], bar[Fv[{gI1}]], Fe[{gI2}]][PL] + 
        conj[Cp[conj[VWm], bar[Fv[{gI1}]], Fe[{gI2}]][PR]]*
         Cp[conj[VWm], bar[Fv[{gI1}]], Fe[{gI2}]][PR])]] + 
   3*sum[gI1, 1, 6, A0[Mass2[Sd[{gI1}]]]*Cp[VWm, conj[VWm], conj[Sd[{gI1}]], 
       Sd[{gI1}]]] + sum[gI1, 1, 6, A0[Mass2[Se[{gI1}]]]*
     Cp[VWm, conj[VWm], conj[Se[{gI1}]], Se[{gI1}]]] + 
   3*sum[gI1, 1, 6, A0[Mass2[Su[{gI1}]]]*Cp[VWm, conj[VWm], conj[Su[{gI1}]], 
       Su[{gI1}]]] + sum[gI1, 1, 6, A0[Mass2[Sv[{gI1}]]]*
     Cp[VWm, conj[VWm], conj[Sv[{gI1}]], Sv[{gI1}]]] + 
   sum[gI1, 1, 6, sum[gI2, 1, 2, 
     4*B0[p^2, Mass2[Chi[{gI1}]], Mass2[Cha[{gI2}]]]*Mass[Cha[{gI2}]]*
       Mass[Chi[{gI1}]]*Re[conj[Cp[conj[VWm], Chi[{gI1}], Cha[{gI2}]][PL]]*
         Cp[conj[VWm], Chi[{gI1}], Cha[{gI2}]][PR]] + 
      H0[p^2, Mass2[Chi[{gI1}]], Mass2[Cha[{gI2}]]]*
       (conj[Cp[conj[VWm], Chi[{gI1}], Cha[{gI2}]][PL]]*
         Cp[conj[VWm], Chi[{gI1}], Cha[{gI2}]][PL] + 
        conj[Cp[conj[VWm], Chi[{gI1}], Cha[{gI2}]][PR]]*
         Cp[conj[VWm], Chi[{gI1}], Cha[{gI2}]][PR])]] - 
   12*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Sd[{gI2}]], 
        Mass2[Su[{gI1}]]]*conj[Cp[conj[VWm], conj[Su[{gI1}]], Sd[{gI2}]]]*
       Cp[conj[VWm], conj[Su[{gI1}]], Sd[{gI2}]]]] - 
   4*sum[gI1, 1, 6, sum[gI2, 1, 6, B00[p^2, Mass2[Se[{gI2}]], 
        Mass2[Sv[{gI1}]]]*conj[Cp[conj[VWm], conj[Sv[{gI1}]], Se[{gI2}]]]*
       Cp[conj[VWm], conj[Sv[{gI1}]], Se[{gI2}]]]] + 
   sum[gI2, 1, 2, B0[p^2, 0, Mass2[Hpm[{gI2}]]]*
     conj[Cp[conj[VWm], VP, Hpm[{gI2}]]]*Cp[conj[VWm], VP, Hpm[{gI2}]]] + 
   sum[gI2, 1, 2, B0[p^2, Mass2[VZ], Mass2[Hpm[{gI2}]]]*
     conj[Cp[conj[VWm], VZ, Hpm[{gI2}]]]*Cp[conj[VWm], VZ, Hpm[{gI2}]]] + 
   sum[gI2, 1, 2, B0[p^2, Mass2[VZp], Mass2[Hpm[{gI2}]]]*
     conj[Cp[conj[VWm], VZp, Hpm[{gI2}]]]*Cp[conj[VWm], VZp, Hpm[{gI2}]]] + 
   sum[gI2, 1, 3, B0[p^2, Mass2[VWm], Mass2[hh[{gI2}]]]*
     conj[Cp[conj[VWm], VWm, hh[{gI2}]]]*Cp[conj[VWm], VWm, hh[{gI2}]]] - 
   (A0[0]*(4*Cp[VWm, conj[VWm], VP, VP][1] + Cp[VWm, conj[VWm], VP, VP][2] + 
      Cp[VWm, conj[VWm], VP, VP][3]))/2 + 
   (2*rMS*Mass2[VZ]*Cp[VWm, conj[VWm], VZ, VZ][1] - 
     A0[Mass2[VZ]]*(4*Cp[VWm, conj[VWm], VZ, VZ][1] + 
       Cp[VWm, conj[VWm], VZ, VZ][2] + Cp[VWm, conj[VWm], VZ, VZ][3]))/2 + 
   (2*rMS*Mass2[VZp]*Cp[VWm, conj[VWm], VZp, VZp][1] - 
     A0[Mass2[VZp]]*(4*Cp[VWm, conj[VWm], VZp, VZp][1] + 
       Cp[VWm, conj[VWm], VZp, VZp][2] + Cp[VWm, conj[VWm], VZp, VZp][3]))/
    2 + 2*rMS*Mass2[VWm]*Cp[VWm, conj[VWm], conj[VWm], VWm][1] - 
   A0[Mass2[VWm]]*(4*Cp[VWm, conj[VWm], conj[VWm], VWm][1] + 
     Cp[VWm, conj[VWm], conj[VWm], VWm][2] + 
     Cp[VWm, conj[VWm], conj[VWm], VWm][3])}}
