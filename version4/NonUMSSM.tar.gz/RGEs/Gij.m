{{{Sq[{lef1}][{gen1, col1}], Sq[{lef2}][{gen2, col2}]}, 
  -((g1^2 + 45*g2^2 + 80*g3^2 + 60*gp^2*Qq^2)*Kronecker[i1, i2])/30 + 
   MatMul[Adj[Yd], Yd][i1, i2] + MatMul[Adj[Yu], Yu][i1, i2], 
  ((199*g1^4 + 10*g1^2*(9*g2^2 + 16*g3^2 + 12*gp^2*Qq*(9*Qd + 3*Qe1 + 3*Qe2 + 
          3*Qe3 - 3*QHd + 3*QHu - 3*Ql1 - 3*Ql2 - 3*Ql3 + 10*Qq - 18*Qu)) + 
      25*(135*g2^4 + 72*g2^2*(4*g3^2 + 3*gp^2*Qq^2) + 
        8*(-4*g3^4 + 48*g3^2*gp^2*Qq^2 + 9*gp^4*Qq^2*(9*Qd^2 + Qe1^2 + 
            Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 
            20*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2))))*
     Kronecker[i1, i2])/900 + ((2*g1^2)/5 + 2*gp^2*Qd^2 + 2*gp^2*QHd^2 - 
     2*gp^2*Qq^2 - Ye11*conj[Ye11] - Ye22*conj[Ye22] - Ye33*conj[Ye33] - 
     \[Lambda]*conj[\[Lambda]] - 3*trace[Yd, Adj[Yd]])*
    MatMul[Adj[Yd], Yd][i1, i2] + (4*g1^2*MatMul[Adj[Yu], Yu][i1, i2])/5 + 
   2*gp^2*QHu^2*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*gp^2*Qq^2*MatMul[Adj[Yu], Yu][i1, i2] + 
   2*gp^2*Qu^2*MatMul[Adj[Yu], Yu][i1, i2] - 
   Yv11*conj[Yv11]*MatMul[Adj[Yu], Yu][i1, i2] - 
   Yv22*conj[Yv22]*MatMul[Adj[Yu], Yu][i1, i2] - 
   Yv33*conj[Yv33]*MatMul[Adj[Yu], Yu][i1, i2] - \[Lambda]*conj[\[Lambda]]*
    MatMul[Adj[Yu], Yu][i1, i2] - 3*trace[Yu, Adj[Yu]]*
    MatMul[Adj[Yu], Yu][i1, i2] - 2*MatMul[Adj[Yd], Yd, Adj[Yd], Yd][i1, 
     i2] - 2*MatMul[Adj[Yu], Yu, Adj[Yu], Yu][i1, i2]}, 
 {{Sl01[{lef1}][{gen1}], Sl01[{lef2}][{gen2}]}, 
  (-3*g1^2)/10 - (3*g2^2)/2 - 2*gp^2*Ql1^2 + Ye11*conj[Ye11] + 
   Yv11*conj[Yv11], (207*g1^4)/100 + (9*g1^2*g2^2)/10 + (15*g2^4)/4 - 
   (18*g1^2*gp^2*Qd*Ql1)/5 - (6*g1^2*gp^2*Qe1*Ql1)/5 - 
   (6*g1^2*gp^2*Qe2*Ql1)/5 - (6*g1^2*gp^2*Qe3*Ql1)/5 + 
   (6*g1^2*gp^2*QHd*Ql1)/5 - (6*g1^2*gp^2*QHu*Ql1)/5 + 
   (12*g1^2*gp^2*Ql1^2)/5 + 6*g2^2*gp^2*Ql1^2 + 18*gp^4*Qd^2*Ql1^2 + 
   2*gp^4*Qe1^2*Ql1^2 + 2*gp^4*Qe2^2*Ql1^2 + 2*gp^4*Qe3^2*Ql1^2 + 
   4*gp^4*QHd^2*Ql1^2 + 4*gp^4*QHu^2*Ql1^2 + 8*gp^4*Ql1^4 + 
   (6*g1^2*gp^2*Ql1*Ql2)/5 + 4*gp^4*Ql1^2*Ql2^2 + (6*g1^2*gp^2*Ql1*Ql3)/5 + 
   4*gp^4*Ql1^2*Ql3^2 - (18*g1^2*gp^2*Ql1*Qq)/5 + 36*gp^4*Ql1^2*Qq^2 + 
   2*gp^4*Ql1^2*Qs^2 + (36*g1^2*gp^2*Ql1*Qu)/5 + 18*gp^4*Ql1^2*Qu^2 + 
   2*gp^4*Ql1^2*Qv1^2 + 2*gp^4*Ql1^2*Qv2^2 + 2*gp^4*Ql1^2*Qv3^2 - 
   3*Ye11^2*conj[Ye11]^2 - 3*Yv11^2*conj[Yv11]^2 + 
   (Ye11*conj[Ye11]*(6*g1^2 + 10*gp^2*Qe1^2 + 10*gp^2*QHd^2 - 10*gp^2*Ql1^2 - 
      5*Ye22*conj[Ye22] - 5*Ye33*conj[Ye33] - 5*\[Lambda]*conj[\[Lambda]] - 
      15*trace[Yd, Adj[Yd]]))/5 + Yv11*conj[Yv11]*
    (2*gp^2*QHu^2 - 2*gp^2*Ql1^2 + 2*gp^2*Qv1^2 - Yv22*conj[Yv22] - 
     Yv33*conj[Yv33] - \[Lambda]*conj[\[Lambda]] - 3*trace[Yu, Adj[Yu]])}, 
 {{Sl02[{lef1}][{gen1}], Sl02[{lef2}][{gen2}]}, 
  (-3*g1^2)/10 - (3*g2^2)/2 - 2*gp^2*Ql2^2 + Ye22*conj[Ye22] + 
   Yv22*conj[Yv22], (207*g1^4)/100 + (9*g1^2*g2^2)/10 + (15*g2^4)/4 - 
   (18*g1^2*gp^2*Qd*Ql2)/5 - (6*g1^2*gp^2*Qe1*Ql2)/5 - 
   (6*g1^2*gp^2*Qe2*Ql2)/5 - (6*g1^2*gp^2*Qe3*Ql2)/5 + 
   (6*g1^2*gp^2*QHd*Ql2)/5 - (6*g1^2*gp^2*QHu*Ql2)/5 + 
   (6*g1^2*gp^2*Ql1*Ql2)/5 + (12*g1^2*gp^2*Ql2^2)/5 + 6*g2^2*gp^2*Ql2^2 + 
   18*gp^4*Qd^2*Ql2^2 + 2*gp^4*Qe1^2*Ql2^2 + 2*gp^4*Qe2^2*Ql2^2 + 
   2*gp^4*Qe3^2*Ql2^2 + 4*gp^4*QHd^2*Ql2^2 + 4*gp^4*QHu^2*Ql2^2 + 
   4*gp^4*Ql1^2*Ql2^2 + 8*gp^4*Ql2^4 + (6*g1^2*gp^2*Ql2*Ql3)/5 + 
   4*gp^4*Ql2^2*Ql3^2 - (18*g1^2*gp^2*Ql2*Qq)/5 + 36*gp^4*Ql2^2*Qq^2 + 
   2*gp^4*Ql2^2*Qs^2 + (36*g1^2*gp^2*Ql2*Qu)/5 + 18*gp^4*Ql2^2*Qu^2 + 
   2*gp^4*Ql2^2*Qv1^2 + 2*gp^4*Ql2^2*Qv2^2 + 2*gp^4*Ql2^2*Qv3^2 - 
   3*Ye22^2*conj[Ye22]^2 - 3*Yv22^2*conj[Yv22]^2 + 
   (Ye22*conj[Ye22]*(6*g1^2 + 10*gp^2*Qe2^2 + 10*gp^2*QHd^2 - 10*gp^2*Ql2^2 - 
      5*Ye11*conj[Ye11] - 5*Ye33*conj[Ye33] - 5*\[Lambda]*conj[\[Lambda]] - 
      15*trace[Yd, Adj[Yd]]))/5 + Yv22*conj[Yv22]*
    (2*gp^2*QHu^2 - 2*gp^2*Ql2^2 + 2*gp^2*Qv2^2 - Yv11*conj[Yv11] - 
     Yv33*conj[Yv33] - \[Lambda]*conj[\[Lambda]] - 3*trace[Yu, Adj[Yu]])}, 
 {{Sl03[{lef1}][{gen1}], Sl03[{lef2}][{gen2}]}, 
  (-3*g1^2)/10 - (3*g2^2)/2 - 2*gp^2*Ql3^2 + Ye33*conj[Ye33] + 
   Yv33*conj[Yv33], (207*g1^4)/100 + (9*g1^2*g2^2)/10 + (15*g2^4)/4 - 
   (18*g1^2*gp^2*Qd*Ql3)/5 - (6*g1^2*gp^2*Qe1*Ql3)/5 - 
   (6*g1^2*gp^2*Qe2*Ql3)/5 - (6*g1^2*gp^2*Qe3*Ql3)/5 + 
   (6*g1^2*gp^2*QHd*Ql3)/5 - (6*g1^2*gp^2*QHu*Ql3)/5 + 
   (6*g1^2*gp^2*Ql1*Ql3)/5 + (6*g1^2*gp^2*Ql2*Ql3)/5 + 
   (12*g1^2*gp^2*Ql3^2)/5 + 6*g2^2*gp^2*Ql3^2 + 18*gp^4*Qd^2*Ql3^2 + 
   2*gp^4*Qe1^2*Ql3^2 + 2*gp^4*Qe2^2*Ql3^2 + 2*gp^4*Qe3^2*Ql3^2 + 
   4*gp^4*QHd^2*Ql3^2 + 4*gp^4*QHu^2*Ql3^2 + 4*gp^4*Ql1^2*Ql3^2 + 
   4*gp^4*Ql2^2*Ql3^2 + 8*gp^4*Ql3^4 - (18*g1^2*gp^2*Ql3*Qq)/5 + 
   36*gp^4*Ql3^2*Qq^2 + 2*gp^4*Ql3^2*Qs^2 + (36*g1^2*gp^2*Ql3*Qu)/5 + 
   18*gp^4*Ql3^2*Qu^2 + 2*gp^4*Ql3^2*Qv1^2 + 2*gp^4*Ql3^2*Qv2^2 + 
   2*gp^4*Ql3^2*Qv3^2 - 3*Ye33^2*conj[Ye33]^2 - 3*Yv33^2*conj[Yv33]^2 + 
   (Ye33*conj[Ye33]*(6*g1^2 + 10*gp^2*Qe3^2 + 10*gp^2*QHd^2 - 10*gp^2*Ql3^2 - 
      5*Ye11*conj[Ye11] - 5*Ye22*conj[Ye22] - 5*\[Lambda]*conj[\[Lambda]] - 
      15*trace[Yd, Adj[Yd]]))/5 + Yv33*conj[Yv33]*
    (2*gp^2*QHu^2 - 2*gp^2*Ql3^2 + 2*gp^2*Qv3^2 - Yv11*conj[Yv11] - 
     Yv22*conj[Yv22] - \[Lambda]*conj[\[Lambda]] - 3*trace[Yu, Adj[Yu]])}, 
 {{SHd[{lef1}][{gen1}], SHd[{lef2}][{gen2}]}, (-3*g1^2)/10 - (3*g2^2)/2 - 
   2*gp^2*QHd^2 + Ye11*conj[Ye11] + Ye22*conj[Ye22] + Ye33*conj[Ye33] + 
   \[Lambda]*conj[\[Lambda]] + 3*trace[Yd, Adj[Yd]], 
  (207*g1^4)/100 + (9*g1^2*g2^2)/10 + (15*g2^4)/4 - (18*g1^2*gp^2*Qd*QHd)/5 - 
   (6*g1^2*gp^2*Qe1*QHd)/5 - (6*g1^2*gp^2*Qe2*QHd)/5 - 
   (6*g1^2*gp^2*Qe3*QHd)/5 + (12*g1^2*gp^2*QHd^2)/5 + 6*g2^2*gp^2*QHd^2 + 
   18*gp^4*Qd^2*QHd^2 + 2*gp^4*Qe1^2*QHd^2 + 2*gp^4*Qe2^2*QHd^2 + 
   2*gp^4*Qe3^2*QHd^2 + 8*gp^4*QHd^4 - (6*g1^2*gp^2*QHd*QHu)/5 + 
   4*gp^4*QHd^2*QHu^2 + (6*g1^2*gp^2*QHd*Ql1)/5 + 4*gp^4*QHd^2*Ql1^2 + 
   (6*g1^2*gp^2*QHd*Ql2)/5 + 4*gp^4*QHd^2*Ql2^2 + (6*g1^2*gp^2*QHd*Ql3)/5 + 
   4*gp^4*QHd^2*Ql3^2 - (18*g1^2*gp^2*QHd*Qq)/5 + 36*gp^4*QHd^2*Qq^2 + 
   2*gp^4*QHd^2*Qs^2 + (36*g1^2*gp^2*QHd*Qu)/5 + 18*gp^4*QHd^2*Qu^2 + 
   2*gp^4*QHd^2*Qv1^2 + 2*gp^4*QHd^2*Qv2^2 + 2*gp^4*QHd^2*Qv3^2 - 
   3*Ye11^2*conj[Ye11]^2 - 3*Ye22^2*conj[Ye22]^2 + 
   (6*g1^2*Ye33*conj[Ye33])/5 + 2*gp^2*Qe3^2*Ye33*conj[Ye33] - 
   2*gp^2*QHd^2*Ye33*conj[Ye33] + 2*gp^2*Ql3^2*Ye33*conj[Ye33] - 
   3*Ye33^2*conj[Ye33]^2 + conj[Ye11]*((6*g1^2*Ye11)/5 + 
     2*gp^2*(Qe1^2 - QHd^2 + Ql1^2)*Ye11 - Ye11*Yv11*conj[Yv11]) + 
   conj[Ye22]*((6*g1^2*Ye22)/5 + 2*gp^2*(Qe2^2 - QHd^2 + Ql2^2)*Ye22 - 
     Ye22*Yv22*conj[Yv22]) - Ye33*Yv33*conj[Ye33]*conj[Yv33] - 
   2*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]] + 2*gp^2*QHu^2*\[Lambda]*
    conj[\[Lambda]] + 2*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]] - 
   Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - Yv22*\[Lambda]*conj[Yv22]*
    conj[\[Lambda]] - Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   3*\[Lambda]^2*conj[\[Lambda]]^2 - (2*g1^2*trace[Yd, Adj[Yd]])/5 + 
   16*g3^2*trace[Yd, Adj[Yd]] + 6*gp^2*Qd^2*trace[Yd, Adj[Yd]] - 
   6*gp^2*QHd^2*trace[Yd, Adj[Yd]] + 6*gp^2*Qq^2*trace[Yd, Adj[Yd]] - 
   3*\[Lambda]*conj[\[Lambda]]*trace[Yu, Adj[Yu]] - 
   9*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 3*trace[Yd, Adj[Yu], Yu, Adj[Yd]]}, 
 {{SHu[{lef1}][{gen1}], SHu[{lef2}][{gen2}]}, (-3*g1^2)/10 - (3*g2^2)/2 - 
   2*gp^2*QHu^2 + Yv11*conj[Yv11] + Yv22*conj[Yv22] + Yv33*conj[Yv33] + 
   \[Lambda]*conj[\[Lambda]] + 3*trace[Yu, Adj[Yu]], 
  (207*g1^4)/100 + (9*g1^2*g2^2)/10 + (15*g2^4)/4 + (18*g1^2*gp^2*Qd*QHu)/5 + 
   (6*g1^2*gp^2*Qe1*QHu)/5 + (6*g1^2*gp^2*Qe2*QHu)/5 + 
   (6*g1^2*gp^2*Qe3*QHu)/5 - (6*g1^2*gp^2*QHd*QHu)/5 + 
   (12*g1^2*gp^2*QHu^2)/5 + 6*g2^2*gp^2*QHu^2 + 18*gp^4*Qd^2*QHu^2 + 
   2*gp^4*Qe1^2*QHu^2 + 2*gp^4*Qe2^2*QHu^2 + 2*gp^4*Qe3^2*QHu^2 + 
   4*gp^4*QHd^2*QHu^2 + 8*gp^4*QHu^4 - (6*g1^2*gp^2*QHu*Ql1)/5 + 
   4*gp^4*QHu^2*Ql1^2 - (6*g1^2*gp^2*QHu*Ql2)/5 + 4*gp^4*QHu^2*Ql2^2 - 
   (6*g1^2*gp^2*QHu*Ql3)/5 + 4*gp^4*QHu^2*Ql3^2 + (18*g1^2*gp^2*QHu*Qq)/5 + 
   36*gp^4*QHu^2*Qq^2 + 2*gp^4*QHu^2*Qs^2 - (36*g1^2*gp^2*QHu*Qu)/5 + 
   18*gp^4*QHu^2*Qu^2 + 2*gp^4*QHu^2*Qv1^2 + 2*gp^4*QHu^2*Qv2^2 + 
   2*gp^4*QHu^2*Qv3^2 + Yv11*(2*gp^2*(-QHu^2 + Ql1^2 + Qv1^2) - 
     Ye11*conj[Ye11])*conj[Yv11] - 3*Yv11^2*conj[Yv11]^2 + 
   Yv22*(2*gp^2*(-QHu^2 + Ql2^2 + Qv2^2) - Ye22*conj[Ye22])*conj[Yv22] - 
   3*Yv22^2*conj[Yv22]^2 - 2*gp^2*QHu^2*Yv33*conj[Yv33] + 
   2*gp^2*Ql3^2*Yv33*conj[Yv33] + 2*gp^2*Qv3^2*Yv33*conj[Yv33] - 
   Ye33*Yv33*conj[Ye33]*conj[Yv33] - 3*Yv33^2*conj[Yv33]^2 + 
   2*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]] - 2*gp^2*QHu^2*\[Lambda]*
    conj[\[Lambda]] + 2*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]] - 
   Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - Ye22*\[Lambda]*conj[Ye22]*
    conj[\[Lambda]] - Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   3*\[Lambda]^2*conj[\[Lambda]]^2 - 3*\[Lambda]*conj[\[Lambda]]*
    trace[Yd, Adj[Yd]] + (4*g1^2*trace[Yu, Adj[Yu]])/5 + 
   16*g3^2*trace[Yu, Adj[Yu]] - 6*gp^2*QHu^2*trace[Yu, Adj[Yu]] + 
   6*gp^2*Qq^2*trace[Yu, Adj[Yu]] + 6*gp^2*Qu^2*trace[Yu, Adj[Yu]] - 
   3*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 9*trace[Yu, Adj[Yu], Yu, Adj[Yu]]}, 
 {{SdR[{gen1, col1}], SdR[{gen2, col2}]}, 
  (-2*(g1^2 + 20*g3^2 + 15*gp^2*Qd^2)*Kronecker[i1, i2])/15 + 
   2*MatMul[conj[Yd], Tp[Yd]][i1, i2], 
  (2*(101*g1^4 + 10*g1^2*(8*g3^2 + 3*gp^2*Qd*(11*Qd + 
          3*(Qe1 + Qe2 + Qe3 - QHd + QHu - Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu))) - 
      25*(4*g3^4 - 48*g3^2*gp^2*Qd^2 - 9*gp^4*Qd^2*(11*Qd^2 + Qe1^2 + Qe2^2 + 
          Qe3^2 + 2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + 
          Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2)))*Kronecker[i1, i2])/225 + 
   ((2*g1^2)/5 + 6*g2^2 - 4*gp^2*Qd^2 + 4*gp^2*QHd^2 + 4*gp^2*Qq^2 - 
     2*Ye11*conj[Ye11] - 2*Ye22*conj[Ye22] - 2*Ye33*conj[Ye33] - 
     2*\[Lambda]*conj[\[Lambda]] - 6*trace[Yd, Adj[Yd]])*
    MatMul[conj[Yd], Tp[Yd]][i1, i2] - 
   2*(MatMul[conj[Yd], Tp[Yd], conj[Yd], Tp[Yd]][i1, i2] + 
     MatMul[conj[Yd], Tp[Yu], conj[Yu], Tp[Yd]][i1, i2])}, 
 {{SuR[{gen1, col1}], SuR[{gen2, col2}]}, 
  (-2*(4*g1^2 + 20*g3^2 + 15*gp^2*Qu^2)*Kronecker[i1, i2])/15 + 
   2*MatMul[conj[Yu], Tp[Yu]][i1, i2], 
  (2*(428*g1^4 + 20*g1^2*(16*g3^2 + 3*gp^2*Qu*(-9*Qd - 3*Qe1 - 3*Qe2 - 
          3*Qe3 + 3*QHd - 3*QHu + 3*Ql1 + 3*Ql2 + 3*Ql3 - 9*Qq + 22*Qu)) - 
      25*(4*g3^4 - 48*g3^2*gp^2*Qu^2 - 9*gp^4*Qu^2*(9*Qd^2 + Qe1^2 + Qe2^2 + 
          Qe3^2 + 2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + 
          Qs^2 + 11*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2)))*Kronecker[i1, i2])/225 + 
   ((-2*g1^2)/5 + 6*g2^2 + 4*gp^2*QHu^2 + 4*gp^2*Qq^2 - 4*gp^2*Qu^2 - 
     2*Yv11*conj[Yv11] - 2*Yv22*conj[Yv22] - 2*Yv33*conj[Yv33] - 
     2*\[Lambda]*conj[\[Lambda]] - 6*trace[Yu, Adj[Yu]])*
    MatMul[conj[Yu], Tp[Yu]][i1, i2] - 
   2*(MatMul[conj[Yu], Tp[Yd], conj[Yd], Tp[Yu]][i1, i2] + 
     MatMul[conj[Yu], Tp[Yu], conj[Yu], Tp[Yu]][i1, i2])}, 
 {{Se01R, Se01R}, (-6*g1^2)/5 - 2*gp^2*Qe1^2 + 2*Ye11*conj[Ye11], 
  (234*g1^4)/25 + (12*g1^2*gp^2*Qe1*(3*Qd + 3*Qe1 + Qe2 + Qe3 - QHd + QHu - 
      Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu))/5 + 
   2*gp^4*Qe1^2*(9*Qd^2 + 3*Qe1^2 + Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 
     2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + 
     Qv3^2) - 4*Ye11^2*conj[Ye11]^2 - 
   (2*Ye11*conj[Ye11]*(3*g1^2 - 15*g2^2 + 10*gp^2*Qe1^2 - 10*gp^2*QHd^2 - 
      10*gp^2*Ql1^2 + 5*Ye22*conj[Ye22] + 5*Ye33*conj[Ye33] + 
      5*Yv11*conj[Yv11] + 5*\[Lambda]*conj[\[Lambda]] + 
      15*trace[Yd, Adj[Yd]]))/5}, {{Se02R, Se02R}, 
  (-6*g1^2)/5 - 2*gp^2*Qe2^2 + 2*Ye22*conj[Ye22], 
  (234*g1^4)/25 + (12*g1^2*gp^2*Qe2*(3*Qd + Qe1 + 3*Qe2 + Qe3 - QHd + QHu - 
      Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu))/5 + 
   2*gp^4*Qe2^2*(9*Qd^2 + Qe1^2 + 3*Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 
     2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + 
     Qv3^2) - 4*Ye22^2*conj[Ye22]^2 - 
   (2*Ye22*conj[Ye22]*(3*g1^2 - 15*g2^2 + 10*gp^2*Qe2^2 - 10*gp^2*QHd^2 - 
      10*gp^2*Ql2^2 + 5*Ye11*conj[Ye11] + 5*Ye33*conj[Ye33] + 
      5*Yv22*conj[Yv22] + 5*\[Lambda]*conj[\[Lambda]] + 
      15*trace[Yd, Adj[Yd]]))/5}, {{Se03R, Se03R}, 
  (-6*g1^2)/5 - 2*gp^2*Qe3^2 + 2*Ye33*conj[Ye33], 
  (234*g1^4)/25 + (12*g1^2*gp^2*Qe3*(3*Qd + Qe1 + Qe2 + 3*Qe3 - QHd + QHu - 
      Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu))/5 + 
   2*gp^4*Qe3^2*(9*Qd^2 + Qe1^2 + Qe2^2 + 3*Qe3^2 + 2*QHd^2 + 2*QHu^2 + 
     2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + 
     Qv3^2) - 4*Ye33^2*conj[Ye33]^2 - 
   (2*Ye33*conj[Ye33]*(3*g1^2 - 15*g2^2 + 10*gp^2*Qe3^2 - 10*gp^2*QHd^2 - 
      10*gp^2*Ql3^2 + 5*Ye11*conj[Ye11] + 5*Ye22*conj[Ye22] + 
      5*Yv33*conj[Yv33] + 5*\[Lambda]*conj[\[Lambda]] + 
      15*trace[Yd, Adj[Yd]]))/5}, {{Sv01R, Sv01R}, 
  -2*gp^2*Qv1^2 + 2*Yv11*conj[Yv11], 
  2*gp^4*Qv1^2*(9*Qd^2 + Qe1^2 + Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 
     2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 9*Qu^2 + 3*Qv1^2 + 
     Qv2^2 + Qv3^2) - 4*Yv11^2*conj[Yv11]^2 + 
   (2*Yv11*conj[Yv11]*(3*g1^2 + 15*g2^2 + 10*gp^2*QHu^2 + 10*gp^2*Ql1^2 - 
      10*gp^2*Qv1^2 - 5*Ye11*conj[Ye11] - 5*Yv22*conj[Yv22] - 
      5*Yv33*conj[Yv33] - 5*\[Lambda]*conj[\[Lambda]] - 
      15*trace[Yu, Adj[Yu]]))/5}, {{Sv02R, Sv02R}, 
  -2*gp^2*Qv2^2 + 2*Yv22*conj[Yv22], 
  2*gp^4*Qv2^2*(9*Qd^2 + Qe1^2 + Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 
     2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + 
     3*Qv2^2 + Qv3^2) - 4*Yv22^2*conj[Yv22]^2 + 
   (2*Yv22*conj[Yv22]*(3*g1^2 + 15*g2^2 + 10*gp^2*QHu^2 + 10*gp^2*Ql2^2 - 
      10*gp^2*Qv2^2 - 5*Ye22*conj[Ye22] - 5*Yv11*conj[Yv11] - 
      5*Yv33*conj[Yv33] - 5*\[Lambda]*conj[\[Lambda]] - 
      15*trace[Yu, Adj[Yu]]))/5}, {{Sv03R, Sv03R}, 
  -2*gp^2*Qv3^2 + 2*Yv33*conj[Yv33], 
  2*gp^4*Qv3^2*(9*Qd^2 + Qe1^2 + Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 
     2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + 
     3*Qv3^2) - 4*Yv33^2*conj[Yv33]^2 + 
   (2*Yv33*conj[Yv33]*(3*g1^2 + 15*g2^2 + 10*gp^2*QHu^2 + 10*gp^2*Ql3^2 - 
      10*gp^2*Qv3^2 - 5*Ye33*conj[Ye33] - 5*Yv11*conj[Yv11] - 
      5*Yv22*conj[Yv22] - 5*\[Lambda]*conj[\[Lambda]] - 
      15*trace[Yu, Adj[Yu]]))/5}, 
 {{SsR, SsR}, -2*gp^2*Qs^2 + 2*\[Lambda]*conj[\[Lambda]], 
  2*gp^4*Qs^2*(9*Qd^2 + Qe1^2 + Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 
     2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + 3*Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2) - 
   4*\[Lambda]^2*conj[\[Lambda]]^2 + 
   (2*\[Lambda]*conj[\[Lambda]]*(3*g1^2 + 15*g2^2 + 10*gp^2*QHd^2 + 
      10*gp^2*QHu^2 - 10*gp^2*Qs^2 - 5*Ye11*conj[Ye11] - 5*Ye22*conj[Ye22] - 
      5*Ye33*conj[Ye33] - 5*Yv11*conj[Yv11] - 5*Yv22*conj[Yv22] - 
      5*Yv33*conj[Yv33] - 15*trace[Yd, Adj[Yd]] - 15*trace[Yu, Adj[Yu]]))/5}}
