{{{Tr1[1], Sqrt[3/5]*g1*(me012 + me022 + me032 - mHd2 + mHu2 - ml012 - 
     ml022 - ml032 + trace[md2] + trace[mq2] - 2*trace[mu2])}, 
  {Tr1[4], gp*(me012*Qe1 + me022*Qe2 + me032*Qe3 + 2*mHd2*QHd + 2*mHu2*QHu + 
     2*ml012*Ql1 + 2*ml022*Ql2 + 2*ml032*Ql3 + ms2*Qs + mvR012*Qv1 + 
     mvR022*Qv2 + mvR032*Qv3 + 3*Qd*trace[md2] + 6*Qq*trace[mq2] + 
     3*Qu*trace[mu2])}}, 
 {{Tr2U1[1, 1], (g1^2*(6*me012 + 6*me022 + 6*me032 + 3*mHd2 + 3*mHu2 + 
      3*ml012 + 3*ml022 + 3*ml032 + 2*trace[md2] + trace[mq2] + 
      8*trace[mu2]))/10}, {Tr2U1[1, 4], Sqrt[3/5]*g1*gp*
    (me012*Qe1 + me022*Qe2 + me032*Qe3 - mHd2*QHd + mHu2*QHu - ml012*Ql1 - 
     ml022*Ql2 - ml032*Ql3 + Qd*trace[md2] + Qq*trace[mq2] - 
     2*Qu*trace[mu2])}, 
  {Tr3[1], (g1*(36*g1^2*me012 + 36*g1^2*me022 + 36*g1^2*me032 - 9*g1^2*mHd2 - 
      45*g2^2*mHd2 + 9*g1^2*mHu2 + 45*g2^2*mHu2 - 9*g1^2*ml012 - 
      45*g2^2*ml012 - 9*g1^2*ml022 - 45*g2^2*ml022 - 9*g1^2*ml032 - 
      45*g2^2*ml032 + 60*gp^2*me012*Qe1^2 + 60*gp^2*me022*Qe2^2 + 
      60*gp^2*me032*Qe3^2 - 60*gp^2*mHd2*QHd^2 + 60*gp^2*mHu2*QHu^2 - 
      60*gp^2*ml012*Ql1^2 - 60*gp^2*ml022*Ql2^2 - 60*gp^2*ml032*Ql3^2 + 
      30*(-2*me012 + mHd2 + ml012)*Ye11*conj[Ye11] + 
      30*(-2*me022 + mHd2 + ml022)*Ye22*conj[Ye22] - 
      60*me032*Ye33*conj[Ye33] + 30*mHd2*Ye33*conj[Ye33] + 
      30*ml032*Ye33*conj[Ye33] - 30*mHu2*Yv11*conj[Yv11] + 
      30*ml012*Yv11*conj[Yv11] - 30*mHu2*Yv22*conj[Yv22] + 
      30*ml022*Yv22*conj[Yv22] - 30*mHu2*Yv33*conj[Yv33] + 
      30*ml032*Yv33*conj[Yv33] + 30*mHd2*\[Lambda]*conj[\[Lambda]] - 
      30*mHu2*\[Lambda]*conj[\[Lambda]] + 4*g1^2*trace[md2] + 
      80*g3^2*trace[md2] + 60*gp^2*Qd^2*trace[md2] + g1^2*trace[mq2] + 
      45*g2^2*trace[mq2] + 80*g3^2*trace[mq2] + 60*gp^2*Qq^2*trace[mq2] - 
      32*g1^2*trace[mu2] - 160*g3^2*trace[mu2] - 120*gp^2*Qu^2*trace[mu2] + 
      90*mHd2*trace[Yd, Adj[Yd]] - 90*mHu2*trace[Yu, Adj[Yu]] - 
      60*trace[Yd, Adj[Yd], conj[md2]] - 30*trace[Yd, conj[mq2], Adj[Yd]] + 
      120*trace[Yu, Adj[Yu], conj[mu2]] - 30*trace[Yu, conj[mq2], Adj[Yu]]))/
    (20*Sqrt[15])}, {Tr2[2], (mHd2 + mHu2 + ml012 + ml022 + ml032 + 
     3*trace[mq2])/2}, {Tr2[3], (trace[md2] + 2*trace[mq2] + trace[mu2])/2}, 
  {Tr2U1[4, 1], Sqrt[3/5]*g1*gp*(me012*Qe1 + me022*Qe2 + me032*Qe3 - 
     mHd2*QHd + mHu2*QHu - ml012*Ql1 - ml022*Ql2 - ml032*Ql3 + 
     Qd*trace[md2] + Qq*trace[mq2] - 2*Qu*trace[mu2])}, 
  {Tr2U1[4, 4], gp^2*(me012*Qe1^2 + me022*Qe2^2 + me032*Qe3^2 + 
     2*mHd2*QHd^2 + 2*mHu2*QHu^2 + 2*ml012*Ql1^2 + 2*ml022*Ql2^2 + 
     2*ml032*Ql3^2 + ms2*Qs^2 + mvR012*Qv1^2 + mvR022*Qv2^2 + mvR032*Qv3^2 + 
     3*Qd^2*trace[md2] + 6*Qq^2*trace[mq2] + 3*Qu^2*trace[mu2])}, 
  {Tr3[4], (gp*(6*g1^2*me012*Qe1 + 10*gp^2*me012*Qe1^3 + 6*g1^2*me022*Qe2 + 
      10*gp^2*me022*Qe2^3 + 6*g1^2*me032*Qe3 + 10*gp^2*me032*Qe3^3 + 
      3*g1^2*mHd2*QHd + 15*g2^2*mHd2*QHd + 20*gp^2*mHd2*QHd^3 + 
      3*g1^2*mHu2*QHu + 15*g2^2*mHu2*QHu + 20*gp^2*mHu2*QHu^3 + 
      3*g1^2*ml012*Ql1 + 15*g2^2*ml012*Ql1 + 20*gp^2*ml012*Ql1^3 + 
      3*g1^2*ml022*Ql2 + 15*g2^2*ml022*Ql2 + 20*gp^2*ml022*Ql2^3 + 
      3*g1^2*ml032*Ql3 + 15*g2^2*ml032*Ql3 + 20*gp^2*ml032*Ql3^3 + 
      10*gp^2*ms2*Qs^3 + 10*gp^2*mvR012*Qv1^3 + 10*gp^2*mvR022*Qv2^3 + 
      10*gp^2*mvR032*Qv3^3 - 10*(me012*Qe1 + mHd2*QHd + ml012*Ql1)*Ye11*
       conj[Ye11] - 10*(me022*Qe2 + mHd2*QHd + ml022*Ql2)*Ye22*conj[Ye22] - 
      10*me032*Qe3*Ye33*conj[Ye33] - 10*mHd2*QHd*Ye33*conj[Ye33] - 
      10*ml032*Ql3*Ye33*conj[Ye33] - 10*mHu2*QHu*Yv11*conj[Yv11] - 
      10*ml012*Ql1*Yv11*conj[Yv11] - 10*mvR012*Qv1*Yv11*conj[Yv11] - 
      10*mHu2*QHu*Yv22*conj[Yv22] - 10*ml022*Ql2*Yv22*conj[Yv22] - 
      10*mvR022*Qv2*Yv22*conj[Yv22] - 10*mHu2*QHu*Yv33*conj[Yv33] - 
      10*ml032*Ql3*Yv33*conj[Yv33] - 10*mvR032*Qv3*Yv33*conj[Yv33] - 
      10*mHd2*QHd*\[Lambda]*conj[\[Lambda]] - 10*mHu2*QHu*\[Lambda]*
       conj[\[Lambda]] - 10*ms2*Qs*\[Lambda]*conj[\[Lambda]] + 
      2*g1^2*Qd*trace[md2] + 40*g3^2*Qd*trace[md2] + 
      30*gp^2*Qd^3*trace[md2] + g1^2*Qq*trace[mq2] + 45*g2^2*Qq*trace[mq2] + 
      80*g3^2*Qq*trace[mq2] + 60*gp^2*Qq^3*trace[mq2] + 
      8*g1^2*Qu*trace[mu2] + 40*g3^2*Qu*trace[mu2] + 
      30*gp^2*Qu^3*trace[mu2] - 30*mHd2*QHd*trace[Yd, Adj[Yd]] - 
      30*mHu2*QHu*trace[Yu, Adj[Yu]] - 30*Qd*trace[Yd, Adj[Yd], conj[md2]] - 
      30*Qq*trace[Yd, conj[mq2], Adj[Yd]] - 
      30*Qu*trace[Yu, Adj[Yu], conj[mu2]] - 
      30*Qq*trace[Yu, conj[mq2], Adj[Yu]]))/10}}}
