{{vd, (vd*(3*g1^2 + 15*g2^2 + 20*gp^2*QHd^2 + 3*g1^2*Xi + 15*g2^2*Xi + 
     20*gp^2*QHd^2*Xi - 20*Ye11*conj[Ye11] - 20*Ye22*conj[Ye22] - 
     20*Ye33*conj[Ye33] - 20*\[Lambda]*conj[\[Lambda]] - 
     60*trace[Yd, Adj[Yd]]))/20, (-207*g1^4*vd)/200 - (9*g1^2*g2^2*vd)/20 - 
   3*g2^4*vd + (9*g1^2*gp^2*Qd*QHd*vd)/5 + (3*g1^2*gp^2*Qe1*QHd*vd)/5 + 
   (3*g1^2*gp^2*Qe2*QHd*vd)/5 + (3*g1^2*gp^2*Qe3*QHd*vd)/5 - 
   (6*g1^2*gp^2*QHd^2*vd)/5 - 3*g2^2*gp^2*QHd^2*vd - 9*gp^4*Qd^2*QHd^2*vd - 
   gp^4*Qe1^2*QHd^2*vd - gp^4*Qe2^2*QHd^2*vd - gp^4*Qe3^2*QHd^2*vd - 
   4*gp^4*QHd^4*vd + (3*g1^2*gp^2*QHd*QHu*vd)/5 - 2*gp^4*QHd^2*QHu^2*vd - 
   (3*g1^2*gp^2*QHd*Ql1*vd)/5 - 2*gp^4*QHd^2*Ql1^2*vd - 
   (3*g1^2*gp^2*QHd*Ql2*vd)/5 - 2*gp^4*QHd^2*Ql2^2*vd - 
   (3*g1^2*gp^2*QHd*Ql3*vd)/5 - 2*gp^4*QHd^2*Ql3^2*vd + 
   (9*g1^2*gp^2*QHd*Qq*vd)/5 - 18*gp^4*QHd^2*Qq^2*vd - gp^4*QHd^2*Qs^2*vd - 
   (18*g1^2*gp^2*QHd*Qu*vd)/5 - 9*gp^4*QHd^2*Qu^2*vd - gp^4*QHd^2*Qv1^2*vd - 
   gp^4*QHd^2*Qv2^2*vd - gp^4*QHd^2*Qv3^2*vd - (9*g1^4*vd*Xi)/200 - 
   (9*g1^2*g2^2*vd*Xi)/20 + (13*g2^4*vd*Xi)/8 - (3*g1^2*gp^2*QHd^2*vd*Xi)/5 - 
   3*g2^2*gp^2*QHd^2*vd*Xi - 2*gp^4*QHd^4*vd*Xi + (9*g1^4*vd*Xi^2)/200 + 
   (9*g1^2*g2^2*vd*Xi^2)/20 + (3*g1^2*gp^2*QHd^2*vd*Xi^2)/5 + 
   3*g2^2*gp^2*QHd^2*vd*Xi^2 + 2*gp^4*QHd^4*vd*Xi^2 + 
   3*vd*Ye11^2*conj[Ye11]^2 + 3*vd*Ye22^2*conj[Ye22]^2 - 
   (6*g1^2*vd*Ye33*conj[Ye33])/5 - 2*gp^2*Qe3^2*vd*Ye33*conj[Ye33] + 
   2*gp^2*QHd^2*vd*Ye33*conj[Ye33] - 2*gp^2*Ql3^2*vd*Ye33*conj[Ye33] - 
   (3*g1^2*vd*Xi*Ye33*conj[Ye33])/10 - (3*g2^2*vd*Xi*Ye33*conj[Ye33])/2 - 
   2*gp^2*QHd^2*vd*Xi*Ye33*conj[Ye33] + 3*vd*Ye33^2*conj[Ye33]^2 - 
   (vd*Ye11*conj[Ye11]*(20*gp^2*(Qe1^2 + Ql1^2 + QHd^2*(-1 + Xi)) + 
      15*g2^2*Xi + 3*g1^2*(4 + Xi) - 10*Yv11*conj[Yv11]))/10 - 
   (vd*Ye22*conj[Ye22]*(20*gp^2*(Qe2^2 + Ql2^2 + QHd^2*(-1 + Xi)) + 
      15*g2^2*Xi + 3*g1^2*(4 + Xi) - 10*Yv22*conj[Yv22]))/10 + 
   vd*Ye33*Yv33*conj[Ye33]*conj[Yv33] + 2*gp^2*QHd^2*vd*\[Lambda]*
    conj[\[Lambda]] - 2*gp^2*QHu^2*vd*\[Lambda]*conj[\[Lambda]] - 
   2*gp^2*Qs^2*vd*\[Lambda]*conj[\[Lambda]] - 
   (3*g1^2*vd*Xi*\[Lambda]*conj[\[Lambda]])/10 - 
   (3*g2^2*vd*Xi*\[Lambda]*conj[\[Lambda]])/2 - 2*gp^2*QHd^2*vd*Xi*\[Lambda]*
    conj[\[Lambda]] + vd*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] + 
   vd*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] + 
   vd*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] + 
   3*vd*\[Lambda]^2*conj[\[Lambda]]^2 + (2*g1^2*vd*trace[Yd, Adj[Yd]])/5 - 
   16*g3^2*vd*trace[Yd, Adj[Yd]] - 6*gp^2*Qd^2*vd*trace[Yd, Adj[Yd]] + 
   6*gp^2*QHd^2*vd*trace[Yd, Adj[Yd]] - 6*gp^2*Qq^2*vd*trace[Yd, Adj[Yd]] - 
   (9*g1^2*vd*Xi*trace[Yd, Adj[Yd]])/10 - (9*g2^2*vd*Xi*trace[Yd, Adj[Yd]])/
    2 - 6*gp^2*QHd^2*vd*Xi*trace[Yd, Adj[Yd]] + 
   3*vd*\[Lambda]*conj[\[Lambda]]*trace[Yu, Adj[Yu]] + 
   9*vd*trace[Yd, Adj[Yd], Yd, Adj[Yd]] + 
   3*vd*trace[Yd, Adj[Yu], Yu, Adj[Yd]]}, 
 {vu, (vu*(3*g1^2 + 15*g2^2 + 20*gp^2*QHu^2 + 3*g1^2*Xi + 15*g2^2*Xi + 
     20*gp^2*QHu^2*Xi - 20*Yv11*conj[Yv11] - 20*Yv22*conj[Yv22] - 
     20*Yv33*conj[Yv33] - 20*\[Lambda]*conj[\[Lambda]] - 
     60*trace[Yu, Adj[Yu]]))/20, (-207*g1^4*vu)/200 - (9*g1^2*g2^2*vu)/20 - 
   3*g2^4*vu - (9*g1^2*gp^2*Qd*QHu*vu)/5 - (3*g1^2*gp^2*Qe1*QHu*vu)/5 - 
   (3*g1^2*gp^2*Qe2*QHu*vu)/5 - (3*g1^2*gp^2*Qe3*QHu*vu)/5 + 
   (3*g1^2*gp^2*QHd*QHu*vu)/5 - (6*g1^2*gp^2*QHu^2*vu)/5 - 
   3*g2^2*gp^2*QHu^2*vu - 9*gp^4*Qd^2*QHu^2*vu - gp^4*Qe1^2*QHu^2*vu - 
   gp^4*Qe2^2*QHu^2*vu - gp^4*Qe3^2*QHu^2*vu - 2*gp^4*QHd^2*QHu^2*vu - 
   4*gp^4*QHu^4*vu + (3*g1^2*gp^2*QHu*Ql1*vu)/5 - 2*gp^4*QHu^2*Ql1^2*vu + 
   (3*g1^2*gp^2*QHu*Ql2*vu)/5 - 2*gp^4*QHu^2*Ql2^2*vu + 
   (3*g1^2*gp^2*QHu*Ql3*vu)/5 - 2*gp^4*QHu^2*Ql3^2*vu - 
   (9*g1^2*gp^2*QHu*Qq*vu)/5 - 18*gp^4*QHu^2*Qq^2*vu - gp^4*QHu^2*Qs^2*vu + 
   (18*g1^2*gp^2*QHu*Qu*vu)/5 - 9*gp^4*QHu^2*Qu^2*vu - gp^4*QHu^2*Qv1^2*vu - 
   gp^4*QHu^2*Qv2^2*vu - gp^4*QHu^2*Qv3^2*vu - (9*g1^4*vu*Xi)/200 - 
   (9*g1^2*g2^2*vu*Xi)/20 + (13*g2^4*vu*Xi)/8 - (3*g1^2*gp^2*QHu^2*vu*Xi)/5 - 
   3*g2^2*gp^2*QHu^2*vu*Xi - 2*gp^4*QHu^4*vu*Xi + (9*g1^4*vu*Xi^2)/200 + 
   (9*g1^2*g2^2*vu*Xi^2)/20 + (3*g1^2*gp^2*QHu^2*vu*Xi^2)/5 + 
   3*g2^2*gp^2*QHu^2*vu*Xi^2 + 2*gp^4*QHu^4*vu*Xi^2 - 
   (vu*Yv11*(20*gp^2*(Ql1^2 + Qv1^2 + QHu^2*(-1 + Xi)) + 
      3*(g1^2 + 5*g2^2)*Xi - 10*Ye11*conj[Ye11])*conj[Yv11])/10 + 
   3*vu*Yv11^2*conj[Yv11]^2 - 
   (vu*Yv22*(20*gp^2*(Ql2^2 + Qv2^2 + QHu^2*(-1 + Xi)) + 
      3*(g1^2 + 5*g2^2)*Xi - 10*Ye22*conj[Ye22])*conj[Yv22])/10 + 
   3*vu*Yv22^2*conj[Yv22]^2 + 2*gp^2*QHu^2*vu*Yv33*conj[Yv33] - 
   2*gp^2*Ql3^2*vu*Yv33*conj[Yv33] - 2*gp^2*Qv3^2*vu*Yv33*conj[Yv33] - 
   (3*g1^2*vu*Xi*Yv33*conj[Yv33])/10 - (3*g2^2*vu*Xi*Yv33*conj[Yv33])/2 - 
   2*gp^2*QHu^2*vu*Xi*Yv33*conj[Yv33] + vu*Ye33*Yv33*conj[Ye33]*conj[Yv33] + 
   3*vu*Yv33^2*conj[Yv33]^2 - 2*gp^2*QHd^2*vu*\[Lambda]*conj[\[Lambda]] + 
   2*gp^2*QHu^2*vu*\[Lambda]*conj[\[Lambda]] - 2*gp^2*Qs^2*vu*\[Lambda]*
    conj[\[Lambda]] - (3*g1^2*vu*Xi*\[Lambda]*conj[\[Lambda]])/10 - 
   (3*g2^2*vu*Xi*\[Lambda]*conj[\[Lambda]])/2 - 2*gp^2*QHu^2*vu*Xi*\[Lambda]*
    conj[\[Lambda]] + vu*Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]] + 
   vu*Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] + 
   vu*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] + 
   3*vu*\[Lambda]^2*conj[\[Lambda]]^2 + 3*vu*\[Lambda]*conj[\[Lambda]]*
    trace[Yd, Adj[Yd]] - (4*g1^2*vu*trace[Yu, Adj[Yu]])/5 - 
   16*g3^2*vu*trace[Yu, Adj[Yu]] + 6*gp^2*QHu^2*vu*trace[Yu, Adj[Yu]] - 
   6*gp^2*Qq^2*vu*trace[Yu, Adj[Yu]] - 6*gp^2*Qu^2*vu*trace[Yu, Adj[Yu]] - 
   (9*g1^2*vu*Xi*trace[Yu, Adj[Yu]])/10 - (9*g2^2*vu*Xi*trace[Yu, Adj[Yu]])/
    2 - 6*gp^2*QHu^2*vu*Xi*trace[Yu, Adj[Yu]] + 
   3*vu*trace[Yd, Adj[Yu], Yu, Adj[Yd]] + 
   9*vu*trace[Yu, Adj[Yu], Yu, Adj[Yu]]}, 
 {vS, vS*(gp^2*Qs^2*(1 + Xi) - 2*\[Lambda]*conj[\[Lambda]]), 
  -(gp^4*Qs^2*vS*(9*Qd^2 + Qe1^2 + Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 
      2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + 3*Qs^2 + 9*Qu^2 + Qv1^2 + 
      Qv2^2 + Qv3^2 + 2*Qs^2*Xi - 2*Qs^2*Xi^2)) + 
   4*vS*\[Lambda]^2*conj[\[Lambda]]^2 - 
   (2*vS*\[Lambda]*conj[\[Lambda]]*(3*g1^2 + 15*g2^2 + 10*gp^2*QHd^2 + 
      10*gp^2*QHu^2 - 10*gp^2*Qs^2 + 10*gp^2*Qs^2*Xi - 5*Ye11*conj[Ye11] - 
      5*Ye22*conj[Ye22] - 5*Ye33*conj[Ye33] - 5*Yv11*conj[Yv11] - 
      5*Yv22*conj[Yv22] - 5*Yv33*conj[Yv33] - 15*trace[Yd, Adj[Yd]] - 
      15*trace[Yu, Adj[Yu]]))/5}}
