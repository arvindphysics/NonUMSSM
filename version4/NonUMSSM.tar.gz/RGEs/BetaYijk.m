{{Yd[i1, i2], ((-7*g1^2)/15 - 3*g2^2 - (16*g3^2)/3 - 2*gp^2*Qd^2 - 
     2*gp^2*QHd^2 - 2*gp^2*Qq^2 + Ye11*conj[Ye11] + Ye22*conj[Ye22] + 
     Ye33*conj[Ye33] + \[Lambda]*conj[\[Lambda]] + 3*trace[Yd, Adj[Yd]])*
    Yd[i1, i2] + 3*MatMul[Yd, Adj[Yd], Yd][i1, i2] + 
   MatMul[Yd, Adj[Yu], Yu][i1, i2], 
  ((287*g1^4)/90 + g1^2*g2^2 + (15*g2^4)/2 + (8*g1^2*g3^2)/9 + 8*g2^2*g3^2 - 
     (16*g3^4)/9 + (44*g1^2*gp^2*Qd^2)/15 + (32*g3^2*gp^2*Qd^2)/3 + 
     22*gp^4*Qd^4 + (4*g1^2*gp^2*Qd*Qe1)/5 + 2*gp^4*Qd^2*Qe1^2 + 
     (4*g1^2*gp^2*Qd*Qe2)/5 + 2*gp^4*Qd^2*Qe2^2 + (4*g1^2*gp^2*Qd*Qe3)/5 + 
     2*gp^4*Qd^2*Qe3^2 - (22*g1^2*gp^2*Qd*QHd)/5 - (6*g1^2*gp^2*Qe1*QHd)/5 - 
     (6*g1^2*gp^2*Qe2*QHd)/5 - (6*g1^2*gp^2*Qe3*QHd)/5 + 
     (12*g1^2*gp^2*QHd^2)/5 + 6*g2^2*gp^2*QHd^2 + 22*gp^4*Qd^2*QHd^2 + 
     2*gp^4*Qe1^2*QHd^2 + 2*gp^4*Qe2^2*QHd^2 + 2*gp^4*Qe3^2*QHd^2 + 
     8*gp^4*QHd^4 + (4*g1^2*gp^2*Qd*QHu)/5 - (6*g1^2*gp^2*QHd*QHu)/5 + 
     4*gp^4*Qd^2*QHu^2 + 4*gp^4*QHd^2*QHu^2 - (4*g1^2*gp^2*Qd*Ql1)/5 + 
     (6*g1^2*gp^2*QHd*Ql1)/5 + 4*gp^4*Qd^2*Ql1^2 + 4*gp^4*QHd^2*Ql1^2 - 
     (4*g1^2*gp^2*Qd*Ql2)/5 + (6*g1^2*gp^2*QHd*Ql2)/5 + 4*gp^4*Qd^2*Ql2^2 + 
     4*gp^4*QHd^2*Ql2^2 - (4*g1^2*gp^2*Qd*Ql3)/5 + (6*g1^2*gp^2*QHd*Ql3)/5 + 
     4*gp^4*Qd^2*Ql3^2 + 4*gp^4*QHd^2*Ql3^2 + (18*g1^2*gp^2*Qd*Qq)/5 + 
     (2*g1^2*gp^2*Qe1*Qq)/5 + (2*g1^2*gp^2*Qe2*Qq)/5 + 
     (2*g1^2*gp^2*Qe3*Qq)/5 - 4*g1^2*gp^2*QHd*Qq + (2*g1^2*gp^2*QHu*Qq)/5 - 
     (2*g1^2*gp^2*Ql1*Qq)/5 - (2*g1^2*gp^2*Ql2*Qq)/5 - 
     (2*g1^2*gp^2*Ql3*Qq)/5 + (4*g1^2*gp^2*Qq^2)/3 + 6*g2^2*gp^2*Qq^2 + 
     (32*g3^2*gp^2*Qq^2)/3 + 54*gp^4*Qd^2*Qq^2 + 2*gp^4*Qe1^2*Qq^2 + 
     2*gp^4*Qe2^2*Qq^2 + 2*gp^4*Qe3^2*Qq^2 + 40*gp^4*QHd^2*Qq^2 + 
     4*gp^4*QHu^2*Qq^2 + 4*gp^4*Ql1^2*Qq^2 + 4*gp^4*Ql2^2*Qq^2 + 
     4*gp^4*Ql3^2*Qq^2 + 40*gp^4*Qq^4 + 2*gp^4*Qd^2*Qs^2 + 
     2*gp^4*QHd^2*Qs^2 + 2*gp^4*Qq^2*Qs^2 - (24*g1^2*gp^2*Qd*Qu)/5 + 
     (36*g1^2*gp^2*QHd*Qu)/5 - (12*g1^2*gp^2*Qq*Qu)/5 + 18*gp^4*Qd^2*Qu^2 + 
     18*gp^4*QHd^2*Qu^2 + 18*gp^4*Qq^2*Qu^2 + 2*gp^4*Qd^2*Qv1^2 + 
     2*gp^4*QHd^2*Qv1^2 + 2*gp^4*Qq^2*Qv1^2 + 2*gp^4*Qd^2*Qv2^2 + 
     2*gp^4*QHd^2*Qv2^2 + 2*gp^4*Qq^2*Qv2^2 + 2*gp^4*Qd^2*Qv3^2 + 
     2*gp^4*QHd^2*Qv3^2 + 2*gp^4*Qq^2*Qv3^2 - 3*Ye11^2*conj[Ye11]^2 - 
     3*Ye22^2*conj[Ye22]^2 + (6*g1^2*Ye33*conj[Ye33])/5 + 
     2*gp^2*Qe3^2*Ye33*conj[Ye33] - 2*gp^2*QHd^2*Ye33*conj[Ye33] + 
     2*gp^2*Ql3^2*Ye33*conj[Ye33] - 3*Ye33^2*conj[Ye33]^2 + 
     conj[Ye11]*((6*g1^2*Ye11)/5 + 2*gp^2*(Qe1^2 - QHd^2 + Ql1^2)*Ye11 - 
       Ye11*Yv11*conj[Yv11]) + conj[Ye22]*((6*g1^2*Ye22)/5 + 
       2*gp^2*(Qe2^2 - QHd^2 + Ql2^2)*Ye22 - Ye22*Yv22*conj[Yv22]) - 
     Ye33*Yv33*conj[Ye33]*conj[Yv33] - 2*gp^2*QHd^2*\[Lambda]*
      conj[\[Lambda]] + 2*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]] + 
     2*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]] - Yv11*\[Lambda]*conj[Yv11]*
      conj[\[Lambda]] - Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
     Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
     3*\[Lambda]^2*conj[\[Lambda]]^2 - (2*g1^2*trace[Yd, Adj[Yd]])/5 + 
     16*g3^2*trace[Yd, Adj[Yd]] + 6*gp^2*Qd^2*trace[Yd, Adj[Yd]] - 
     6*gp^2*QHd^2*trace[Yd, Adj[Yd]] + 6*gp^2*Qq^2*trace[Yd, Adj[Yd]] - 
     3*\[Lambda]*conj[\[Lambda]]*trace[Yu, Adj[Yu]] - 
     9*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 3*trace[Yd, Adj[Yu], Yu, Adj[Yd]])*
    Yd[i1, i2] + ((4*g1^2)/5 + 6*g2^2 - 2*gp^2*Qd^2 + 6*gp^2*QHd^2 + 
     2*gp^2*Qq^2 - 3*Ye11*conj[Ye11] - 3*Ye22*conj[Ye22] - 
     3*Ye33*conj[Ye33] - 3*\[Lambda]*conj[\[Lambda]] - 9*trace[Yd, Adj[Yd]])*
    MatMul[Yd, Adj[Yd], Yd][i1, i2] + 
   (4*g1^2*MatMul[Yd, Adj[Yu], Yu][i1, i2])/5 + 
   2*gp^2*QHu^2*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   2*gp^2*Qq^2*MatMul[Yd, Adj[Yu], Yu][i1, i2] + 
   2*gp^2*Qu^2*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   Yv11*conj[Yv11]*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   Yv22*conj[Yv22]*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   Yv33*conj[Yv33]*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   \[Lambda]*conj[\[Lambda]]*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   3*trace[Yu, Adj[Yu]]*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   4*MatMul[Yd, Adj[Yd], Yd, Adj[Yd], Yd][i1, i2] - 
   2*MatMul[Yd, Adj[Yu], Yu, Adj[Yd], Yd][i1, i2] - 
   2*MatMul[Yd, Adj[Yu], Yu, Adj[Yu], Yu][i1, i2]}, 
 {Ye11, (-9*g1^2*Ye11)/5 - 3*g2^2*Ye11 - 2*gp^2*Qe1^2*Ye11 - 
   2*gp^2*QHd^2*Ye11 - 2*gp^2*Ql1^2*Ye11 + 4*Ye11^2*conj[Ye11] + 
   Ye11*Ye22*conj[Ye22] + Ye11*Ye33*conj[Ye33] + Ye11*Yv11*conj[Yv11] + 
   Ye11*\[Lambda]*conj[\[Lambda]] + 3*Ye11*trace[Yd, Adj[Yd]], 
  -(Ye11*(-135*g1^4 - 18*g1^2*g2^2 - 75*g2^4 - 72*g1^2*gp^2*Qd*Qe1 - 
      72*g1^2*gp^2*Qe1^2 - 180*gp^4*Qd^2*Qe1^2 - 60*gp^4*Qe1^4 - 
      24*g1^2*gp^2*Qe1*Qe2 - 20*gp^4*Qe1^2*Qe2^2 - 24*g1^2*gp^2*Qe1*Qe3 - 
      20*gp^4*Qe1^2*Qe3^2 + 36*g1^2*gp^2*Qd*QHd + 36*g1^2*gp^2*Qe1*QHd + 
      12*g1^2*gp^2*Qe2*QHd + 12*g1^2*gp^2*Qe3*QHd - 24*g1^2*gp^2*QHd^2 - 
      60*g2^2*gp^2*QHd^2 - 180*gp^4*Qd^2*QHd^2 - 60*gp^4*Qe1^2*QHd^2 - 
      20*gp^4*Qe2^2*QHd^2 - 20*gp^4*Qe3^2*QHd^2 - 80*gp^4*QHd^4 - 
      24*g1^2*gp^2*Qe1*QHu + 12*g1^2*gp^2*QHd*QHu - 40*gp^4*Qe1^2*QHu^2 - 
      40*gp^4*QHd^2*QHu^2 + 36*g1^2*gp^2*Qd*Ql1 + 36*g1^2*gp^2*Qe1*Ql1 + 
      12*g1^2*gp^2*Qe2*Ql1 + 12*g1^2*gp^2*Qe3*Ql1 - 24*g1^2*gp^2*QHd*Ql1 + 
      12*g1^2*gp^2*QHu*Ql1 - 24*g1^2*gp^2*Ql1^2 - 60*g2^2*gp^2*Ql1^2 - 
      180*gp^4*Qd^2*Ql1^2 - 60*gp^4*Qe1^2*Ql1^2 - 20*gp^4*Qe2^2*Ql1^2 - 
      20*gp^4*Qe3^2*Ql1^2 - 80*gp^4*QHd^2*Ql1^2 - 40*gp^4*QHu^2*Ql1^2 - 
      80*gp^4*Ql1^4 + 24*g1^2*gp^2*Qe1*Ql2 - 12*g1^2*gp^2*QHd*Ql2 - 
      12*g1^2*gp^2*Ql1*Ql2 - 40*gp^4*Qe1^2*Ql2^2 - 40*gp^4*QHd^2*Ql2^2 - 
      40*gp^4*Ql1^2*Ql2^2 + 24*g1^2*gp^2*Qe1*Ql3 - 12*g1^2*gp^2*QHd*Ql3 - 
      12*g1^2*gp^2*Ql1*Ql3 - 40*gp^4*Qe1^2*Ql3^2 - 40*gp^4*QHd^2*Ql3^2 - 
      40*gp^4*Ql1^2*Ql3^2 - 72*g1^2*gp^2*Qe1*Qq + 36*g1^2*gp^2*QHd*Qq + 
      36*g1^2*gp^2*Ql1*Qq - 360*gp^4*Qe1^2*Qq^2 - 360*gp^4*QHd^2*Qq^2 - 
      360*gp^4*Ql1^2*Qq^2 - 20*gp^4*Qe1^2*Qs^2 - 20*gp^4*QHd^2*Qs^2 - 
      20*gp^4*Ql1^2*Qs^2 + 144*g1^2*gp^2*Qe1*Qu - 72*g1^2*gp^2*QHd*Qu - 
      72*g1^2*gp^2*Ql1*Qu - 180*gp^4*Qe1^2*Qu^2 - 180*gp^4*QHd^2*Qu^2 - 
      180*gp^4*Ql1^2*Qu^2 - 20*gp^4*Qe1^2*Qv1^2 - 20*gp^4*QHd^2*Qv1^2 - 
      20*gp^4*Ql1^2*Qv1^2 - 20*gp^4*Qe1^2*Qv2^2 - 20*gp^4*QHd^2*Qv2^2 - 
      20*gp^4*Ql1^2*Qv2^2 - 20*gp^4*Qe1^2*Qv3^2 - 20*gp^4*QHd^2*Qv3^2 - 
      20*gp^4*Ql1^2*Qv3^2 + 100*Ye11^2*conj[Ye11]^2 + 
      30*Ye22^2*conj[Ye22]^2 - 12*g1^2*Ye33*conj[Ye33] - 
      20*gp^2*Qe3^2*Ye33*conj[Ye33] + 20*gp^2*QHd^2*Ye33*conj[Ye33] - 
      20*gp^2*Ql3^2*Ye33*conj[Ye33] + 30*Ye33^2*conj[Ye33]^2 - 
      20*gp^2*QHu^2*Yv11*conj[Yv11] + 20*gp^2*Ql1^2*Yv11*conj[Yv11] - 
      20*gp^2*Qv1^2*Yv11*conj[Yv11] + 30*Yv11^2*conj[Yv11]^2 + 
      10*Yv11*Yv22*conj[Yv11]*conj[Yv22] - 2*Ye22*conj[Ye22]*
       (6*g1^2 + 10*gp^2*(Qe2^2 - QHd^2 + Ql2^2) - 5*Yv22*conj[Yv22]) + 
      10*Ye33*Yv33*conj[Ye33]*conj[Yv33] + 10*Yv11*Yv33*conj[Yv11]*
       conj[Yv33] + 20*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]] - 
      20*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]] - 20*gp^2*Qs^2*\[Lambda]*
       conj[\[Lambda]] + 20*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] + 
      10*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] + 
      10*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] + 
      30*\[Lambda]^2*conj[\[Lambda]]^2 + 4*g1^2*trace[Yd, Adj[Yd]] - 
      160*g3^2*trace[Yd, Adj[Yd]] - 60*gp^2*Qd^2*trace[Yd, Adj[Yd]] + 
      60*gp^2*QHd^2*trace[Yd, Adj[Yd]] - 60*gp^2*Qq^2*trace[Yd, Adj[Yd]] + 
      2*Ye11*conj[Ye11]*(-6*g1^2 - 30*g2^2 - 20*gp^2*QHd^2 - 20*gp^2*Ql1^2 + 
        15*Ye22*conj[Ye22] + 15*Ye33*conj[Ye33] + 15*Yv11*conj[Yv11] + 
        15*\[Lambda]*conj[\[Lambda]] + 45*trace[Yd, Adj[Yd]]) + 
      30*Yv11*conj[Yv11]*trace[Yu, Adj[Yu]] + 30*\[Lambda]*conj[\[Lambda]]*
       trace[Yu, Adj[Yu]] + 90*trace[Yd, Adj[Yd], Yd, Adj[Yd]] + 
      30*trace[Yd, Adj[Yu], Yu, Adj[Yd]]))/10}, 
 {Ye22, (-9*g1^2*Ye22)/5 - 3*g2^2*Ye22 - 2*gp^2*Qe2^2*Ye22 - 
   2*gp^2*QHd^2*Ye22 - 2*gp^2*Ql2^2*Ye22 + Ye11*Ye22*conj[Ye11] + 
   4*Ye22^2*conj[Ye22] + Ye22*Ye33*conj[Ye33] + Ye22*Yv22*conj[Yv22] + 
   Ye22*\[Lambda]*conj[\[Lambda]] + 3*Ye22*trace[Yd, Adj[Yd]], 
  (Ye22*(135*g1^4 + 18*g1^2*g2^2 + 75*g2^4 + 72*g1^2*gp^2*Qd*Qe2 + 
     24*g1^2*gp^2*Qe1*Qe2 + 72*g1^2*gp^2*Qe2^2 + 180*gp^4*Qd^2*Qe2^2 + 
     20*gp^4*Qe1^2*Qe2^2 + 60*gp^4*Qe2^4 + 24*g1^2*gp^2*Qe2*Qe3 + 
     20*gp^4*Qe2^2*Qe3^2 - 36*g1^2*gp^2*Qd*QHd - 12*g1^2*gp^2*Qe1*QHd - 
     36*g1^2*gp^2*Qe2*QHd - 12*g1^2*gp^2*Qe3*QHd + 24*g1^2*gp^2*QHd^2 + 
     60*g2^2*gp^2*QHd^2 + 180*gp^4*Qd^2*QHd^2 + 20*gp^4*Qe1^2*QHd^2 + 
     60*gp^4*Qe2^2*QHd^2 + 20*gp^4*Qe3^2*QHd^2 + 80*gp^4*QHd^4 + 
     24*g1^2*gp^2*Qe2*QHu - 12*g1^2*gp^2*QHd*QHu + 40*gp^4*Qe2^2*QHu^2 + 
     40*gp^4*QHd^2*QHu^2 - 24*g1^2*gp^2*Qe2*Ql1 + 12*g1^2*gp^2*QHd*Ql1 + 
     40*gp^4*Qe2^2*Ql1^2 + 40*gp^4*QHd^2*Ql1^2 - 36*g1^2*gp^2*Qd*Ql2 - 
     12*g1^2*gp^2*Qe1*Ql2 - 36*g1^2*gp^2*Qe2*Ql2 - 12*g1^2*gp^2*Qe3*Ql2 + 
     24*g1^2*gp^2*QHd*Ql2 - 12*g1^2*gp^2*QHu*Ql2 + 12*g1^2*gp^2*Ql1*Ql2 + 
     24*g1^2*gp^2*Ql2^2 + 60*g2^2*gp^2*Ql2^2 + 180*gp^4*Qd^2*Ql2^2 + 
     20*gp^4*Qe1^2*Ql2^2 + 60*gp^4*Qe2^2*Ql2^2 + 20*gp^4*Qe3^2*Ql2^2 + 
     80*gp^4*QHd^2*Ql2^2 + 40*gp^4*QHu^2*Ql2^2 + 40*gp^4*Ql1^2*Ql2^2 + 
     80*gp^4*Ql2^4 - 24*g1^2*gp^2*Qe2*Ql3 + 12*g1^2*gp^2*QHd*Ql3 + 
     12*g1^2*gp^2*Ql2*Ql3 + 40*gp^4*Qe2^2*Ql3^2 + 40*gp^4*QHd^2*Ql3^2 + 
     40*gp^4*Ql2^2*Ql3^2 + 72*g1^2*gp^2*Qe2*Qq - 36*g1^2*gp^2*QHd*Qq - 
     36*g1^2*gp^2*Ql2*Qq + 360*gp^4*Qe2^2*Qq^2 + 360*gp^4*QHd^2*Qq^2 + 
     360*gp^4*Ql2^2*Qq^2 + 20*gp^4*Qe2^2*Qs^2 + 20*gp^4*QHd^2*Qs^2 + 
     20*gp^4*Ql2^2*Qs^2 - 144*g1^2*gp^2*Qe2*Qu + 72*g1^2*gp^2*QHd*Qu + 
     72*g1^2*gp^2*Ql2*Qu + 180*gp^4*Qe2^2*Qu^2 + 180*gp^4*QHd^2*Qu^2 + 
     180*gp^4*Ql2^2*Qu^2 + 20*gp^4*Qe2^2*Qv1^2 + 20*gp^4*QHd^2*Qv1^2 + 
     20*gp^4*Ql2^2*Qv1^2 + 20*gp^4*Qe2^2*Qv2^2 + 20*gp^4*QHd^2*Qv2^2 + 
     20*gp^4*Ql2^2*Qv2^2 + 20*gp^4*Qe2^2*Qv3^2 + 20*gp^4*QHd^2*Qv3^2 + 
     20*gp^4*Ql2^2*Qv3^2 - 30*Ye11^2*conj[Ye11]^2 - 100*Ye22^2*conj[Ye22]^2 + 
     12*g1^2*Ye33*conj[Ye33] + 20*gp^2*Qe3^2*Ye33*conj[Ye33] - 
     20*gp^2*QHd^2*Ye33*conj[Ye33] + 20*gp^2*Ql3^2*Ye33*conj[Ye33] - 
     30*Ye33^2*conj[Ye33]^2 + 2*Ye11*conj[Ye11]*(6*g1^2 + 10*gp^2*Qe1^2 - 
       10*gp^2*QHd^2 + 10*gp^2*Ql1^2 - 15*Ye22*conj[Ye22] - 
       5*Yv11*conj[Yv11]) + 20*gp^2*QHu^2*Yv22*conj[Yv22] - 
     20*gp^2*Ql2^2*Yv22*conj[Yv22] + 20*gp^2*Qv2^2*Yv22*conj[Yv22] - 
     10*Yv11*Yv22*conj[Yv11]*conj[Yv22] - 30*Yv22^2*conj[Yv22]^2 - 
     10*Ye33*Yv33*conj[Ye33]*conj[Yv33] - 10*Yv22*Yv33*conj[Yv22]*
      conj[Yv33] - 20*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]] + 
     20*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]] + 20*gp^2*Qs^2*\[Lambda]*
      conj[\[Lambda]] - 10*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
     20*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
     10*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
     30*\[Lambda]^2*conj[\[Lambda]]^2 + 2*Ye22*conj[Ye22]*
      (6*g1^2 + 30*g2^2 + 20*gp^2*QHd^2 + 20*gp^2*Ql2^2 - 
       15*Ye33*conj[Ye33] - 15*Yv22*conj[Yv22] - 15*\[Lambda]*
        conj[\[Lambda]] - 45*trace[Yd, Adj[Yd]]) - 
     4*g1^2*trace[Yd, Adj[Yd]] + 160*g3^2*trace[Yd, Adj[Yd]] + 
     60*gp^2*Qd^2*trace[Yd, Adj[Yd]] - 60*gp^2*QHd^2*trace[Yd, Adj[Yd]] + 
     60*gp^2*Qq^2*trace[Yd, Adj[Yd]] - 30*Yv22*conj[Yv22]*
      trace[Yu, Adj[Yu]] - 30*\[Lambda]*conj[\[Lambda]]*trace[Yu, Adj[Yu]] - 
     90*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 
     30*trace[Yd, Adj[Yu], Yu, Adj[Yd]]))/10}, 
 {Ye33, (-9*g1^2*Ye33)/5 - 3*g2^2*Ye33 - 2*gp^2*Qe3^2*Ye33 - 
   2*gp^2*QHd^2*Ye33 - 2*gp^2*Ql3^2*Ye33 + Ye11*Ye33*conj[Ye11] + 
   Ye22*Ye33*conj[Ye22] + 4*Ye33^2*conj[Ye33] + Ye33*Yv33*conj[Yv33] + 
   Ye33*\[Lambda]*conj[\[Lambda]] + 3*Ye33*trace[Yd, Adj[Yd]], 
  (Ye33*(135*g1^4 + 18*g1^2*g2^2 + 75*g2^4 + 72*g1^2*gp^2*Qd*Qe3 + 
     24*g1^2*gp^2*Qe1*Qe3 + 24*g1^2*gp^2*Qe2*Qe3 + 72*g1^2*gp^2*Qe3^2 + 
     180*gp^4*Qd^2*Qe3^2 + 20*gp^4*Qe1^2*Qe3^2 + 20*gp^4*Qe2^2*Qe3^2 + 
     60*gp^4*Qe3^4 - 36*g1^2*gp^2*Qd*QHd - 12*g1^2*gp^2*Qe1*QHd - 
     12*g1^2*gp^2*Qe2*QHd - 36*g1^2*gp^2*Qe3*QHd + 24*g1^2*gp^2*QHd^2 + 
     60*g2^2*gp^2*QHd^2 + 180*gp^4*Qd^2*QHd^2 + 20*gp^4*Qe1^2*QHd^2 + 
     20*gp^4*Qe2^2*QHd^2 + 60*gp^4*Qe3^2*QHd^2 + 80*gp^4*QHd^4 + 
     24*g1^2*gp^2*Qe3*QHu - 12*g1^2*gp^2*QHd*QHu + 40*gp^4*Qe3^2*QHu^2 + 
     40*gp^4*QHd^2*QHu^2 - 24*g1^2*gp^2*Qe3*Ql1 + 12*g1^2*gp^2*QHd*Ql1 + 
     40*gp^4*Qe3^2*Ql1^2 + 40*gp^4*QHd^2*Ql1^2 - 24*g1^2*gp^2*Qe3*Ql2 + 
     12*g1^2*gp^2*QHd*Ql2 + 40*gp^4*Qe3^2*Ql2^2 + 40*gp^4*QHd^2*Ql2^2 - 
     36*g1^2*gp^2*Qd*Ql3 - 12*g1^2*gp^2*Qe1*Ql3 - 12*g1^2*gp^2*Qe2*Ql3 - 
     36*g1^2*gp^2*Qe3*Ql3 + 24*g1^2*gp^2*QHd*Ql3 - 12*g1^2*gp^2*QHu*Ql3 + 
     12*g1^2*gp^2*Ql1*Ql3 + 12*g1^2*gp^2*Ql2*Ql3 + 24*g1^2*gp^2*Ql3^2 + 
     60*g2^2*gp^2*Ql3^2 + 180*gp^4*Qd^2*Ql3^2 + 20*gp^4*Qe1^2*Ql3^2 + 
     20*gp^4*Qe2^2*Ql3^2 + 60*gp^4*Qe3^2*Ql3^2 + 80*gp^4*QHd^2*Ql3^2 + 
     40*gp^4*QHu^2*Ql3^2 + 40*gp^4*Ql1^2*Ql3^2 + 40*gp^4*Ql2^2*Ql3^2 + 
     80*gp^4*Ql3^4 + 72*g1^2*gp^2*Qe3*Qq - 36*g1^2*gp^2*QHd*Qq - 
     36*g1^2*gp^2*Ql3*Qq + 360*gp^4*Qe3^2*Qq^2 + 360*gp^4*QHd^2*Qq^2 + 
     360*gp^4*Ql3^2*Qq^2 + 20*gp^4*Qe3^2*Qs^2 + 20*gp^4*QHd^2*Qs^2 + 
     20*gp^4*Ql3^2*Qs^2 - 144*g1^2*gp^2*Qe3*Qu + 72*g1^2*gp^2*QHd*Qu + 
     72*g1^2*gp^2*Ql3*Qu + 180*gp^4*Qe3^2*Qu^2 + 180*gp^4*QHd^2*Qu^2 + 
     180*gp^4*Ql3^2*Qu^2 + 20*gp^4*Qe3^2*Qv1^2 + 20*gp^4*QHd^2*Qv1^2 + 
     20*gp^4*Ql3^2*Qv1^2 + 20*gp^4*Qe3^2*Qv2^2 + 20*gp^4*QHd^2*Qv2^2 + 
     20*gp^4*Ql3^2*Qv2^2 + 20*gp^4*Qe3^2*Qv3^2 + 20*gp^4*QHd^2*Qv3^2 + 
     20*gp^4*Ql3^2*Qv3^2 - 30*Ye11^2*conj[Ye11]^2 - 30*Ye22^2*conj[Ye22]^2 + 
     12*g1^2*Ye33*conj[Ye33] + 60*g2^2*Ye33*conj[Ye33] + 
     40*gp^2*QHd^2*Ye33*conj[Ye33] + 40*gp^2*Ql3^2*Ye33*conj[Ye33] - 
     100*Ye33^2*conj[Ye33]^2 + 2*Ye11*conj[Ye11]*(6*g1^2 + 10*gp^2*Qe1^2 - 
       10*gp^2*QHd^2 + 10*gp^2*Ql1^2 - 15*Ye33*conj[Ye33] - 
       5*Yv11*conj[Yv11]) + 2*Ye22*conj[Ye22]*(6*g1^2 + 10*gp^2*Qe2^2 - 
       10*gp^2*QHd^2 + 10*gp^2*Ql2^2 - 15*Ye33*conj[Ye33] - 
       5*Yv22*conj[Yv22]) + 20*gp^2*QHu^2*Yv33*conj[Yv33] - 
     20*gp^2*Ql3^2*Yv33*conj[Yv33] + 20*gp^2*Qv3^2*Yv33*conj[Yv33] - 
     30*Ye33*Yv33*conj[Ye33]*conj[Yv33] - 10*Yv11*Yv33*conj[Yv11]*
      conj[Yv33] - 10*Yv22*Yv33*conj[Yv22]*conj[Yv33] - 
     30*Yv33^2*conj[Yv33]^2 - 20*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]] + 
     20*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]] + 20*gp^2*Qs^2*\[Lambda]*
      conj[\[Lambda]] - 30*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
     10*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
     10*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
     20*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
     30*\[Lambda]^2*conj[\[Lambda]]^2 - 4*g1^2*trace[Yd, Adj[Yd]] + 
     160*g3^2*trace[Yd, Adj[Yd]] + 60*gp^2*Qd^2*trace[Yd, Adj[Yd]] - 
     60*gp^2*QHd^2*trace[Yd, Adj[Yd]] + 60*gp^2*Qq^2*trace[Yd, Adj[Yd]] - 
     90*Ye33*conj[Ye33]*trace[Yd, Adj[Yd]] - 30*Yv33*conj[Yv33]*
      trace[Yu, Adj[Yu]] - 30*\[Lambda]*conj[\[Lambda]]*trace[Yu, Adj[Yu]] - 
     90*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 
     30*trace[Yd, Adj[Yu], Yu, Adj[Yd]]))/10}, 
 {\[Lambda], (-3*g1^2*\[Lambda])/5 - 3*g2^2*\[Lambda] - 
   2*gp^2*QHd^2*\[Lambda] - 2*gp^2*QHu^2*\[Lambda] - 2*gp^2*Qs^2*\[Lambda] + 
   Ye11*\[Lambda]*conj[Ye11] + Ye22*\[Lambda]*conj[Ye22] + 
   Ye33*\[Lambda]*conj[Ye33] + Yv11*\[Lambda]*conj[Yv11] + 
   Yv22*\[Lambda]*conj[Yv22] + Yv33*\[Lambda]*conj[Yv33] + 
   4*\[Lambda]^2*conj[\[Lambda]] + 3*\[Lambda]*trace[Yd, Adj[Yd]] + 
   3*\[Lambda]*trace[Yu, Adj[Yu]], (207*g1^4*\[Lambda])/50 + 
   (9*g1^2*g2^2*\[Lambda])/5 + (15*g2^4*\[Lambda])/2 - 
   (18*g1^2*gp^2*Qd*QHd*\[Lambda])/5 - (6*g1^2*gp^2*Qe1*QHd*\[Lambda])/5 - 
   (6*g1^2*gp^2*Qe2*QHd*\[Lambda])/5 - (6*g1^2*gp^2*Qe3*QHd*\[Lambda])/5 + 
   (12*g1^2*gp^2*QHd^2*\[Lambda])/5 + 6*g2^2*gp^2*QHd^2*\[Lambda] + 
   18*gp^4*Qd^2*QHd^2*\[Lambda] + 2*gp^4*Qe1^2*QHd^2*\[Lambda] + 
   2*gp^4*Qe2^2*QHd^2*\[Lambda] + 2*gp^4*Qe3^2*QHd^2*\[Lambda] + 
   8*gp^4*QHd^4*\[Lambda] + (18*g1^2*gp^2*Qd*QHu*\[Lambda])/5 + 
   (6*g1^2*gp^2*Qe1*QHu*\[Lambda])/5 + (6*g1^2*gp^2*Qe2*QHu*\[Lambda])/5 + 
   (6*g1^2*gp^2*Qe3*QHu*\[Lambda])/5 - (12*g1^2*gp^2*QHd*QHu*\[Lambda])/5 + 
   (12*g1^2*gp^2*QHu^2*\[Lambda])/5 + 6*g2^2*gp^2*QHu^2*\[Lambda] + 
   18*gp^4*Qd^2*QHu^2*\[Lambda] + 2*gp^4*Qe1^2*QHu^2*\[Lambda] + 
   2*gp^4*Qe2^2*QHu^2*\[Lambda] + 2*gp^4*Qe3^2*QHu^2*\[Lambda] + 
   8*gp^4*QHd^2*QHu^2*\[Lambda] + 8*gp^4*QHu^4*\[Lambda] + 
   (6*g1^2*gp^2*QHd*Ql1*\[Lambda])/5 - (6*g1^2*gp^2*QHu*Ql1*\[Lambda])/5 + 
   4*gp^4*QHd^2*Ql1^2*\[Lambda] + 4*gp^4*QHu^2*Ql1^2*\[Lambda] + 
   (6*g1^2*gp^2*QHd*Ql2*\[Lambda])/5 - (6*g1^2*gp^2*QHu*Ql2*\[Lambda])/5 + 
   4*gp^4*QHd^2*Ql2^2*\[Lambda] + 4*gp^4*QHu^2*Ql2^2*\[Lambda] + 
   (6*g1^2*gp^2*QHd*Ql3*\[Lambda])/5 - (6*g1^2*gp^2*QHu*Ql3*\[Lambda])/5 + 
   4*gp^4*QHd^2*Ql3^2*\[Lambda] + 4*gp^4*QHu^2*Ql3^2*\[Lambda] - 
   (18*g1^2*gp^2*QHd*Qq*\[Lambda])/5 + (18*g1^2*gp^2*QHu*Qq*\[Lambda])/5 + 
   36*gp^4*QHd^2*Qq^2*\[Lambda] + 36*gp^4*QHu^2*Qq^2*\[Lambda] + 
   18*gp^4*Qd^2*Qs^2*\[Lambda] + 2*gp^4*Qe1^2*Qs^2*\[Lambda] + 
   2*gp^4*Qe2^2*Qs^2*\[Lambda] + 2*gp^4*Qe3^2*Qs^2*\[Lambda] + 
   6*gp^4*QHd^2*Qs^2*\[Lambda] + 6*gp^4*QHu^2*Qs^2*\[Lambda] + 
   4*gp^4*Ql1^2*Qs^2*\[Lambda] + 4*gp^4*Ql2^2*Qs^2*\[Lambda] + 
   4*gp^4*Ql3^2*Qs^2*\[Lambda] + 36*gp^4*Qq^2*Qs^2*\[Lambda] + 
   6*gp^4*Qs^4*\[Lambda] + (36*g1^2*gp^2*QHd*Qu*\[Lambda])/5 - 
   (36*g1^2*gp^2*QHu*Qu*\[Lambda])/5 + 18*gp^4*QHd^2*Qu^2*\[Lambda] + 
   18*gp^4*QHu^2*Qu^2*\[Lambda] + 18*gp^4*Qs^2*Qu^2*\[Lambda] + 
   2*gp^4*QHd^2*Qv1^2*\[Lambda] + 2*gp^4*QHu^2*Qv1^2*\[Lambda] + 
   2*gp^4*Qs^2*Qv1^2*\[Lambda] + 2*gp^4*QHd^2*Qv2^2*\[Lambda] + 
   2*gp^4*QHu^2*Qv2^2*\[Lambda] + 2*gp^4*Qs^2*Qv2^2*\[Lambda] + 
   2*gp^4*QHd^2*Qv3^2*\[Lambda] + 2*gp^4*QHu^2*Qv3^2*\[Lambda] + 
   2*gp^4*Qs^2*Qv3^2*\[Lambda] - 3*Ye11^2*\[Lambda]*conj[Ye11]^2 - 
   3*Ye22^2*\[Lambda]*conj[Ye22]^2 + (6*g1^2*Ye33*\[Lambda]*conj[Ye33])/5 + 
   2*gp^2*Qe3^2*Ye33*\[Lambda]*conj[Ye33] - 2*gp^2*QHd^2*Ye33*\[Lambda]*
    conj[Ye33] + 2*gp^2*Ql3^2*Ye33*\[Lambda]*conj[Ye33] - 
   3*Ye33^2*\[Lambda]*conj[Ye33]^2 - 2*gp^2*QHu^2*Yv11*\[Lambda]*conj[Yv11] + 
   2*gp^2*Ql1^2*Yv11*\[Lambda]*conj[Yv11] + 2*gp^2*Qv1^2*Yv11*\[Lambda]*
    conj[Yv11] - 3*Yv11^2*\[Lambda]*conj[Yv11]^2 - 
   2*gp^2*QHu^2*Yv22*\[Lambda]*conj[Yv22] + 2*gp^2*Ql2^2*Yv22*\[Lambda]*
    conj[Yv22] + 2*gp^2*Qv2^2*Yv22*\[Lambda]*conj[Yv22] - 
   3*Yv22^2*\[Lambda]*conj[Yv22]^2 - 2*gp^2*QHu^2*Yv33*\[Lambda]*conj[Yv33] + 
   2*gp^2*Ql3^2*Yv33*\[Lambda]*conj[Yv33] + 2*gp^2*Qv3^2*Yv33*\[Lambda]*
    conj[Yv33] - 2*Ye33*Yv33*\[Lambda]*conj[Ye33]*conj[Yv33] - 
   3*Yv33^2*\[Lambda]*conj[Yv33]^2 + (6*g1^2*\[Lambda]^2*conj[\[Lambda]])/5 + 
   6*g2^2*\[Lambda]^2*conj[\[Lambda]] + 4*gp^2*QHd^2*\[Lambda]^2*
    conj[\[Lambda]] + 4*gp^2*QHu^2*\[Lambda]^2*conj[\[Lambda]] - 
   3*Ye33*\[Lambda]^2*conj[Ye33]*conj[\[Lambda]] - 
   3*Yv11*\[Lambda]^2*conj[Yv11]*conj[\[Lambda]] - 
   3*Yv22*\[Lambda]^2*conj[Yv22]*conj[\[Lambda]] - 
   3*Yv33*\[Lambda]^2*conj[Yv33]*conj[\[Lambda]] - 
   10*\[Lambda]^3*conj[\[Lambda]]^2 - 
   (Ye11*\[Lambda]*conj[Ye11]*(-6*g1^2 - 10*gp^2*(Qe1^2 - QHd^2 + Ql1^2) + 
      10*Yv11*conj[Yv11] + 15*\[Lambda]*conj[\[Lambda]]))/5 - 
   (Ye22*\[Lambda]*conj[Ye22]*(-6*g1^2 - 10*gp^2*(Qe2^2 - QHd^2 + Ql2^2) + 
      10*Yv22*conj[Yv22] + 15*\[Lambda]*conj[\[Lambda]]))/5 - 
   (2*g1^2*\[Lambda]*trace[Yd, Adj[Yd]])/5 + 16*g3^2*\[Lambda]*
    trace[Yd, Adj[Yd]] + 6*gp^2*Qd^2*\[Lambda]*trace[Yd, Adj[Yd]] - 
   6*gp^2*QHd^2*\[Lambda]*trace[Yd, Adj[Yd]] + 6*gp^2*Qq^2*\[Lambda]*
    trace[Yd, Adj[Yd]] - 9*\[Lambda]^2*conj[\[Lambda]]*trace[Yd, Adj[Yd]] + 
   (4*g1^2*\[Lambda]*trace[Yu, Adj[Yu]])/5 + 16*g3^2*\[Lambda]*
    trace[Yu, Adj[Yu]] - 6*gp^2*QHu^2*\[Lambda]*trace[Yu, Adj[Yu]] + 
   6*gp^2*Qq^2*\[Lambda]*trace[Yu, Adj[Yu]] + 6*gp^2*Qu^2*\[Lambda]*
    trace[Yu, Adj[Yu]] - 9*\[Lambda]^2*conj[\[Lambda]]*trace[Yu, Adj[Yu]] - 
   9*\[Lambda]*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 
   6*\[Lambda]*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   9*\[Lambda]*trace[Yu, Adj[Yu], Yu, Adj[Yu]]}, 
 {Yv11, (-3*g1^2*Yv11)/5 - 3*g2^2*Yv11 - 2*gp^2*QHu^2*Yv11 - 
   2*gp^2*Ql1^2*Yv11 - 2*gp^2*Qv1^2*Yv11 + Ye11*Yv11*conj[Ye11] + 
   4*Yv11^2*conj[Yv11] + Yv11*Yv22*conj[Yv22] + Yv11*Yv33*conj[Yv33] + 
   Yv11*\[Lambda]*conj[\[Lambda]] + 3*Yv11*trace[Yu, Adj[Yu]], 
  (207*g1^4*Yv11)/50 + (9*g1^2*g2^2*Yv11)/5 + (15*g2^4*Yv11)/2 + 
   (18*g1^2*gp^2*Qd*QHu*Yv11)/5 + (6*g1^2*gp^2*Qe1*QHu*Yv11)/5 + 
   (6*g1^2*gp^2*Qe2*QHu*Yv11)/5 + (6*g1^2*gp^2*Qe3*QHu*Yv11)/5 - 
   (6*g1^2*gp^2*QHd*QHu*Yv11)/5 + (12*g1^2*gp^2*QHu^2*Yv11)/5 + 
   6*g2^2*gp^2*QHu^2*Yv11 + 18*gp^4*Qd^2*QHu^2*Yv11 + 
   2*gp^4*Qe1^2*QHu^2*Yv11 + 2*gp^4*Qe2^2*QHu^2*Yv11 + 
   2*gp^4*Qe3^2*QHu^2*Yv11 + 4*gp^4*QHd^2*QHu^2*Yv11 + 8*gp^4*QHu^4*Yv11 - 
   (18*g1^2*gp^2*Qd*Ql1*Yv11)/5 - (6*g1^2*gp^2*Qe1*Ql1*Yv11)/5 - 
   (6*g1^2*gp^2*Qe2*Ql1*Yv11)/5 - (6*g1^2*gp^2*Qe3*Ql1*Yv11)/5 + 
   (6*g1^2*gp^2*QHd*Ql1*Yv11)/5 - (12*g1^2*gp^2*QHu*Ql1*Yv11)/5 + 
   (12*g1^2*gp^2*Ql1^2*Yv11)/5 + 6*g2^2*gp^2*Ql1^2*Yv11 + 
   18*gp^4*Qd^2*Ql1^2*Yv11 + 2*gp^4*Qe1^2*Ql1^2*Yv11 + 
   2*gp^4*Qe2^2*Ql1^2*Yv11 + 2*gp^4*Qe3^2*Ql1^2*Yv11 + 
   4*gp^4*QHd^2*Ql1^2*Yv11 + 8*gp^4*QHu^2*Ql1^2*Yv11 + 8*gp^4*Ql1^4*Yv11 - 
   (6*g1^2*gp^2*QHu*Ql2*Yv11)/5 + (6*g1^2*gp^2*Ql1*Ql2*Yv11)/5 + 
   4*gp^4*QHu^2*Ql2^2*Yv11 + 4*gp^4*Ql1^2*Ql2^2*Yv11 - 
   (6*g1^2*gp^2*QHu*Ql3*Yv11)/5 + (6*g1^2*gp^2*Ql1*Ql3*Yv11)/5 + 
   4*gp^4*QHu^2*Ql3^2*Yv11 + 4*gp^4*Ql1^2*Ql3^2*Yv11 + 
   (18*g1^2*gp^2*QHu*Qq*Yv11)/5 - (18*g1^2*gp^2*Ql1*Qq*Yv11)/5 + 
   36*gp^4*QHu^2*Qq^2*Yv11 + 36*gp^4*Ql1^2*Qq^2*Yv11 + 
   2*gp^4*QHu^2*Qs^2*Yv11 + 2*gp^4*Ql1^2*Qs^2*Yv11 - 
   (36*g1^2*gp^2*QHu*Qu*Yv11)/5 + (36*g1^2*gp^2*Ql1*Qu*Yv11)/5 + 
   18*gp^4*QHu^2*Qu^2*Yv11 + 18*gp^4*Ql1^2*Qu^2*Yv11 + 
   18*gp^4*Qd^2*Qv1^2*Yv11 + 2*gp^4*Qe1^2*Qv1^2*Yv11 + 
   2*gp^4*Qe2^2*Qv1^2*Yv11 + 2*gp^4*Qe3^2*Qv1^2*Yv11 + 
   4*gp^4*QHd^2*Qv1^2*Yv11 + 6*gp^4*QHu^2*Qv1^2*Yv11 + 
   6*gp^4*Ql1^2*Qv1^2*Yv11 + 4*gp^4*Ql2^2*Qv1^2*Yv11 + 
   4*gp^4*Ql3^2*Qv1^2*Yv11 + 36*gp^4*Qq^2*Qv1^2*Yv11 + 
   2*gp^4*Qs^2*Qv1^2*Yv11 + 18*gp^4*Qu^2*Qv1^2*Yv11 + 6*gp^4*Qv1^4*Yv11 + 
   2*gp^4*QHu^2*Qv2^2*Yv11 + 2*gp^4*Ql1^2*Qv2^2*Yv11 + 
   2*gp^4*Qv1^2*Qv2^2*Yv11 + 2*gp^4*QHu^2*Qv3^2*Yv11 + 
   2*gp^4*Ql1^2*Qv3^2*Yv11 + 2*gp^4*Qv1^2*Qv3^2*Yv11 - 
   3*Ye11^2*Yv11*conj[Ye11]^2 - 10*Yv11^3*conj[Yv11]^2 - 
   2*gp^2*QHu^2*Yv11*Yv22*conj[Yv22] + 2*gp^2*Ql2^2*Yv11*Yv22*conj[Yv22] + 
   2*gp^2*Qv2^2*Yv11*Yv22*conj[Yv22] - Ye22*Yv11*Yv22*conj[Ye22]*conj[Yv22] - 
   3*Yv11*Yv22^2*conj[Yv22]^2 - 2*gp^2*QHu^2*Yv11*Yv33*conj[Yv33] + 
   2*gp^2*Ql3^2*Yv11*Yv33*conj[Yv33] + 2*gp^2*Qv3^2*Yv11*Yv33*conj[Yv33] - 
   Ye33*Yv11*Yv33*conj[Ye33]*conj[Yv33] - 3*Yv11*Yv33^2*conj[Yv33]^2 + 
   2*gp^2*QHd^2*Yv11*\[Lambda]*conj[\[Lambda]] - 2*gp^2*QHu^2*Yv11*\[Lambda]*
    conj[\[Lambda]] + 2*gp^2*Qs^2*Yv11*\[Lambda]*conj[\[Lambda]] - 
   Ye22*Yv11*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   Ye33*Yv11*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   3*Yv11*\[Lambda]^2*conj[\[Lambda]]^2 - 3*Yv11*\[Lambda]*conj[\[Lambda]]*
    trace[Yd, Adj[Yd]] - (Ye11*Yv11*conj[Ye11]*(-6*g1^2 - 10*gp^2*Qe1^2 - 
      10*gp^2*QHd^2 + 10*gp^2*Ql1^2 + 5*Ye22*conj[Ye22] + 5*Ye33*conj[Ye33] + 
      15*Yv11*conj[Yv11] + 10*\[Lambda]*conj[\[Lambda]] + 
      15*trace[Yd, Adj[Yd]]))/5 + 
   (Yv11^2*conj[Yv11]*(6*g1^2 + 30*g2^2 + 20*gp^2*QHu^2 + 20*gp^2*Ql1^2 - 
      15*Yv22*conj[Yv22] - 15*Yv33*conj[Yv33] - 
      15*\[Lambda]*conj[\[Lambda]] - 45*trace[Yu, Adj[Yu]]))/5 + 
   (4*g1^2*Yv11*trace[Yu, Adj[Yu]])/5 + 16*g3^2*Yv11*trace[Yu, Adj[Yu]] - 
   6*gp^2*QHu^2*Yv11*trace[Yu, Adj[Yu]] + 6*gp^2*Qq^2*Yv11*
    trace[Yu, Adj[Yu]] + 6*gp^2*Qu^2*Yv11*trace[Yu, Adj[Yu]] - 
   3*Yv11*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   9*Yv11*trace[Yu, Adj[Yu], Yu, Adj[Yu]]}, 
 {Yv22, (-3*g1^2*Yv22)/5 - 3*g2^2*Yv22 - 2*gp^2*QHu^2*Yv22 - 
   2*gp^2*Ql2^2*Yv22 - 2*gp^2*Qv2^2*Yv22 + Ye22*Yv22*conj[Ye22] + 
   Yv11*Yv22*conj[Yv11] + 4*Yv22^2*conj[Yv22] + Yv22*Yv33*conj[Yv33] + 
   Yv22*\[Lambda]*conj[\[Lambda]] + 3*Yv22*trace[Yu, Adj[Yu]], 
  (207*g1^4*Yv22)/50 + (9*g1^2*g2^2*Yv22)/5 + (15*g2^4*Yv22)/2 + 
   (18*g1^2*gp^2*Qd*QHu*Yv22)/5 + (6*g1^2*gp^2*Qe1*QHu*Yv22)/5 + 
   (6*g1^2*gp^2*Qe2*QHu*Yv22)/5 + (6*g1^2*gp^2*Qe3*QHu*Yv22)/5 - 
   (6*g1^2*gp^2*QHd*QHu*Yv22)/5 + (12*g1^2*gp^2*QHu^2*Yv22)/5 + 
   6*g2^2*gp^2*QHu^2*Yv22 + 18*gp^4*Qd^2*QHu^2*Yv22 + 
   2*gp^4*Qe1^2*QHu^2*Yv22 + 2*gp^4*Qe2^2*QHu^2*Yv22 + 
   2*gp^4*Qe3^2*QHu^2*Yv22 + 4*gp^4*QHd^2*QHu^2*Yv22 + 8*gp^4*QHu^4*Yv22 - 
   (6*g1^2*gp^2*QHu*Ql1*Yv22)/5 + 4*gp^4*QHu^2*Ql1^2*Yv22 - 
   (18*g1^2*gp^2*Qd*Ql2*Yv22)/5 - (6*g1^2*gp^2*Qe1*Ql2*Yv22)/5 - 
   (6*g1^2*gp^2*Qe2*Ql2*Yv22)/5 - (6*g1^2*gp^2*Qe3*Ql2*Yv22)/5 + 
   (6*g1^2*gp^2*QHd*Ql2*Yv22)/5 - (12*g1^2*gp^2*QHu*Ql2*Yv22)/5 + 
   (6*g1^2*gp^2*Ql1*Ql2*Yv22)/5 + (12*g1^2*gp^2*Ql2^2*Yv22)/5 + 
   6*g2^2*gp^2*Ql2^2*Yv22 + 18*gp^4*Qd^2*Ql2^2*Yv22 + 
   2*gp^4*Qe1^2*Ql2^2*Yv22 + 2*gp^4*Qe2^2*Ql2^2*Yv22 + 
   2*gp^4*Qe3^2*Ql2^2*Yv22 + 4*gp^4*QHd^2*Ql2^2*Yv22 + 
   8*gp^4*QHu^2*Ql2^2*Yv22 + 4*gp^4*Ql1^2*Ql2^2*Yv22 + 8*gp^4*Ql2^4*Yv22 - 
   (6*g1^2*gp^2*QHu*Ql3*Yv22)/5 + (6*g1^2*gp^2*Ql2*Ql3*Yv22)/5 + 
   4*gp^4*QHu^2*Ql3^2*Yv22 + 4*gp^4*Ql2^2*Ql3^2*Yv22 + 
   (18*g1^2*gp^2*QHu*Qq*Yv22)/5 - (18*g1^2*gp^2*Ql2*Qq*Yv22)/5 + 
   36*gp^4*QHu^2*Qq^2*Yv22 + 36*gp^4*Ql2^2*Qq^2*Yv22 + 
   2*gp^4*QHu^2*Qs^2*Yv22 + 2*gp^4*Ql2^2*Qs^2*Yv22 - 
   (36*g1^2*gp^2*QHu*Qu*Yv22)/5 + (36*g1^2*gp^2*Ql2*Qu*Yv22)/5 + 
   18*gp^4*QHu^2*Qu^2*Yv22 + 18*gp^4*Ql2^2*Qu^2*Yv22 + 
   2*gp^4*QHu^2*Qv1^2*Yv22 + 2*gp^4*Ql2^2*Qv1^2*Yv22 + 
   18*gp^4*Qd^2*Qv2^2*Yv22 + 2*gp^4*Qe1^2*Qv2^2*Yv22 + 
   2*gp^4*Qe2^2*Qv2^2*Yv22 + 2*gp^4*Qe3^2*Qv2^2*Yv22 + 
   4*gp^4*QHd^2*Qv2^2*Yv22 + 6*gp^4*QHu^2*Qv2^2*Yv22 + 
   4*gp^4*Ql1^2*Qv2^2*Yv22 + 6*gp^4*Ql2^2*Qv2^2*Yv22 + 
   4*gp^4*Ql3^2*Qv2^2*Yv22 + 36*gp^4*Qq^2*Qv2^2*Yv22 + 
   2*gp^4*Qs^2*Qv2^2*Yv22 + 18*gp^4*Qu^2*Qv2^2*Yv22 + 
   2*gp^4*Qv1^2*Qv2^2*Yv22 + 6*gp^4*Qv2^4*Yv22 + 2*gp^4*QHu^2*Qv3^2*Yv22 + 
   2*gp^4*Ql2^2*Qv3^2*Yv22 + 2*gp^4*Qv2^2*Qv3^2*Yv22 - 
   3*Ye22^2*Yv22*conj[Ye22]^2 - 3*Yv11^2*Yv22*conj[Yv11]^2 + 
   (6*g1^2*Yv22^2*conj[Yv22])/5 + 6*g2^2*Yv22^2*conj[Yv22] + 
   4*gp^2*QHu^2*Yv22^2*conj[Yv22] + 4*gp^2*Ql2^2*Yv22^2*conj[Yv22] - 
   10*Yv22^3*conj[Yv22]^2 - Yv11*Yv22*conj[Yv11]*
    (2*gp^2*(QHu^2 - Ql1^2 - Qv1^2) + Ye11*conj[Ye11] + 3*Yv22*conj[Yv22]) - 
   2*gp^2*QHu^2*Yv22*Yv33*conj[Yv33] + 2*gp^2*Ql3^2*Yv22*Yv33*conj[Yv33] + 
   2*gp^2*Qv3^2*Yv22*Yv33*conj[Yv33] - Ye33*Yv22*Yv33*conj[Ye33]*conj[Yv33] - 
   3*Yv22^2*Yv33*conj[Yv22]*conj[Yv33] - 3*Yv22*Yv33^2*conj[Yv33]^2 + 
   2*gp^2*QHd^2*Yv22*\[Lambda]*conj[\[Lambda]] - 2*gp^2*QHu^2*Yv22*\[Lambda]*
    conj[\[Lambda]] + 2*gp^2*Qs^2*Yv22*\[Lambda]*conj[\[Lambda]] - 
   Ye11*Yv22*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - 
   Ye33*Yv22*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   3*Yv22^2*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   3*Yv22*\[Lambda]^2*conj[\[Lambda]]^2 - 3*Yv22*\[Lambda]*conj[\[Lambda]]*
    trace[Yd, Adj[Yd]] - (Ye22*Yv22*conj[Ye22]*(-6*g1^2 - 10*gp^2*Qe2^2 - 
      10*gp^2*QHd^2 + 10*gp^2*Ql2^2 + 5*Ye11*conj[Ye11] + 5*Ye33*conj[Ye33] + 
      15*Yv22*conj[Yv22] + 10*\[Lambda]*conj[\[Lambda]] + 
      15*trace[Yd, Adj[Yd]]))/5 + (4*g1^2*Yv22*trace[Yu, Adj[Yu]])/5 + 
   16*g3^2*Yv22*trace[Yu, Adj[Yu]] - 6*gp^2*QHu^2*Yv22*trace[Yu, Adj[Yu]] + 
   6*gp^2*Qq^2*Yv22*trace[Yu, Adj[Yu]] + 6*gp^2*Qu^2*Yv22*
    trace[Yu, Adj[Yu]] - 9*Yv22^2*conj[Yv22]*trace[Yu, Adj[Yu]] - 
   3*Yv22*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   9*Yv22*trace[Yu, Adj[Yu], Yu, Adj[Yu]]}, 
 {Yv33, (-3*g1^2*Yv33)/5 - 3*g2^2*Yv33 - 2*gp^2*QHu^2*Yv33 - 
   2*gp^2*Ql3^2*Yv33 - 2*gp^2*Qv3^2*Yv33 + Ye33*Yv33*conj[Ye33] + 
   Yv11*Yv33*conj[Yv11] + Yv22*Yv33*conj[Yv22] + 4*Yv33^2*conj[Yv33] + 
   Yv33*\[Lambda]*conj[\[Lambda]] + 3*Yv33*trace[Yu, Adj[Yu]], 
  (207*g1^4*Yv33)/50 + (9*g1^2*g2^2*Yv33)/5 + (15*g2^4*Yv33)/2 + 
   (18*g1^2*gp^2*Qd*QHu*Yv33)/5 + (6*g1^2*gp^2*Qe1*QHu*Yv33)/5 + 
   (6*g1^2*gp^2*Qe2*QHu*Yv33)/5 + (6*g1^2*gp^2*Qe3*QHu*Yv33)/5 - 
   (6*g1^2*gp^2*QHd*QHu*Yv33)/5 + (12*g1^2*gp^2*QHu^2*Yv33)/5 + 
   6*g2^2*gp^2*QHu^2*Yv33 + 18*gp^4*Qd^2*QHu^2*Yv33 + 
   2*gp^4*Qe1^2*QHu^2*Yv33 + 2*gp^4*Qe2^2*QHu^2*Yv33 + 
   2*gp^4*Qe3^2*QHu^2*Yv33 + 4*gp^4*QHd^2*QHu^2*Yv33 + 8*gp^4*QHu^4*Yv33 - 
   (6*g1^2*gp^2*QHu*Ql1*Yv33)/5 + 4*gp^4*QHu^2*Ql1^2*Yv33 - 
   (6*g1^2*gp^2*QHu*Ql2*Yv33)/5 + 4*gp^4*QHu^2*Ql2^2*Yv33 - 
   (18*g1^2*gp^2*Qd*Ql3*Yv33)/5 - (6*g1^2*gp^2*Qe1*Ql3*Yv33)/5 - 
   (6*g1^2*gp^2*Qe2*Ql3*Yv33)/5 - (6*g1^2*gp^2*Qe3*Ql3*Yv33)/5 + 
   (6*g1^2*gp^2*QHd*Ql3*Yv33)/5 - (12*g1^2*gp^2*QHu*Ql3*Yv33)/5 + 
   (6*g1^2*gp^2*Ql1*Ql3*Yv33)/5 + (6*g1^2*gp^2*Ql2*Ql3*Yv33)/5 + 
   (12*g1^2*gp^2*Ql3^2*Yv33)/5 + 6*g2^2*gp^2*Ql3^2*Yv33 + 
   18*gp^4*Qd^2*Ql3^2*Yv33 + 2*gp^4*Qe1^2*Ql3^2*Yv33 + 
   2*gp^4*Qe2^2*Ql3^2*Yv33 + 2*gp^4*Qe3^2*Ql3^2*Yv33 + 
   4*gp^4*QHd^2*Ql3^2*Yv33 + 8*gp^4*QHu^2*Ql3^2*Yv33 + 
   4*gp^4*Ql1^2*Ql3^2*Yv33 + 4*gp^4*Ql2^2*Ql3^2*Yv33 + 8*gp^4*Ql3^4*Yv33 + 
   (18*g1^2*gp^2*QHu*Qq*Yv33)/5 - (18*g1^2*gp^2*Ql3*Qq*Yv33)/5 + 
   36*gp^4*QHu^2*Qq^2*Yv33 + 36*gp^4*Ql3^2*Qq^2*Yv33 + 
   2*gp^4*QHu^2*Qs^2*Yv33 + 2*gp^4*Ql3^2*Qs^2*Yv33 - 
   (36*g1^2*gp^2*QHu*Qu*Yv33)/5 + (36*g1^2*gp^2*Ql3*Qu*Yv33)/5 + 
   18*gp^4*QHu^2*Qu^2*Yv33 + 18*gp^4*Ql3^2*Qu^2*Yv33 + 
   2*gp^4*QHu^2*Qv1^2*Yv33 + 2*gp^4*Ql3^2*Qv1^2*Yv33 + 
   2*gp^4*QHu^2*Qv2^2*Yv33 + 2*gp^4*Ql3^2*Qv2^2*Yv33 + 
   18*gp^4*Qd^2*Qv3^2*Yv33 + 2*gp^4*Qe1^2*Qv3^2*Yv33 + 
   2*gp^4*Qe2^2*Qv3^2*Yv33 + 2*gp^4*Qe3^2*Qv3^2*Yv33 + 
   4*gp^4*QHd^2*Qv3^2*Yv33 + 6*gp^4*QHu^2*Qv3^2*Yv33 + 
   4*gp^4*Ql1^2*Qv3^2*Yv33 + 4*gp^4*Ql2^2*Qv3^2*Yv33 + 
   6*gp^4*Ql3^2*Qv3^2*Yv33 + 36*gp^4*Qq^2*Qv3^2*Yv33 + 
   2*gp^4*Qs^2*Qv3^2*Yv33 + 18*gp^4*Qu^2*Qv3^2*Yv33 + 
   2*gp^4*Qv1^2*Qv3^2*Yv33 + 2*gp^4*Qv2^2*Qv3^2*Yv33 + 6*gp^4*Qv3^4*Yv33 - 
   3*Ye33^2*Yv33*conj[Ye33]^2 - 3*Yv11^2*Yv33*conj[Yv11]^2 - 
   2*gp^2*QHu^2*Yv22*Yv33*conj[Yv22] + 2*gp^2*Ql2^2*Yv22*Yv33*conj[Yv22] + 
   2*gp^2*Qv2^2*Yv22*Yv33*conj[Yv22] - Ye22*Yv22*Yv33*conj[Ye22]*conj[Yv22] - 
   3*Yv22^2*Yv33*conj[Yv22]^2 + (6*g1^2*Yv33^2*conj[Yv33])/5 + 
   6*g2^2*Yv33^2*conj[Yv33] + 4*gp^2*QHu^2*Yv33^2*conj[Yv33] + 
   4*gp^2*Ql3^2*Yv33^2*conj[Yv33] - 3*Yv22*Yv33^2*conj[Yv22]*conj[Yv33] - 
   10*Yv33^3*conj[Yv33]^2 - Yv11*Yv33*conj[Yv11]*
    (2*gp^2*(QHu^2 - Ql1^2 - Qv1^2) + Ye11*conj[Ye11] + 3*Yv33*conj[Yv33]) + 
   2*gp^2*QHd^2*Yv33*\[Lambda]*conj[\[Lambda]] - 2*gp^2*QHu^2*Yv33*\[Lambda]*
    conj[\[Lambda]] + 2*gp^2*Qs^2*Yv33*\[Lambda]*conj[\[Lambda]] - 
   Ye11*Yv33*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - 
   Ye22*Yv33*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   3*Yv33^2*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   3*Yv33*\[Lambda]^2*conj[\[Lambda]]^2 - 3*Yv33*\[Lambda]*conj[\[Lambda]]*
    trace[Yd, Adj[Yd]] - (Ye33*Yv33*conj[Ye33]*(-6*g1^2 - 10*gp^2*Qe3^2 - 
      10*gp^2*QHd^2 + 10*gp^2*Ql3^2 + 5*Ye11*conj[Ye11] + 5*Ye22*conj[Ye22] + 
      15*Yv33*conj[Yv33] + 10*\[Lambda]*conj[\[Lambda]] + 
      15*trace[Yd, Adj[Yd]]))/5 + (4*g1^2*Yv33*trace[Yu, Adj[Yu]])/5 + 
   16*g3^2*Yv33*trace[Yu, Adj[Yu]] - 6*gp^2*QHu^2*Yv33*trace[Yu, Adj[Yu]] + 
   6*gp^2*Qq^2*Yv33*trace[Yu, Adj[Yu]] + 6*gp^2*Qu^2*Yv33*
    trace[Yu, Adj[Yu]] - 9*Yv33^2*conj[Yv33]*trace[Yu, Adj[Yu]] - 
   3*Yv33*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   9*Yv33*trace[Yu, Adj[Yu], Yu, Adj[Yu]]}, 
 {Yu[i1, i2], ((-13*g1^2)/15 - 3*g2^2 - (16*g3^2)/3 - 2*gp^2*QHu^2 - 
     2*gp^2*Qq^2 - 2*gp^2*Qu^2 + Yv11*conj[Yv11] + Yv22*conj[Yv22] + 
     Yv33*conj[Yv33] + \[Lambda]*conj[\[Lambda]] + 3*trace[Yu, Adj[Yu]])*
    Yu[i1, i2] + MatMul[Yu, Adj[Yd], Yd][i1, i2] + 
   3*MatMul[Yu, Adj[Yu], Yu][i1, i2], 
  ((2743*g1^4)/450 + g1^2*g2^2 + (15*g2^4)/2 + (136*g1^2*g3^2)/45 + 
     8*g2^2*g3^2 - (16*g3^4)/9 + (18*g1^2*gp^2*Qd*QHu)/5 + 
     (6*g1^2*gp^2*Qe1*QHu)/5 + (6*g1^2*gp^2*Qe2*QHu)/5 + 
     (6*g1^2*gp^2*Qe3*QHu)/5 - (6*g1^2*gp^2*QHd*QHu)/5 + 
     (12*g1^2*gp^2*QHu^2)/5 + 6*g2^2*gp^2*QHu^2 + 18*gp^4*Qd^2*QHu^2 + 
     2*gp^4*Qe1^2*QHu^2 + 2*gp^4*Qe2^2*QHu^2 + 2*gp^4*Qe3^2*QHu^2 + 
     4*gp^4*QHd^2*QHu^2 + 8*gp^4*QHu^4 - (6*g1^2*gp^2*QHu*Ql1)/5 + 
     4*gp^4*QHu^2*Ql1^2 - (6*g1^2*gp^2*QHu*Ql2)/5 + 4*gp^4*QHu^2*Ql2^2 - 
     (6*g1^2*gp^2*QHu*Ql3)/5 + 4*gp^4*QHu^2*Ql3^2 + (6*g1^2*gp^2*Qd*Qq)/5 + 
     (2*g1^2*gp^2*Qe1*Qq)/5 + (2*g1^2*gp^2*Qe2*Qq)/5 + 
     (2*g1^2*gp^2*Qe3*Qq)/5 - (2*g1^2*gp^2*QHd*Qq)/5 + 4*g1^2*gp^2*QHu*Qq - 
     (2*g1^2*gp^2*Ql1*Qq)/5 - (2*g1^2*gp^2*Ql2*Qq)/5 - 
     (2*g1^2*gp^2*Ql3*Qq)/5 + (4*g1^2*gp^2*Qq^2)/3 + 6*g2^2*gp^2*Qq^2 + 
     (32*g3^2*gp^2*Qq^2)/3 + 18*gp^4*Qd^2*Qq^2 + 2*gp^4*Qe1^2*Qq^2 + 
     2*gp^4*Qe2^2*Qq^2 + 2*gp^4*Qe3^2*Qq^2 + 4*gp^4*QHd^2*Qq^2 + 
     40*gp^4*QHu^2*Qq^2 + 4*gp^4*Ql1^2*Qq^2 + 4*gp^4*Ql2^2*Qq^2 + 
     4*gp^4*Ql3^2*Qq^2 + 40*gp^4*Qq^4 + 2*gp^4*QHu^2*Qs^2 + 
     2*gp^4*Qq^2*Qs^2 - (24*g1^2*gp^2*Qd*Qu)/5 - (8*g1^2*gp^2*Qe1*Qu)/5 - 
     (8*g1^2*gp^2*Qe2*Qu)/5 - (8*g1^2*gp^2*Qe3*Qu)/5 + 
     (8*g1^2*gp^2*QHd*Qu)/5 - (44*g1^2*gp^2*QHu*Qu)/5 + 
     (8*g1^2*gp^2*Ql1*Qu)/5 + (8*g1^2*gp^2*Ql2*Qu)/5 + 
     (8*g1^2*gp^2*Ql3*Qu)/5 - (36*g1^2*gp^2*Qq*Qu)/5 + 
     (176*g1^2*gp^2*Qu^2)/15 + (32*g3^2*gp^2*Qu^2)/3 + 18*gp^4*Qd^2*Qu^2 + 
     2*gp^4*Qe1^2*Qu^2 + 2*gp^4*Qe2^2*Qu^2 + 2*gp^4*Qe3^2*Qu^2 + 
     4*gp^4*QHd^2*Qu^2 + 22*gp^4*QHu^2*Qu^2 + 4*gp^4*Ql1^2*Qu^2 + 
     4*gp^4*Ql2^2*Qu^2 + 4*gp^4*Ql3^2*Qu^2 + 54*gp^4*Qq^2*Qu^2 + 
     2*gp^4*Qs^2*Qu^2 + 22*gp^4*Qu^4 + 2*gp^4*QHu^2*Qv1^2 + 
     2*gp^4*Qq^2*Qv1^2 + 2*gp^4*Qu^2*Qv1^2 + 2*gp^4*QHu^2*Qv2^2 + 
     2*gp^4*Qq^2*Qv2^2 + 2*gp^4*Qu^2*Qv2^2 + 2*gp^4*QHu^2*Qv3^2 + 
     2*gp^4*Qq^2*Qv3^2 + 2*gp^4*Qu^2*Qv3^2 + 
     Yv11*(2*gp^2*(-QHu^2 + Ql1^2 + Qv1^2) - Ye11*conj[Ye11])*conj[Yv11] - 
     3*Yv11^2*conj[Yv11]^2 + Yv22*(2*gp^2*(-QHu^2 + Ql2^2 + Qv2^2) - 
       Ye22*conj[Ye22])*conj[Yv22] - 3*Yv22^2*conj[Yv22]^2 - 
     2*gp^2*QHu^2*Yv33*conj[Yv33] + 2*gp^2*Ql3^2*Yv33*conj[Yv33] + 
     2*gp^2*Qv3^2*Yv33*conj[Yv33] - Ye33*Yv33*conj[Ye33]*conj[Yv33] - 
     3*Yv33^2*conj[Yv33]^2 + 2*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]] - 
     2*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]] + 2*gp^2*Qs^2*\[Lambda]*
      conj[\[Lambda]] - Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - 
     Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - Ye33*\[Lambda]*conj[Ye33]*
      conj[\[Lambda]] - 3*\[Lambda]^2*conj[\[Lambda]]^2 - 
     3*\[Lambda]*conj[\[Lambda]]*trace[Yd, Adj[Yd]] + 
     (4*g1^2*trace[Yu, Adj[Yu]])/5 + 16*g3^2*trace[Yu, Adj[Yu]] - 
     6*gp^2*QHu^2*trace[Yu, Adj[Yu]] + 6*gp^2*Qq^2*trace[Yu, Adj[Yu]] + 
     6*gp^2*Qu^2*trace[Yu, Adj[Yu]] - 3*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
     9*trace[Yu, Adj[Yu], Yu, Adj[Yu]])*Yu[i1, i2] + 
   ((2*g1^2)/5 + 2*gp^2*Qd^2 + 2*gp^2*QHd^2 - 2*gp^2*Qq^2 - Ye11*conj[Ye11] - 
     Ye22*conj[Ye22] - Ye33*conj[Ye33] - \[Lambda]*conj[\[Lambda]] - 
     3*trace[Yd, Adj[Yd]])*MatMul[Yu, Adj[Yd], Yd][i1, i2] + 
   (2*g1^2*MatMul[Yu, Adj[Yu], Yu][i1, i2])/5 + 
   6*g2^2*MatMul[Yu, Adj[Yu], Yu][i1, i2] + 
   6*gp^2*QHu^2*MatMul[Yu, Adj[Yu], Yu][i1, i2] + 
   2*gp^2*Qq^2*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   2*gp^2*Qu^2*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   3*Yv11*conj[Yv11]*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   3*Yv22*conj[Yv22]*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   3*Yv33*conj[Yv33]*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   3*\[Lambda]*conj[\[Lambda]]*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   9*trace[Yu, Adj[Yu]]*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   2*MatMul[Yu, Adj[Yd], Yd, Adj[Yd], Yd][i1, i2] - 
   2*MatMul[Yu, Adj[Yd], Yd, Adj[Yu], Yu][i1, i2] - 
   4*MatMul[Yu, Adj[Yu], Yu, Adj[Yu], Yu][i1, i2]}}
