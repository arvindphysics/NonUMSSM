{{mq2[i1, i2], (-2*g1^2*MassB*conj[MassB]*Kronecker[i1, i2])/15 - 
   (32*g3^2*MassG*conj[MassG]*Kronecker[i1, i2])/3 - 
   8*gp^2*MassU*Qq^2*conj[MassU]*Kronecker[i1, i2] - 
   6*g2^2*MassWB*conj[MassWB]*Kronecker[i1, i2] + 
   (g1*Kronecker[i1, i2]*Tr1[1])/Sqrt[15] + 2*gp*Qq*Kronecker[i1, i2]*
    Tr1[4] + 2*mHd2*MatMul[Adj[Yd], Yd][i1, i2] + 
   2*mHu2*MatMul[Adj[Yu], Yu][i1, i2] + 2*MatMul[Adj[T[Yd]], T[Yd]][i1, i2] + 
   2*MatMul[Adj[T[Yu]], T[Yu]][i1, i2] + MatMul[mq2, Adj[Yd], Yd][i1, i2] + 
   MatMul[mq2, Adj[Yu], Yu][i1, i2] + 2*MatMul[Adj[Yd], md2, Yd][i1, i2] + 
   MatMul[Adj[Yd], Yd, mq2][i1, i2] + 2*MatMul[Adj[Yu], mu2, Yu][i1, i2] + 
   MatMul[Adj[Yu], Yu, mq2][i1, i2], 
  (-16*g3^2*(-(g1^2*(MassB + 2*MassG)) - 
      15*(-8*g3^2*MassG + 3*g2^2*(2*MassG + MassWB) + 
        4*gp^2*(2*MassG + MassU)*Qq^2))*conj[MassG]*Kronecker[i1, i2])/45 + 
   (12*g1^2*gp^2*MassB*Qd*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (24*g1^2*gp^2*MassU*Qd*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (4*g1^2*gp^2*MassB*Qe1*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (8*g1^2*gp^2*MassU*Qe1*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (4*g1^2*gp^2*MassB*Qe2*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (8*g1^2*gp^2*MassU*Qe2*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (4*g1^2*gp^2*MassB*Qe3*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (8*g1^2*gp^2*MassU*Qe3*Qq*conj[MassU]*Kronecker[i1, i2])/5 - 
   (4*g1^2*gp^2*MassB*QHd*Qq*conj[MassU]*Kronecker[i1, i2])/5 - 
   (8*g1^2*gp^2*MassU*QHd*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (4*g1^2*gp^2*MassB*QHu*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (8*g1^2*gp^2*MassU*QHu*Qq*conj[MassU]*Kronecker[i1, i2])/5 - 
   (4*g1^2*gp^2*MassB*Ql1*Qq*conj[MassU]*Kronecker[i1, i2])/5 - 
   (8*g1^2*gp^2*MassU*Ql1*Qq*conj[MassU]*Kronecker[i1, i2])/5 - 
   (4*g1^2*gp^2*MassB*Ql2*Qq*conj[MassU]*Kronecker[i1, i2])/5 - 
   (8*g1^2*gp^2*MassU*Ql2*Qq*conj[MassU]*Kronecker[i1, i2])/5 - 
   (4*g1^2*gp^2*MassB*Ql3*Qq*conj[MassU]*Kronecker[i1, i2])/5 - 
   (8*g1^2*gp^2*MassU*Ql3*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (8*g1^2*gp^2*MassB*Qq^2*conj[MassU]*Kronecker[i1, i2])/3 + 
   (64*g3^2*gp^2*MassG*Qq^2*conj[MassU]*Kronecker[i1, i2])/3 + 
   (16*g1^2*gp^2*MassU*Qq^2*conj[MassU]*Kronecker[i1, i2])/3 + 
   24*g2^2*gp^2*MassU*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   (128*g3^2*gp^2*MassU*Qq^2*conj[MassU]*Kronecker[i1, i2])/3 + 
   12*g2^2*gp^2*MassWB*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   216*gp^4*MassU*Qd^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qe1^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qe2^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qe3^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   48*gp^4*MassU*QHd^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   48*gp^4*MassU*QHu^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   48*gp^4*MassU*Ql1^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   48*gp^4*MassU*Ql2^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   48*gp^4*MassU*Ql3^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   480*gp^4*MassU*Qq^4*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qq^2*Qs^2*conj[MassU]*Kronecker[i1, i2] - 
   (24*g1^2*gp^2*MassB*Qq*Qu*conj[MassU]*Kronecker[i1, i2])/5 - 
   (48*g1^2*gp^2*MassU*Qq*Qu*conj[MassU]*Kronecker[i1, i2])/5 + 
   216*gp^4*MassU*Qq^2*Qu^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qq^2*Qv1^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qq^2*Qv2^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qq^2*Qv3^2*conj[MassU]*Kronecker[i1, i2] + 
   (g1^2*g2^2*MassB*conj[MassWB]*Kronecker[i1, i2])/5 + 
   16*g2^2*g3^2*MassG*conj[MassWB]*Kronecker[i1, i2] + 
   (2*g1^2*g2^2*MassWB*conj[MassWB]*Kronecker[i1, i2])/5 + 
   33*g2^4*MassWB*conj[MassWB]*Kronecker[i1, i2] + 
   32*g2^2*g3^2*MassWB*conj[MassWB]*Kronecker[i1, i2] + 
   12*g2^2*gp^2*MassU*Qq^2*conj[MassWB]*Kronecker[i1, i2] + 
   24*g2^2*gp^2*MassWB*Qq^2*conj[MassWB]*Kronecker[i1, i2] + 
   6*g2^4*Kronecker[i1, i2]*Tr2[2] + (32*g3^4*Kronecker[i1, i2]*Tr2[3])/3 + 
   (2*g1^2*Kronecker[i1, i2]*Tr2U1[1, 1])/15 + 
   (4*g1*gp*Qq*Kronecker[i1, i2]*Tr2U1[1, 4])/Sqrt[15] + 
   (4*g1*gp*Qq*Kronecker[i1, i2]*Tr2U1[4, 1])/Sqrt[15] + 
   8*gp^2*Qq^2*Kronecker[i1, i2]*Tr2U1[4, 4] + 
   (4*g1*Kronecker[i1, i2]*Tr3[1])/Sqrt[15] + 8*gp*Qq*Kronecker[i1, i2]*
    Tr3[4] + (4*g1^2*mHd2*MatMul[Adj[Yd], Yd][i1, i2])/5 + 
   4*gp^2*mHd2*Qd^2*MatMul[Adj[Yd], Yd][i1, i2] + 
   4*gp^2*mHd2*QHd^2*MatMul[Adj[Yd], Yd][i1, i2] - 
   4*gp^2*mHd2*Qq^2*MatMul[Adj[Yd], Yd][i1, i2] + 
   8*gp^2*MassU*Qd^2*conj[MassU]*MatMul[Adj[Yd], Yd][i1, i2] + 
   8*gp^2*MassU*QHd^2*conj[MassU]*MatMul[Adj[Yd], Yd][i1, i2] - 
   8*gp^2*MassU*Qq^2*conj[MassU]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*me012*Ye11*conj[Ye11]*MatMul[Adj[Yd], Yd][i1, i2] - 
   4*mHd2*Ye11*conj[Ye11]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*ml012*Ye11*conj[Ye11]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*me022*Ye22*conj[Ye22]*MatMul[Adj[Yd], Yd][i1, i2] - 
   4*mHd2*Ye22*conj[Ye22]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*ml022*Ye22*conj[Ye22]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*me032*Ye33*conj[Ye33]*MatMul[Adj[Yd], Yd][i1, i2] - 
   4*mHd2*Ye33*conj[Ye33]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*ml032*Ye33*conj[Ye33]*MatMul[Adj[Yd], Yd][i1, i2] - 
   4*mHd2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*mHu2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*ms2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*conj[T[Ye11]]*T[Ye11]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*conj[T[Ye22]]*T[Ye22]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*conj[T[Ye33]]*T[Ye33]*MatMul[Adj[Yd], Yd][i1, i2] - 
   2*conj[T[\[Lambda]]]*T[\[Lambda]]*MatMul[Adj[Yd], Yd][i1, i2] - 
   12*mHd2*trace[Yd, Adj[Yd]]*MatMul[Adj[Yd], Yd][i1, i2] - 
   6*trace[conj[T[Yd]], Tp[T[Yd]]]*MatMul[Adj[Yd], Yd][i1, i2] - 
   6*trace[md2, Yd, Adj[Yd]]*MatMul[Adj[Yd], Yd][i1, i2] - 
   6*trace[mq2, Adj[Yd], Yd]*MatMul[Adj[Yd], Yd][i1, i2] - 
   4*gp^2*Qd^2*conj[MassU]*MatMul[Adj[Yd], T[Yd]][i1, i2] - 
   4*gp^2*QHd^2*conj[MassU]*MatMul[Adj[Yd], T[Yd]][i1, i2] + 
   4*gp^2*Qq^2*conj[MassU]*MatMul[Adj[Yd], T[Yd]][i1, i2] - 
   2*Ye11*conj[T[Ye11]]*MatMul[Adj[Yd], T[Yd]][i1, i2] - 
   2*Ye22*conj[T[Ye22]]*MatMul[Adj[Yd], T[Yd]][i1, i2] - 
   2*Ye33*conj[T[Ye33]]*MatMul[Adj[Yd], T[Yd]][i1, i2] - 
   2*\[Lambda]*conj[T[\[Lambda]]]*MatMul[Adj[Yd], T[Yd]][i1, i2] - 
   6*trace[conj[T[Yd]], Tp[Yd]]*MatMul[Adj[Yd], T[Yd]][i1, i2] + 
   (8*g1^2*mHu2*MatMul[Adj[Yu], Yu][i1, i2])/5 + 
   4*gp^2*mHu2*QHu^2*MatMul[Adj[Yu], Yu][i1, i2] - 
   4*gp^2*mHu2*Qq^2*MatMul[Adj[Yu], Yu][i1, i2] + 
   4*gp^2*mHu2*Qu^2*MatMul[Adj[Yu], Yu][i1, i2] + 
   8*gp^2*MassU*QHu^2*conj[MassU]*MatMul[Adj[Yu], Yu][i1, i2] - 
   8*gp^2*MassU*Qq^2*conj[MassU]*MatMul[Adj[Yu], Yu][i1, i2] + 
   8*gp^2*MassU*Qu^2*conj[MassU]*MatMul[Adj[Yu], Yu][i1, i2] - 
   4*mHu2*Yv11*conj[Yv11]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*ml012*Yv11*conj[Yv11]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*mvR012*Yv11*conj[Yv11]*MatMul[Adj[Yu], Yu][i1, i2] - 
   4*mHu2*Yv22*conj[Yv22]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*ml022*Yv22*conj[Yv22]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*mvR022*Yv22*conj[Yv22]*MatMul[Adj[Yu], Yu][i1, i2] - 
   4*mHu2*Yv33*conj[Yv33]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*ml032*Yv33*conj[Yv33]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*mvR032*Yv33*conj[Yv33]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*mHd2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yu], Yu][i1, i2] - 
   4*mHu2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*ms2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*conj[T[Yv11]]*T[Yv11]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*conj[T[Yv22]]*T[Yv22]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*conj[T[Yv33]]*T[Yv33]*MatMul[Adj[Yu], Yu][i1, i2] - 
   2*conj[T[\[Lambda]]]*T[\[Lambda]]*MatMul[Adj[Yu], Yu][i1, i2] - 
   12*mHu2*trace[Yu, Adj[Yu]]*MatMul[Adj[Yu], Yu][i1, i2] - 
   6*trace[conj[T[Yu]], Tp[T[Yu]]]*MatMul[Adj[Yu], Yu][i1, i2] - 
   6*trace[mq2, Adj[Yu], Yu]*MatMul[Adj[Yu], Yu][i1, i2] - 
   6*trace[mu2, Yu, Adj[Yu]]*MatMul[Adj[Yu], Yu][i1, i2] + 
   (g1^2*conj[MassB]*((597*g1^2*MassB + 80*g3^2*(2*MassB + MassG) + 
        45*g2^2*(2*MassB + MassWB) + 60*gp^2*(2*MassB + MassU)*Qq*
         (9*Qd + 3*Qe1 + 3*Qe2 + 3*Qe3 - 3*QHd + 3*QHu - 3*Ql1 - 3*Ql2 - 
          3*Ql3 + 10*Qq - 18*Qu))*Kronecker[i1, i2] + 
      180*(2*MassB*MatMul[Adj[Yd], Yd][i1, i2] - MatMul[Adj[Yd], T[Yd]][i1, 
         i2] + 4*MassB*MatMul[Adj[Yu], Yu][i1, i2] - 
        2*MatMul[Adj[Yu], T[Yu]][i1, i2])))/225 - 
   4*gp^2*QHu^2*conj[MassU]*MatMul[Adj[Yu], T[Yu]][i1, i2] + 
   4*gp^2*Qq^2*conj[MassU]*MatMul[Adj[Yu], T[Yu]][i1, i2] - 
   4*gp^2*Qu^2*conj[MassU]*MatMul[Adj[Yu], T[Yu]][i1, i2] - 
   2*Yv11*conj[T[Yv11]]*MatMul[Adj[Yu], T[Yu]][i1, i2] - 
   2*Yv22*conj[T[Yv22]]*MatMul[Adj[Yu], T[Yu]][i1, i2] - 
   2*Yv33*conj[T[Yv33]]*MatMul[Adj[Yu], T[Yu]][i1, i2] - 
   2*\[Lambda]*conj[T[\[Lambda]]]*MatMul[Adj[Yu], T[Yu]][i1, i2] - 
   6*trace[conj[T[Yu]], Tp[Yu]]*MatMul[Adj[Yu], T[Yu]][i1, i2] - 
   (4*g1^2*MassB*MatMul[Adj[T[Yd]], Yd][i1, i2])/5 - 
   4*gp^2*MassU*Qd^2*MatMul[Adj[T[Yd]], Yd][i1, i2] - 
   4*gp^2*MassU*QHd^2*MatMul[Adj[T[Yd]], Yd][i1, i2] + 
   4*gp^2*MassU*Qq^2*MatMul[Adj[T[Yd]], Yd][i1, i2] - 
   2*conj[Ye11]*T[Ye11]*MatMul[Adj[T[Yd]], Yd][i1, i2] - 
   2*conj[Ye22]*T[Ye22]*MatMul[Adj[T[Yd]], Yd][i1, i2] - 
   2*conj[Ye33]*T[Ye33]*MatMul[Adj[T[Yd]], Yd][i1, i2] - 
   2*conj[\[Lambda]]*T[\[Lambda]]*MatMul[Adj[T[Yd]], Yd][i1, i2] - 
   6*trace[Adj[Yd], T[Yd]]*MatMul[Adj[T[Yd]], Yd][i1, i2] + 
   (4*g1^2*MatMul[Adj[T[Yd]], T[Yd]][i1, i2])/5 + 
   4*gp^2*Qd^2*MatMul[Adj[T[Yd]], T[Yd]][i1, i2] + 
   4*gp^2*QHd^2*MatMul[Adj[T[Yd]], T[Yd]][i1, i2] - 
   4*gp^2*Qq^2*MatMul[Adj[T[Yd]], T[Yd]][i1, i2] - 
   2*Ye11*conj[Ye11]*MatMul[Adj[T[Yd]], T[Yd]][i1, i2] - 
   2*Ye22*conj[Ye22]*MatMul[Adj[T[Yd]], T[Yd]][i1, i2] - 
   2*Ye33*conj[Ye33]*MatMul[Adj[T[Yd]], T[Yd]][i1, i2] - 
   2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[T[Yd]], T[Yd]][i1, i2] - 
   6*trace[Yd, Adj[Yd]]*MatMul[Adj[T[Yd]], T[Yd]][i1, i2] - 
   (8*g1^2*MassB*MatMul[Adj[T[Yu]], Yu][i1, i2])/5 - 
   4*gp^2*MassU*QHu^2*MatMul[Adj[T[Yu]], Yu][i1, i2] + 
   4*gp^2*MassU*Qq^2*MatMul[Adj[T[Yu]], Yu][i1, i2] - 
   4*gp^2*MassU*Qu^2*MatMul[Adj[T[Yu]], Yu][i1, i2] - 
   2*conj[Yv11]*T[Yv11]*MatMul[Adj[T[Yu]], Yu][i1, i2] - 
   2*conj[Yv22]*T[Yv22]*MatMul[Adj[T[Yu]], Yu][i1, i2] - 
   2*conj[Yv33]*T[Yv33]*MatMul[Adj[T[Yu]], Yu][i1, i2] - 
   2*conj[\[Lambda]]*T[\[Lambda]]*MatMul[Adj[T[Yu]], Yu][i1, i2] - 
   6*trace[Adj[Yu], T[Yu]]*MatMul[Adj[T[Yu]], Yu][i1, i2] + 
   (8*g1^2*MatMul[Adj[T[Yu]], T[Yu]][i1, i2])/5 + 
   4*gp^2*QHu^2*MatMul[Adj[T[Yu]], T[Yu]][i1, i2] - 
   4*gp^2*Qq^2*MatMul[Adj[T[Yu]], T[Yu]][i1, i2] + 
   4*gp^2*Qu^2*MatMul[Adj[T[Yu]], T[Yu]][i1, i2] - 
   2*Yv11*conj[Yv11]*MatMul[Adj[T[Yu]], T[Yu]][i1, i2] - 
   2*Yv22*conj[Yv22]*MatMul[Adj[T[Yu]], T[Yu]][i1, i2] - 
   2*Yv33*conj[Yv33]*MatMul[Adj[T[Yu]], T[Yu]][i1, i2] - 
   2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[T[Yu]], T[Yu]][i1, i2] - 
   6*trace[Yu, Adj[Yu]]*MatMul[Adj[T[Yu]], T[Yu]][i1, i2] + 
   (2*g1^2*MatMul[mq2, Adj[Yd], Yd][i1, i2])/5 + 
   2*gp^2*Qd^2*MatMul[mq2, Adj[Yd], Yd][i1, i2] + 
   2*gp^2*QHd^2*MatMul[mq2, Adj[Yd], Yd][i1, i2] - 
   2*gp^2*Qq^2*MatMul[mq2, Adj[Yd], Yd][i1, i2] - 
   Ye11*conj[Ye11]*MatMul[mq2, Adj[Yd], Yd][i1, i2] - 
   Ye22*conj[Ye22]*MatMul[mq2, Adj[Yd], Yd][i1, i2] - 
   Ye33*conj[Ye33]*MatMul[mq2, Adj[Yd], Yd][i1, i2] - 
   \[Lambda]*conj[\[Lambda]]*MatMul[mq2, Adj[Yd], Yd][i1, i2] - 
   3*trace[Yd, Adj[Yd]]*MatMul[mq2, Adj[Yd], Yd][i1, i2] + 
   (4*g1^2*MatMul[mq2, Adj[Yu], Yu][i1, i2])/5 + 
   2*gp^2*QHu^2*MatMul[mq2, Adj[Yu], Yu][i1, i2] - 
   2*gp^2*Qq^2*MatMul[mq2, Adj[Yu], Yu][i1, i2] + 
   2*gp^2*Qu^2*MatMul[mq2, Adj[Yu], Yu][i1, i2] - 
   Yv11*conj[Yv11]*MatMul[mq2, Adj[Yu], Yu][i1, i2] - 
   Yv22*conj[Yv22]*MatMul[mq2, Adj[Yu], Yu][i1, i2] - 
   Yv33*conj[Yv33]*MatMul[mq2, Adj[Yu], Yu][i1, i2] - 
   \[Lambda]*conj[\[Lambda]]*MatMul[mq2, Adj[Yu], Yu][i1, i2] - 
   3*trace[Yu, Adj[Yu]]*MatMul[mq2, Adj[Yu], Yu][i1, i2] + 
   (4*g1^2*MatMul[Adj[Yd], md2, Yd][i1, i2])/5 + 
   4*gp^2*Qd^2*MatMul[Adj[Yd], md2, Yd][i1, i2] + 
   4*gp^2*QHd^2*MatMul[Adj[Yd], md2, Yd][i1, i2] - 
   4*gp^2*Qq^2*MatMul[Adj[Yd], md2, Yd][i1, i2] - 
   2*Ye11*conj[Ye11]*MatMul[Adj[Yd], md2, Yd][i1, i2] - 
   2*Ye22*conj[Ye22]*MatMul[Adj[Yd], md2, Yd][i1, i2] - 
   2*Ye33*conj[Ye33]*MatMul[Adj[Yd], md2, Yd][i1, i2] - 
   2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yd], md2, Yd][i1, i2] - 
   6*trace[Yd, Adj[Yd]]*MatMul[Adj[Yd], md2, Yd][i1, i2] + 
   (2*g1^2*MatMul[Adj[Yd], Yd, mq2][i1, i2])/5 + 
   2*gp^2*Qd^2*MatMul[Adj[Yd], Yd, mq2][i1, i2] + 
   2*gp^2*QHd^2*MatMul[Adj[Yd], Yd, mq2][i1, i2] - 
   2*gp^2*Qq^2*MatMul[Adj[Yd], Yd, mq2][i1, i2] - 
   Ye11*conj[Ye11]*MatMul[Adj[Yd], Yd, mq2][i1, i2] - 
   Ye22*conj[Ye22]*MatMul[Adj[Yd], Yd, mq2][i1, i2] - 
   Ye33*conj[Ye33]*MatMul[Adj[Yd], Yd, mq2][i1, i2] - 
   \[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yd], Yd, mq2][i1, i2] - 
   3*trace[Yd, Adj[Yd]]*MatMul[Adj[Yd], Yd, mq2][i1, i2] + 
   (8*g1^2*MatMul[Adj[Yu], mu2, Yu][i1, i2])/5 + 
   4*gp^2*QHu^2*MatMul[Adj[Yu], mu2, Yu][i1, i2] - 
   4*gp^2*Qq^2*MatMul[Adj[Yu], mu2, Yu][i1, i2] + 
   4*gp^2*Qu^2*MatMul[Adj[Yu], mu2, Yu][i1, i2] - 
   2*Yv11*conj[Yv11]*MatMul[Adj[Yu], mu2, Yu][i1, i2] - 
   2*Yv22*conj[Yv22]*MatMul[Adj[Yu], mu2, Yu][i1, i2] - 
   2*Yv33*conj[Yv33]*MatMul[Adj[Yu], mu2, Yu][i1, i2] - 
   2*\[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yu], mu2, Yu][i1, i2] - 
   6*trace[Yu, Adj[Yu]]*MatMul[Adj[Yu], mu2, Yu][i1, i2] + 
   (4*g1^2*MatMul[Adj[Yu], Yu, mq2][i1, i2])/5 + 
   2*gp^2*QHu^2*MatMul[Adj[Yu], Yu, mq2][i1, i2] - 
   2*gp^2*Qq^2*MatMul[Adj[Yu], Yu, mq2][i1, i2] + 
   2*gp^2*Qu^2*MatMul[Adj[Yu], Yu, mq2][i1, i2] - 
   Yv11*conj[Yv11]*MatMul[Adj[Yu], Yu, mq2][i1, i2] - 
   Yv22*conj[Yv22]*MatMul[Adj[Yu], Yu, mq2][i1, i2] - 
   Yv33*conj[Yv33]*MatMul[Adj[Yu], Yu, mq2][i1, i2] - 
   \[Lambda]*conj[\[Lambda]]*MatMul[Adj[Yu], Yu, mq2][i1, i2] - 
   3*trace[Yu, Adj[Yu]]*MatMul[Adj[Yu], Yu, mq2][i1, i2] - 
   8*mHd2*MatMul[Adj[Yd], Yd, Adj[Yd], Yd][i1, i2] - 
   4*MatMul[Adj[Yd], Yd, Adj[T[Yd]], T[Yd]][i1, i2] - 
   4*MatMul[Adj[Yd], T[Yd], Adj[T[Yd]], Yd][i1, i2] - 
   8*mHu2*MatMul[Adj[Yu], Yu, Adj[Yu], Yu][i1, i2] - 
   4*MatMul[Adj[Yu], Yu, Adj[T[Yu]], T[Yu]][i1, i2] - 
   4*MatMul[Adj[Yu], T[Yu], Adj[T[Yu]], Yu][i1, i2] - 
   4*MatMul[Adj[T[Yd]], Yd, Adj[Yd], T[Yd]][i1, i2] - 
   4*MatMul[Adj[T[Yd]], T[Yd], Adj[Yd], Yd][i1, i2] - 
   4*MatMul[Adj[T[Yu]], Yu, Adj[Yu], T[Yu]][i1, i2] - 
   4*MatMul[Adj[T[Yu]], T[Yu], Adj[Yu], Yu][i1, i2] - 
   2*MatMul[mq2, Adj[Yd], Yd, Adj[Yd], Yd][i1, i2] - 
   2*MatMul[mq2, Adj[Yu], Yu, Adj[Yu], Yu][i1, i2] - 
   4*MatMul[Adj[Yd], md2, Yd, Adj[Yd], Yd][i1, i2] - 
   4*MatMul[Adj[Yd], Yd, mq2, Adj[Yd], Yd][i1, i2] - 
   4*MatMul[Adj[Yd], Yd, Adj[Yd], md2, Yd][i1, i2] - 
   2*MatMul[Adj[Yd], Yd, Adj[Yd], Yd, mq2][i1, i2] - 
   4*MatMul[Adj[Yu], mu2, Yu, Adj[Yu], Yu][i1, i2] - 
   4*MatMul[Adj[Yu], Yu, mq2, Adj[Yu], Yu][i1, i2] - 
   4*MatMul[Adj[Yu], Yu, Adj[Yu], mu2, Yu][i1, i2] - 
   2*MatMul[Adj[Yu], Yu, Adj[Yu], Yu, mq2][i1, i2]}, 
 {ml012, (-6*g1^2*MassB*conj[MassB])/5 - 8*gp^2*MassU*Ql1^2*conj[MassU] - 
   6*g2^2*MassWB*conj[MassWB] + 2*Tep*conj[Tep] + 2*me012*Ye11*conj[Ye11] + 
   2*mHd2*Ye11*conj[Ye11] + 2*ml012*Ye11*conj[Ye11] + 
   2*mHu2*Yv11*conj[Yv11] + 2*ml012*Yv11*conj[Yv11] + 
   2*mvR012*Yv11*conj[Yv11] + 2*conj[T[Ye11]]*T[Ye11] + 
   2*conj[T[Yv11]]*T[Yv11] - Sqrt[3/5]*g1*Tr1[1] + 2*gp*Ql1*Tr1[4], 
  (9*g1^2*g2^2*MassB*conj[MassWB])/5 + (18*g1^2*g2^2*MassWB*conj[MassWB])/5 + 
   33*g2^4*MassWB*conj[MassWB] + 12*g2^2*gp^2*MassU*Ql1^2*conj[MassWB] + 
   24*g2^2*gp^2*MassWB*Ql1^2*conj[MassWB] + (12*g1^2*me012*Ye11*conj[Ye11])/
    5 + (12*g1^2*mHd2*Ye11*conj[Ye11])/5 + (12*g1^2*ml012*Ye11*conj[Ye11])/
    5 + 4*gp^2*me012*Qe1^2*Ye11*conj[Ye11] + 4*gp^2*mHd2*Qe1^2*Ye11*
    conj[Ye11] + 4*gp^2*ml012*Qe1^2*Ye11*conj[Ye11] + 
   4*gp^2*me012*QHd^2*Ye11*conj[Ye11] + 4*gp^2*mHd2*QHd^2*Ye11*conj[Ye11] + 
   4*gp^2*ml012*QHd^2*Ye11*conj[Ye11] - 4*gp^2*me012*Ql1^2*Ye11*conj[Ye11] - 
   4*gp^2*mHd2*Ql1^2*Ye11*conj[Ye11] - 4*gp^2*ml012*Ql1^2*Ye11*conj[Ye11] - 
   12*me012*Ye11^2*conj[Ye11]^2 - 12*mHd2*Ye11^2*conj[Ye11]^2 - 
   12*ml012*Ye11^2*conj[Ye11]^2 - 2*me012*Ye11*Ye22*conj[Ye11]*conj[Ye22] - 
   2*me022*Ye11*Ye22*conj[Ye11]*conj[Ye22] - 4*mHd2*Ye11*Ye22*conj[Ye11]*
    conj[Ye22] - 2*ml012*Ye11*Ye22*conj[Ye11]*conj[Ye22] - 
   2*ml022*Ye11*Ye22*conj[Ye11]*conj[Ye22] - 2*me012*Ye11*Ye33*conj[Ye11]*
    conj[Ye33] - 2*me032*Ye11*Ye33*conj[Ye11]*conj[Ye33] - 
   4*mHd2*Ye11*Ye33*conj[Ye11]*conj[Ye33] - 2*ml012*Ye11*Ye33*conj[Ye11]*
    conj[Ye33] - 2*ml032*Ye11*Ye33*conj[Ye11]*conj[Ye33] + 
   4*gp^2*mHu2*QHu^2*Yv11*conj[Yv11] + 4*gp^2*ml012*QHu^2*Yv11*conj[Yv11] + 
   4*gp^2*mvR012*QHu^2*Yv11*conj[Yv11] - 4*gp^2*mHu2*Ql1^2*Yv11*conj[Yv11] - 
   4*gp^2*ml012*Ql1^2*Yv11*conj[Yv11] - 4*gp^2*mvR012*Ql1^2*Yv11*conj[Yv11] + 
   4*gp^2*mHu2*Qv1^2*Yv11*conj[Yv11] + 4*gp^2*ml012*Qv1^2*Yv11*conj[Yv11] + 
   4*gp^2*mvR012*Qv1^2*Yv11*conj[Yv11] - 12*mHu2*Yv11^2*conj[Yv11]^2 - 
   12*ml012*Yv11^2*conj[Yv11]^2 - 12*mvR012*Yv11^2*conj[Yv11]^2 - 
   4*mHu2*Yv11*Yv22*conj[Yv11]*conj[Yv22] - 2*ml012*Yv11*Yv22*conj[Yv11]*
    conj[Yv22] - 2*ml022*Yv11*Yv22*conj[Yv11]*conj[Yv22] - 
   2*mvR012*Yv11*Yv22*conj[Yv11]*conj[Yv22] - 2*mvR022*Yv11*Yv22*conj[Yv11]*
    conj[Yv22] - 4*mHu2*Yv11*Yv33*conj[Yv11]*conj[Yv33] - 
   2*ml012*Yv11*Yv33*conj[Yv11]*conj[Yv33] - 2*ml032*Yv11*Yv33*conj[Yv11]*
    conj[Yv33] - 2*mvR012*Yv11*Yv33*conj[Yv11]*conj[Yv33] - 
   2*mvR032*Yv11*Yv33*conj[Yv11]*conj[Yv33] - 2*me012*Ye11*\[Lambda]*
    conj[Ye11]*conj[\[Lambda]] - 4*mHd2*Ye11*\[Lambda]*conj[Ye11]*
    conj[\[Lambda]] - 2*mHu2*Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - 
   2*ml012*Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - 
   2*ms2*Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - 
   2*mHd2*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   4*mHu2*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   2*ml012*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   2*ms2*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   2*mvR012*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   (12*g1^2*MassB*Ye11*conj[T[Ye11]])/5 - 4*gp^2*MassU*Qe1^2*Ye11*
    conj[T[Ye11]] - 4*gp^2*MassU*QHd^2*Ye11*conj[T[Ye11]] + 
   4*gp^2*MassU*Ql1^2*Ye11*conj[T[Ye11]] - 4*gp^2*MassU*QHu^2*Yv11*
    conj[T[Yv11]] + 4*gp^2*MassU*Ql1^2*Yv11*conj[T[Yv11]] - 
   4*gp^2*MassU*Qv1^2*Yv11*conj[T[Yv11]] + 
   (3*g1^2*conj[MassB]*(207*g1^2*MassB + 15*g2^2*(2*MassB + MassWB) - 
      20*gp^2*(2*MassB + MassU)*Ql1*(3*Qd + Qe1 + Qe2 + Qe3 - QHd + QHu - 
        2*Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu) + 20*conj[Ye11]*
       (2*MassB*Ye11 - T[Ye11])))/25 + (12*g1^2*conj[T[Ye11]]*T[Ye11])/5 + 
   4*gp^2*Qe1^2*conj[T[Ye11]]*T[Ye11] + 4*gp^2*QHd^2*conj[T[Ye11]]*T[Ye11] - 
   4*gp^2*Ql1^2*conj[T[Ye11]]*T[Ye11] - 24*Ye11*conj[Ye11]*conj[T[Ye11]]*
    T[Ye11] - 2*Ye22*conj[Ye22]*conj[T[Ye11]]*T[Ye11] - 
   2*Ye33*conj[Ye33]*conj[T[Ye11]]*T[Ye11] - 2*\[Lambda]*conj[\[Lambda]]*
    conj[T[Ye11]]*T[Ye11] - 2*Ye22*conj[Ye11]*conj[T[Ye22]]*T[Ye11] - 
   2*Ye33*conj[Ye11]*conj[T[Ye33]]*T[Ye11] - 2*\[Lambda]*conj[Ye11]*
    conj[T[\[Lambda]]]*T[Ye11] - 2*Ye11*conj[Ye22]*conj[T[Ye11]]*T[Ye22] - 
   2*Ye11*conj[Ye11]*conj[T[Ye22]]*T[Ye22] - 2*Ye11*conj[Ye33]*conj[T[Ye11]]*
    T[Ye33] - 2*Ye11*conj[Ye11]*conj[T[Ye33]]*T[Ye33] + 
   (4*gp^2*conj[MassU]*
     (3*Ql1*(-(g1^2*(MassB + 2*MassU)*(3*Qd + Qe1 + Qe2 + Qe3 - QHd + QHu - 
           2*Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu)) + 
        5*Ql1*(g2^2*(2*MassU + MassWB) + 2*gp^2*MassU*(9*Qd^2 + Qe1^2 + 
            Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 4*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 
            18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2))) + 
      5*(Qe1^2 + QHd^2 - Ql1^2)*conj[Ye11]*(2*MassU*Ye11 - T[Ye11]) + 
      5*(QHu^2 - Ql1^2 + Qv1^2)*conj[Yv11]*(2*MassU*Yv11 - T[Yv11])))/5 + 
   4*gp^2*QHu^2*conj[T[Yv11]]*T[Yv11] - 4*gp^2*Ql1^2*conj[T[Yv11]]*T[Yv11] + 
   4*gp^2*Qv1^2*conj[T[Yv11]]*T[Yv11] - 24*Yv11*conj[Yv11]*conj[T[Yv11]]*
    T[Yv11] - 2*Yv22*conj[Yv22]*conj[T[Yv11]]*T[Yv11] - 
   2*Yv33*conj[Yv33]*conj[T[Yv11]]*T[Yv11] - 2*\[Lambda]*conj[\[Lambda]]*
    conj[T[Yv11]]*T[Yv11] - 2*Yv22*conj[Yv11]*conj[T[Yv22]]*T[Yv11] - 
   2*Yv33*conj[Yv11]*conj[T[Yv33]]*T[Yv11] - 2*\[Lambda]*conj[Yv11]*
    conj[T[\[Lambda]]]*T[Yv11] - 2*Yv11*conj[Yv22]*conj[T[Yv11]]*T[Yv22] - 
   2*Yv11*conj[Yv11]*conj[T[Yv22]]*T[Yv22] - 2*Yv11*conj[Yv33]*conj[T[Yv11]]*
    T[Yv33] - 2*Yv11*conj[Yv11]*conj[T[Yv33]]*T[Yv33] - 
   2*Ye11*conj[\[Lambda]]*conj[T[Ye11]]*T[\[Lambda]] - 
   2*Yv11*conj[\[Lambda]]*conj[T[Yv11]]*T[\[Lambda]] - 
   2*Ye11*conj[Ye11]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   2*Yv11*conj[Yv11]*conj[T[\[Lambda]]]*T[\[Lambda]] + 6*g2^4*Tr2[2] + 
   (6*g1^2*Tr2U1[1, 1])/5 - 4*Sqrt[3/5]*g1*gp*Ql1*Tr2U1[1, 4] - 
   4*Sqrt[3/5]*g1*gp*Ql1*Tr2U1[4, 1] + 8*gp^2*Ql1^2*Tr2U1[4, 4] - 
   4*Sqrt[3/5]*g1*Tr3[1] + 8*gp*Ql1*Tr3[4] - 6*me012*Ye11*conj[Ye11]*
    trace[Yd, Adj[Yd]] - 12*mHd2*Ye11*conj[Ye11]*trace[Yd, Adj[Yd]] - 
   6*ml012*Ye11*conj[Ye11]*trace[Yd, Adj[Yd]] - 6*conj[T[Ye11]]*T[Ye11]*
    trace[Yd, Adj[Yd]] - 12*mHu2*Yv11*conj[Yv11]*trace[Yu, Adj[Yu]] - 
   6*ml012*Yv11*conj[Yv11]*trace[Yu, Adj[Yu]] - 6*mvR012*Yv11*conj[Yv11]*
    trace[Yu, Adj[Yu]] - 6*conj[T[Yv11]]*T[Yv11]*trace[Yu, Adj[Yu]] - 
   6*Ye11*conj[T[Ye11]]*trace[Adj[Yd], T[Yd]] - 
   6*Yv11*conj[T[Yv11]]*trace[Adj[Yu], T[Yu]] - 
   6*conj[Ye11]*T[Ye11]*trace[conj[T[Yd]], Tp[Yd]] - 
   6*Ye11*conj[Ye11]*trace[conj[T[Yd]], Tp[T[Yd]]] - 
   6*conj[Yv11]*T[Yv11]*trace[conj[T[Yu]], Tp[Yu]] - 
   6*Yv11*conj[Yv11]*trace[conj[T[Yu]], Tp[T[Yu]]] - 
   6*Ye11*conj[Ye11]*trace[md2, Yd, Adj[Yd]] - 
   6*Ye11*conj[Ye11]*trace[mq2, Adj[Yd], Yd] - 
   6*Yv11*conj[Yv11]*trace[mq2, Adj[Yu], Yu] - 
   6*Yv11*conj[Yv11]*trace[mu2, Yu, Adj[Yu]]}, 
 {ml022, (-6*g1^2*MassB*conj[MassB])/5 - 8*gp^2*MassU*Ql2^2*conj[MassU] - 
   6*g2^2*MassWB*conj[MassWB] + 2*Tmup*conj[Tmup] + 2*me022*Ye22*conj[Ye22] + 
   2*mHd2*Ye22*conj[Ye22] + 2*ml022*Ye22*conj[Ye22] + 
   2*mHu2*Yv22*conj[Yv22] + 2*ml022*Yv22*conj[Yv22] + 
   2*mvR022*Yv22*conj[Yv22] + 2*conj[T[Ye22]]*T[Ye22] + 
   2*conj[T[Yv22]]*T[Yv22] - Sqrt[3/5]*g1*Tr1[1] + 2*gp*Ql2*Tr1[4], 
  (9*g1^2*g2^2*MassB*conj[MassWB])/5 + (18*g1^2*g2^2*MassWB*conj[MassWB])/5 + 
   33*g2^4*MassWB*conj[MassWB] + 12*g2^2*gp^2*MassU*Ql2^2*conj[MassWB] + 
   24*g2^2*gp^2*MassWB*Ql2^2*conj[MassWB] + (12*g1^2*me022*Ye22*conj[Ye22])/
    5 + (12*g1^2*mHd2*Ye22*conj[Ye22])/5 + (12*g1^2*ml022*Ye22*conj[Ye22])/
    5 + 4*gp^2*me022*Qe2^2*Ye22*conj[Ye22] + 4*gp^2*mHd2*Qe2^2*Ye22*
    conj[Ye22] + 4*gp^2*ml022*Qe2^2*Ye22*conj[Ye22] + 
   4*gp^2*me022*QHd^2*Ye22*conj[Ye22] + 4*gp^2*mHd2*QHd^2*Ye22*conj[Ye22] + 
   4*gp^2*ml022*QHd^2*Ye22*conj[Ye22] - 4*gp^2*me022*Ql2^2*Ye22*conj[Ye22] - 
   4*gp^2*mHd2*Ql2^2*Ye22*conj[Ye22] - 4*gp^2*ml022*Ql2^2*Ye22*conj[Ye22] - 
   2*me012*Ye11*Ye22*conj[Ye11]*conj[Ye22] - 2*me022*Ye11*Ye22*conj[Ye11]*
    conj[Ye22] - 4*mHd2*Ye11*Ye22*conj[Ye11]*conj[Ye22] - 
   2*ml012*Ye11*Ye22*conj[Ye11]*conj[Ye22] - 2*ml022*Ye11*Ye22*conj[Ye11]*
    conj[Ye22] - 12*me022*Ye22^2*conj[Ye22]^2 - 12*mHd2*Ye22^2*conj[Ye22]^2 - 
   12*ml022*Ye22^2*conj[Ye22]^2 - 2*me022*Ye22*Ye33*conj[Ye22]*conj[Ye33] - 
   2*me032*Ye22*Ye33*conj[Ye22]*conj[Ye33] - 4*mHd2*Ye22*Ye33*conj[Ye22]*
    conj[Ye33] - 2*ml022*Ye22*Ye33*conj[Ye22]*conj[Ye33] - 
   2*ml032*Ye22*Ye33*conj[Ye22]*conj[Ye33] + 4*gp^2*mHu2*QHu^2*Yv22*
    conj[Yv22] + 4*gp^2*ml022*QHu^2*Yv22*conj[Yv22] + 
   4*gp^2*mvR022*QHu^2*Yv22*conj[Yv22] - 4*gp^2*mHu2*Ql2^2*Yv22*conj[Yv22] - 
   4*gp^2*ml022*Ql2^2*Yv22*conj[Yv22] - 4*gp^2*mvR022*Ql2^2*Yv22*conj[Yv22] + 
   4*gp^2*mHu2*Qv2^2*Yv22*conj[Yv22] + 4*gp^2*ml022*Qv2^2*Yv22*conj[Yv22] + 
   4*gp^2*mvR022*Qv2^2*Yv22*conj[Yv22] - 4*mHu2*Yv11*Yv22*conj[Yv11]*
    conj[Yv22] - 2*ml012*Yv11*Yv22*conj[Yv11]*conj[Yv22] - 
   2*ml022*Yv11*Yv22*conj[Yv11]*conj[Yv22] - 2*mvR012*Yv11*Yv22*conj[Yv11]*
    conj[Yv22] - 2*mvR022*Yv11*Yv22*conj[Yv11]*conj[Yv22] - 
   12*mHu2*Yv22^2*conj[Yv22]^2 - 12*ml022*Yv22^2*conj[Yv22]^2 - 
   12*mvR022*Yv22^2*conj[Yv22]^2 - 4*mHu2*Yv22*Yv33*conj[Yv22]*conj[Yv33] - 
   2*ml022*Yv22*Yv33*conj[Yv22]*conj[Yv33] - 2*ml032*Yv22*Yv33*conj[Yv22]*
    conj[Yv33] - 2*mvR022*Yv22*Yv33*conj[Yv22]*conj[Yv33] - 
   2*mvR032*Yv22*Yv33*conj[Yv22]*conj[Yv33] - 2*me022*Ye22*\[Lambda]*
    conj[Ye22]*conj[\[Lambda]] - 4*mHd2*Ye22*\[Lambda]*conj[Ye22]*
    conj[\[Lambda]] - 2*mHu2*Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   2*ml022*Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   2*ms2*Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   2*mHd2*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   4*mHu2*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   2*ml022*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   2*ms2*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   2*mvR022*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   (12*g1^2*MassB*Ye22*conj[T[Ye22]])/5 - 4*gp^2*MassU*Qe2^2*Ye22*
    conj[T[Ye22]] - 4*gp^2*MassU*QHd^2*Ye22*conj[T[Ye22]] + 
   4*gp^2*MassU*Ql2^2*Ye22*conj[T[Ye22]] - 4*gp^2*MassU*QHu^2*Yv22*
    conj[T[Yv22]] + 4*gp^2*MassU*Ql2^2*Yv22*conj[T[Yv22]] - 
   4*gp^2*MassU*Qv2^2*Yv22*conj[T[Yv22]] - 2*Ye22*conj[Ye22]*conj[T[Ye11]]*
    T[Ye11] - 2*Ye22*conj[Ye11]*conj[T[Ye22]]*T[Ye11] + 
   (3*g1^2*conj[MassB]*(207*g1^2*MassB + 15*g2^2*(2*MassB + MassWB) - 
      20*gp^2*(2*MassB + MassU)*Ql2*(3*Qd + Qe1 + Qe2 + Qe3 - QHd + QHu - 
        Ql1 - 2*Ql2 - Ql3 + 3*Qq - 6*Qu) + 20*conj[Ye22]*
       (2*MassB*Ye22 - T[Ye22])))/25 - 2*Ye11*conj[Ye22]*conj[T[Ye11]]*
    T[Ye22] + (12*g1^2*conj[T[Ye22]]*T[Ye22])/5 + 
   4*gp^2*Qe2^2*conj[T[Ye22]]*T[Ye22] + 4*gp^2*QHd^2*conj[T[Ye22]]*T[Ye22] - 
   4*gp^2*Ql2^2*conj[T[Ye22]]*T[Ye22] - 2*Ye11*conj[Ye11]*conj[T[Ye22]]*
    T[Ye22] - 24*Ye22*conj[Ye22]*conj[T[Ye22]]*T[Ye22] - 
   2*Ye33*conj[Ye33]*conj[T[Ye22]]*T[Ye22] - 2*\[Lambda]*conj[\[Lambda]]*
    conj[T[Ye22]]*T[Ye22] - 2*Ye33*conj[Ye22]*conj[T[Ye33]]*T[Ye22] - 
   2*\[Lambda]*conj[Ye22]*conj[T[\[Lambda]]]*T[Ye22] - 
   2*Ye22*conj[Ye33]*conj[T[Ye22]]*T[Ye33] - 2*Ye22*conj[Ye22]*conj[T[Ye33]]*
    T[Ye33] - 2*Yv22*conj[Yv22]*conj[T[Yv11]]*T[Yv11] - 
   2*Yv22*conj[Yv11]*conj[T[Yv22]]*T[Yv11] + 
   (4*gp^2*conj[MassU]*
     (3*Ql2*(-(g1^2*(MassB + 2*MassU)*(3*Qd + Qe1 + Qe2 + Qe3 - QHd + QHu - 
           Ql1 - 2*Ql2 - Ql3 + 3*Qq - 6*Qu)) + 
        5*Ql2*(g2^2*(2*MassU + MassWB) + 2*gp^2*MassU*(9*Qd^2 + Qe1^2 + 
            Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 4*Ql2^2 + 2*Ql3^2 + 
            18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2))) + 
      5*(Qe2^2 + QHd^2 - Ql2^2)*conj[Ye22]*(2*MassU*Ye22 - T[Ye22]) + 
      5*(QHu^2 - Ql2^2 + Qv2^2)*conj[Yv22]*(2*MassU*Yv22 - T[Yv22])))/5 - 
   2*Yv11*conj[Yv22]*conj[T[Yv11]]*T[Yv22] + 4*gp^2*QHu^2*conj[T[Yv22]]*
    T[Yv22] - 4*gp^2*Ql2^2*conj[T[Yv22]]*T[Yv22] + 
   4*gp^2*Qv2^2*conj[T[Yv22]]*T[Yv22] - 2*Yv11*conj[Yv11]*conj[T[Yv22]]*
    T[Yv22] - 24*Yv22*conj[Yv22]*conj[T[Yv22]]*T[Yv22] - 
   2*Yv33*conj[Yv33]*conj[T[Yv22]]*T[Yv22] - 2*\[Lambda]*conj[\[Lambda]]*
    conj[T[Yv22]]*T[Yv22] - 2*Yv33*conj[Yv22]*conj[T[Yv33]]*T[Yv22] - 
   2*\[Lambda]*conj[Yv22]*conj[T[\[Lambda]]]*T[Yv22] - 
   2*Yv22*conj[Yv33]*conj[T[Yv22]]*T[Yv33] - 2*Yv22*conj[Yv22]*conj[T[Yv33]]*
    T[Yv33] - 2*Ye22*conj[\[Lambda]]*conj[T[Ye22]]*T[\[Lambda]] - 
   2*Yv22*conj[\[Lambda]]*conj[T[Yv22]]*T[\[Lambda]] - 
   2*Ye22*conj[Ye22]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   2*Yv22*conj[Yv22]*conj[T[\[Lambda]]]*T[\[Lambda]] + 6*g2^4*Tr2[2] + 
   (6*g1^2*Tr2U1[1, 1])/5 - 4*Sqrt[3/5]*g1*gp*Ql2*Tr2U1[1, 4] - 
   4*Sqrt[3/5]*g1*gp*Ql2*Tr2U1[4, 1] + 8*gp^2*Ql2^2*Tr2U1[4, 4] - 
   4*Sqrt[3/5]*g1*Tr3[1] + 8*gp*Ql2*Tr3[4] - 6*me022*Ye22*conj[Ye22]*
    trace[Yd, Adj[Yd]] - 12*mHd2*Ye22*conj[Ye22]*trace[Yd, Adj[Yd]] - 
   6*ml022*Ye22*conj[Ye22]*trace[Yd, Adj[Yd]] - 6*conj[T[Ye22]]*T[Ye22]*
    trace[Yd, Adj[Yd]] - 12*mHu2*Yv22*conj[Yv22]*trace[Yu, Adj[Yu]] - 
   6*ml022*Yv22*conj[Yv22]*trace[Yu, Adj[Yu]] - 6*mvR022*Yv22*conj[Yv22]*
    trace[Yu, Adj[Yu]] - 6*conj[T[Yv22]]*T[Yv22]*trace[Yu, Adj[Yu]] - 
   6*Ye22*conj[T[Ye22]]*trace[Adj[Yd], T[Yd]] - 
   6*Yv22*conj[T[Yv22]]*trace[Adj[Yu], T[Yu]] - 
   6*conj[Ye22]*T[Ye22]*trace[conj[T[Yd]], Tp[Yd]] - 
   6*Ye22*conj[Ye22]*trace[conj[T[Yd]], Tp[T[Yd]]] - 
   6*conj[Yv22]*T[Yv22]*trace[conj[T[Yu]], Tp[Yu]] - 
   6*Yv22*conj[Yv22]*trace[conj[T[Yu]], Tp[T[Yu]]] - 
   6*Ye22*conj[Ye22]*trace[md2, Yd, Adj[Yd]] - 
   6*Ye22*conj[Ye22]*trace[mq2, Adj[Yd], Yd] - 
   6*Yv22*conj[Yv22]*trace[mq2, Adj[Yu], Yu] - 
   6*Yv22*conj[Yv22]*trace[mu2, Yu, Adj[Yu]]}, 
 {ml032, (-6*g1^2*MassB*conj[MassB])/5 - 8*gp^2*MassU*Ql3^2*conj[MassU] - 
   6*g2^2*MassWB*conj[MassWB] + 2*me032*Ye33*conj[Ye33] + 
   2*mHd2*Ye33*conj[Ye33] + 2*ml032*Ye33*conj[Ye33] + 
   2*mHu2*Yv33*conj[Yv33] + 2*ml032*Yv33*conj[Yv33] + 
   2*mvR032*Yv33*conj[Yv33] + 2*conj[T[Ye33]]*T[Ye33] + 
   2*conj[T[Yv33]]*T[Yv33] - Sqrt[3/5]*g1*Tr1[1] + 2*gp*Ql3*Tr1[4], 
  (9*g1^2*g2^2*MassB*conj[MassWB])/5 + (18*g1^2*g2^2*MassWB*conj[MassWB])/5 + 
   33*g2^4*MassWB*conj[MassWB] + 12*g2^2*gp^2*MassU*Ql3^2*conj[MassWB] + 
   24*g2^2*gp^2*MassWB*Ql3^2*conj[MassWB] + (12*g1^2*me032*Ye33*conj[Ye33])/
    5 + (12*g1^2*mHd2*Ye33*conj[Ye33])/5 + (12*g1^2*ml032*Ye33*conj[Ye33])/
    5 + 4*gp^2*me032*Qe3^2*Ye33*conj[Ye33] + 4*gp^2*mHd2*Qe3^2*Ye33*
    conj[Ye33] + 4*gp^2*ml032*Qe3^2*Ye33*conj[Ye33] + 
   4*gp^2*me032*QHd^2*Ye33*conj[Ye33] + 4*gp^2*mHd2*QHd^2*Ye33*conj[Ye33] + 
   4*gp^2*ml032*QHd^2*Ye33*conj[Ye33] - 4*gp^2*me032*Ql3^2*Ye33*conj[Ye33] - 
   4*gp^2*mHd2*Ql3^2*Ye33*conj[Ye33] - 4*gp^2*ml032*Ql3^2*Ye33*conj[Ye33] - 
   2*me012*Ye11*Ye33*conj[Ye11]*conj[Ye33] - 2*me032*Ye11*Ye33*conj[Ye11]*
    conj[Ye33] - 4*mHd2*Ye11*Ye33*conj[Ye11]*conj[Ye33] - 
   2*ml012*Ye11*Ye33*conj[Ye11]*conj[Ye33] - 2*ml032*Ye11*Ye33*conj[Ye11]*
    conj[Ye33] - 2*me022*Ye22*Ye33*conj[Ye22]*conj[Ye33] - 
   2*me032*Ye22*Ye33*conj[Ye22]*conj[Ye33] - 4*mHd2*Ye22*Ye33*conj[Ye22]*
    conj[Ye33] - 2*ml022*Ye22*Ye33*conj[Ye22]*conj[Ye33] - 
   2*ml032*Ye22*Ye33*conj[Ye22]*conj[Ye33] - 12*me032*Ye33^2*conj[Ye33]^2 - 
   12*mHd2*Ye33^2*conj[Ye33]^2 - 12*ml032*Ye33^2*conj[Ye33]^2 + 
   4*gp^2*mHu2*QHu^2*Yv33*conj[Yv33] + 4*gp^2*ml032*QHu^2*Yv33*conj[Yv33] + 
   4*gp^2*mvR032*QHu^2*Yv33*conj[Yv33] - 4*gp^2*mHu2*Ql3^2*Yv33*conj[Yv33] - 
   4*gp^2*ml032*Ql3^2*Yv33*conj[Yv33] - 4*gp^2*mvR032*Ql3^2*Yv33*conj[Yv33] + 
   4*gp^2*mHu2*Qv3^2*Yv33*conj[Yv33] + 4*gp^2*ml032*Qv3^2*Yv33*conj[Yv33] + 
   4*gp^2*mvR032*Qv3^2*Yv33*conj[Yv33] - 4*mHu2*Yv11*Yv33*conj[Yv11]*
    conj[Yv33] - 2*ml012*Yv11*Yv33*conj[Yv11]*conj[Yv33] - 
   2*ml032*Yv11*Yv33*conj[Yv11]*conj[Yv33] - 2*mvR012*Yv11*Yv33*conj[Yv11]*
    conj[Yv33] - 2*mvR032*Yv11*Yv33*conj[Yv11]*conj[Yv33] - 
   4*mHu2*Yv22*Yv33*conj[Yv22]*conj[Yv33] - 2*ml022*Yv22*Yv33*conj[Yv22]*
    conj[Yv33] - 2*ml032*Yv22*Yv33*conj[Yv22]*conj[Yv33] - 
   2*mvR022*Yv22*Yv33*conj[Yv22]*conj[Yv33] - 2*mvR032*Yv22*Yv33*conj[Yv22]*
    conj[Yv33] - 12*mHu2*Yv33^2*conj[Yv33]^2 - 12*ml032*Yv33^2*conj[Yv33]^2 - 
   12*mvR032*Yv33^2*conj[Yv33]^2 - 2*me032*Ye33*\[Lambda]*conj[Ye33]*
    conj[\[Lambda]] - 4*mHd2*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   2*mHu2*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   2*ml032*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   2*ms2*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   2*mHd2*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   4*mHu2*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   2*ml032*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   2*ms2*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   2*mvR032*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   (12*g1^2*MassB*Ye33*conj[T[Ye33]])/5 - 4*gp^2*MassU*Qe3^2*Ye33*
    conj[T[Ye33]] - 4*gp^2*MassU*QHd^2*Ye33*conj[T[Ye33]] + 
   4*gp^2*MassU*Ql3^2*Ye33*conj[T[Ye33]] - 4*gp^2*MassU*QHu^2*Yv33*
    conj[T[Yv33]] + 4*gp^2*MassU*Ql3^2*Yv33*conj[T[Yv33]] - 
   4*gp^2*MassU*Qv3^2*Yv33*conj[T[Yv33]] - 2*Ye33*conj[Ye33]*conj[T[Ye11]]*
    T[Ye11] - 2*Ye33*conj[Ye11]*conj[T[Ye33]]*T[Ye11] - 
   2*Ye33*conj[Ye33]*conj[T[Ye22]]*T[Ye22] - 2*Ye33*conj[Ye22]*conj[T[Ye33]]*
    T[Ye22] + (3*g1^2*conj[MassB]*(207*g1^2*MassB + 
      15*g2^2*(2*MassB + MassWB) - 20*gp^2*(2*MassB + MassU)*Ql3*
       (3*Qd + Qe1 + Qe2 + Qe3 - QHd + QHu - Ql1 - Ql2 - 2*Ql3 + 3*Qq - 
        6*Qu) + 20*conj[Ye33]*(2*MassB*Ye33 - T[Ye33])))/25 - 
   2*Ye11*conj[Ye33]*conj[T[Ye11]]*T[Ye33] - 2*Ye22*conj[Ye33]*conj[T[Ye22]]*
    T[Ye33] + (12*g1^2*conj[T[Ye33]]*T[Ye33])/5 + 
   4*gp^2*Qe3^2*conj[T[Ye33]]*T[Ye33] + 4*gp^2*QHd^2*conj[T[Ye33]]*T[Ye33] - 
   4*gp^2*Ql3^2*conj[T[Ye33]]*T[Ye33] - 2*Ye11*conj[Ye11]*conj[T[Ye33]]*
    T[Ye33] - 2*Ye22*conj[Ye22]*conj[T[Ye33]]*T[Ye33] - 
   24*Ye33*conj[Ye33]*conj[T[Ye33]]*T[Ye33] - 2*\[Lambda]*conj[\[Lambda]]*
    conj[T[Ye33]]*T[Ye33] - 2*\[Lambda]*conj[Ye33]*conj[T[\[Lambda]]]*
    T[Ye33] - 2*Yv33*conj[Yv33]*conj[T[Yv11]]*T[Yv11] - 
   2*Yv33*conj[Yv11]*conj[T[Yv33]]*T[Yv11] - 2*Yv33*conj[Yv33]*conj[T[Yv22]]*
    T[Yv22] - 2*Yv33*conj[Yv22]*conj[T[Yv33]]*T[Yv22] + 
   (4*gp^2*conj[MassU]*
     (3*Ql3*(-(g1^2*(MassB + 2*MassU)*(3*Qd + Qe1 + Qe2 + Qe3 - QHd + QHu - 
           Ql1 - Ql2 - 2*Ql3 + 3*Qq - 6*Qu)) + 
        5*Ql3*(g2^2*(2*MassU + MassWB) + 2*gp^2*MassU*(9*Qd^2 + Qe1^2 + 
            Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 4*Ql3^2 + 
            18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2))) + 
      5*(Qe3^2 + QHd^2 - Ql3^2)*conj[Ye33]*(2*MassU*Ye33 - T[Ye33]) + 
      5*(QHu^2 - Ql3^2 + Qv3^2)*conj[Yv33]*(2*MassU*Yv33 - T[Yv33])))/5 - 
   2*Yv11*conj[Yv33]*conj[T[Yv11]]*T[Yv33] - 2*Yv22*conj[Yv33]*conj[T[Yv22]]*
    T[Yv33] + 4*gp^2*QHu^2*conj[T[Yv33]]*T[Yv33] - 
   4*gp^2*Ql3^2*conj[T[Yv33]]*T[Yv33] + 4*gp^2*Qv3^2*conj[T[Yv33]]*T[Yv33] - 
   2*Yv11*conj[Yv11]*conj[T[Yv33]]*T[Yv33] - 2*Yv22*conj[Yv22]*conj[T[Yv33]]*
    T[Yv33] - 24*Yv33*conj[Yv33]*conj[T[Yv33]]*T[Yv33] - 
   2*\[Lambda]*conj[\[Lambda]]*conj[T[Yv33]]*T[Yv33] - 
   2*\[Lambda]*conj[Yv33]*conj[T[\[Lambda]]]*T[Yv33] - 
   2*Ye33*conj[\[Lambda]]*conj[T[Ye33]]*T[\[Lambda]] - 
   2*Yv33*conj[\[Lambda]]*conj[T[Yv33]]*T[\[Lambda]] - 
   2*Ye33*conj[Ye33]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   2*Yv33*conj[Yv33]*conj[T[\[Lambda]]]*T[\[Lambda]] + 6*g2^4*Tr2[2] + 
   (6*g1^2*Tr2U1[1, 1])/5 - 4*Sqrt[3/5]*g1*gp*Ql3*Tr2U1[1, 4] - 
   4*Sqrt[3/5]*g1*gp*Ql3*Tr2U1[4, 1] + 8*gp^2*Ql3^2*Tr2U1[4, 4] - 
   4*Sqrt[3/5]*g1*Tr3[1] + 8*gp*Ql3*Tr3[4] - 6*me032*Ye33*conj[Ye33]*
    trace[Yd, Adj[Yd]] - 12*mHd2*Ye33*conj[Ye33]*trace[Yd, Adj[Yd]] - 
   6*ml032*Ye33*conj[Ye33]*trace[Yd, Adj[Yd]] - 6*conj[T[Ye33]]*T[Ye33]*
    trace[Yd, Adj[Yd]] - 12*mHu2*Yv33*conj[Yv33]*trace[Yu, Adj[Yu]] - 
   6*ml032*Yv33*conj[Yv33]*trace[Yu, Adj[Yu]] - 6*mvR032*Yv33*conj[Yv33]*
    trace[Yu, Adj[Yu]] - 6*conj[T[Yv33]]*T[Yv33]*trace[Yu, Adj[Yu]] - 
   6*Ye33*conj[T[Ye33]]*trace[Adj[Yd], T[Yd]] - 
   6*Yv33*conj[T[Yv33]]*trace[Adj[Yu], T[Yu]] - 
   6*conj[Ye33]*T[Ye33]*trace[conj[T[Yd]], Tp[Yd]] - 
   6*Ye33*conj[Ye33]*trace[conj[T[Yd]], Tp[T[Yd]]] - 
   6*conj[Yv33]*T[Yv33]*trace[conj[T[Yu]], Tp[Yu]] - 
   6*Yv33*conj[Yv33]*trace[conj[T[Yu]], Tp[T[Yu]]] - 
   6*Ye33*conj[Ye33]*trace[md2, Yd, Adj[Yd]] - 
   6*Ye33*conj[Ye33]*trace[mq2, Adj[Yd], Yd] - 
   6*Yv33*conj[Yv33]*trace[mq2, Adj[Yu], Yu] - 
   6*Yv33*conj[Yv33]*trace[mu2, Yu, Adj[Yu]]}, 
 {mHd2, (-6*g1^2*MassB*conj[MassB])/5 - 8*gp^2*MassU*QHd^2*conj[MassU] - 
   6*g2^2*MassWB*conj[MassWB] + 2*me012*Ye11*conj[Ye11] + 
   2*mHd2*Ye11*conj[Ye11] + 2*ml012*Ye11*conj[Ye11] + 
   2*me022*Ye22*conj[Ye22] + 2*mHd2*Ye22*conj[Ye22] + 
   2*ml022*Ye22*conj[Ye22] + 2*me032*Ye33*conj[Ye33] + 
   2*mHd2*Ye33*conj[Ye33] + 2*ml032*Ye33*conj[Ye33] + 
   2*mHd2*\[Lambda]*conj[\[Lambda]] + 2*mHu2*\[Lambda]*conj[\[Lambda]] + 
   2*ms2*\[Lambda]*conj[\[Lambda]] + 2*conj[T[Ye11]]*T[Ye11] + 
   2*conj[T[Ye22]]*T[Ye22] + 2*conj[T[Ye33]]*T[Ye33] + 
   2*conj[T[\[Lambda]]]*T[\[Lambda]] - Sqrt[3/5]*g1*Tr1[1] + 
   2*gp*QHd*Tr1[4] + 6*mHd2*trace[Yd, Adj[Yd]] + 
   6*trace[conj[T[Yd]], Tp[T[Yd]]] + 6*trace[md2, Yd, Adj[Yd]] + 
   6*trace[mq2, Adj[Yd], Yd], (9*g1^2*g2^2*MassB*conj[MassWB])/5 + 
   (18*g1^2*g2^2*MassWB*conj[MassWB])/5 + 33*g2^4*MassWB*conj[MassWB] + 
   12*g2^2*gp^2*MassU*QHd^2*conj[MassWB] + 24*g2^2*gp^2*MassWB*QHd^2*
    conj[MassWB] + (12*g1^2*me012*Ye11*conj[Ye11])/5 + 
   (12*g1^2*mHd2*Ye11*conj[Ye11])/5 + (12*g1^2*ml012*Ye11*conj[Ye11])/5 + 
   4*gp^2*me012*Qe1^2*Ye11*conj[Ye11] + 4*gp^2*mHd2*Qe1^2*Ye11*conj[Ye11] + 
   4*gp^2*ml012*Qe1^2*Ye11*conj[Ye11] - 4*gp^2*me012*QHd^2*Ye11*conj[Ye11] - 
   4*gp^2*mHd2*QHd^2*Ye11*conj[Ye11] - 4*gp^2*ml012*QHd^2*Ye11*conj[Ye11] + 
   4*gp^2*me012*Ql1^2*Ye11*conj[Ye11] + 4*gp^2*mHd2*Ql1^2*Ye11*conj[Ye11] + 
   4*gp^2*ml012*Ql1^2*Ye11*conj[Ye11] - 12*me012*Ye11^2*conj[Ye11]^2 - 
   12*mHd2*Ye11^2*conj[Ye11]^2 - 12*ml012*Ye11^2*conj[Ye11]^2 + 
   (12*g1^2*me022*Ye22*conj[Ye22])/5 + (12*g1^2*mHd2*Ye22*conj[Ye22])/5 + 
   (12*g1^2*ml022*Ye22*conj[Ye22])/5 + 4*gp^2*me022*Qe2^2*Ye22*conj[Ye22] + 
   4*gp^2*mHd2*Qe2^2*Ye22*conj[Ye22] + 4*gp^2*ml022*Qe2^2*Ye22*conj[Ye22] - 
   4*gp^2*me022*QHd^2*Ye22*conj[Ye22] - 4*gp^2*mHd2*QHd^2*Ye22*conj[Ye22] - 
   4*gp^2*ml022*QHd^2*Ye22*conj[Ye22] + 4*gp^2*me022*Ql2^2*Ye22*conj[Ye22] + 
   4*gp^2*mHd2*Ql2^2*Ye22*conj[Ye22] + 4*gp^2*ml022*Ql2^2*Ye22*conj[Ye22] - 
   12*me022*Ye22^2*conj[Ye22]^2 - 12*mHd2*Ye22^2*conj[Ye22]^2 - 
   12*ml022*Ye22^2*conj[Ye22]^2 + (12*g1^2*me032*Ye33*conj[Ye33])/5 + 
   (12*g1^2*mHd2*Ye33*conj[Ye33])/5 + (12*g1^2*ml032*Ye33*conj[Ye33])/5 + 
   4*gp^2*me032*Qe3^2*Ye33*conj[Ye33] + 4*gp^2*mHd2*Qe3^2*Ye33*conj[Ye33] + 
   4*gp^2*ml032*Qe3^2*Ye33*conj[Ye33] - 4*gp^2*me032*QHd^2*Ye33*conj[Ye33] - 
   4*gp^2*mHd2*QHd^2*Ye33*conj[Ye33] - 4*gp^2*ml032*QHd^2*Ye33*conj[Ye33] + 
   4*gp^2*me032*Ql3^2*Ye33*conj[Ye33] + 4*gp^2*mHd2*Ql3^2*Ye33*conj[Ye33] + 
   4*gp^2*ml032*Ql3^2*Ye33*conj[Ye33] - 12*me032*Ye33^2*conj[Ye33]^2 - 
   12*mHd2*Ye33^2*conj[Ye33]^2 - 12*ml032*Ye33^2*conj[Ye33]^2 - 
   2*me012*Ye11*Yv11*conj[Ye11]*conj[Yv11] - 2*mHd2*Ye11*Yv11*conj[Ye11]*
    conj[Yv11] - 2*mHu2*Ye11*Yv11*conj[Ye11]*conj[Yv11] - 
   4*ml012*Ye11*Yv11*conj[Ye11]*conj[Yv11] - 2*mvR012*Ye11*Yv11*conj[Ye11]*
    conj[Yv11] - 2*me022*Ye22*Yv22*conj[Ye22]*conj[Yv22] - 
   2*mHd2*Ye22*Yv22*conj[Ye22]*conj[Yv22] - 2*mHu2*Ye22*Yv22*conj[Ye22]*
    conj[Yv22] - 4*ml022*Ye22*Yv22*conj[Ye22]*conj[Yv22] - 
   2*mvR022*Ye22*Yv22*conj[Ye22]*conj[Yv22] - 2*me032*Ye33*Yv33*conj[Ye33]*
    conj[Yv33] - 2*mHd2*Ye33*Yv33*conj[Ye33]*conj[Yv33] - 
   2*mHu2*Ye33*Yv33*conj[Ye33]*conj[Yv33] - 4*ml032*Ye33*Yv33*conj[Ye33]*
    conj[Yv33] - 2*mvR032*Ye33*Yv33*conj[Ye33]*conj[Yv33] - 
   4*gp^2*mHd2*QHd^2*\[Lambda]*conj[\[Lambda]] - 4*gp^2*mHu2*QHd^2*\[Lambda]*
    conj[\[Lambda]] - 4*gp^2*ms2*QHd^2*\[Lambda]*conj[\[Lambda]] + 
   4*gp^2*mHd2*QHu^2*\[Lambda]*conj[\[Lambda]] + 4*gp^2*mHu2*QHu^2*\[Lambda]*
    conj[\[Lambda]] + 4*gp^2*ms2*QHu^2*\[Lambda]*conj[\[Lambda]] + 
   4*gp^2*mHd2*Qs^2*\[Lambda]*conj[\[Lambda]] + 4*gp^2*mHu2*Qs^2*\[Lambda]*
    conj[\[Lambda]] + 4*gp^2*ms2*Qs^2*\[Lambda]*conj[\[Lambda]] - 
   2*mHd2*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   4*mHu2*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   2*ml012*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   2*ms2*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   2*mvR012*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]] - 
   2*mHd2*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   4*mHu2*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   2*ml022*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   2*ms2*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   2*mvR022*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]] - 
   2*mHd2*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   4*mHu2*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   2*ml032*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   2*ms2*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   2*mvR032*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]] - 
   12*mHd2*\[Lambda]^2*conj[\[Lambda]]^2 - 12*mHu2*\[Lambda]^2*
    conj[\[Lambda]]^2 - 12*ms2*\[Lambda]^2*conj[\[Lambda]]^2 - 
   (12*g1^2*MassB*Ye11*conj[T[Ye11]])/5 - 4*gp^2*MassU*Qe1^2*Ye11*
    conj[T[Ye11]] + 4*gp^2*MassU*QHd^2*Ye11*conj[T[Ye11]] - 
   4*gp^2*MassU*Ql1^2*Ye11*conj[T[Ye11]] - (12*g1^2*MassB*Ye22*conj[T[Ye22]])/
    5 - 4*gp^2*MassU*Qe2^2*Ye22*conj[T[Ye22]] + 4*gp^2*MassU*QHd^2*Ye22*
    conj[T[Ye22]] - 4*gp^2*MassU*Ql2^2*Ye22*conj[T[Ye22]] - 
   (12*g1^2*MassB*Ye33*conj[T[Ye33]])/5 - 4*gp^2*MassU*Qe3^2*Ye33*
    conj[T[Ye33]] + 4*gp^2*MassU*QHd^2*Ye33*conj[T[Ye33]] - 
   4*gp^2*MassU*Ql3^2*Ye33*conj[T[Ye33]] + 4*gp^2*MassU*QHd^2*\[Lambda]*
    conj[T[\[Lambda]]] - 4*gp^2*MassU*QHu^2*\[Lambda]*conj[T[\[Lambda]]] - 
   4*gp^2*MassU*Qs^2*\[Lambda]*conj[T[\[Lambda]]] + 
   (12*g1^2*conj[T[Ye11]]*T[Ye11])/5 + 4*gp^2*Qe1^2*conj[T[Ye11]]*T[Ye11] - 
   4*gp^2*QHd^2*conj[T[Ye11]]*T[Ye11] + 4*gp^2*Ql1^2*conj[T[Ye11]]*T[Ye11] - 
   24*Ye11*conj[Ye11]*conj[T[Ye11]]*T[Ye11] - 2*Yv11*conj[Yv11]*conj[T[Ye11]]*
    T[Ye11] - 2*Yv11*conj[Ye11]*conj[T[Yv11]]*T[Ye11] + 
   (12*g1^2*conj[T[Ye22]]*T[Ye22])/5 + 4*gp^2*Qe2^2*conj[T[Ye22]]*T[Ye22] - 
   4*gp^2*QHd^2*conj[T[Ye22]]*T[Ye22] + 4*gp^2*Ql2^2*conj[T[Ye22]]*T[Ye22] - 
   24*Ye22*conj[Ye22]*conj[T[Ye22]]*T[Ye22] - 2*Yv22*conj[Yv22]*conj[T[Ye22]]*
    T[Ye22] - 2*Yv22*conj[Ye22]*conj[T[Yv22]]*T[Ye22] + 
   (12*g1^2*conj[T[Ye33]]*T[Ye33])/5 + 4*gp^2*Qe3^2*conj[T[Ye33]]*T[Ye33] - 
   4*gp^2*QHd^2*conj[T[Ye33]]*T[Ye33] + 4*gp^2*Ql3^2*conj[T[Ye33]]*T[Ye33] - 
   24*Ye33*conj[Ye33]*conj[T[Ye33]]*T[Ye33] - 2*Yv33*conj[Yv33]*conj[T[Ye33]]*
    T[Ye33] - 2*Yv33*conj[Ye33]*conj[T[Yv33]]*T[Ye33] - 
   2*Ye11*conj[Yv11]*conj[T[Ye11]]*T[Yv11] - 2*Ye11*conj[Ye11]*conj[T[Yv11]]*
    T[Yv11] - 2*\[Lambda]*conj[\[Lambda]]*conj[T[Yv11]]*T[Yv11] - 
   2*\[Lambda]*conj[Yv11]*conj[T[\[Lambda]]]*T[Yv11] - 
   2*Ye22*conj[Yv22]*conj[T[Ye22]]*T[Yv22] - 2*Ye22*conj[Ye22]*conj[T[Yv22]]*
    T[Yv22] - 2*\[Lambda]*conj[\[Lambda]]*conj[T[Yv22]]*T[Yv22] - 
   2*\[Lambda]*conj[Yv22]*conj[T[\[Lambda]]]*T[Yv22] - 
   2*Ye33*conj[Yv33]*conj[T[Ye33]]*T[Yv33] - 2*Ye33*conj[Ye33]*conj[T[Yv33]]*
    T[Yv33] - 2*\[Lambda]*conj[\[Lambda]]*conj[T[Yv33]]*T[Yv33] - 
   2*\[Lambda]*conj[Yv33]*conj[T[\[Lambda]]]*T[Yv33] - 
   2*Yv11*conj[\[Lambda]]*conj[T[Yv11]]*T[\[Lambda]] - 
   2*Yv22*conj[\[Lambda]]*conj[T[Yv22]]*T[\[Lambda]] - 
   2*Yv33*conj[\[Lambda]]*conj[T[Yv33]]*T[\[Lambda]] - 
   4*gp^2*QHd^2*conj[T[\[Lambda]]]*T[\[Lambda]] + 
   4*gp^2*QHu^2*conj[T[\[Lambda]]]*T[\[Lambda]] + 
   4*gp^2*Qs^2*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   2*Yv11*conj[Yv11]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   2*Yv22*conj[Yv22]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   2*Yv33*conj[Yv33]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   24*\[Lambda]*conj[\[Lambda]]*conj[T[\[Lambda]]]*T[\[Lambda]] + 
   6*g2^4*Tr2[2] + (6*g1^2*Tr2U1[1, 1])/5 - 4*Sqrt[3/5]*g1*gp*QHd*
    Tr2U1[1, 4] - 4*Sqrt[3/5]*g1*gp*QHd*Tr2U1[4, 1] + 
   8*gp^2*QHd^2*Tr2U1[4, 4] - 4*Sqrt[3/5]*g1*Tr3[1] + 8*gp*QHd*Tr3[4] - 
   (4*g1^2*mHd2*trace[Yd, Adj[Yd]])/5 + 32*g3^2*mHd2*trace[Yd, Adj[Yd]] + 
   12*gp^2*mHd2*Qd^2*trace[Yd, Adj[Yd]] - 12*gp^2*mHd2*QHd^2*
    trace[Yd, Adj[Yd]] + 12*gp^2*mHd2*Qq^2*trace[Yd, Adj[Yd]] + 
   64*g3^2*MassG*conj[MassG]*trace[Yd, Adj[Yd]] - 
   6*mHd2*\[Lambda]*conj[\[Lambda]]*trace[Yu, Adj[Yu]] - 
   12*mHu2*\[Lambda]*conj[\[Lambda]]*trace[Yu, Adj[Yu]] - 
   6*ms2*\[Lambda]*conj[\[Lambda]]*trace[Yu, Adj[Yu]] - 
   6*conj[T[\[Lambda]]]*T[\[Lambda]]*trace[Yu, Adj[Yu]] - 
   32*g3^2*conj[MassG]*trace[Adj[Yd], T[Yd]] + 
   (g1^2*conj[MassB]*(621*g1^2*MassB + 90*g2^2*MassB + 45*g2^2*MassWB - 
      360*gp^2*MassB*Qd*QHd - 180*gp^2*MassU*Qd*QHd - 
      120*gp^2*MassB*Qe1*QHd - 60*gp^2*MassU*Qe1*QHd - 
      120*gp^2*MassB*Qe2*QHd - 60*gp^2*MassU*Qe2*QHd - 
      120*gp^2*MassB*Qe3*QHd - 60*gp^2*MassU*Qe3*QHd + 240*gp^2*MassB*QHd^2 + 
      120*gp^2*MassU*QHd^2 - 120*gp^2*MassB*QHd*QHu - 60*gp^2*MassU*QHd*QHu + 
      120*gp^2*MassB*QHd*Ql1 + 60*gp^2*MassU*QHd*Ql1 + 
      120*gp^2*MassB*QHd*Ql2 + 60*gp^2*MassU*QHd*Ql2 + 
      120*gp^2*MassB*QHd*Ql3 + 60*gp^2*MassU*QHd*Ql3 - 
      360*gp^2*MassB*QHd*Qq - 180*gp^2*MassU*QHd*Qq + 720*gp^2*MassB*QHd*Qu + 
      360*gp^2*MassU*QHd*Qu + 120*MassB*Ye33*conj[Ye33] + 
      60*conj[Ye11]*(2*MassB*Ye11 - T[Ye11]) + 60*conj[Ye22]*
       (2*MassB*Ye22 - T[Ye22]) - 60*conj[Ye33]*T[Ye33] - 
      40*MassB*trace[Yd, Adj[Yd]] + 20*trace[Adj[Yd], T[Yd]]))/25 + 
   (4*gp^2*conj[MassU]*(-9*g1^2*MassB*Qd*QHd - 18*g1^2*MassU*Qd*QHd - 
      3*g1^2*MassB*Qe1*QHd - 6*g1^2*MassU*Qe1*QHd - 3*g1^2*MassB*Qe2*QHd - 
      6*g1^2*MassU*Qe2*QHd - 3*g1^2*MassB*Qe3*QHd - 6*g1^2*MassU*Qe3*QHd + 
      6*g1^2*MassB*QHd^2 + 12*g1^2*MassU*QHd^2 + 30*g2^2*MassU*QHd^2 + 
      15*g2^2*MassWB*QHd^2 + 270*gp^2*MassU*Qd^2*QHd^2 + 
      30*gp^2*MassU*Qe1^2*QHd^2 + 30*gp^2*MassU*Qe2^2*QHd^2 + 
      30*gp^2*MassU*Qe3^2*QHd^2 + 120*gp^2*MassU*QHd^4 - 
      3*g1^2*MassB*QHd*QHu - 6*g1^2*MassU*QHd*QHu + 60*gp^2*MassU*QHd^2*
       QHu^2 + 3*g1^2*MassB*QHd*Ql1 + 6*g1^2*MassU*QHd*Ql1 + 
      60*gp^2*MassU*QHd^2*Ql1^2 + 3*g1^2*MassB*QHd*Ql2 + 
      6*g1^2*MassU*QHd*Ql2 + 60*gp^2*MassU*QHd^2*Ql2^2 + 
      3*g1^2*MassB*QHd*Ql3 + 6*g1^2*MassU*QHd*Ql3 + 60*gp^2*MassU*QHd^2*
       Ql3^2 - 9*g1^2*MassB*QHd*Qq - 18*g1^2*MassU*QHd*Qq + 
      540*gp^2*MassU*QHd^2*Qq^2 + 30*gp^2*MassU*QHd^2*Qs^2 + 
      18*g1^2*MassB*QHd*Qu + 36*g1^2*MassU*QHd*Qu + 270*gp^2*MassU*QHd^2*
       Qu^2 + 30*gp^2*MassU*QHd^2*Qv1^2 + 30*gp^2*MassU*QHd^2*Qv2^2 + 
      30*gp^2*MassU*QHd^2*Qv3^2 + 10*MassU*Qe3^2*Ye33*conj[Ye33] - 
      10*MassU*QHd^2*Ye33*conj[Ye33] + 10*MassU*Ql3^2*Ye33*conj[Ye33] - 
      10*MassU*QHd^2*\[Lambda]*conj[\[Lambda]] + 10*MassU*QHu^2*\[Lambda]*
       conj[\[Lambda]] + 10*MassU*Qs^2*\[Lambda]*conj[\[Lambda]] + 
      5*(Qe1^2 - QHd^2 + Ql1^2)*conj[Ye11]*(2*MassU*Ye11 - T[Ye11]) + 
      5*(Qe2^2 - QHd^2 + Ql2^2)*conj[Ye22]*(2*MassU*Ye22 - T[Ye22]) - 
      5*Qe3^2*conj[Ye33]*T[Ye33] + 5*QHd^2*conj[Ye33]*T[Ye33] - 
      5*Ql3^2*conj[Ye33]*T[Ye33] + 5*QHd^2*conj[\[Lambda]]*T[\[Lambda]] - 
      5*QHu^2*conj[\[Lambda]]*T[\[Lambda]] - 5*Qs^2*conj[\[Lambda]]*
       T[\[Lambda]] + 30*MassU*Qd^2*trace[Yd, Adj[Yd]] - 
      30*MassU*QHd^2*trace[Yd, Adj[Yd]] + 30*MassU*Qq^2*trace[Yd, Adj[Yd]] - 
      15*Qd^2*trace[Adj[Yd], T[Yd]] + 15*QHd^2*trace[Adj[Yd], T[Yd]] - 
      15*Qq^2*trace[Adj[Yd], T[Yd]]))/5 - 6*\[Lambda]*conj[T[\[Lambda]]]*
    trace[Adj[Yu], T[Yu]] + (4*g1^2*MassB*trace[conj[T[Yd]], Tp[Yd]])/5 - 
   32*g3^2*MassG*trace[conj[T[Yd]], Tp[Yd]] - 12*gp^2*MassU*Qd^2*
    trace[conj[T[Yd]], Tp[Yd]] + 12*gp^2*MassU*QHd^2*
    trace[conj[T[Yd]], Tp[Yd]] - 12*gp^2*MassU*Qq^2*
    trace[conj[T[Yd]], Tp[Yd]] - (4*g1^2*trace[conj[T[Yd]], Tp[T[Yd]]])/5 + 
   32*g3^2*trace[conj[T[Yd]], Tp[T[Yd]]] + 
   12*gp^2*Qd^2*trace[conj[T[Yd]], Tp[T[Yd]]] - 
   12*gp^2*QHd^2*trace[conj[T[Yd]], Tp[T[Yd]]] + 
   12*gp^2*Qq^2*trace[conj[T[Yd]], Tp[T[Yd]]] - 
   6*conj[\[Lambda]]*T[\[Lambda]]*trace[conj[T[Yu]], Tp[Yu]] - 
   6*\[Lambda]*conj[\[Lambda]]*trace[conj[T[Yu]], Tp[T[Yu]]] - 
   (4*g1^2*trace[md2, Yd, Adj[Yd]])/5 + 32*g3^2*trace[md2, Yd, Adj[Yd]] + 
   12*gp^2*Qd^2*trace[md2, Yd, Adj[Yd]] - 
   12*gp^2*QHd^2*trace[md2, Yd, Adj[Yd]] + 
   12*gp^2*Qq^2*trace[md2, Yd, Adj[Yd]] - (4*g1^2*trace[mq2, Adj[Yd], Yd])/
    5 + 32*g3^2*trace[mq2, Adj[Yd], Yd] + 
   12*gp^2*Qd^2*trace[mq2, Adj[Yd], Yd] - 
   12*gp^2*QHd^2*trace[mq2, Adj[Yd], Yd] + 
   12*gp^2*Qq^2*trace[mq2, Adj[Yd], Yd] - 6*\[Lambda]*conj[\[Lambda]]*
    trace[mq2, Adj[Yu], Yu] - 6*\[Lambda]*conj[\[Lambda]]*
    trace[mu2, Yu, Adj[Yu]] - 36*mHd2*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 
   36*trace[Yd, Adj[Yd], T[Yd], Adj[T[Yd]]] - 
   6*mHd2*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   6*mHu2*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   6*trace[Yd, Adj[Yu], T[Yu], Adj[T[Yd]]] - 
   36*trace[Yd, Adj[T[Yd]], T[Yd], Adj[Yd]] - 
   6*trace[Yd, Adj[T[Yu]], T[Yu], Adj[Yd]] - 
   6*trace[Yu, Adj[Yd], T[Yd], Adj[T[Yu]]] - 
   6*trace[Yu, Adj[T[Yd]], T[Yd], Adj[Yu]] - 
   36*trace[md2, Yd, Adj[Yd], Yd, Adj[Yd]] - 
   6*trace[md2, Yd, Adj[Yu], Yu, Adj[Yd]] - 
   36*trace[mq2, Adj[Yd], Yd, Adj[Yd], Yd] - 
   6*trace[mq2, Adj[Yd], Yd, Adj[Yu], Yu] - 
   6*trace[mq2, Adj[Yu], Yu, Adj[Yd], Yd] - 
   6*trace[mu2, Yu, Adj[Yd], Yd, Adj[Yu]]}, 
 {mHu2, (-6*g1^2*MassB*conj[MassB])/5 - 8*gp^2*MassU*QHu^2*conj[MassU] - 
   6*g2^2*MassWB*conj[MassWB] + 2*Tep*conj[Tep] + 2*Tmup*conj[Tmup] + 
   2*mHu2*Yv11*conj[Yv11] + 2*ml012*Yv11*conj[Yv11] + 
   2*mvR012*Yv11*conj[Yv11] + 2*mHu2*Yv22*conj[Yv22] + 
   2*ml022*Yv22*conj[Yv22] + 2*mvR022*Yv22*conj[Yv22] + 
   2*mHu2*Yv33*conj[Yv33] + 2*ml032*Yv33*conj[Yv33] + 
   2*mvR032*Yv33*conj[Yv33] + 2*mHd2*\[Lambda]*conj[\[Lambda]] + 
   2*mHu2*\[Lambda]*conj[\[Lambda]] + 2*ms2*\[Lambda]*conj[\[Lambda]] + 
   2*conj[T[Yv11]]*T[Yv11] + 2*conj[T[Yv22]]*T[Yv22] + 
   2*conj[T[Yv33]]*T[Yv33] + 2*conj[T[\[Lambda]]]*T[\[Lambda]] + 
   Sqrt[3/5]*g1*Tr1[1] + 2*gp*QHu*Tr1[4] + 6*mHu2*trace[Yu, Adj[Yu]] + 
   6*trace[conj[T[Yu]], Tp[T[Yu]]] + 6*trace[mq2, Adj[Yu], Yu] + 
   6*trace[mu2, Yu, Adj[Yu]], (9*g1^2*g2^2*MassB*conj[MassWB])/5 + 
   (18*g1^2*g2^2*MassWB*conj[MassWB])/5 + 33*g2^4*MassWB*conj[MassWB] + 
   12*g2^2*gp^2*MassU*QHu^2*conj[MassWB] + 24*g2^2*gp^2*MassWB*QHu^2*
    conj[MassWB] - 4*gp^2*mHu2*QHu^2*Yv11*conj[Yv11] - 
   4*gp^2*ml012*QHu^2*Yv11*conj[Yv11] - 4*gp^2*mvR012*QHu^2*Yv11*conj[Yv11] + 
   4*gp^2*mHu2*Ql1^2*Yv11*conj[Yv11] + 4*gp^2*ml012*Ql1^2*Yv11*conj[Yv11] + 
   4*gp^2*mvR012*Ql1^2*Yv11*conj[Yv11] + 4*gp^2*mHu2*Qv1^2*Yv11*conj[Yv11] + 
   4*gp^2*ml012*Qv1^2*Yv11*conj[Yv11] + 4*gp^2*mvR012*Qv1^2*Yv11*conj[Yv11] - 
   2*me012*Ye11*Yv11*conj[Ye11]*conj[Yv11] - 2*mHd2*Ye11*Yv11*conj[Ye11]*
    conj[Yv11] - 2*mHu2*Ye11*Yv11*conj[Ye11]*conj[Yv11] - 
   4*ml012*Ye11*Yv11*conj[Ye11]*conj[Yv11] - 2*mvR012*Ye11*Yv11*conj[Ye11]*
    conj[Yv11] - 12*mHu2*Yv11^2*conj[Yv11]^2 - 12*ml012*Yv11^2*conj[Yv11]^2 - 
   12*mvR012*Yv11^2*conj[Yv11]^2 - 4*gp^2*mHu2*QHu^2*Yv22*conj[Yv22] - 
   4*gp^2*ml022*QHu^2*Yv22*conj[Yv22] - 4*gp^2*mvR022*QHu^2*Yv22*conj[Yv22] + 
   4*gp^2*mHu2*Ql2^2*Yv22*conj[Yv22] + 4*gp^2*ml022*Ql2^2*Yv22*conj[Yv22] + 
   4*gp^2*mvR022*Ql2^2*Yv22*conj[Yv22] + 4*gp^2*mHu2*Qv2^2*Yv22*conj[Yv22] + 
   4*gp^2*ml022*Qv2^2*Yv22*conj[Yv22] + 4*gp^2*mvR022*Qv2^2*Yv22*conj[Yv22] - 
   2*me022*Ye22*Yv22*conj[Ye22]*conj[Yv22] - 2*mHd2*Ye22*Yv22*conj[Ye22]*
    conj[Yv22] - 2*mHu2*Ye22*Yv22*conj[Ye22]*conj[Yv22] - 
   4*ml022*Ye22*Yv22*conj[Ye22]*conj[Yv22] - 2*mvR022*Ye22*Yv22*conj[Ye22]*
    conj[Yv22] - 12*mHu2*Yv22^2*conj[Yv22]^2 - 12*ml022*Yv22^2*conj[Yv22]^2 - 
   12*mvR022*Yv22^2*conj[Yv22]^2 - 4*gp^2*mHu2*QHu^2*Yv33*conj[Yv33] - 
   4*gp^2*ml032*QHu^2*Yv33*conj[Yv33] - 4*gp^2*mvR032*QHu^2*Yv33*conj[Yv33] + 
   4*gp^2*mHu2*Ql3^2*Yv33*conj[Yv33] + 4*gp^2*ml032*Ql3^2*Yv33*conj[Yv33] + 
   4*gp^2*mvR032*Ql3^2*Yv33*conj[Yv33] + 4*gp^2*mHu2*Qv3^2*Yv33*conj[Yv33] + 
   4*gp^2*ml032*Qv3^2*Yv33*conj[Yv33] + 4*gp^2*mvR032*Qv3^2*Yv33*conj[Yv33] - 
   2*me032*Ye33*Yv33*conj[Ye33]*conj[Yv33] - 2*mHd2*Ye33*Yv33*conj[Ye33]*
    conj[Yv33] - 2*mHu2*Ye33*Yv33*conj[Ye33]*conj[Yv33] - 
   4*ml032*Ye33*Yv33*conj[Ye33]*conj[Yv33] - 2*mvR032*Ye33*Yv33*conj[Ye33]*
    conj[Yv33] - 12*mHu2*Yv33^2*conj[Yv33]^2 - 12*ml032*Yv33^2*conj[Yv33]^2 - 
   12*mvR032*Yv33^2*conj[Yv33]^2 + 4*gp^2*mHd2*QHd^2*\[Lambda]*
    conj[\[Lambda]] + 4*gp^2*mHu2*QHd^2*\[Lambda]*conj[\[Lambda]] + 
   4*gp^2*ms2*QHd^2*\[Lambda]*conj[\[Lambda]] - 4*gp^2*mHd2*QHu^2*\[Lambda]*
    conj[\[Lambda]] - 4*gp^2*mHu2*QHu^2*\[Lambda]*conj[\[Lambda]] - 
   4*gp^2*ms2*QHu^2*\[Lambda]*conj[\[Lambda]] + 4*gp^2*mHd2*Qs^2*\[Lambda]*
    conj[\[Lambda]] + 4*gp^2*mHu2*Qs^2*\[Lambda]*conj[\[Lambda]] + 
   4*gp^2*ms2*Qs^2*\[Lambda]*conj[\[Lambda]] - 2*me012*Ye11*\[Lambda]*
    conj[Ye11]*conj[\[Lambda]] - 4*mHd2*Ye11*\[Lambda]*conj[Ye11]*
    conj[\[Lambda]] - 2*mHu2*Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - 
   2*ml012*Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - 
   2*ms2*Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]] - 
   2*me022*Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   4*mHd2*Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   2*mHu2*Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   2*ml022*Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   2*ms2*Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]] - 
   2*me032*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   4*mHd2*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   2*mHu2*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   2*ml032*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   2*ms2*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]] - 
   12*mHd2*\[Lambda]^2*conj[\[Lambda]]^2 - 12*mHu2*\[Lambda]^2*
    conj[\[Lambda]]^2 - 12*ms2*\[Lambda]^2*conj[\[Lambda]]^2 + 
   4*gp^2*MassU*QHu^2*Yv11*conj[T[Yv11]] - 4*gp^2*MassU*Ql1^2*Yv11*
    conj[T[Yv11]] - 4*gp^2*MassU*Qv1^2*Yv11*conj[T[Yv11]] + 
   4*gp^2*MassU*QHu^2*Yv22*conj[T[Yv22]] - 4*gp^2*MassU*Ql2^2*Yv22*
    conj[T[Yv22]] - 4*gp^2*MassU*Qv2^2*Yv22*conj[T[Yv22]] + 
   4*gp^2*MassU*QHu^2*Yv33*conj[T[Yv33]] - 4*gp^2*MassU*Ql3^2*Yv33*
    conj[T[Yv33]] - 4*gp^2*MassU*Qv3^2*Yv33*conj[T[Yv33]] - 
   4*gp^2*MassU*QHd^2*\[Lambda]*conj[T[\[Lambda]]] + 
   4*gp^2*MassU*QHu^2*\[Lambda]*conj[T[\[Lambda]]] - 
   4*gp^2*MassU*Qs^2*\[Lambda]*conj[T[\[Lambda]]] - 
   2*Yv11*conj[Yv11]*conj[T[Ye11]]*T[Ye11] - 2*\[Lambda]*conj[\[Lambda]]*
    conj[T[Ye11]]*T[Ye11] - 2*Yv11*conj[Ye11]*conj[T[Yv11]]*T[Ye11] - 
   2*\[Lambda]*conj[Ye11]*conj[T[\[Lambda]]]*T[Ye11] - 
   2*Yv22*conj[Yv22]*conj[T[Ye22]]*T[Ye22] - 2*\[Lambda]*conj[\[Lambda]]*
    conj[T[Ye22]]*T[Ye22] - 2*Yv22*conj[Ye22]*conj[T[Yv22]]*T[Ye22] - 
   2*\[Lambda]*conj[Ye22]*conj[T[\[Lambda]]]*T[Ye22] - 
   2*Yv33*conj[Yv33]*conj[T[Ye33]]*T[Ye33] - 2*\[Lambda]*conj[\[Lambda]]*
    conj[T[Ye33]]*T[Ye33] - 2*Yv33*conj[Ye33]*conj[T[Yv33]]*T[Ye33] - 
   2*\[Lambda]*conj[Ye33]*conj[T[\[Lambda]]]*T[Ye33] - 
   2*Ye11*conj[Yv11]*conj[T[Ye11]]*T[Yv11] - 4*gp^2*QHu^2*conj[T[Yv11]]*
    T[Yv11] + 4*gp^2*Ql1^2*conj[T[Yv11]]*T[Yv11] + 
   4*gp^2*Qv1^2*conj[T[Yv11]]*T[Yv11] - 2*Ye11*conj[Ye11]*conj[T[Yv11]]*
    T[Yv11] - 24*Yv11*conj[Yv11]*conj[T[Yv11]]*T[Yv11] - 
   2*Ye22*conj[Yv22]*conj[T[Ye22]]*T[Yv22] - 4*gp^2*QHu^2*conj[T[Yv22]]*
    T[Yv22] + 4*gp^2*Ql2^2*conj[T[Yv22]]*T[Yv22] + 
   4*gp^2*Qv2^2*conj[T[Yv22]]*T[Yv22] - 2*Ye22*conj[Ye22]*conj[T[Yv22]]*
    T[Yv22] - 24*Yv22*conj[Yv22]*conj[T[Yv22]]*T[Yv22] - 
   2*Ye33*conj[Yv33]*conj[T[Ye33]]*T[Yv33] - 4*gp^2*QHu^2*conj[T[Yv33]]*
    T[Yv33] + 4*gp^2*Ql3^2*conj[T[Yv33]]*T[Yv33] + 
   4*gp^2*Qv3^2*conj[T[Yv33]]*T[Yv33] - 2*Ye33*conj[Ye33]*conj[T[Yv33]]*
    T[Yv33] - 24*Yv33*conj[Yv33]*conj[T[Yv33]]*T[Yv33] - 
   2*Ye11*conj[\[Lambda]]*conj[T[Ye11]]*T[\[Lambda]] - 
   2*Ye22*conj[\[Lambda]]*conj[T[Ye22]]*T[\[Lambda]] - 
   2*Ye33*conj[\[Lambda]]*conj[T[Ye33]]*T[\[Lambda]] + 
   4*gp^2*QHd^2*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   4*gp^2*QHu^2*conj[T[\[Lambda]]]*T[\[Lambda]] + 
   4*gp^2*Qs^2*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   2*Ye11*conj[Ye11]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   2*Ye22*conj[Ye22]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   2*Ye33*conj[Ye33]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
   24*\[Lambda]*conj[\[Lambda]]*conj[T[\[Lambda]]]*T[\[Lambda]] + 
   6*g2^4*Tr2[2] + (6*g1^2*Tr2U1[1, 1])/5 + 4*Sqrt[3/5]*g1*gp*QHu*
    Tr2U1[1, 4] + 4*Sqrt[3/5]*g1*gp*QHu*Tr2U1[4, 1] + 
   8*gp^2*QHu^2*Tr2U1[4, 4] + 4*Sqrt[3/5]*g1*Tr3[1] + 8*gp*QHu*Tr3[4] - 
   12*mHd2*\[Lambda]*conj[\[Lambda]]*trace[Yd, Adj[Yd]] - 
   6*mHu2*\[Lambda]*conj[\[Lambda]]*trace[Yd, Adj[Yd]] - 
   6*ms2*\[Lambda]*conj[\[Lambda]]*trace[Yd, Adj[Yd]] - 
   6*conj[T[\[Lambda]]]*T[\[Lambda]]*trace[Yd, Adj[Yd]] + 
   (8*g1^2*mHu2*trace[Yu, Adj[Yu]])/5 + 32*g3^2*mHu2*trace[Yu, Adj[Yu]] - 
   12*gp^2*mHu2*QHu^2*trace[Yu, Adj[Yu]] + 12*gp^2*mHu2*Qq^2*
    trace[Yu, Adj[Yu]] + 12*gp^2*mHu2*Qu^2*trace[Yu, Adj[Yu]] + 
   64*g3^2*MassG*conj[MassG]*trace[Yu, Adj[Yu]] - 
   6*\[Lambda]*conj[T[\[Lambda]]]*trace[Adj[Yd], T[Yd]] + 
   (g1^2*conj[MassB]*(621*g1^2*MassB + 45*g2^2*(2*MassB + MassWB) + 
      60*gp^2*(2*MassB + MassU)*QHu*(3*Qd + Qe1 + Qe2 + Qe3 - QHd + 2*QHu - 
        Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu) + 80*MassB*trace[Yu, Adj[Yu]] - 
      40*trace[Adj[Yu], T[Yu]]))/25 - 32*g3^2*conj[MassG]*
    trace[Adj[Yu], T[Yu]] + (4*gp^2*conj[MassU]*(9*g1^2*MassB*Qd*QHu + 
      18*g1^2*MassU*Qd*QHu + 3*g1^2*MassB*Qe1*QHu + 6*g1^2*MassU*Qe1*QHu + 
      3*g1^2*MassB*Qe2*QHu + 6*g1^2*MassU*Qe2*QHu + 3*g1^2*MassB*Qe3*QHu + 
      6*g1^2*MassU*Qe3*QHu - 3*g1^2*MassB*QHd*QHu - 6*g1^2*MassU*QHd*QHu + 
      6*g1^2*MassB*QHu^2 + 12*g1^2*MassU*QHu^2 + 30*g2^2*MassU*QHu^2 + 
      15*g2^2*MassWB*QHu^2 + 270*gp^2*MassU*Qd^2*QHu^2 + 
      30*gp^2*MassU*Qe1^2*QHu^2 + 30*gp^2*MassU*Qe2^2*QHu^2 + 
      30*gp^2*MassU*Qe3^2*QHu^2 + 60*gp^2*MassU*QHd^2*QHu^2 + 
      120*gp^2*MassU*QHu^4 - 3*g1^2*MassB*QHu*Ql1 - 6*g1^2*MassU*QHu*Ql1 + 
      60*gp^2*MassU*QHu^2*Ql1^2 - 3*g1^2*MassB*QHu*Ql2 - 
      6*g1^2*MassU*QHu*Ql2 + 60*gp^2*MassU*QHu^2*Ql2^2 - 
      3*g1^2*MassB*QHu*Ql3 - 6*g1^2*MassU*QHu*Ql3 + 60*gp^2*MassU*QHu^2*
       Ql3^2 + 9*g1^2*MassB*QHu*Qq + 18*g1^2*MassU*QHu*Qq + 
      540*gp^2*MassU*QHu^2*Qq^2 + 30*gp^2*MassU*QHu^2*Qs^2 - 
      18*g1^2*MassB*QHu*Qu - 36*g1^2*MassU*QHu*Qu + 270*gp^2*MassU*QHu^2*
       Qu^2 + 30*gp^2*MassU*QHu^2*Qv1^2 + 30*gp^2*MassU*QHu^2*Qv2^2 + 
      30*gp^2*MassU*QHu^2*Qv3^2 - 10*MassU*QHu^2*Yv33*conj[Yv33] + 
      10*MassU*Ql3^2*Yv33*conj[Yv33] + 10*MassU*Qv3^2*Yv33*conj[Yv33] + 
      10*MassU*QHd^2*\[Lambda]*conj[\[Lambda]] - 10*MassU*QHu^2*\[Lambda]*
       conj[\[Lambda]] + 10*MassU*Qs^2*\[Lambda]*conj[\[Lambda]] - 
      5*(QHu^2 - Ql1^2 - Qv1^2)*conj[Yv11]*(2*MassU*Yv11 - T[Yv11]) - 
      5*(QHu^2 - Ql2^2 - Qv2^2)*conj[Yv22]*(2*MassU*Yv22 - T[Yv22]) + 
      5*QHu^2*conj[Yv33]*T[Yv33] - 5*Ql3^2*conj[Yv33]*T[Yv33] - 
      5*Qv3^2*conj[Yv33]*T[Yv33] - 5*QHd^2*conj[\[Lambda]]*T[\[Lambda]] + 
      5*QHu^2*conj[\[Lambda]]*T[\[Lambda]] - 5*Qs^2*conj[\[Lambda]]*
       T[\[Lambda]] - 30*MassU*QHu^2*trace[Yu, Adj[Yu]] + 
      30*MassU*Qq^2*trace[Yu, Adj[Yu]] + 30*MassU*Qu^2*trace[Yu, Adj[Yu]] + 
      15*QHu^2*trace[Adj[Yu], T[Yu]] - 15*Qq^2*trace[Adj[Yu], T[Yu]] - 
      15*Qu^2*trace[Adj[Yu], T[Yu]]))/5 - 6*conj[\[Lambda]]*T[\[Lambda]]*
    trace[conj[T[Yd]], Tp[Yd]] - 6*\[Lambda]*conj[\[Lambda]]*
    trace[conj[T[Yd]], Tp[T[Yd]]] - (8*g1^2*MassB*trace[conj[T[Yu]], Tp[Yu]])/
    5 - 32*g3^2*MassG*trace[conj[T[Yu]], Tp[Yu]] + 
   12*gp^2*MassU*QHu^2*trace[conj[T[Yu]], Tp[Yu]] - 
   12*gp^2*MassU*Qq^2*trace[conj[T[Yu]], Tp[Yu]] - 
   12*gp^2*MassU*Qu^2*trace[conj[T[Yu]], Tp[Yu]] + 
   (8*g1^2*trace[conj[T[Yu]], Tp[T[Yu]]])/5 + 
   32*g3^2*trace[conj[T[Yu]], Tp[T[Yu]]] - 
   12*gp^2*QHu^2*trace[conj[T[Yu]], Tp[T[Yu]]] + 
   12*gp^2*Qq^2*trace[conj[T[Yu]], Tp[T[Yu]]] + 
   12*gp^2*Qu^2*trace[conj[T[Yu]], Tp[T[Yu]]] - 6*\[Lambda]*conj[\[Lambda]]*
    trace[md2, Yd, Adj[Yd]] - 6*\[Lambda]*conj[\[Lambda]]*
    trace[mq2, Adj[Yd], Yd] + (8*g1^2*trace[mq2, Adj[Yu], Yu])/5 + 
   32*g3^2*trace[mq2, Adj[Yu], Yu] - 12*gp^2*QHu^2*trace[mq2, Adj[Yu], Yu] + 
   12*gp^2*Qq^2*trace[mq2, Adj[Yu], Yu] + 
   12*gp^2*Qu^2*trace[mq2, Adj[Yu], Yu] + (8*g1^2*trace[mu2, Yu, Adj[Yu]])/
    5 + 32*g3^2*trace[mu2, Yu, Adj[Yu]] - 
   12*gp^2*QHu^2*trace[mu2, Yu, Adj[Yu]] + 
   12*gp^2*Qq^2*trace[mu2, Yu, Adj[Yu]] + 
   12*gp^2*Qu^2*trace[mu2, Yu, Adj[Yu]] - 
   6*mHd2*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   6*mHu2*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   6*trace[Yd, Adj[Yu], T[Yu], Adj[T[Yd]]] - 
   6*trace[Yd, Adj[T[Yu]], T[Yu], Adj[Yd]] - 
   6*trace[Yu, Adj[Yd], T[Yd], Adj[T[Yu]]] - 
   36*mHu2*trace[Yu, Adj[Yu], Yu, Adj[Yu]] - 
   36*trace[Yu, Adj[Yu], T[Yu], Adj[T[Yu]]] - 
   6*trace[Yu, Adj[T[Yd]], T[Yd], Adj[Yu]] - 
   36*trace[Yu, Adj[T[Yu]], T[Yu], Adj[Yu]] - 
   6*trace[md2, Yd, Adj[Yu], Yu, Adj[Yd]] - 
   6*trace[mq2, Adj[Yd], Yd, Adj[Yu], Yu] - 
   6*trace[mq2, Adj[Yu], Yu, Adj[Yd], Yd] - 
   36*trace[mq2, Adj[Yu], Yu, Adj[Yu], Yu] - 
   6*trace[mu2, Yu, Adj[Yd], Yd, Adj[Yu]] - 
   36*trace[mu2, Yu, Adj[Yu], Yu, Adj[Yu]]}, 
 {md2[i1, i2], (-8*g1^2*MassB*conj[MassB]*Kronecker[i1, i2])/15 - 
   (32*g3^2*MassG*conj[MassG]*Kronecker[i1, i2])/3 - 
   8*gp^2*MassU*Qd^2*conj[MassU]*Kronecker[i1, i2] + 
   (2*g1*Kronecker[i1, i2]*Tr1[1])/Sqrt[15] + 2*gp*Qd*Kronecker[i1, i2]*
    Tr1[4] + 4*mHd2*MatMul[Yd, Adj[Yd]][i1, i2] + 
   4*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] + 2*MatMul[md2, Yd, Adj[Yd]][i1, i2] + 
   4*MatMul[Yd, mq2, Adj[Yd]][i1, i2] + 2*MatMul[Yd, Adj[Yd], md2][i1, i2], 
  (-64*g3^2*(30*g3^2*MassG - g1^2*(MassB + 2*MassG) - 
      15*gp^2*(2*MassG + MassU)*Qd^2)*conj[MassG]*Kronecker[i1, i2])/45 + 
   (88*g1^2*gp^2*MassB*Qd^2*conj[MassU]*Kronecker[i1, i2])/15 + 
   (64*g3^2*gp^2*MassG*Qd^2*conj[MassU]*Kronecker[i1, i2])/3 + 
   (176*g1^2*gp^2*MassU*Qd^2*conj[MassU]*Kronecker[i1, i2])/15 + 
   (128*g3^2*gp^2*MassU*Qd^2*conj[MassU]*Kronecker[i1, i2])/3 + 
   264*gp^4*MassU*Qd^4*conj[MassU]*Kronecker[i1, i2] + 
   (8*g1^2*gp^2*MassB*Qd*Qe1*conj[MassU]*Kronecker[i1, i2])/5 + 
   (16*g1^2*gp^2*MassU*Qd*Qe1*conj[MassU]*Kronecker[i1, i2])/5 + 
   24*gp^4*MassU*Qd^2*Qe1^2*conj[MassU]*Kronecker[i1, i2] + 
   (8*g1^2*gp^2*MassB*Qd*Qe2*conj[MassU]*Kronecker[i1, i2])/5 + 
   (16*g1^2*gp^2*MassU*Qd*Qe2*conj[MassU]*Kronecker[i1, i2])/5 + 
   24*gp^4*MassU*Qd^2*Qe2^2*conj[MassU]*Kronecker[i1, i2] + 
   (8*g1^2*gp^2*MassB*Qd*Qe3*conj[MassU]*Kronecker[i1, i2])/5 + 
   (16*g1^2*gp^2*MassU*Qd*Qe3*conj[MassU]*Kronecker[i1, i2])/5 + 
   24*gp^4*MassU*Qd^2*Qe3^2*conj[MassU]*Kronecker[i1, i2] - 
   (8*g1^2*gp^2*MassB*Qd*QHd*conj[MassU]*Kronecker[i1, i2])/5 - 
   (16*g1^2*gp^2*MassU*Qd*QHd*conj[MassU]*Kronecker[i1, i2])/5 + 
   48*gp^4*MassU*Qd^2*QHd^2*conj[MassU]*Kronecker[i1, i2] + 
   (8*g1^2*gp^2*MassB*Qd*QHu*conj[MassU]*Kronecker[i1, i2])/5 + 
   (16*g1^2*gp^2*MassU*Qd*QHu*conj[MassU]*Kronecker[i1, i2])/5 + 
   48*gp^4*MassU*Qd^2*QHu^2*conj[MassU]*Kronecker[i1, i2] - 
   (8*g1^2*gp^2*MassB*Qd*Ql1*conj[MassU]*Kronecker[i1, i2])/5 - 
   (16*g1^2*gp^2*MassU*Qd*Ql1*conj[MassU]*Kronecker[i1, i2])/5 + 
   48*gp^4*MassU*Qd^2*Ql1^2*conj[MassU]*Kronecker[i1, i2] - 
   (8*g1^2*gp^2*MassB*Qd*Ql2*conj[MassU]*Kronecker[i1, i2])/5 - 
   (16*g1^2*gp^2*MassU*Qd*Ql2*conj[MassU]*Kronecker[i1, i2])/5 + 
   48*gp^4*MassU*Qd^2*Ql2^2*conj[MassU]*Kronecker[i1, i2] - 
   (8*g1^2*gp^2*MassB*Qd*Ql3*conj[MassU]*Kronecker[i1, i2])/5 - 
   (16*g1^2*gp^2*MassU*Qd*Ql3*conj[MassU]*Kronecker[i1, i2])/5 + 
   48*gp^4*MassU*Qd^2*Ql3^2*conj[MassU]*Kronecker[i1, i2] + 
   (24*g1^2*gp^2*MassB*Qd*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   (48*g1^2*gp^2*MassU*Qd*Qq*conj[MassU]*Kronecker[i1, i2])/5 + 
   432*gp^4*MassU*Qd^2*Qq^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qd^2*Qs^2*conj[MassU]*Kronecker[i1, i2] - 
   (48*g1^2*gp^2*MassB*Qd*Qu*conj[MassU]*Kronecker[i1, i2])/5 - 
   (96*g1^2*gp^2*MassU*Qd*Qu*conj[MassU]*Kronecker[i1, i2])/5 + 
   216*gp^4*MassU*Qd^2*Qu^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qd^2*Qv1^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qd^2*Qv2^2*conj[MassU]*Kronecker[i1, i2] + 
   24*gp^4*MassU*Qd^2*Qv3^2*conj[MassU]*Kronecker[i1, i2] + 
   (32*g3^4*Kronecker[i1, i2]*Tr2[3])/3 + 
   (8*g1^2*Kronecker[i1, i2]*Tr2U1[1, 1])/15 + 
   (8*g1*gp*Qd*Kronecker[i1, i2]*Tr2U1[1, 4])/Sqrt[15] + 
   (8*g1*gp*Qd*Kronecker[i1, i2]*Tr2U1[4, 1])/Sqrt[15] + 
   8*gp^2*Qd^2*Kronecker[i1, i2]*Tr2U1[4, 4] + 
   (8*g1*Kronecker[i1, i2]*Tr3[1])/Sqrt[15] + 8*gp*Qd*Kronecker[i1, i2]*
    Tr3[4] + (4*g1^2*mHd2*MatMul[Yd, Adj[Yd]][i1, i2])/5 + 
   12*g2^2*mHd2*MatMul[Yd, Adj[Yd]][i1, i2] - 
   8*gp^2*mHd2*Qd^2*MatMul[Yd, Adj[Yd]][i1, i2] + 
   8*gp^2*mHd2*QHd^2*MatMul[Yd, Adj[Yd]][i1, i2] + 
   8*gp^2*mHd2*Qq^2*MatMul[Yd, Adj[Yd]][i1, i2] - 
   16*gp^2*MassU*Qd^2*conj[MassU]*MatMul[Yd, Adj[Yd]][i1, i2] + 
   16*gp^2*MassU*QHd^2*conj[MassU]*MatMul[Yd, Adj[Yd]][i1, i2] + 
   16*gp^2*MassU*Qq^2*conj[MassU]*MatMul[Yd, Adj[Yd]][i1, i2] + 
   24*g2^2*MassWB*conj[MassWB]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*me012*Ye11*conj[Ye11]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   8*mHd2*Ye11*conj[Ye11]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*ml012*Ye11*conj[Ye11]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*me022*Ye22*conj[Ye22]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   8*mHd2*Ye22*conj[Ye22]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*ml022*Ye22*conj[Ye22]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*me032*Ye33*conj[Ye33]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   8*mHd2*Ye33*conj[Ye33]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*ml032*Ye33*conj[Ye33]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   8*mHd2*\[Lambda]*conj[\[Lambda]]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*mHu2*\[Lambda]*conj[\[Lambda]]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*ms2*\[Lambda]*conj[\[Lambda]]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*conj[T[Ye11]]*T[Ye11]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*conj[T[Ye22]]*T[Ye22]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*conj[T[Ye33]]*T[Ye33]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   4*conj[T[\[Lambda]]]*T[\[Lambda]]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   24*mHd2*trace[Yd, Adj[Yd]]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   12*trace[conj[T[Yd]], Tp[T[Yd]]]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   12*trace[md2, Yd, Adj[Yd]]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   12*trace[mq2, Adj[Yd], Yd]*MatMul[Yd, Adj[Yd]][i1, i2] - 
   (4*g1^2*MassB*MatMul[Yd, Adj[T[Yd]]][i1, i2])/5 - 
   12*g2^2*MassWB*MatMul[Yd, Adj[T[Yd]]][i1, i2] + 
   8*gp^2*MassU*Qd^2*MatMul[Yd, Adj[T[Yd]]][i1, i2] - 
   8*gp^2*MassU*QHd^2*MatMul[Yd, Adj[T[Yd]]][i1, i2] - 
   8*gp^2*MassU*Qq^2*MatMul[Yd, Adj[T[Yd]]][i1, i2] - 
   4*conj[Ye11]*T[Ye11]*MatMul[Yd, Adj[T[Yd]]][i1, i2] - 
   4*conj[Ye22]*T[Ye22]*MatMul[Yd, Adj[T[Yd]]][i1, i2] - 
   4*conj[Ye33]*T[Ye33]*MatMul[Yd, Adj[T[Yd]]][i1, i2] - 
   4*conj[\[Lambda]]*T[\[Lambda]]*MatMul[Yd, Adj[T[Yd]]][i1, i2] - 
   12*trace[Adj[Yd], T[Yd]]*MatMul[Yd, Adj[T[Yd]]][i1, i2] + 
   (4*g1^2*conj[MassB]*(2*(303*g1^2*MassB + 40*g3^2*(2*MassB + MassG) + 
        15*gp^2*(2*MassB + MassU)*Qd*(11*Qd + 3*(Qe1 + Qe2 + Qe3 - QHd + 
            QHu - Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu)))*Kronecker[i1, i2] + 
      90*MassB*MatMul[Yd, Adj[Yd]][i1, i2] - 
      45*MatMul[T[Yd], Adj[Yd]][i1, i2]))/225 + 8*gp^2*Qd^2*conj[MassU]*
    MatMul[T[Yd], Adj[Yd]][i1, i2] - 8*gp^2*QHd^2*conj[MassU]*
    MatMul[T[Yd], Adj[Yd]][i1, i2] - 8*gp^2*Qq^2*conj[MassU]*
    MatMul[T[Yd], Adj[Yd]][i1, i2] - 12*g2^2*conj[MassWB]*
    MatMul[T[Yd], Adj[Yd]][i1, i2] - 4*Ye11*conj[T[Ye11]]*
    MatMul[T[Yd], Adj[Yd]][i1, i2] - 4*Ye22*conj[T[Ye22]]*
    MatMul[T[Yd], Adj[Yd]][i1, i2] - 4*Ye33*conj[T[Ye33]]*
    MatMul[T[Yd], Adj[Yd]][i1, i2] - 4*\[Lambda]*conj[T[\[Lambda]]]*
    MatMul[T[Yd], Adj[Yd]][i1, i2] - 12*trace[conj[T[Yd]], Tp[Yd]]*
    MatMul[T[Yd], Adj[Yd]][i1, i2] + 
   (4*g1^2*MatMul[T[Yd], Adj[T[Yd]]][i1, i2])/5 + 
   12*g2^2*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] - 
   8*gp^2*Qd^2*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] + 
   8*gp^2*QHd^2*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] + 
   8*gp^2*Qq^2*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] - 
   4*Ye11*conj[Ye11]*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] - 
   4*Ye22*conj[Ye22]*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] - 
   4*Ye33*conj[Ye33]*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] - 
   4*\[Lambda]*conj[\[Lambda]]*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] - 
   12*trace[Yd, Adj[Yd]]*MatMul[T[Yd], Adj[T[Yd]]][i1, i2] + 
   (2*g1^2*MatMul[md2, Yd, Adj[Yd]][i1, i2])/5 + 
   6*g2^2*MatMul[md2, Yd, Adj[Yd]][i1, i2] - 
   4*gp^2*Qd^2*MatMul[md2, Yd, Adj[Yd]][i1, i2] + 
   4*gp^2*QHd^2*MatMul[md2, Yd, Adj[Yd]][i1, i2] + 
   4*gp^2*Qq^2*MatMul[md2, Yd, Adj[Yd]][i1, i2] - 
   2*Ye11*conj[Ye11]*MatMul[md2, Yd, Adj[Yd]][i1, i2] - 
   2*Ye22*conj[Ye22]*MatMul[md2, Yd, Adj[Yd]][i1, i2] - 
   2*Ye33*conj[Ye33]*MatMul[md2, Yd, Adj[Yd]][i1, i2] - 
   2*\[Lambda]*conj[\[Lambda]]*MatMul[md2, Yd, Adj[Yd]][i1, i2] - 
   6*trace[Yd, Adj[Yd]]*MatMul[md2, Yd, Adj[Yd]][i1, i2] + 
   (4*g1^2*MatMul[Yd, mq2, Adj[Yd]][i1, i2])/5 + 
   12*g2^2*MatMul[Yd, mq2, Adj[Yd]][i1, i2] - 
   8*gp^2*Qd^2*MatMul[Yd, mq2, Adj[Yd]][i1, i2] + 
   8*gp^2*QHd^2*MatMul[Yd, mq2, Adj[Yd]][i1, i2] + 
   8*gp^2*Qq^2*MatMul[Yd, mq2, Adj[Yd]][i1, i2] - 
   4*Ye11*conj[Ye11]*MatMul[Yd, mq2, Adj[Yd]][i1, i2] - 
   4*Ye22*conj[Ye22]*MatMul[Yd, mq2, Adj[Yd]][i1, i2] - 
   4*Ye33*conj[Ye33]*MatMul[Yd, mq2, Adj[Yd]][i1, i2] - 
   4*\[Lambda]*conj[\[Lambda]]*MatMul[Yd, mq2, Adj[Yd]][i1, i2] - 
   12*trace[Yd, Adj[Yd]]*MatMul[Yd, mq2, Adj[Yd]][i1, i2] + 
   (2*g1^2*MatMul[Yd, Adj[Yd], md2][i1, i2])/5 + 
   6*g2^2*MatMul[Yd, Adj[Yd], md2][i1, i2] - 
   4*gp^2*Qd^2*MatMul[Yd, Adj[Yd], md2][i1, i2] + 
   4*gp^2*QHd^2*MatMul[Yd, Adj[Yd], md2][i1, i2] + 
   4*gp^2*Qq^2*MatMul[Yd, Adj[Yd], md2][i1, i2] - 
   2*Ye11*conj[Ye11]*MatMul[Yd, Adj[Yd], md2][i1, i2] - 
   2*Ye22*conj[Ye22]*MatMul[Yd, Adj[Yd], md2][i1, i2] - 
   2*Ye33*conj[Ye33]*MatMul[Yd, Adj[Yd], md2][i1, i2] - 
   2*\[Lambda]*conj[\[Lambda]]*MatMul[Yd, Adj[Yd], md2][i1, i2] - 
   6*trace[Yd, Adj[Yd]]*MatMul[Yd, Adj[Yd], md2][i1, i2] - 
   8*mHd2*MatMul[Yd, Adj[Yd], Yd, Adj[Yd]][i1, i2] - 
   4*MatMul[Yd, Adj[Yd], T[Yd], Adj[T[Yd]]][i1, i2] - 
   4*mHd2*MatMul[Yd, Adj[Yu], Yu, Adj[Yd]][i1, i2] - 
   4*mHu2*MatMul[Yd, Adj[Yu], Yu, Adj[Yd]][i1, i2] - 
   4*MatMul[Yd, Adj[Yu], T[Yu], Adj[T[Yd]]][i1, i2] - 
   4*MatMul[Yd, Adj[T[Yd]], T[Yd], Adj[Yd]][i1, i2] - 
   4*MatMul[Yd, Adj[T[Yu]], T[Yu], Adj[Yd]][i1, i2] - 
   4*MatMul[T[Yd], Adj[Yd], Yd, Adj[T[Yd]]][i1, i2] - 
   4*MatMul[T[Yd], Adj[Yu], Yu, Adj[T[Yd]]][i1, i2] - 
   4*MatMul[T[Yd], Adj[T[Yd]], Yd, Adj[Yd]][i1, i2] - 
   4*MatMul[T[Yd], Adj[T[Yu]], Yu, Adj[Yd]][i1, i2] - 
   2*MatMul[md2, Yd, Adj[Yd], Yd, Adj[Yd]][i1, i2] - 
   2*MatMul[md2, Yd, Adj[Yu], Yu, Adj[Yd]][i1, i2] - 
   4*MatMul[Yd, mq2, Adj[Yd], Yd, Adj[Yd]][i1, i2] - 
   4*MatMul[Yd, mq2, Adj[Yu], Yu, Adj[Yd]][i1, i2] - 
   4*MatMul[Yd, Adj[Yd], md2, Yd, Adj[Yd]][i1, i2] - 
   4*MatMul[Yd, Adj[Yd], Yd, mq2, Adj[Yd]][i1, i2] - 
   2*MatMul[Yd, Adj[Yd], Yd, Adj[Yd], md2][i1, i2] - 
   4*MatMul[Yd, Adj[Yu], mu2, Yu, Adj[Yd]][i1, i2] - 
   4*MatMul[Yd, Adj[Yu], Yu, mq2, Adj[Yd]][i1, i2] - 
   2*MatMul[Yd, Adj[Yu], Yu, Adj[Yd], md2][i1, i2]}, 
 {mu2[i1, i2], (-32*g1^2*MassB*conj[MassB]*Kronecker[i1, i2])/15 - 
   (32*g3^2*MassG*conj[MassG]*Kronecker[i1, i2])/3 - 
   8*gp^2*MassU*Qu^2*conj[MassU]*Kronecker[i1, i2] - 
   (4*g1*Kronecker[i1, i2]*Tr1[1])/Sqrt[15] + 2*gp*Qu*Kronecker[i1, i2]*
    Tr1[4] + 4*mHu2*MatMul[Yu, Adj[Yu]][i1, i2] + 
   4*MatMul[T[Yu], Adj[T[Yu]]][i1, i2] + 2*MatMul[mu2, Yu, Adj[Yu]][i1, i2] + 
   4*MatMul[Yu, mq2, Adj[Yu]][i1, i2] + 2*MatMul[Yu, Adj[Yu], mu2][i1, i2], 
  (4*g1^2*conj[MassB]*(4*(642*g1^2*MassB + 80*g3^2*(2*MassB + MassG) - 
        15*gp^2*(2*MassB + MassU)*(9*Qd + 3*Qe1 + 3*Qe2 + 3*Qe3 - 3*QHd + 
          3*QHu - 3*Ql1 - 3*Ql2 - 3*Ql3 + 9*Qq - 22*Qu)*Qu)*
       Kronecker[i1, i2] + 45*(-2*MassB*MatMul[Yu, Adj[Yu]][i1, i2] + 
        MatMul[T[Yu], Adj[Yu]][i1, i2])) + 
    10*(32*g3^2*(-30*g3^2*MassG + 4*g1^2*(MassB + 2*MassG) + 
        15*gp^2*(2*MassG + MassU)*Qu^2)*conj[MassG]*Kronecker[i1, i2] + 
      12*Kronecker[i1, i2]*(20*g3^4*Tr2[3] + 4*g1^2*Tr2U1[1, 1] - 
        2*Sqrt[15]*g1*(gp*Qu*(Tr2U1[1, 4] + Tr2U1[4, 1]) + Tr3[1]) + 
        15*gp*Qu*(gp*Qu*Tr2U1[4, 4] + Tr3[4])) + 12*gp^2*conj[MassU]*
       (Qu*(-2*g1^2*(MassB + 2*MassU)*(9*Qd + 3*Qe1 + 3*Qe2 + 3*Qe3 - 3*QHd + 
            3*QHu - 3*Ql1 - 3*Ql2 - 3*Ql3 + 9*Qq - 22*Qu) + 
          5*Qu*(8*g3^2*(MassG + 2*MassU) + 9*gp^2*MassU*(9*Qd^2 + Qe1^2 + 
              Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 
              2*Ql3^2 + 18*Qq^2 + Qs^2 + 11*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2)))*
         Kronecker[i1, i2] + 15*(QHu^2 + Qq^2 - Qu^2)*
         (2*MassU*MatMul[Yu, Adj[Yu]][i1, i2] - MatMul[T[Yu], Adj[Yu]][i1, 
           i2])) - 9*(2*(g1^2*mHu2 - 15*g2^2*mHu2 - 10*gp^2*mHu2*QHu^2 - 
          10*gp^2*mHu2*Qq^2 + 10*gp^2*mHu2*Qu^2 - 30*g2^2*MassWB*
           conj[MassWB] + 5*(2*mHu2 + ml012 + mvR012)*Yv11*conj[Yv11] + 
          10*mHu2*Yv22*conj[Yv22] + 5*ml022*Yv22*conj[Yv22] + 
          5*mvR022*Yv22*conj[Yv22] + 10*mHu2*Yv33*conj[Yv33] + 
          5*ml032*Yv33*conj[Yv33] + 5*mvR032*Yv33*conj[Yv33] + 
          5*mHd2*\[Lambda]*conj[\[Lambda]] + 10*mHu2*\[Lambda]*
           conj[\[Lambda]] + 5*ms2*\[Lambda]*conj[\[Lambda]] + 
          5*conj[T[Yv11]]*T[Yv11] + 5*conj[T[Yv22]]*T[Yv22] + 
          5*conj[T[Yv33]]*T[Yv33] + 5*conj[T[\[Lambda]]]*T[\[Lambda]] + 
          30*mHu2*trace[Yu, Adj[Yu]] + 15*trace[conj[T[Yu]], Tp[T[Yu]]] + 
          15*trace[mq2, Adj[Yu], Yu] + 15*trace[mu2, Yu, Adj[Yu]])*
         MatMul[Yu, Adj[Yu]][i1, i2] + 2*(-(g1^2*MassB) + 15*g2^2*MassWB + 
          10*gp^2*MassU*QHu^2 + 10*gp^2*MassU*Qq^2 - 10*gp^2*MassU*Qu^2 + 
          5*conj[Yv11]*T[Yv11] + 5*conj[Yv22]*T[Yv22] + 
          5*conj[Yv33]*T[Yv33] + 5*conj[\[Lambda]]*T[\[Lambda]] + 
          15*trace[Adj[Yu], T[Yu]])*MatMul[Yu, Adj[T[Yu]]][i1, i2] + 
        30*g2^2*conj[MassWB]*MatMul[T[Yu], Adj[Yu]][i1, i2] + 
        10*Yv11*conj[T[Yv11]]*MatMul[T[Yu], Adj[Yu]][i1, i2] + 
        10*Yv22*conj[T[Yv22]]*MatMul[T[Yu], Adj[Yu]][i1, i2] + 
        10*Yv33*conj[T[Yv33]]*MatMul[T[Yu], Adj[Yu]][i1, i2] + 
        10*\[Lambda]*conj[T[\[Lambda]]]*MatMul[T[Yu], Adj[Yu]][i1, i2] + 
        30*trace[conj[T[Yu]], Tp[Yu]]*MatMul[T[Yu], Adj[Yu]][i1, i2] + 
        2*g1^2*MatMul[T[Yu], Adj[T[Yu]]][i1, i2] - 
        30*g2^2*MatMul[T[Yu], Adj[T[Yu]]][i1, i2] - 20*gp^2*QHu^2*
         MatMul[T[Yu], Adj[T[Yu]]][i1, i2] - 20*gp^2*Qq^2*
         MatMul[T[Yu], Adj[T[Yu]]][i1, i2] + 20*gp^2*Qu^2*
         MatMul[T[Yu], Adj[T[Yu]]][i1, i2] + 10*Yv11*conj[Yv11]*
         MatMul[T[Yu], Adj[T[Yu]]][i1, i2] + 10*Yv22*conj[Yv22]*
         MatMul[T[Yu], Adj[T[Yu]]][i1, i2] + 10*Yv33*conj[Yv33]*
         MatMul[T[Yu], Adj[T[Yu]]][i1, i2] + 10*\[Lambda]*conj[\[Lambda]]*
         MatMul[T[Yu], Adj[T[Yu]]][i1, i2] + 30*trace[Yu, Adj[Yu]]*
         MatMul[T[Yu], Adj[T[Yu]]][i1, i2] + g1^2*MatMul[mu2, Yu, Adj[Yu]][
          i1, i2] - 15*g2^2*MatMul[mu2, Yu, Adj[Yu]][i1, i2] - 
        10*gp^2*QHu^2*MatMul[mu2, Yu, Adj[Yu]][i1, i2] - 
        10*gp^2*Qq^2*MatMul[mu2, Yu, Adj[Yu]][i1, i2] + 
        10*gp^2*Qu^2*MatMul[mu2, Yu, Adj[Yu]][i1, i2] + 
        5*Yv11*conj[Yv11]*MatMul[mu2, Yu, Adj[Yu]][i1, i2] + 
        5*Yv22*conj[Yv22]*MatMul[mu2, Yu, Adj[Yu]][i1, i2] + 
        5*Yv33*conj[Yv33]*MatMul[mu2, Yu, Adj[Yu]][i1, i2] + 
        5*\[Lambda]*conj[\[Lambda]]*MatMul[mu2, Yu, Adj[Yu]][i1, i2] + 
        15*trace[Yu, Adj[Yu]]*MatMul[mu2, Yu, Adj[Yu]][i1, i2] + 
        2*g1^2*MatMul[Yu, mq2, Adj[Yu]][i1, i2] - 
        30*g2^2*MatMul[Yu, mq2, Adj[Yu]][i1, i2] - 20*gp^2*QHu^2*
         MatMul[Yu, mq2, Adj[Yu]][i1, i2] - 20*gp^2*Qq^2*
         MatMul[Yu, mq2, Adj[Yu]][i1, i2] + 20*gp^2*Qu^2*
         MatMul[Yu, mq2, Adj[Yu]][i1, i2] + 10*Yv11*conj[Yv11]*
         MatMul[Yu, mq2, Adj[Yu]][i1, i2] + 10*Yv22*conj[Yv22]*
         MatMul[Yu, mq2, Adj[Yu]][i1, i2] + 10*Yv33*conj[Yv33]*
         MatMul[Yu, mq2, Adj[Yu]][i1, i2] + 10*\[Lambda]*conj[\[Lambda]]*
         MatMul[Yu, mq2, Adj[Yu]][i1, i2] + 30*trace[Yu, Adj[Yu]]*
         MatMul[Yu, mq2, Adj[Yu]][i1, i2] + g1^2*MatMul[Yu, Adj[Yu], mu2][i1, 
          i2] - 15*g2^2*MatMul[Yu, Adj[Yu], mu2][i1, i2] - 
        10*gp^2*QHu^2*MatMul[Yu, Adj[Yu], mu2][i1, i2] - 
        10*gp^2*Qq^2*MatMul[Yu, Adj[Yu], mu2][i1, i2] + 
        10*gp^2*Qu^2*MatMul[Yu, Adj[Yu], mu2][i1, i2] + 
        5*Yv11*conj[Yv11]*MatMul[Yu, Adj[Yu], mu2][i1, i2] + 
        5*Yv22*conj[Yv22]*MatMul[Yu, Adj[Yu], mu2][i1, i2] + 
        5*Yv33*conj[Yv33]*MatMul[Yu, Adj[Yu], mu2][i1, i2] + 
        5*\[Lambda]*conj[\[Lambda]]*MatMul[Yu, Adj[Yu], mu2][i1, i2] + 
        15*trace[Yu, Adj[Yu]]*MatMul[Yu, Adj[Yu], mu2][i1, i2] + 
        10*mHd2*MatMul[Yu, Adj[Yd], Yd, Adj[Yu]][i1, i2] + 
        10*mHu2*MatMul[Yu, Adj[Yd], Yd, Adj[Yu]][i1, i2] + 
        10*MatMul[Yu, Adj[Yd], T[Yd], Adj[T[Yu]]][i1, i2] + 
        20*mHu2*MatMul[Yu, Adj[Yu], Yu, Adj[Yu]][i1, i2] + 
        10*MatMul[Yu, Adj[Yu], T[Yu], Adj[T[Yu]]][i1, i2] + 
        10*MatMul[Yu, Adj[T[Yd]], T[Yd], Adj[Yu]][i1, i2] + 
        10*MatMul[Yu, Adj[T[Yu]], T[Yu], Adj[Yu]][i1, i2] + 
        10*MatMul[T[Yu], Adj[Yd], Yd, Adj[T[Yu]]][i1, i2] + 
        10*MatMul[T[Yu], Adj[Yu], Yu, Adj[T[Yu]]][i1, i2] + 
        10*MatMul[T[Yu], Adj[T[Yd]], Yd, Adj[Yu]][i1, i2] + 
        10*MatMul[T[Yu], Adj[T[Yu]], Yu, Adj[Yu]][i1, i2] + 
        5*MatMul[mu2, Yu, Adj[Yd], Yd, Adj[Yu]][i1, i2] + 
        5*MatMul[mu2, Yu, Adj[Yu], Yu, Adj[Yu]][i1, i2] + 
        10*MatMul[Yu, mq2, Adj[Yd], Yd, Adj[Yu]][i1, i2] + 
        10*MatMul[Yu, mq2, Adj[Yu], Yu, Adj[Yu]][i1, i2] + 
        10*MatMul[Yu, Adj[Yd], md2, Yd, Adj[Yu]][i1, i2] + 
        10*MatMul[Yu, Adj[Yd], Yd, mq2, Adj[Yu]][i1, i2] + 
        5*MatMul[Yu, Adj[Yd], Yd, Adj[Yu], mu2][i1, i2] + 
        10*MatMul[Yu, Adj[Yu], mu2, Yu, Adj[Yu]][i1, i2] + 
        10*MatMul[Yu, Adj[Yu], Yu, mq2, Adj[Yu]][i1, i2] + 
        5*MatMul[Yu, Adj[Yu], Yu, Adj[Yu], mu2][i1, i2])))/225}, 
 {me012, (-24*g1^2*MassB*conj[MassB])/5 - 8*gp^2*MassU*Qe1^2*conj[MassU] + 
   4*Tep*conj[Tep] + 4*me012*Ye11*conj[Ye11] + 4*mHd2*Ye11*conj[Ye11] + 
   4*ml012*Ye11*conj[Ye11] + 4*conj[T[Ye11]]*T[Ye11] + 
   2*Sqrt[3/5]*g1*Tr1[1] + 2*gp*Qe1*Tr1[4], 
  (4*(3*g1^2*conj[MassB]*(234*g1^2*MassB + 10*gp^2*(2*MassB + MassU)*Qe1*
        (3*Qd + 3*Qe1 + Qe2 + Qe3 - QHd + QHu - Ql1 - Ql2 - Ql3 + 3*Qq - 
         6*Qu) + 5*conj[Ye11]*(-2*MassB*Ye11 + T[Ye11])) + 
     5*(-20*(me012 + mHd2 + ml012)*Ye11^2*conj[Ye11]^2 + 
       3*g1^2*MassB*Ye11*conj[T[Ye11]] - 15*g2^2*MassWB*Ye11*conj[T[Ye11]] + 
       10*gp^2*MassU*Qe1^2*Ye11*conj[T[Ye11]] - 10*gp^2*MassU*QHd^2*Ye11*
        conj[T[Ye11]] - 10*gp^2*MassU*Ql1^2*Ye11*conj[T[Ye11]] + 
       2*gp^2*conj[MassU]*(3*Qe1*(g1^2*(MassB + 2*MassU)*(3*Qd + 3*Qe1 + 
             Qe2 + Qe3 - QHd + QHu - Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu) + 
           5*gp^2*MassU*Qe1*(9*Qd^2 + 3*Qe1^2 + Qe2^2 + Qe3^2 + 2*QHd^2 + 
             2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 
             9*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2)) - 5*(Qe1^2 - QHd^2 - Ql1^2)*
          conj[Ye11]*(2*MassU*Ye11 - T[Ye11])) - 3*g1^2*conj[T[Ye11]]*
        T[Ye11] + 15*g2^2*conj[T[Ye11]]*T[Ye11] - 10*gp^2*Qe1^2*conj[T[Ye11]]*
        T[Ye11] + 10*gp^2*QHd^2*conj[T[Ye11]]*T[Ye11] + 
       10*gp^2*Ql1^2*conj[T[Ye11]]*T[Ye11] - 5*Ye22*conj[Ye22]*conj[T[Ye11]]*
        T[Ye11] - 5*Ye33*conj[Ye33]*conj[T[Ye11]]*T[Ye11] - 
       5*Yv11*conj[Yv11]*conj[T[Ye11]]*T[Ye11] - 5*\[Lambda]*conj[\[Lambda]]*
        conj[T[Ye11]]*T[Ye11] - 5*Ye11*conj[Ye22]*conj[T[Ye11]]*T[Ye22] - 
       5*Ye11*conj[Ye33]*conj[T[Ye11]]*T[Ye33] - 5*Ye11*conj[Yv11]*
        conj[T[Ye11]]*T[Yv11] - 5*Ye11*conj[\[Lambda]]*conj[T[Ye11]]*
        T[\[Lambda]] + 6*g1^2*Tr2U1[1, 1] + 2*Sqrt[15]*g1*gp*Qe1*
        Tr2U1[1, 4] + 2*Sqrt[15]*g1*gp*Qe1*Tr2U1[4, 1] + 
       10*gp^2*Qe1^2*Tr2U1[4, 4] + 2*Sqrt[15]*g1*Tr3[1] + 10*gp*Qe1*Tr3[4] - 
       15*conj[T[Ye11]]*T[Ye11]*trace[Yd, Adj[Yd]] - 15*Ye11*conj[T[Ye11]]*
        trace[Adj[Yd], T[Yd]] - conj[Ye11]*(3*g1^2*me012*Ye11 - 
         15*g2^2*me012*Ye11 + 3*g1^2*mHd2*Ye11 - 15*g2^2*mHd2*Ye11 + 
         3*g1^2*ml012*Ye11 - 15*g2^2*ml012*Ye11 + 10*gp^2*me012*Qe1^2*Ye11 + 
         10*gp^2*mHd2*Qe1^2*Ye11 + 10*gp^2*ml012*Qe1^2*Ye11 - 
         10*gp^2*me012*QHd^2*Ye11 - 10*gp^2*mHd2*QHd^2*Ye11 - 
         10*gp^2*ml012*QHd^2*Ye11 - 10*gp^2*me012*Ql1^2*Ye11 - 
         10*gp^2*mHd2*Ql1^2*Ye11 - 10*gp^2*ml012*Ql1^2*Ye11 + 
         5*(me012 + me022 + 2*mHd2 + ml012 + ml022)*Ye11*Ye22*conj[Ye22] + 
         5*me012*Ye11*Ye33*conj[Ye33] + 5*me032*Ye11*Ye33*conj[Ye33] + 
         10*mHd2*Ye11*Ye33*conj[Ye33] + 5*ml012*Ye11*Ye33*conj[Ye33] + 
         5*ml032*Ye11*Ye33*conj[Ye33] + 5*me012*Ye11*Yv11*conj[Yv11] + 
         5*mHd2*Ye11*Yv11*conj[Yv11] + 5*mHu2*Ye11*Yv11*conj[Yv11] + 
         10*ml012*Ye11*Yv11*conj[Yv11] + 5*mvR012*Ye11*Yv11*conj[Yv11] + 
         5*me012*Ye11*\[Lambda]*conj[\[Lambda]] + 10*mHd2*Ye11*\[Lambda]*
          conj[\[Lambda]] + 5*mHu2*Ye11*\[Lambda]*conj[\[Lambda]] + 
         5*ml012*Ye11*\[Lambda]*conj[\[Lambda]] + 5*ms2*Ye11*\[Lambda]*
          conj[\[Lambda]] + 40*Ye11*conj[T[Ye11]]*T[Ye11] + 
         5*Ye22*conj[T[Ye22]]*T[Ye11] + 5*Ye33*conj[T[Ye33]]*T[Ye11] + 
         5*Yv11*conj[T[Yv11]]*T[Ye11] + 5*\[Lambda]*conj[T[\[Lambda]]]*
          T[Ye11] + 15*g2^2*conj[MassWB]*(-2*MassWB*Ye11 + T[Ye11]) + 
         5*Ye11*conj[T[Ye22]]*T[Ye22] + 5*Ye11*conj[T[Ye33]]*T[Ye33] + 
         5*Ye11*conj[T[Yv11]]*T[Yv11] + 5*Ye11*conj[T[\[Lambda]]]*
          T[\[Lambda]] + 15*me012*Ye11*trace[Yd, Adj[Yd]] + 
         30*mHd2*Ye11*trace[Yd, Adj[Yd]] + 15*ml012*Ye11*trace[Yd, Adj[Yd]] + 
         15*T[Ye11]*trace[conj[T[Yd]], Tp[Yd]] + 
         15*Ye11*trace[conj[T[Yd]], Tp[T[Yd]]] + 
         15*Ye11*trace[md2, Yd, Adj[Yd]] + 15*Ye11*trace[mq2, Adj[Yd], 
           Yd]))))/25}, {me022, (-24*g1^2*MassB*conj[MassB])/5 - 
   8*gp^2*MassU*Qe2^2*conj[MassU] + 4*Tmup*conj[Tmup] + 
   4*me022*Ye22*conj[Ye22] + 4*mHd2*Ye22*conj[Ye22] + 
   4*ml022*Ye22*conj[Ye22] + 4*conj[T[Ye22]]*T[Ye22] + 
   2*Sqrt[3/5]*g1*Tr1[1] + 2*gp*Qe2*Tr1[4], 
  (4*(3*g1^2*conj[MassB]*(234*g1^2*MassB + 10*gp^2*(2*MassB + MassU)*Qe2*
        (3*Qd + Qe1 + 3*Qe2 + Qe3 - QHd + QHu - Ql1 - Ql2 - Ql3 + 3*Qq - 
         6*Qu) + 5*conj[Ye22]*(-2*MassB*Ye22 + T[Ye22])) + 
     5*(-20*(me022 + mHd2 + ml022)*Ye22^2*conj[Ye22]^2 + 
       3*g1^2*MassB*Ye22*conj[T[Ye22]] - 15*g2^2*MassWB*Ye22*conj[T[Ye22]] + 
       10*gp^2*MassU*Qe2^2*Ye22*conj[T[Ye22]] - 10*gp^2*MassU*QHd^2*Ye22*
        conj[T[Ye22]] - 10*gp^2*MassU*Ql2^2*Ye22*conj[T[Ye22]] - 
       5*Ye22*conj[Ye11]*conj[T[Ye22]]*T[Ye11] + 2*gp^2*conj[MassU]*
        (3*Qe2*(g1^2*(MassB + 2*MassU)*(3*Qd + Qe1 + 3*Qe2 + Qe3 - QHd + 
             QHu - Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu) + 5*gp^2*MassU*Qe2*
            (9*Qd^2 + Qe1^2 + 3*Qe2^2 + Qe3^2 + 2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 
             2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + 
             Qv3^2)) - 5*(Qe2^2 - QHd^2 - Ql2^2)*conj[Ye22]*
          (2*MassU*Ye22 - T[Ye22])) - 3*g1^2*conj[T[Ye22]]*T[Ye22] + 
       15*g2^2*conj[T[Ye22]]*T[Ye22] - 10*gp^2*Qe2^2*conj[T[Ye22]]*T[Ye22] + 
       10*gp^2*QHd^2*conj[T[Ye22]]*T[Ye22] + 10*gp^2*Ql2^2*conj[T[Ye22]]*
        T[Ye22] - 5*Ye11*conj[Ye11]*conj[T[Ye22]]*T[Ye22] - 
       5*Ye33*conj[Ye33]*conj[T[Ye22]]*T[Ye22] - 5*Yv22*conj[Yv22]*
        conj[T[Ye22]]*T[Ye22] - 5*\[Lambda]*conj[\[Lambda]]*conj[T[Ye22]]*
        T[Ye22] - 5*Ye22*conj[Ye33]*conj[T[Ye22]]*T[Ye33] - 
       5*Ye22*conj[Yv22]*conj[T[Ye22]]*T[Yv22] - 5*Ye22*conj[\[Lambda]]*
        conj[T[Ye22]]*T[\[Lambda]] + 6*g1^2*Tr2U1[1, 1] + 
       2*Sqrt[15]*g1*gp*Qe2*Tr2U1[1, 4] + 2*Sqrt[15]*g1*gp*Qe2*Tr2U1[4, 1] + 
       10*gp^2*Qe2^2*Tr2U1[4, 4] + 2*Sqrt[15]*g1*Tr3[1] + 10*gp*Qe2*Tr3[4] - 
       15*conj[T[Ye22]]*T[Ye22]*trace[Yd, Adj[Yd]] - 15*Ye22*conj[T[Ye22]]*
        trace[Adj[Yd], T[Yd]] - conj[Ye22]*(3*g1^2*me022*Ye22 - 
         15*g2^2*me022*Ye22 + 3*g1^2*mHd2*Ye22 - 15*g2^2*mHd2*Ye22 + 
         3*g1^2*ml022*Ye22 - 15*g2^2*ml022*Ye22 + 10*gp^2*me022*Qe2^2*Ye22 + 
         10*gp^2*mHd2*Qe2^2*Ye22 + 10*gp^2*ml022*Qe2^2*Ye22 - 
         10*gp^2*me022*QHd^2*Ye22 - 10*gp^2*mHd2*QHd^2*Ye22 - 
         10*gp^2*ml022*QHd^2*Ye22 - 10*gp^2*me022*Ql2^2*Ye22 - 
         10*gp^2*mHd2*Ql2^2*Ye22 - 10*gp^2*ml022*Ql2^2*Ye22 + 
         5*(me012 + me022 + 2*mHd2 + ml012 + ml022)*Ye11*Ye22*conj[Ye11] + 
         5*me022*Ye22*Ye33*conj[Ye33] + 5*me032*Ye22*Ye33*conj[Ye33] + 
         10*mHd2*Ye22*Ye33*conj[Ye33] + 5*ml022*Ye22*Ye33*conj[Ye33] + 
         5*ml032*Ye22*Ye33*conj[Ye33] + 5*me022*Ye22*Yv22*conj[Yv22] + 
         5*mHd2*Ye22*Yv22*conj[Yv22] + 5*mHu2*Ye22*Yv22*conj[Yv22] + 
         10*ml022*Ye22*Yv22*conj[Yv22] + 5*mvR022*Ye22*Yv22*conj[Yv22] + 
         5*me022*Ye22*\[Lambda]*conj[\[Lambda]] + 10*mHd2*Ye22*\[Lambda]*
          conj[\[Lambda]] + 5*mHu2*Ye22*\[Lambda]*conj[\[Lambda]] + 
         5*ml022*Ye22*\[Lambda]*conj[\[Lambda]] + 5*ms2*Ye22*\[Lambda]*
          conj[\[Lambda]] + 5*Ye22*conj[T[Ye11]]*T[Ye11] + 
         5*Ye11*conj[T[Ye11]]*T[Ye22] + 40*Ye22*conj[T[Ye22]]*T[Ye22] + 
         5*Ye33*conj[T[Ye33]]*T[Ye22] + 5*Yv22*conj[T[Yv22]]*T[Ye22] + 
         5*\[Lambda]*conj[T[\[Lambda]]]*T[Ye22] + 15*g2^2*conj[MassWB]*
          (-2*MassWB*Ye22 + T[Ye22]) + 5*Ye22*conj[T[Ye33]]*T[Ye33] + 
         5*Ye22*conj[T[Yv22]]*T[Yv22] + 5*Ye22*conj[T[\[Lambda]]]*
          T[\[Lambda]] + 15*me022*Ye22*trace[Yd, Adj[Yd]] + 
         30*mHd2*Ye22*trace[Yd, Adj[Yd]] + 15*ml022*Ye22*trace[Yd, Adj[Yd]] + 
         15*T[Ye22]*trace[conj[T[Yd]], Tp[Yd]] + 
         15*Ye22*trace[conj[T[Yd]], Tp[T[Yd]]] + 
         15*Ye22*trace[md2, Yd, Adj[Yd]] + 15*Ye22*trace[mq2, Adj[Yd], 
           Yd]))))/25}, {me032, (-24*g1^2*MassB*conj[MassB])/5 - 
   8*gp^2*MassU*Qe3^2*conj[MassU] + 4*me032*Ye33*conj[Ye33] + 
   4*mHd2*Ye33*conj[Ye33] + 4*ml032*Ye33*conj[Ye33] + 
   4*conj[T[Ye33]]*T[Ye33] + 2*Sqrt[3/5]*g1*Tr1[1] + 2*gp*Qe3*Tr1[4], 
  (4*(3*g1^2*conj[MassB]*(234*g1^2*MassB + 10*gp^2*(2*MassB + MassU)*Qe3*
        (3*Qd + Qe1 + Qe2 + 3*Qe3 - QHd + QHu - Ql1 - Ql2 - Ql3 + 3*Qq - 
         6*Qu) + 5*conj[Ye33]*(-2*MassB*Ye33 + T[Ye33])) + 
     5*(-20*(me032 + mHd2 + ml032)*Ye33^2*conj[Ye33]^2 + 
       3*g1^2*MassB*Ye33*conj[T[Ye33]] - 15*g2^2*MassWB*Ye33*conj[T[Ye33]] + 
       10*gp^2*MassU*Qe3^2*Ye33*conj[T[Ye33]] - 10*gp^2*MassU*QHd^2*Ye33*
        conj[T[Ye33]] - 10*gp^2*MassU*Ql3^2*Ye33*conj[T[Ye33]] - 
       5*Ye33*conj[Ye11]*conj[T[Ye33]]*T[Ye11] - 5*Ye33*conj[Ye22]*
        conj[T[Ye33]]*T[Ye22] + 2*gp^2*conj[MassU]*
        (3*Qe3*(g1^2*(MassB + 2*MassU)*(3*Qd + Qe1 + Qe2 + 3*Qe3 - QHd + 
             QHu - Ql1 - Ql2 - Ql3 + 3*Qq - 6*Qu) + 5*gp^2*MassU*Qe3*
            (9*Qd^2 + Qe1^2 + Qe2^2 + 3*Qe3^2 + 2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 
             2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 9*Qu^2 + Qv1^2 + Qv2^2 + 
             Qv3^2)) - 5*(Qe3^2 - QHd^2 - Ql3^2)*conj[Ye33]*
          (2*MassU*Ye33 - T[Ye33])) - 3*g1^2*conj[T[Ye33]]*T[Ye33] + 
       15*g2^2*conj[T[Ye33]]*T[Ye33] - 10*gp^2*Qe3^2*conj[T[Ye33]]*T[Ye33] + 
       10*gp^2*QHd^2*conj[T[Ye33]]*T[Ye33] + 10*gp^2*Ql3^2*conj[T[Ye33]]*
        T[Ye33] - 5*Ye11*conj[Ye11]*conj[T[Ye33]]*T[Ye33] - 
       5*Ye22*conj[Ye22]*conj[T[Ye33]]*T[Ye33] - 5*Yv33*conj[Yv33]*
        conj[T[Ye33]]*T[Ye33] - 5*\[Lambda]*conj[\[Lambda]]*conj[T[Ye33]]*
        T[Ye33] - 5*Ye33*conj[Yv33]*conj[T[Ye33]]*T[Yv33] - 
       5*Ye33*conj[\[Lambda]]*conj[T[Ye33]]*T[\[Lambda]] + 
       6*g1^2*Tr2U1[1, 1] + 2*Sqrt[15]*g1*gp*Qe3*Tr2U1[1, 4] + 
       2*Sqrt[15]*g1*gp*Qe3*Tr2U1[4, 1] + 10*gp^2*Qe3^2*Tr2U1[4, 4] + 
       2*Sqrt[15]*g1*Tr3[1] + 10*gp*Qe3*Tr3[4] - 15*conj[T[Ye33]]*T[Ye33]*
        trace[Yd, Adj[Yd]] - 15*Ye33*conj[T[Ye33]]*trace[Adj[Yd], T[Yd]] - 
       conj[Ye33]*(3*g1^2*me032*Ye33 - 15*g2^2*me032*Ye33 + 
         3*g1^2*mHd2*Ye33 - 15*g2^2*mHd2*Ye33 + 3*g1^2*ml032*Ye33 - 
         15*g2^2*ml032*Ye33 + 10*gp^2*me032*Qe3^2*Ye33 + 
         10*gp^2*mHd2*Qe3^2*Ye33 + 10*gp^2*ml032*Qe3^2*Ye33 - 
         10*gp^2*me032*QHd^2*Ye33 - 10*gp^2*mHd2*QHd^2*Ye33 - 
         10*gp^2*ml032*QHd^2*Ye33 - 10*gp^2*me032*Ql3^2*Ye33 - 
         10*gp^2*mHd2*Ql3^2*Ye33 - 10*gp^2*ml032*Ql3^2*Ye33 + 
         5*(me012 + me032 + 2*mHd2 + ml012 + ml032)*Ye11*Ye33*conj[Ye11] + 
         5*me022*Ye22*Ye33*conj[Ye22] + 5*me032*Ye22*Ye33*conj[Ye22] + 
         10*mHd2*Ye22*Ye33*conj[Ye22] + 5*ml022*Ye22*Ye33*conj[Ye22] + 
         5*ml032*Ye22*Ye33*conj[Ye22] + 5*me032*Ye33*Yv33*conj[Yv33] + 
         5*mHd2*Ye33*Yv33*conj[Yv33] + 5*mHu2*Ye33*Yv33*conj[Yv33] + 
         10*ml032*Ye33*Yv33*conj[Yv33] + 5*mvR032*Ye33*Yv33*conj[Yv33] + 
         5*me032*Ye33*\[Lambda]*conj[\[Lambda]] + 10*mHd2*Ye33*\[Lambda]*
          conj[\[Lambda]] + 5*mHu2*Ye33*\[Lambda]*conj[\[Lambda]] + 
         5*ml032*Ye33*\[Lambda]*conj[\[Lambda]] + 5*ms2*Ye33*\[Lambda]*
          conj[\[Lambda]] + 5*Ye33*conj[T[Ye11]]*T[Ye11] + 
         5*Ye33*conj[T[Ye22]]*T[Ye22] + 5*Ye11*conj[T[Ye11]]*T[Ye33] + 
         5*Ye22*conj[T[Ye22]]*T[Ye33] + 40*Ye33*conj[T[Ye33]]*T[Ye33] + 
         5*Yv33*conj[T[Yv33]]*T[Ye33] + 5*\[Lambda]*conj[T[\[Lambda]]]*
          T[Ye33] + 15*g2^2*conj[MassWB]*(-2*MassWB*Ye33 + T[Ye33]) + 
         5*Ye33*conj[T[Yv33]]*T[Yv33] + 5*Ye33*conj[T[\[Lambda]]]*
          T[\[Lambda]] + 15*me032*Ye33*trace[Yd, Adj[Yd]] + 
         30*mHd2*Ye33*trace[Yd, Adj[Yd]] + 15*ml032*Ye33*trace[Yd, Adj[Yd]] + 
         15*T[Ye33]*trace[conj[T[Yd]], Tp[Yd]] + 
         15*Ye33*trace[conj[T[Yd]], Tp[T[Yd]]] + 
         15*Ye33*trace[md2, Yd, Adj[Yd]] + 15*Ye33*trace[mq2, Adj[Yd], 
           Yd]))))/25}, {mvR012, -8*gp^2*MassU*Qv1^2*conj[MassU] + 
   4*(mHu2 + ml012 + mvR012)*Yv11*conj[Yv11] + 4*conj[T[Yv11]]*T[Yv11] + 
   2*gp*Qv1*Tr1[4], -16*(mHu2 + ml012 + mvR012)*Yv11^2*conj[Yv11]^2 + 
   8*conj[MassU]*(3*gp^4*MassU*Qv1^2*(9*Qd^2 + Qe1^2 + Qe2^2 + Qe3^2 + 
       2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 
       9*Qu^2 + 3*Qv1^2 + Qv2^2 + Qv3^2) + gp^2*(QHu^2 + Ql1^2 - Qv1^2)*
      conj[Yv11]*(2*MassU*Yv11 - T[Yv11])) + 
   8*gp*Qv1*(gp*Qv1*Tr2U1[4, 4] + Tr3[4]) - 
   (4*conj[T[Yv11]]*(5*conj[Ye11]*(Yv11*T[Ye11] + Ye11*T[Yv11]) + 
      T[Yv11]*(-3*g1^2 - 15*g2^2 - 10*gp^2*QHu^2 - 10*gp^2*Ql1^2 + 
        10*gp^2*Qv1^2 + 5*Yv22*conj[Yv22] + 5*Yv33*conj[Yv33] + 
        5*\[Lambda]*conj[\[Lambda]] + 15*trace[Yu, Adj[Yu]]) + 
      Yv11*(3*g1^2*MassB + 15*g2^2*MassWB + 10*gp^2*MassU*QHu^2 + 
        10*gp^2*MassU*Ql1^2 - 10*gp^2*MassU*Qv1^2 + 5*conj[Yv22]*T[Yv22] + 
        5*conj[Yv33]*T[Yv33] + 5*conj[\[Lambda]]*T[\[Lambda]] + 
        15*trace[Adj[Yu], T[Yu]])))/5 + 
   (4*conj[Yv11]*(3*g1^2*mHu2*Yv11 + 15*g2^2*mHu2*Yv11 + 3*g1^2*ml012*Yv11 + 
      15*g2^2*ml012*Yv11 + 3*g1^2*mvR012*Yv11 + 15*g2^2*mvR012*Yv11 + 
      10*gp^2*mHu2*QHu^2*Yv11 + 10*gp^2*ml012*QHu^2*Yv11 + 
      10*gp^2*mvR012*QHu^2*Yv11 + 10*gp^2*mHu2*Ql1^2*Yv11 + 
      10*gp^2*ml012*Ql1^2*Yv11 + 10*gp^2*mvR012*Ql1^2*Yv11 - 
      10*gp^2*mHu2*Qv1^2*Yv11 - 10*gp^2*ml012*Qv1^2*Yv11 - 
      10*gp^2*mvR012*Qv1^2*Yv11 - 5*me012*Ye11*Yv11*conj[Ye11] - 
      5*mHd2*Ye11*Yv11*conj[Ye11] - 5*mHu2*Ye11*Yv11*conj[Ye11] - 
      10*ml012*Ye11*Yv11*conj[Ye11] - 5*mvR012*Ye11*Yv11*conj[Ye11] - 
      10*mHu2*Yv11*Yv22*conj[Yv22] - 5*ml012*Yv11*Yv22*conj[Yv22] - 
      5*ml022*Yv11*Yv22*conj[Yv22] - 5*mvR012*Yv11*Yv22*conj[Yv22] - 
      5*mvR022*Yv11*Yv22*conj[Yv22] - 10*mHu2*Yv11*Yv33*conj[Yv33] - 
      5*ml012*Yv11*Yv33*conj[Yv33] - 5*ml032*Yv11*Yv33*conj[Yv33] - 
      5*mvR012*Yv11*Yv33*conj[Yv33] - 5*mvR032*Yv11*Yv33*conj[Yv33] - 
      5*mHd2*Yv11*\[Lambda]*conj[\[Lambda]] - 10*mHu2*Yv11*\[Lambda]*
       conj[\[Lambda]] - 5*ml012*Yv11*\[Lambda]*conj[\[Lambda]] - 
      5*ms2*Yv11*\[Lambda]*conj[\[Lambda]] - 5*mvR012*Yv11*\[Lambda]*
       conj[\[Lambda]] - 5*Yv11*conj[T[Ye11]]*T[Ye11] + 
      3*g1^2*conj[MassB]*(2*MassB*Yv11 - T[Yv11]) + 15*g2^2*conj[MassWB]*
       (2*MassWB*Yv11 - T[Yv11]) - 5*Ye11*conj[T[Ye11]]*T[Yv11] - 
      40*Yv11*conj[T[Yv11]]*T[Yv11] - 5*Yv22*conj[T[Yv22]]*T[Yv11] - 
      5*Yv33*conj[T[Yv33]]*T[Yv11] - 5*\[Lambda]*conj[T[\[Lambda]]]*T[Yv11] - 
      5*Yv11*conj[T[Yv22]]*T[Yv22] - 5*Yv11*conj[T[Yv33]]*T[Yv33] - 
      5*Yv11*conj[T[\[Lambda]]]*T[\[Lambda]] - 30*mHu2*Yv11*
       trace[Yu, Adj[Yu]] - 15*ml012*Yv11*trace[Yu, Adj[Yu]] - 
      15*mvR012*Yv11*trace[Yu, Adj[Yu]] - 15*T[Yv11]*trace[conj[T[Yu]], 
        Tp[Yu]] - 15*Yv11*trace[conj[T[Yu]], Tp[T[Yu]]] - 
      15*Yv11*trace[mq2, Adj[Yu], Yu] - 15*Yv11*trace[mu2, Yu, Adj[Yu]]))/5}, 
 {mvR022, -8*gp^2*MassU*Qv2^2*conj[MassU] + 4*(mHu2 + ml022 + mvR022)*Yv22*
    conj[Yv22] + 4*conj[T[Yv22]]*T[Yv22] + 2*gp*Qv2*Tr1[4], 
  -16*(mHu2 + ml022 + mvR022)*Yv22^2*conj[Yv22]^2 + 
   8*conj[MassU]*(3*gp^4*MassU*Qv2^2*(9*Qd^2 + Qe1^2 + Qe2^2 + Qe3^2 + 
       2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 
       9*Qu^2 + Qv1^2 + 3*Qv2^2 + Qv3^2) + gp^2*(QHu^2 + Ql2^2 - Qv2^2)*
      conj[Yv22]*(2*MassU*Yv22 - T[Yv22])) + 
   8*gp*Qv2*(gp*Qv2*Tr2U1[4, 4] + Tr3[4]) - 
   (4*conj[T[Yv22]]*(3*g1^2*MassB*Yv22 + 15*g2^2*MassWB*Yv22 + 
      10*gp^2*MassU*QHu^2*Yv22 + 10*gp^2*MassU*Ql2^2*Yv22 - 
      10*gp^2*MassU*Qv2^2*Yv22 - 3*g1^2*T[Yv22] - 15*g2^2*T[Yv22] - 
      10*gp^2*QHu^2*T[Yv22] - 10*gp^2*Ql2^2*T[Yv22] + 10*gp^2*Qv2^2*T[Yv22] + 
      5*Yv33*conj[Yv33]*T[Yv22] + 5*\[Lambda]*conj[\[Lambda]]*T[Yv22] + 
      5*conj[Ye22]*(Yv22*T[Ye22] + Ye22*T[Yv22]) + 
      5*conj[Yv11]*(Yv22*T[Yv11] + Yv11*T[Yv22]) + 5*Yv22*conj[Yv33]*
       T[Yv33] + 5*Yv22*conj[\[Lambda]]*T[\[Lambda]] + 
      15*T[Yv22]*trace[Yu, Adj[Yu]] + 15*Yv22*trace[Adj[Yu], T[Yu]]))/5 + 
   (4*conj[Yv22]*(3*g1^2*mHu2*Yv22 + 15*g2^2*mHu2*Yv22 + 3*g1^2*ml022*Yv22 + 
      15*g2^2*ml022*Yv22 + 3*g1^2*mvR022*Yv22 + 15*g2^2*mvR022*Yv22 + 
      10*gp^2*mHu2*QHu^2*Yv22 + 10*gp^2*ml022*QHu^2*Yv22 + 
      10*gp^2*mvR022*QHu^2*Yv22 + 10*gp^2*mHu2*Ql2^2*Yv22 + 
      10*gp^2*ml022*Ql2^2*Yv22 + 10*gp^2*mvR022*Ql2^2*Yv22 - 
      10*gp^2*mHu2*Qv2^2*Yv22 - 10*gp^2*ml022*Qv2^2*Yv22 - 
      10*gp^2*mvR022*Qv2^2*Yv22 - 5*me022*Ye22*Yv22*conj[Ye22] - 
      5*mHd2*Ye22*Yv22*conj[Ye22] - 5*mHu2*Ye22*Yv22*conj[Ye22] - 
      10*ml022*Ye22*Yv22*conj[Ye22] - 5*mvR022*Ye22*Yv22*conj[Ye22] - 
      10*mHu2*Yv11*Yv22*conj[Yv11] - 5*ml012*Yv11*Yv22*conj[Yv11] - 
      5*ml022*Yv11*Yv22*conj[Yv11] - 5*mvR012*Yv11*Yv22*conj[Yv11] - 
      5*mvR022*Yv11*Yv22*conj[Yv11] - 10*mHu2*Yv22*Yv33*conj[Yv33] - 
      5*ml022*Yv22*Yv33*conj[Yv33] - 5*ml032*Yv22*Yv33*conj[Yv33] - 
      5*mvR022*Yv22*Yv33*conj[Yv33] - 5*mvR032*Yv22*Yv33*conj[Yv33] - 
      5*mHd2*Yv22*\[Lambda]*conj[\[Lambda]] - 10*mHu2*Yv22*\[Lambda]*
       conj[\[Lambda]] - 5*ml022*Yv22*\[Lambda]*conj[\[Lambda]] - 
      5*ms2*Yv22*\[Lambda]*conj[\[Lambda]] - 5*mvR022*Yv22*\[Lambda]*
       conj[\[Lambda]] - 5*Yv22*conj[T[Ye22]]*T[Ye22] - 
      5*Yv22*conj[T[Yv11]]*T[Yv11] + 3*g1^2*conj[MassB]*
       (2*MassB*Yv22 - T[Yv22]) + 15*g2^2*conj[MassWB]*
       (2*MassWB*Yv22 - T[Yv22]) - 5*Ye22*conj[T[Ye22]]*T[Yv22] - 
      5*Yv11*conj[T[Yv11]]*T[Yv22] - 40*Yv22*conj[T[Yv22]]*T[Yv22] - 
      5*Yv33*conj[T[Yv33]]*T[Yv22] - 5*\[Lambda]*conj[T[\[Lambda]]]*T[Yv22] - 
      5*Yv22*conj[T[Yv33]]*T[Yv33] - 5*Yv22*conj[T[\[Lambda]]]*T[\[Lambda]] - 
      30*mHu2*Yv22*trace[Yu, Adj[Yu]] - 15*ml022*Yv22*trace[Yu, Adj[Yu]] - 
      15*mvR022*Yv22*trace[Yu, Adj[Yu]] - 15*T[Yv22]*trace[conj[T[Yu]], 
        Tp[Yu]] - 15*Yv22*trace[conj[T[Yu]], Tp[T[Yu]]] - 
      15*Yv22*trace[mq2, Adj[Yu], Yu] - 15*Yv22*trace[mu2, Yu, Adj[Yu]]))/5}, 
 {mvR032, -8*gp^2*MassU*Qv3^2*conj[MassU] + 4*(mHu2 + ml032 + mvR032)*Yv33*
    conj[Yv33] + 4*conj[T[Yv33]]*T[Yv33] + 2*gp*Qv3*Tr1[4], 
  -16*(mHu2 + ml032 + mvR032)*Yv33^2*conj[Yv33]^2 + 
   8*conj[MassU]*(3*gp^4*MassU*Qv3^2*(9*Qd^2 + Qe1^2 + Qe2^2 + Qe3^2 + 
       2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + Qs^2 + 
       9*Qu^2 + Qv1^2 + Qv2^2 + 3*Qv3^2) + gp^2*(QHu^2 + Ql3^2 - Qv3^2)*
      conj[Yv33]*(2*MassU*Yv33 - T[Yv33])) + 
   8*gp*Qv3*(gp*Qv3*Tr2U1[4, 4] + Tr3[4]) - 
   (4*conj[T[Yv33]]*(3*g1^2*MassB*Yv33 + 15*g2^2*MassWB*Yv33 + 
      10*gp^2*MassU*QHu^2*Yv33 + 10*gp^2*MassU*Ql3^2*Yv33 - 
      10*gp^2*MassU*Qv3^2*Yv33 + 5*Yv33*conj[Yv22]*T[Yv22] - 3*g1^2*T[Yv33] - 
      15*g2^2*T[Yv33] - 10*gp^2*QHu^2*T[Yv33] - 10*gp^2*Ql3^2*T[Yv33] + 
      10*gp^2*Qv3^2*T[Yv33] + 5*Yv22*conj[Yv22]*T[Yv33] + 
      5*\[Lambda]*conj[\[Lambda]]*T[Yv33] + 5*conj[Ye33]*
       (Yv33*T[Ye33] + Ye33*T[Yv33]) + 5*conj[Yv11]*(Yv33*T[Yv11] + 
        Yv11*T[Yv33]) + 5*Yv33*conj[\[Lambda]]*T[\[Lambda]] + 
      15*T[Yv33]*trace[Yu, Adj[Yu]] + 15*Yv33*trace[Adj[Yu], T[Yu]]))/5 + 
   (4*conj[Yv33]*(3*g1^2*mHu2*Yv33 + 15*g2^2*mHu2*Yv33 + 3*g1^2*ml032*Yv33 + 
      15*g2^2*ml032*Yv33 + 3*g1^2*mvR032*Yv33 + 15*g2^2*mvR032*Yv33 + 
      10*gp^2*mHu2*QHu^2*Yv33 + 10*gp^2*ml032*QHu^2*Yv33 + 
      10*gp^2*mvR032*QHu^2*Yv33 + 10*gp^2*mHu2*Ql3^2*Yv33 + 
      10*gp^2*ml032*Ql3^2*Yv33 + 10*gp^2*mvR032*Ql3^2*Yv33 - 
      10*gp^2*mHu2*Qv3^2*Yv33 - 10*gp^2*ml032*Qv3^2*Yv33 - 
      10*gp^2*mvR032*Qv3^2*Yv33 - 5*me032*Ye33*Yv33*conj[Ye33] - 
      5*mHd2*Ye33*Yv33*conj[Ye33] - 5*mHu2*Ye33*Yv33*conj[Ye33] - 
      10*ml032*Ye33*Yv33*conj[Ye33] - 5*mvR032*Ye33*Yv33*conj[Ye33] - 
      10*mHu2*Yv11*Yv33*conj[Yv11] - 5*ml012*Yv11*Yv33*conj[Yv11] - 
      5*ml032*Yv11*Yv33*conj[Yv11] - 5*mvR012*Yv11*Yv33*conj[Yv11] - 
      5*mvR032*Yv11*Yv33*conj[Yv11] - 10*mHu2*Yv22*Yv33*conj[Yv22] - 
      5*ml022*Yv22*Yv33*conj[Yv22] - 5*ml032*Yv22*Yv33*conj[Yv22] - 
      5*mvR022*Yv22*Yv33*conj[Yv22] - 5*mvR032*Yv22*Yv33*conj[Yv22] - 
      5*mHd2*Yv33*\[Lambda]*conj[\[Lambda]] - 10*mHu2*Yv33*\[Lambda]*
       conj[\[Lambda]] - 5*ml032*Yv33*\[Lambda]*conj[\[Lambda]] - 
      5*ms2*Yv33*\[Lambda]*conj[\[Lambda]] - 5*mvR032*Yv33*\[Lambda]*
       conj[\[Lambda]] - 5*Yv33*conj[T[Ye33]]*T[Ye33] - 
      5*Yv33*conj[T[Yv11]]*T[Yv11] - 5*Yv33*conj[T[Yv22]]*T[Yv22] + 
      3*g1^2*conj[MassB]*(2*MassB*Yv33 - T[Yv33]) + 15*g2^2*conj[MassWB]*
       (2*MassWB*Yv33 - T[Yv33]) - 5*Ye33*conj[T[Ye33]]*T[Yv33] - 
      5*Yv11*conj[T[Yv11]]*T[Yv33] - 5*Yv22*conj[T[Yv22]]*T[Yv33] - 
      40*Yv33*conj[T[Yv33]]*T[Yv33] - 5*\[Lambda]*conj[T[\[Lambda]]]*
       T[Yv33] - 5*Yv33*conj[T[\[Lambda]]]*T[\[Lambda]] - 
      30*mHu2*Yv33*trace[Yu, Adj[Yu]] - 15*ml032*Yv33*trace[Yu, Adj[Yu]] - 
      15*mvR032*Yv33*trace[Yu, Adj[Yu]] - 15*T[Yv33]*trace[conj[T[Yu]], 
        Tp[Yu]] - 15*Yv33*trace[conj[T[Yu]], Tp[T[Yu]]] - 
      15*Yv33*trace[mq2, Adj[Yu], Yu] - 15*Yv33*trace[mu2, Yu, Adj[Yu]]))/5}, 
 {ms2, -8*gp^2*MassU*Qs^2*conj[MassU] + 4*(mHd2 + mHu2 + ms2)*\[Lambda]*
    conj[\[Lambda]] + 4*conj[T[\[Lambda]]]*T[\[Lambda]] + 2*gp*Qs*Tr1[4], 
  -16*(mHd2 + mHu2 + ms2)*\[Lambda]^2*conj[\[Lambda]]^2 + 
   8*conj[MassU]*(3*gp^4*MassU*Qs^2*(9*Qd^2 + Qe1^2 + Qe2^2 + Qe3^2 + 
       2*QHd^2 + 2*QHu^2 + 2*Ql1^2 + 2*Ql2^2 + 2*Ql3^2 + 18*Qq^2 + 3*Qs^2 + 
       9*Qu^2 + Qv1^2 + Qv2^2 + Qv3^2) + gp^2*(QHd^2 + QHu^2 - Qs^2)*
      conj[\[Lambda]]*(2*MassU*\[Lambda] - T[\[Lambda]])) + 
   8*gp*Qs*(gp*Qs*Tr2U1[4, 4] + Tr3[4]) - 
   (4*conj[T[\[Lambda]]]*(3*g1^2*MassB*\[Lambda] + 15*g2^2*MassWB*\[Lambda] + 
      10*gp^2*MassU*QHd^2*\[Lambda] + 10*gp^2*MassU*QHu^2*\[Lambda] - 
      10*gp^2*MassU*Qs^2*\[Lambda] + 5*\[Lambda]*conj[Ye33]*T[Ye33] + 
      5*\[Lambda]*conj[Yv11]*T[Yv11] + 5*\[Lambda]*conj[Yv22]*T[Yv22] + 
      5*\[Lambda]*conj[Yv33]*T[Yv33] - 3*g1^2*T[\[Lambda]] - 
      15*g2^2*T[\[Lambda]] - 10*gp^2*QHd^2*T[\[Lambda]] - 
      10*gp^2*QHu^2*T[\[Lambda]] + 10*gp^2*Qs^2*T[\[Lambda]] + 
      5*Ye33*conj[Ye33]*T[\[Lambda]] + 5*Yv11*conj[Yv11]*T[\[Lambda]] + 
      5*Yv22*conj[Yv22]*T[\[Lambda]] + 5*Yv33*conj[Yv33]*T[\[Lambda]] + 
      5*conj[Ye11]*(\[Lambda]*T[Ye11] + Ye11*T[\[Lambda]]) + 
      5*conj[Ye22]*(\[Lambda]*T[Ye22] + Ye22*T[\[Lambda]]) + 
      15*T[\[Lambda]]*trace[Yd, Adj[Yd]] + 15*T[\[Lambda]]*
       trace[Yu, Adj[Yu]] + 15*\[Lambda]*trace[Adj[Yd], T[Yd]] + 
      15*\[Lambda]*trace[Adj[Yu], T[Yu]]))/5 + 
   conj[\[Lambda]]*((12*g1^2*mHd2*\[Lambda])/5 + 12*g2^2*mHd2*\[Lambda] + 
     (12*g1^2*mHu2*\[Lambda])/5 + 12*g2^2*mHu2*\[Lambda] + 
     (12*g1^2*ms2*\[Lambda])/5 + 12*g2^2*ms2*\[Lambda] + 
     8*gp^2*mHd2*QHd^2*\[Lambda] + 8*gp^2*mHu2*QHd^2*\[Lambda] + 
     8*gp^2*ms2*QHd^2*\[Lambda] + 8*gp^2*mHd2*QHu^2*\[Lambda] + 
     8*gp^2*mHu2*QHu^2*\[Lambda] + 8*gp^2*ms2*QHu^2*\[Lambda] - 
     8*gp^2*mHd2*Qs^2*\[Lambda] - 8*gp^2*mHu2*Qs^2*\[Lambda] - 
     8*gp^2*ms2*Qs^2*\[Lambda] - 4*me012*Ye11*\[Lambda]*conj[Ye11] - 
     8*mHd2*Ye11*\[Lambda]*conj[Ye11] - 4*mHu2*Ye11*\[Lambda]*conj[Ye11] - 
     4*ml012*Ye11*\[Lambda]*conj[Ye11] - 4*ms2*Ye11*\[Lambda]*conj[Ye11] - 
     4*me022*Ye22*\[Lambda]*conj[Ye22] - 8*mHd2*Ye22*\[Lambda]*conj[Ye22] - 
     4*mHu2*Ye22*\[Lambda]*conj[Ye22] - 4*ml022*Ye22*\[Lambda]*conj[Ye22] - 
     4*ms2*Ye22*\[Lambda]*conj[Ye22] - 4*me032*Ye33*\[Lambda]*conj[Ye33] - 
     8*mHd2*Ye33*\[Lambda]*conj[Ye33] - 4*mHu2*Ye33*\[Lambda]*conj[Ye33] - 
     4*ml032*Ye33*\[Lambda]*conj[Ye33] - 4*ms2*Ye33*\[Lambda]*conj[Ye33] - 
     4*mHd2*Yv11*\[Lambda]*conj[Yv11] - 8*mHu2*Yv11*\[Lambda]*conj[Yv11] - 
     4*ml012*Yv11*\[Lambda]*conj[Yv11] - 4*ms2*Yv11*\[Lambda]*conj[Yv11] - 
     4*mvR012*Yv11*\[Lambda]*conj[Yv11] - 4*mHd2*Yv22*\[Lambda]*conj[Yv22] - 
     8*mHu2*Yv22*\[Lambda]*conj[Yv22] - 4*ml022*Yv22*\[Lambda]*conj[Yv22] - 
     4*ms2*Yv22*\[Lambda]*conj[Yv22] - 4*mvR022*Yv22*\[Lambda]*conj[Yv22] - 
     4*mHd2*Yv33*\[Lambda]*conj[Yv33] - 8*mHu2*Yv33*\[Lambda]*conj[Yv33] - 
     4*ml032*Yv33*\[Lambda]*conj[Yv33] - 4*ms2*Yv33*\[Lambda]*conj[Yv33] - 
     4*mvR032*Yv33*\[Lambda]*conj[Yv33] - 4*\[Lambda]*conj[T[Ye11]]*T[Ye11] - 
     4*\[Lambda]*conj[T[Ye22]]*T[Ye22] - 4*\[Lambda]*conj[T[Ye33]]*T[Ye33] - 
     4*\[Lambda]*conj[T[Yv11]]*T[Yv11] - 4*\[Lambda]*conj[T[Yv22]]*T[Yv22] - 
     4*\[Lambda]*conj[T[Yv33]]*T[Yv33] + 
     (12*g1^2*conj[MassB]*(2*MassB*\[Lambda] - T[\[Lambda]]))/5 + 
     12*g2^2*conj[MassWB]*(2*MassWB*\[Lambda] - T[\[Lambda]]) - 
     4*Ye11*conj[T[Ye11]]*T[\[Lambda]] - 4*Ye22*conj[T[Ye22]]*T[\[Lambda]] - 
     4*Ye33*conj[T[Ye33]]*T[\[Lambda]] - 4*Yv11*conj[T[Yv11]]*T[\[Lambda]] - 
     4*Yv22*conj[T[Yv22]]*T[\[Lambda]] - 4*Yv33*conj[T[Yv33]]*T[\[Lambda]] - 
     32*\[Lambda]*conj[T[\[Lambda]]]*T[\[Lambda]] - 
     24*mHd2*\[Lambda]*trace[Yd, Adj[Yd]] - 12*mHu2*\[Lambda]*
      trace[Yd, Adj[Yd]] - 12*ms2*\[Lambda]*trace[Yd, Adj[Yd]] - 
     12*mHd2*\[Lambda]*trace[Yu, Adj[Yu]] - 24*mHu2*\[Lambda]*
      trace[Yu, Adj[Yu]] - 12*ms2*\[Lambda]*trace[Yu, Adj[Yu]] - 
     12*T[\[Lambda]]*trace[conj[T[Yd]], Tp[Yd]] - 
     12*\[Lambda]*trace[conj[T[Yd]], Tp[T[Yd]]] - 
     12*T[\[Lambda]]*trace[conj[T[Yu]], Tp[Yu]] - 
     12*\[Lambda]*trace[conj[T[Yu]], Tp[T[Yu]]] - 
     12*\[Lambda]*trace[md2, Yd, Adj[Yd]] - 12*\[Lambda]*
      trace[mq2, Adj[Yd], Yd] - 12*\[Lambda]*trace[mq2, Adj[Yu], Yu] - 
     12*\[Lambda]*trace[mu2, Yu, Adj[Yu]])}}
