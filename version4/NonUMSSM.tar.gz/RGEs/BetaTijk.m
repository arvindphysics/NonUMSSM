{{T[Yd][i1, i2], ((14*g1^2*MassB)/15 + (32*g3^2*MassG)/3 + 6*g2^2*MassWB + 
     4*gp^2*MassU*Qd^2 + 4*gp^2*MassU*QHd^2 + 4*gp^2*MassU*Qq^2 + 
     2*conj[Ye11]*T[Ye11] + 2*conj[Ye22]*T[Ye22] + 2*conj[Ye33]*T[Ye33] + 
     2*conj[\[Lambda]]*T[\[Lambda]] + 6*trace[Adj[Yd], T[Yd]])*Yd[i1, i2] + 
   4*MatMul[Yd, Adj[Yd], T[Yd]][i1, i2] + 
   2*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2] + 
   5*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] + MatMul[T[Yd], Adj[Yu], Yu][i1, 
    i2] - (7*g1^2*T[Yd][i1, i2])/15 - 3*g2^2*T[Yd][i1, i2] - 
   (16*g3^2*T[Yd][i1, i2])/3 - 2*gp^2*Qd^2*T[Yd][i1, i2] - 
   2*gp^2*QHd^2*T[Yd][i1, i2] - 2*gp^2*Qq^2*T[Yd][i1, i2] + 
   Ye11*conj[Ye11]*T[Yd][i1, i2] + Ye22*conj[Ye22]*T[Yd][i1, i2] + 
   Ye33*conj[Ye33]*T[Yd][i1, i2] + \[Lambda]*conj[\[Lambda]]*T[Yd][i1, i2] + 
   3*trace[Yd, Adj[Yd]]*T[Yd][i1, i2], 
  (-2*(287*g1^4*MassB + 45*g1^2*g2^2*MassB + 40*g1^2*g3^2*MassB + 
      40*g1^2*g3^2*MassG + 360*g2^2*g3^2*MassG - 160*g3^4*MassG + 
      45*g1^2*g2^2*MassWB + 675*g2^4*MassWB + 360*g2^2*g3^2*MassWB + 
      132*g1^2*gp^2*MassB*Qd^2 + 480*g3^2*gp^2*MassG*Qd^2 + 
      132*g1^2*gp^2*MassU*Qd^2 + 480*g3^2*gp^2*MassU*Qd^2 + 
      1980*gp^4*MassU*Qd^4 + 36*g1^2*gp^2*MassB*Qd*Qe1 + 
      36*g1^2*gp^2*MassU*Qd*Qe1 + 180*gp^4*MassU*Qd^2*Qe1^2 + 
      36*g1^2*gp^2*MassB*Qd*Qe2 + 36*g1^2*gp^2*MassU*Qd*Qe2 + 
      180*gp^4*MassU*Qd^2*Qe2^2 + 36*g1^2*gp^2*MassB*Qd*Qe3 + 
      36*g1^2*gp^2*MassU*Qd*Qe3 + 180*gp^4*MassU*Qd^2*Qe3^2 - 
      198*g1^2*gp^2*MassB*Qd*QHd - 198*g1^2*gp^2*MassU*Qd*QHd - 
      54*g1^2*gp^2*MassB*Qe1*QHd - 54*g1^2*gp^2*MassU*Qe1*QHd - 
      54*g1^2*gp^2*MassB*Qe2*QHd - 54*g1^2*gp^2*MassU*Qe2*QHd - 
      54*g1^2*gp^2*MassB*Qe3*QHd - 54*g1^2*gp^2*MassU*Qe3*QHd + 
      108*g1^2*gp^2*MassB*QHd^2 + 108*g1^2*gp^2*MassU*QHd^2 + 
      270*g2^2*gp^2*MassU*QHd^2 + 270*g2^2*gp^2*MassWB*QHd^2 + 
      1980*gp^4*MassU*Qd^2*QHd^2 + 180*gp^4*MassU*Qe1^2*QHd^2 + 
      180*gp^4*MassU*Qe2^2*QHd^2 + 180*gp^4*MassU*Qe3^2*QHd^2 + 
      720*gp^4*MassU*QHd^4 + 36*g1^2*gp^2*MassB*Qd*QHu + 
      36*g1^2*gp^2*MassU*Qd*QHu - 54*g1^2*gp^2*MassB*QHd*QHu - 
      54*g1^2*gp^2*MassU*QHd*QHu + 360*gp^4*MassU*Qd^2*QHu^2 + 
      360*gp^4*MassU*QHd^2*QHu^2 - 36*g1^2*gp^2*MassB*Qd*Ql1 - 
      36*g1^2*gp^2*MassU*Qd*Ql1 + 54*g1^2*gp^2*MassB*QHd*Ql1 + 
      54*g1^2*gp^2*MassU*QHd*Ql1 + 360*gp^4*MassU*Qd^2*Ql1^2 + 
      360*gp^4*MassU*QHd^2*Ql1^2 - 36*g1^2*gp^2*MassB*Qd*Ql2 - 
      36*g1^2*gp^2*MassU*Qd*Ql2 + 54*g1^2*gp^2*MassB*QHd*Ql2 + 
      54*g1^2*gp^2*MassU*QHd*Ql2 + 360*gp^4*MassU*Qd^2*Ql2^2 + 
      360*gp^4*MassU*QHd^2*Ql2^2 - 36*g1^2*gp^2*MassB*Qd*Ql3 - 
      36*g1^2*gp^2*MassU*Qd*Ql3 + 54*g1^2*gp^2*MassB*QHd*Ql3 + 
      54*g1^2*gp^2*MassU*QHd*Ql3 + 360*gp^4*MassU*Qd^2*Ql3^2 + 
      360*gp^4*MassU*QHd^2*Ql3^2 + 162*g1^2*gp^2*MassB*Qd*Qq + 
      162*g1^2*gp^2*MassU*Qd*Qq + 18*g1^2*gp^2*MassB*Qe1*Qq + 
      18*g1^2*gp^2*MassU*Qe1*Qq + 18*g1^2*gp^2*MassB*Qe2*Qq + 
      18*g1^2*gp^2*MassU*Qe2*Qq + 18*g1^2*gp^2*MassB*Qe3*Qq + 
      18*g1^2*gp^2*MassU*Qe3*Qq - 180*g1^2*gp^2*MassB*QHd*Qq - 
      180*g1^2*gp^2*MassU*QHd*Qq + 18*g1^2*gp^2*MassB*QHu*Qq + 
      18*g1^2*gp^2*MassU*QHu*Qq - 18*g1^2*gp^2*MassB*Ql1*Qq - 
      18*g1^2*gp^2*MassU*Ql1*Qq - 18*g1^2*gp^2*MassB*Ql2*Qq - 
      18*g1^2*gp^2*MassU*Ql2*Qq - 18*g1^2*gp^2*MassB*Ql3*Qq - 
      18*g1^2*gp^2*MassU*Ql3*Qq + 60*g1^2*gp^2*MassB*Qq^2 + 
      480*g3^2*gp^2*MassG*Qq^2 + 60*g1^2*gp^2*MassU*Qq^2 + 
      270*g2^2*gp^2*MassU*Qq^2 + 480*g3^2*gp^2*MassU*Qq^2 + 
      270*g2^2*gp^2*MassWB*Qq^2 + 4860*gp^4*MassU*Qd^2*Qq^2 + 
      180*gp^4*MassU*Qe1^2*Qq^2 + 180*gp^4*MassU*Qe2^2*Qq^2 + 
      180*gp^4*MassU*Qe3^2*Qq^2 + 3600*gp^4*MassU*QHd^2*Qq^2 + 
      360*gp^4*MassU*QHu^2*Qq^2 + 360*gp^4*MassU*Ql1^2*Qq^2 + 
      360*gp^4*MassU*Ql2^2*Qq^2 + 360*gp^4*MassU*Ql3^2*Qq^2 + 
      3600*gp^4*MassU*Qq^4 + 180*gp^4*MassU*Qd^2*Qs^2 + 
      180*gp^4*MassU*QHd^2*Qs^2 + 180*gp^4*MassU*Qq^2*Qs^2 - 
      216*g1^2*gp^2*MassB*Qd*Qu - 216*g1^2*gp^2*MassU*Qd*Qu + 
      324*g1^2*gp^2*MassB*QHd*Qu + 324*g1^2*gp^2*MassU*QHd*Qu - 
      108*g1^2*gp^2*MassB*Qq*Qu - 108*g1^2*gp^2*MassU*Qq*Qu + 
      1620*gp^4*MassU*Qd^2*Qu^2 + 1620*gp^4*MassU*QHd^2*Qu^2 + 
      1620*gp^4*MassU*Qq^2*Qu^2 + 180*gp^4*MassU*Qd^2*Qv1^2 + 
      180*gp^4*MassU*QHd^2*Qv1^2 + 180*gp^4*MassU*Qq^2*Qv1^2 + 
      180*gp^4*MassU*Qd^2*Qv2^2 + 180*gp^4*MassU*QHd^2*Qv2^2 + 
      180*gp^4*MassU*Qq^2*Qv2^2 + 180*gp^4*MassU*Qd^2*Qv3^2 + 
      180*gp^4*MassU*QHd^2*Qv3^2 + 180*gp^4*MassU*Qq^2*Qv3^2 + 
      54*g1^2*MassB*Ye33*conj[Ye33] + 90*gp^2*MassU*Qe3^2*Ye33*conj[Ye33] - 
      90*gp^2*MassU*QHd^2*Ye33*conj[Ye33] + 90*gp^2*MassU*Ql3^2*Ye33*
       conj[Ye33] - 90*gp^2*MassU*QHd^2*\[Lambda]*conj[\[Lambda]] + 
      90*gp^2*MassU*QHu^2*\[Lambda]*conj[\[Lambda]] + 
      90*gp^2*MassU*Qs^2*\[Lambda]*conj[\[Lambda]] + 
      270*Ye11*conj[Ye11]^2*T[Ye11] + 270*Ye22*conj[Ye22]^2*T[Ye22] - 
      54*g1^2*conj[Ye33]*T[Ye33] - 90*gp^2*Qe3^2*conj[Ye33]*T[Ye33] + 
      90*gp^2*QHd^2*conj[Ye33]*T[Ye33] - 90*gp^2*Ql3^2*conj[Ye33]*T[Ye33] + 
      270*Ye33*conj[Ye33]^2*T[Ye33] + 45*Yv33*conj[Ye33]*conj[Yv33]*T[Ye33] + 
      45*\[Lambda]*conj[Yv11]*conj[\[Lambda]]*T[Yv11] + 
      9*conj[Ye11]*((-6*g1^2 - 10*gp^2*(Qe1^2 - QHd^2 + Ql1^2) + 
          5*Yv11*conj[Yv11])*T[Ye11] + Ye11*(6*g1^2*MassB + 
          10*gp^2*MassU*(Qe1^2 - QHd^2 + Ql1^2) + 5*conj[Yv11]*T[Yv11])) + 
      45*\[Lambda]*conj[Yv22]*conj[\[Lambda]]*T[Yv22] + 
      9*conj[Ye22]*((-6*g1^2 - 10*gp^2*(Qe2^2 - QHd^2 + Ql2^2) + 
          5*Yv22*conj[Yv22])*T[Ye22] + Ye22*(6*g1^2*MassB + 
          10*gp^2*MassU*(Qe2^2 - QHd^2 + Ql2^2) + 5*conj[Yv22]*T[Yv22])) + 
      45*Ye33*conj[Ye33]*conj[Yv33]*T[Yv33] + 45*\[Lambda]*conj[Yv33]*
       conj[\[Lambda]]*T[Yv33] + 90*gp^2*QHd^2*conj[\[Lambda]]*T[\[Lambda]] - 
      90*gp^2*QHu^2*conj[\[Lambda]]*T[\[Lambda]] - 
      90*gp^2*Qs^2*conj[\[Lambda]]*T[\[Lambda]] + 45*Yv11*conj[Yv11]*
       conj[\[Lambda]]*T[\[Lambda]] + 45*Yv22*conj[Yv22]*conj[\[Lambda]]*
       T[\[Lambda]] + 45*Yv33*conj[Yv33]*conj[\[Lambda]]*T[\[Lambda]] + 
      270*\[Lambda]*conj[\[Lambda]]^2*T[\[Lambda]] - 
      18*g1^2*MassB*trace[Yd, Adj[Yd]] + 720*g3^2*MassG*trace[Yd, Adj[Yd]] + 
      270*gp^2*MassU*Qd^2*trace[Yd, Adj[Yd]] - 270*gp^2*MassU*QHd^2*
       trace[Yd, Adj[Yd]] + 270*gp^2*MassU*Qq^2*trace[Yd, Adj[Yd]] + 
      135*conj[\[Lambda]]*T[\[Lambda]]*trace[Yu, Adj[Yu]] + 
      18*g1^2*trace[Adj[Yd], T[Yd]] - 720*g3^2*trace[Adj[Yd], T[Yd]] - 
      270*gp^2*Qd^2*trace[Adj[Yd], T[Yd]] + 270*gp^2*QHd^2*
       trace[Adj[Yd], T[Yd]] - 270*gp^2*Qq^2*trace[Adj[Yd], T[Yd]] + 
      135*\[Lambda]*conj[\[Lambda]]*trace[Adj[Yu], T[Yu]] + 
      810*trace[Yd, Adj[Yd], T[Yd], Adj[Yd]] + 
      135*trace[Yd, Adj[Yu], T[Yu], Adj[Yd]] + 
      135*trace[Yu, Adj[Yd], T[Yd], Adj[Yu]])*Yd[i1, i2])/45 - 
   (2*(4*g1^2*MassB + 30*g2^2*MassWB - 10*gp^2*MassU*Qd^2 + 
      30*gp^2*MassU*QHd^2 + 10*gp^2*MassU*Qq^2 + 15*conj[Ye11]*T[Ye11] + 
      15*conj[Ye22]*T[Ye22] + 15*conj[Ye33]*T[Ye33] + 
      15*conj[\[Lambda]]*T[\[Lambda]] + 45*trace[Adj[Yd], T[Yd]])*
     MatMul[Yd, Adj[Yd], Yd][i1, i2])/5 + 
   (6*g1^2*MatMul[Yd, Adj[Yd], T[Yd]][i1, i2])/5 + 
   6*g2^2*MatMul[Yd, Adj[Yd], T[Yd]][i1, i2] + 
   8*gp^2*QHd^2*MatMul[Yd, Adj[Yd], T[Yd]][i1, i2] - 
   4*Ye11*conj[Ye11]*MatMul[Yd, Adj[Yd], T[Yd]][i1, i2] - 
   4*Ye22*conj[Ye22]*MatMul[Yd, Adj[Yd], T[Yd]][i1, i2] - 
   4*Ye33*conj[Ye33]*MatMul[Yd, Adj[Yd], T[Yd]][i1, i2] - 
   4*\[Lambda]*conj[\[Lambda]]*MatMul[Yd, Adj[Yd], T[Yd]][i1, i2] - 
   12*trace[Yd, Adj[Yd]]*MatMul[Yd, Adj[Yd], T[Yd]][i1, i2] - 
   (8*g1^2*MassB*MatMul[Yd, Adj[Yu], Yu][i1, i2])/5 - 
   4*gp^2*MassU*QHu^2*MatMul[Yd, Adj[Yu], Yu][i1, i2] + 
   4*gp^2*MassU*Qq^2*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   4*gp^2*MassU*Qu^2*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   2*conj[Yv11]*T[Yv11]*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   2*conj[Yv22]*T[Yv22]*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   2*conj[Yv33]*T[Yv33]*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   2*conj[\[Lambda]]*T[\[Lambda]]*MatMul[Yd, Adj[Yu], Yu][i1, i2] - 
   6*trace[Adj[Yu], T[Yu]]*MatMul[Yd, Adj[Yu], Yu][i1, i2] + 
   (8*g1^2*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2])/5 + 
   4*gp^2*QHu^2*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2] - 
   4*gp^2*Qq^2*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2] + 
   4*gp^2*Qu^2*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2] - 
   2*Yv11*conj[Yv11]*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2] - 
   2*Yv22*conj[Yv22]*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2] - 
   2*Yv33*conj[Yv33]*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2] - 
   2*\[Lambda]*conj[\[Lambda]]*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2] - 
   6*trace[Yu, Adj[Yu]]*MatMul[Yd, Adj[Yu], T[Yu]][i1, i2] + 
   (6*g1^2*MatMul[T[Yd], Adj[Yd], Yd][i1, i2])/5 + 
   12*g2^2*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] - 
   6*gp^2*Qd^2*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] + 
   10*gp^2*QHd^2*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] + 
   6*gp^2*Qq^2*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] - 
   5*Ye11*conj[Ye11]*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] - 
   5*Ye22*conj[Ye22]*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] - 
   5*Ye33*conj[Ye33]*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] - 
   5*\[Lambda]*conj[\[Lambda]]*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] - 
   15*trace[Yd, Adj[Yd]]*MatMul[T[Yd], Adj[Yd], Yd][i1, i2] + 
   (4*g1^2*MatMul[T[Yd], Adj[Yu], Yu][i1, i2])/5 + 
   2*gp^2*QHu^2*MatMul[T[Yd], Adj[Yu], Yu][i1, i2] - 
   2*gp^2*Qq^2*MatMul[T[Yd], Adj[Yu], Yu][i1, i2] + 
   2*gp^2*Qu^2*MatMul[T[Yd], Adj[Yu], Yu][i1, i2] - 
   Yv11*conj[Yv11]*MatMul[T[Yd], Adj[Yu], Yu][i1, i2] - 
   Yv22*conj[Yv22]*MatMul[T[Yd], Adj[Yu], Yu][i1, i2] - 
   Yv33*conj[Yv33]*MatMul[T[Yd], Adj[Yu], Yu][i1, i2] - 
   \[Lambda]*conj[\[Lambda]]*MatMul[T[Yd], Adj[Yu], Yu][i1, i2] - 
   3*trace[Yu, Adj[Yu]]*MatMul[T[Yd], Adj[Yu], Yu][i1, i2] - 
   6*MatMul[Yd, Adj[Yd], Yd, Adj[Yd], T[Yd]][i1, i2] - 
   8*MatMul[Yd, Adj[Yd], T[Yd], Adj[Yd], Yd][i1, i2] - 
   2*MatMul[Yd, Adj[Yu], Yu, Adj[Yd], T[Yd]][i1, i2] - 
   4*MatMul[Yd, Adj[Yu], Yu, Adj[Yu], T[Yu]][i1, i2] - 
   4*MatMul[Yd, Adj[Yu], T[Yu], Adj[Yd], Yd][i1, i2] - 
   4*MatMul[Yd, Adj[Yu], T[Yu], Adj[Yu], Yu][i1, i2] - 
   6*MatMul[T[Yd], Adj[Yd], Yd, Adj[Yd], Yd][i1, i2] - 
   4*MatMul[T[Yd], Adj[Yu], Yu, Adj[Yd], Yd][i1, i2] - 
   2*MatMul[T[Yd], Adj[Yu], Yu, Adj[Yu], Yu][i1, i2] + 
   (287*g1^4*T[Yd][i1, i2])/90 + g1^2*g2^2*T[Yd][i1, i2] + 
   (15*g2^4*T[Yd][i1, i2])/2 + (8*g1^2*g3^2*T[Yd][i1, i2])/9 + 
   8*g2^2*g3^2*T[Yd][i1, i2] - (16*g3^4*T[Yd][i1, i2])/9 + 
   (44*g1^2*gp^2*Qd^2*T[Yd][i1, i2])/15 + (32*g3^2*gp^2*Qd^2*T[Yd][i1, i2])/
    3 + 22*gp^4*Qd^4*T[Yd][i1, i2] + (4*g1^2*gp^2*Qd*Qe1*T[Yd][i1, i2])/5 + 
   2*gp^4*Qd^2*Qe1^2*T[Yd][i1, i2] + (4*g1^2*gp^2*Qd*Qe2*T[Yd][i1, i2])/5 + 
   2*gp^4*Qd^2*Qe2^2*T[Yd][i1, i2] + (4*g1^2*gp^2*Qd*Qe3*T[Yd][i1, i2])/5 + 
   2*gp^4*Qd^2*Qe3^2*T[Yd][i1, i2] - (22*g1^2*gp^2*Qd*QHd*T[Yd][i1, i2])/5 - 
   (6*g1^2*gp^2*Qe1*QHd*T[Yd][i1, i2])/5 - 
   (6*g1^2*gp^2*Qe2*QHd*T[Yd][i1, i2])/5 - 
   (6*g1^2*gp^2*Qe3*QHd*T[Yd][i1, i2])/5 + (12*g1^2*gp^2*QHd^2*T[Yd][i1, i2])/
    5 + 6*g2^2*gp^2*QHd^2*T[Yd][i1, i2] + 22*gp^4*Qd^2*QHd^2*T[Yd][i1, i2] + 
   2*gp^4*Qe1^2*QHd^2*T[Yd][i1, i2] + 2*gp^4*Qe2^2*QHd^2*T[Yd][i1, i2] + 
   2*gp^4*Qe3^2*QHd^2*T[Yd][i1, i2] + 8*gp^4*QHd^4*T[Yd][i1, i2] + 
   (4*g1^2*gp^2*Qd*QHu*T[Yd][i1, i2])/5 - (6*g1^2*gp^2*QHd*QHu*T[Yd][i1, i2])/
    5 + 4*gp^4*Qd^2*QHu^2*T[Yd][i1, i2] + 4*gp^4*QHd^2*QHu^2*T[Yd][i1, i2] - 
   (4*g1^2*gp^2*Qd*Ql1*T[Yd][i1, i2])/5 + (6*g1^2*gp^2*QHd*Ql1*T[Yd][i1, i2])/
    5 + 4*gp^4*Qd^2*Ql1^2*T[Yd][i1, i2] + 4*gp^4*QHd^2*Ql1^2*T[Yd][i1, i2] - 
   (4*g1^2*gp^2*Qd*Ql2*T[Yd][i1, i2])/5 + (6*g1^2*gp^2*QHd*Ql2*T[Yd][i1, i2])/
    5 + 4*gp^4*Qd^2*Ql2^2*T[Yd][i1, i2] + 4*gp^4*QHd^2*Ql2^2*T[Yd][i1, i2] - 
   (4*g1^2*gp^2*Qd*Ql3*T[Yd][i1, i2])/5 + (6*g1^2*gp^2*QHd*Ql3*T[Yd][i1, i2])/
    5 + 4*gp^4*Qd^2*Ql3^2*T[Yd][i1, i2] + 4*gp^4*QHd^2*Ql3^2*T[Yd][i1, i2] + 
   (18*g1^2*gp^2*Qd*Qq*T[Yd][i1, i2])/5 + (2*g1^2*gp^2*Qe1*Qq*T[Yd][i1, i2])/
    5 + (2*g1^2*gp^2*Qe2*Qq*T[Yd][i1, i2])/5 + 
   (2*g1^2*gp^2*Qe3*Qq*T[Yd][i1, i2])/5 - 4*g1^2*gp^2*QHd*Qq*T[Yd][i1, i2] + 
   (2*g1^2*gp^2*QHu*Qq*T[Yd][i1, i2])/5 - (2*g1^2*gp^2*Ql1*Qq*T[Yd][i1, i2])/
    5 - (2*g1^2*gp^2*Ql2*Qq*T[Yd][i1, i2])/5 - 
   (2*g1^2*gp^2*Ql3*Qq*T[Yd][i1, i2])/5 + (4*g1^2*gp^2*Qq^2*T[Yd][i1, i2])/
    3 + 6*g2^2*gp^2*Qq^2*T[Yd][i1, i2] + (32*g3^2*gp^2*Qq^2*T[Yd][i1, i2])/
    3 + 54*gp^4*Qd^2*Qq^2*T[Yd][i1, i2] + 2*gp^4*Qe1^2*Qq^2*T[Yd][i1, i2] + 
   2*gp^4*Qe2^2*Qq^2*T[Yd][i1, i2] + 2*gp^4*Qe3^2*Qq^2*T[Yd][i1, i2] + 
   40*gp^4*QHd^2*Qq^2*T[Yd][i1, i2] + 4*gp^4*QHu^2*Qq^2*T[Yd][i1, i2] + 
   4*gp^4*Ql1^2*Qq^2*T[Yd][i1, i2] + 4*gp^4*Ql2^2*Qq^2*T[Yd][i1, i2] + 
   4*gp^4*Ql3^2*Qq^2*T[Yd][i1, i2] + 40*gp^4*Qq^4*T[Yd][i1, i2] + 
   2*gp^4*Qd^2*Qs^2*T[Yd][i1, i2] + 2*gp^4*QHd^2*Qs^2*T[Yd][i1, i2] + 
   2*gp^4*Qq^2*Qs^2*T[Yd][i1, i2] - (24*g1^2*gp^2*Qd*Qu*T[Yd][i1, i2])/5 + 
   (36*g1^2*gp^2*QHd*Qu*T[Yd][i1, i2])/5 - (12*g1^2*gp^2*Qq*Qu*T[Yd][i1, i2])/
    5 + 18*gp^4*Qd^2*Qu^2*T[Yd][i1, i2] + 18*gp^4*QHd^2*Qu^2*T[Yd][i1, i2] + 
   18*gp^4*Qq^2*Qu^2*T[Yd][i1, i2] + 2*gp^4*Qd^2*Qv1^2*T[Yd][i1, i2] + 
   2*gp^4*QHd^2*Qv1^2*T[Yd][i1, i2] + 2*gp^4*Qq^2*Qv1^2*T[Yd][i1, i2] + 
   2*gp^4*Qd^2*Qv2^2*T[Yd][i1, i2] + 2*gp^4*QHd^2*Qv2^2*T[Yd][i1, i2] + 
   2*gp^4*Qq^2*Qv2^2*T[Yd][i1, i2] + 2*gp^4*Qd^2*Qv3^2*T[Yd][i1, i2] + 
   2*gp^4*QHd^2*Qv3^2*T[Yd][i1, i2] + 2*gp^4*Qq^2*Qv3^2*T[Yd][i1, i2] + 
   (6*g1^2*Ye11*conj[Ye11]*T[Yd][i1, i2])/5 + 2*gp^2*Qe1^2*Ye11*conj[Ye11]*
    T[Yd][i1, i2] - 2*gp^2*QHd^2*Ye11*conj[Ye11]*T[Yd][i1, i2] + 
   2*gp^2*Ql1^2*Ye11*conj[Ye11]*T[Yd][i1, i2] - 3*Ye11^2*conj[Ye11]^2*
    T[Yd][i1, i2] + (6*g1^2*Ye22*conj[Ye22]*T[Yd][i1, i2])/5 + 
   2*gp^2*Qe2^2*Ye22*conj[Ye22]*T[Yd][i1, i2] - 2*gp^2*QHd^2*Ye22*conj[Ye22]*
    T[Yd][i1, i2] + 2*gp^2*Ql2^2*Ye22*conj[Ye22]*T[Yd][i1, i2] - 
   3*Ye22^2*conj[Ye22]^2*T[Yd][i1, i2] + 
   (6*g1^2*Ye33*conj[Ye33]*T[Yd][i1, i2])/5 + 2*gp^2*Qe3^2*Ye33*conj[Ye33]*
    T[Yd][i1, i2] - 2*gp^2*QHd^2*Ye33*conj[Ye33]*T[Yd][i1, i2] + 
   2*gp^2*Ql3^2*Ye33*conj[Ye33]*T[Yd][i1, i2] - 3*Ye33^2*conj[Ye33]^2*
    T[Yd][i1, i2] - Ye11*Yv11*conj[Ye11]*conj[Yv11]*T[Yd][i1, i2] - 
   Ye22*Yv22*conj[Ye22]*conj[Yv22]*T[Yd][i1, i2] - 
   Ye33*Yv33*conj[Ye33]*conj[Yv33]*T[Yd][i1, i2] - 
   2*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]]*T[Yd][i1, i2] + 
   2*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]]*T[Yd][i1, i2] + 
   2*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]]*T[Yd][i1, i2] - 
   Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]]*T[Yd][i1, i2] - 
   Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]]*T[Yd][i1, i2] - 
   Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]]*T[Yd][i1, i2] - 
   3*\[Lambda]^2*conj[\[Lambda]]^2*T[Yd][i1, i2] - 
   (2*g1^2*trace[Yd, Adj[Yd]]*T[Yd][i1, i2])/5 + 16*g3^2*trace[Yd, Adj[Yd]]*
    T[Yd][i1, i2] + 6*gp^2*Qd^2*trace[Yd, Adj[Yd]]*T[Yd][i1, i2] - 
   6*gp^2*QHd^2*trace[Yd, Adj[Yd]]*T[Yd][i1, i2] + 
   6*gp^2*Qq^2*trace[Yd, Adj[Yd]]*T[Yd][i1, i2] - 
   3*\[Lambda]*conj[\[Lambda]]*trace[Yu, Adj[Yu]]*T[Yd][i1, i2] - 
   9*trace[Yd, Adj[Yd], Yd, Adj[Yd]]*T[Yd][i1, i2] - 
   3*trace[Yd, Adj[Yu], Yu, Adj[Yd]]*T[Yd][i1, i2]}, 
 {T[Ye11], T[Ye11]*((-9*g1^2)/5 - 3*g2^2 - 2*gp^2*Qe1^2 - 2*gp^2*QHd^2 - 
     2*gp^2*Ql1^2 + 12*Ye11*conj[Ye11] + Ye22*conj[Ye22] + Ye33*conj[Ye33] + 
     Yv11*conj[Yv11] + \[Lambda]*conj[\[Lambda]] + 3*trace[Yd, Adj[Yd]]) + 
   (2*Ye11*(9*g1^2*MassB + 15*g2^2*MassWB + 10*gp^2*MassU*Qe1^2 + 
      10*gp^2*MassU*QHd^2 + 10*gp^2*MassU*Ql1^2 + 5*conj[Ye22]*T[Ye22] + 
      5*conj[Ye33]*T[Ye33] + 5*conj[Yv11]*T[Yv11] + 
      5*conj[\[Lambda]]*T[\[Lambda]] + 15*trace[Adj[Yd], T[Yd]]))/5, 
  (-540*g1^4*MassB*Ye11 - 36*g1^2*g2^2*MassB*Ye11 - 
    36*g1^2*g2^2*MassWB*Ye11 - 300*g2^4*MassWB*Ye11 - 
    144*g1^2*gp^2*MassB*Qd*Qe1*Ye11 - 144*g1^2*gp^2*MassU*Qd*Qe1*Ye11 - 
    144*g1^2*gp^2*MassB*Qe1^2*Ye11 - 144*g1^2*gp^2*MassU*Qe1^2*Ye11 - 
    720*gp^4*MassU*Qd^2*Qe1^2*Ye11 - 240*gp^4*MassU*Qe1^4*Ye11 - 
    48*g1^2*gp^2*MassB*Qe1*Qe2*Ye11 - 48*g1^2*gp^2*MassU*Qe1*Qe2*Ye11 - 
    80*gp^4*MassU*Qe1^2*Qe2^2*Ye11 - 48*g1^2*gp^2*MassB*Qe1*Qe3*Ye11 - 
    48*g1^2*gp^2*MassU*Qe1*Qe3*Ye11 - 80*gp^4*MassU*Qe1^2*Qe3^2*Ye11 + 
    72*g1^2*gp^2*MassB*Qd*QHd*Ye11 + 72*g1^2*gp^2*MassU*Qd*QHd*Ye11 + 
    72*g1^2*gp^2*MassB*Qe1*QHd*Ye11 + 72*g1^2*gp^2*MassU*Qe1*QHd*Ye11 + 
    24*g1^2*gp^2*MassB*Qe2*QHd*Ye11 + 24*g1^2*gp^2*MassU*Qe2*QHd*Ye11 + 
    24*g1^2*gp^2*MassB*Qe3*QHd*Ye11 + 24*g1^2*gp^2*MassU*Qe3*QHd*Ye11 - 
    48*g1^2*gp^2*MassB*QHd^2*Ye11 - 48*g1^2*gp^2*MassU*QHd^2*Ye11 - 
    120*g2^2*gp^2*MassU*QHd^2*Ye11 - 120*g2^2*gp^2*MassWB*QHd^2*Ye11 - 
    720*gp^4*MassU*Qd^2*QHd^2*Ye11 - 240*gp^4*MassU*Qe1^2*QHd^2*Ye11 - 
    80*gp^4*MassU*Qe2^2*QHd^2*Ye11 - 80*gp^4*MassU*Qe3^2*QHd^2*Ye11 - 
    320*gp^4*MassU*QHd^4*Ye11 - 48*g1^2*gp^2*MassB*Qe1*QHu*Ye11 - 
    48*g1^2*gp^2*MassU*Qe1*QHu*Ye11 + 24*g1^2*gp^2*MassB*QHd*QHu*Ye11 + 
    24*g1^2*gp^2*MassU*QHd*QHu*Ye11 - 160*gp^4*MassU*Qe1^2*QHu^2*Ye11 - 
    160*gp^4*MassU*QHd^2*QHu^2*Ye11 + 72*g1^2*gp^2*MassB*Qd*Ql1*Ye11 + 
    72*g1^2*gp^2*MassU*Qd*Ql1*Ye11 + 72*g1^2*gp^2*MassB*Qe1*Ql1*Ye11 + 
    72*g1^2*gp^2*MassU*Qe1*Ql1*Ye11 + 24*g1^2*gp^2*MassB*Qe2*Ql1*Ye11 + 
    24*g1^2*gp^2*MassU*Qe2*Ql1*Ye11 + 24*g1^2*gp^2*MassB*Qe3*Ql1*Ye11 + 
    24*g1^2*gp^2*MassU*Qe3*Ql1*Ye11 - 48*g1^2*gp^2*MassB*QHd*Ql1*Ye11 - 
    48*g1^2*gp^2*MassU*QHd*Ql1*Ye11 + 24*g1^2*gp^2*MassB*QHu*Ql1*Ye11 + 
    24*g1^2*gp^2*MassU*QHu*Ql1*Ye11 - 48*g1^2*gp^2*MassB*Ql1^2*Ye11 - 
    48*g1^2*gp^2*MassU*Ql1^2*Ye11 - 120*g2^2*gp^2*MassU*Ql1^2*Ye11 - 
    120*g2^2*gp^2*MassWB*Ql1^2*Ye11 - 720*gp^4*MassU*Qd^2*Ql1^2*Ye11 - 
    240*gp^4*MassU*Qe1^2*Ql1^2*Ye11 - 80*gp^4*MassU*Qe2^2*Ql1^2*Ye11 - 
    80*gp^4*MassU*Qe3^2*Ql1^2*Ye11 - 320*gp^4*MassU*QHd^2*Ql1^2*Ye11 - 
    160*gp^4*MassU*QHu^2*Ql1^2*Ye11 - 320*gp^4*MassU*Ql1^4*Ye11 + 
    48*g1^2*gp^2*MassB*Qe1*Ql2*Ye11 + 48*g1^2*gp^2*MassU*Qe1*Ql2*Ye11 - 
    24*g1^2*gp^2*MassB*QHd*Ql2*Ye11 - 24*g1^2*gp^2*MassU*QHd*Ql2*Ye11 - 
    24*g1^2*gp^2*MassB*Ql1*Ql2*Ye11 - 24*g1^2*gp^2*MassU*Ql1*Ql2*Ye11 - 
    160*gp^4*MassU*Qe1^2*Ql2^2*Ye11 - 160*gp^4*MassU*QHd^2*Ql2^2*Ye11 - 
    160*gp^4*MassU*Ql1^2*Ql2^2*Ye11 + 48*g1^2*gp^2*MassB*Qe1*Ql3*Ye11 + 
    48*g1^2*gp^2*MassU*Qe1*Ql3*Ye11 - 24*g1^2*gp^2*MassB*QHd*Ql3*Ye11 - 
    24*g1^2*gp^2*MassU*QHd*Ql3*Ye11 - 24*g1^2*gp^2*MassB*Ql1*Ql3*Ye11 - 
    24*g1^2*gp^2*MassU*Ql1*Ql3*Ye11 - 160*gp^4*MassU*Qe1^2*Ql3^2*Ye11 - 
    160*gp^4*MassU*QHd^2*Ql3^2*Ye11 - 160*gp^4*MassU*Ql1^2*Ql3^2*Ye11 - 
    144*g1^2*gp^2*MassB*Qe1*Qq*Ye11 - 144*g1^2*gp^2*MassU*Qe1*Qq*Ye11 + 
    72*g1^2*gp^2*MassB*QHd*Qq*Ye11 + 72*g1^2*gp^2*MassU*QHd*Qq*Ye11 + 
    72*g1^2*gp^2*MassB*Ql1*Qq*Ye11 + 72*g1^2*gp^2*MassU*Ql1*Qq*Ye11 - 
    1440*gp^4*MassU*Qe1^2*Qq^2*Ye11 - 1440*gp^4*MassU*QHd^2*Qq^2*Ye11 - 
    1440*gp^4*MassU*Ql1^2*Qq^2*Ye11 - 80*gp^4*MassU*Qe1^2*Qs^2*Ye11 - 
    80*gp^4*MassU*QHd^2*Qs^2*Ye11 - 80*gp^4*MassU*Ql1^2*Qs^2*Ye11 + 
    288*g1^2*gp^2*MassB*Qe1*Qu*Ye11 + 288*g1^2*gp^2*MassU*Qe1*Qu*Ye11 - 
    144*g1^2*gp^2*MassB*QHd*Qu*Ye11 - 144*g1^2*gp^2*MassU*QHd*Qu*Ye11 - 
    144*g1^2*gp^2*MassB*Ql1*Qu*Ye11 - 144*g1^2*gp^2*MassU*Ql1*Qu*Ye11 - 
    720*gp^4*MassU*Qe1^2*Qu^2*Ye11 - 720*gp^4*MassU*QHd^2*Qu^2*Ye11 - 
    720*gp^4*MassU*Ql1^2*Qu^2*Ye11 - 80*gp^4*MassU*Qe1^2*Qv1^2*Ye11 - 
    80*gp^4*MassU*QHd^2*Qv1^2*Ye11 - 80*gp^4*MassU*Ql1^2*Qv1^2*Ye11 - 
    80*gp^4*MassU*Qe1^2*Qv2^2*Ye11 - 80*gp^4*MassU*QHd^2*Qv2^2*Ye11 - 
    80*gp^4*MassU*Ql1^2*Qv2^2*Ye11 - 80*gp^4*MassU*Qe1^2*Qv3^2*Ye11 - 
    80*gp^4*MassU*QHd^2*Qv3^2*Ye11 - 80*gp^4*MassU*Ql1^2*Qv3^2*Ye11 - 
    40*gp^2*MassU*QHu^2*Ye11*Yv11*conj[Yv11] + 40*gp^2*MassU*Ql1^2*Ye11*Yv11*
     conj[Yv11] - 40*gp^2*MassU*Qv1^2*Ye11*Yv11*conj[Yv11] + 
    40*gp^2*MassU*QHd^2*Ye11*\[Lambda]*conj[\[Lambda]] - 
    40*gp^2*MassU*QHu^2*Ye11*\[Lambda]*conj[\[Lambda]] - 
    40*gp^2*MassU*Qs^2*Ye11*\[Lambda]*conj[\[Lambda]] + 135*g1^4*T[Ye11] + 
    18*g1^2*g2^2*T[Ye11] + 75*g2^4*T[Ye11] + 72*g1^2*gp^2*Qd*Qe1*T[Ye11] + 
    72*g1^2*gp^2*Qe1^2*T[Ye11] + 180*gp^4*Qd^2*Qe1^2*T[Ye11] + 
    60*gp^4*Qe1^4*T[Ye11] + 24*g1^2*gp^2*Qe1*Qe2*T[Ye11] + 
    20*gp^4*Qe1^2*Qe2^2*T[Ye11] + 24*g1^2*gp^2*Qe1*Qe3*T[Ye11] + 
    20*gp^4*Qe1^2*Qe3^2*T[Ye11] - 36*g1^2*gp^2*Qd*QHd*T[Ye11] - 
    36*g1^2*gp^2*Qe1*QHd*T[Ye11] - 12*g1^2*gp^2*Qe2*QHd*T[Ye11] - 
    12*g1^2*gp^2*Qe3*QHd*T[Ye11] + 24*g1^2*gp^2*QHd^2*T[Ye11] + 
    60*g2^2*gp^2*QHd^2*T[Ye11] + 180*gp^4*Qd^2*QHd^2*T[Ye11] + 
    60*gp^4*Qe1^2*QHd^2*T[Ye11] + 20*gp^4*Qe2^2*QHd^2*T[Ye11] + 
    20*gp^4*Qe3^2*QHd^2*T[Ye11] + 80*gp^4*QHd^4*T[Ye11] + 
    24*g1^2*gp^2*Qe1*QHu*T[Ye11] - 12*g1^2*gp^2*QHd*QHu*T[Ye11] + 
    40*gp^4*Qe1^2*QHu^2*T[Ye11] + 40*gp^4*QHd^2*QHu^2*T[Ye11] - 
    36*g1^2*gp^2*Qd*Ql1*T[Ye11] - 36*g1^2*gp^2*Qe1*Ql1*T[Ye11] - 
    12*g1^2*gp^2*Qe2*Ql1*T[Ye11] - 12*g1^2*gp^2*Qe3*Ql1*T[Ye11] + 
    24*g1^2*gp^2*QHd*Ql1*T[Ye11] - 12*g1^2*gp^2*QHu*Ql1*T[Ye11] + 
    24*g1^2*gp^2*Ql1^2*T[Ye11] + 60*g2^2*gp^2*Ql1^2*T[Ye11] + 
    180*gp^4*Qd^2*Ql1^2*T[Ye11] + 60*gp^4*Qe1^2*Ql1^2*T[Ye11] + 
    20*gp^4*Qe2^2*Ql1^2*T[Ye11] + 20*gp^4*Qe3^2*Ql1^2*T[Ye11] + 
    80*gp^4*QHd^2*Ql1^2*T[Ye11] + 40*gp^4*QHu^2*Ql1^2*T[Ye11] + 
    80*gp^4*Ql1^4*T[Ye11] - 24*g1^2*gp^2*Qe1*Ql2*T[Ye11] + 
    12*g1^2*gp^2*QHd*Ql2*T[Ye11] + 12*g1^2*gp^2*Ql1*Ql2*T[Ye11] + 
    40*gp^4*Qe1^2*Ql2^2*T[Ye11] + 40*gp^4*QHd^2*Ql2^2*T[Ye11] + 
    40*gp^4*Ql1^2*Ql2^2*T[Ye11] - 24*g1^2*gp^2*Qe1*Ql3*T[Ye11] + 
    12*g1^2*gp^2*QHd*Ql3*T[Ye11] + 12*g1^2*gp^2*Ql1*Ql3*T[Ye11] + 
    40*gp^4*Qe1^2*Ql3^2*T[Ye11] + 40*gp^4*QHd^2*Ql3^2*T[Ye11] + 
    40*gp^4*Ql1^2*Ql3^2*T[Ye11] + 72*g1^2*gp^2*Qe1*Qq*T[Ye11] - 
    36*g1^2*gp^2*QHd*Qq*T[Ye11] - 36*g1^2*gp^2*Ql1*Qq*T[Ye11] + 
    360*gp^4*Qe1^2*Qq^2*T[Ye11] + 360*gp^4*QHd^2*Qq^2*T[Ye11] + 
    360*gp^4*Ql1^2*Qq^2*T[Ye11] + 20*gp^4*Qe1^2*Qs^2*T[Ye11] + 
    20*gp^4*QHd^2*Qs^2*T[Ye11] + 20*gp^4*Ql1^2*Qs^2*T[Ye11] - 
    144*g1^2*gp^2*Qe1*Qu*T[Ye11] + 72*g1^2*gp^2*QHd*Qu*T[Ye11] + 
    72*g1^2*gp^2*Ql1*Qu*T[Ye11] + 180*gp^4*Qe1^2*Qu^2*T[Ye11] + 
    180*gp^4*QHd^2*Qu^2*T[Ye11] + 180*gp^4*Ql1^2*Qu^2*T[Ye11] + 
    20*gp^4*Qe1^2*Qv1^2*T[Ye11] + 20*gp^4*QHd^2*Qv1^2*T[Ye11] + 
    20*gp^4*Ql1^2*Qv1^2*T[Ye11] + 20*gp^4*Qe1^2*Qv2^2*T[Ye11] + 
    20*gp^4*QHd^2*Qv2^2*T[Ye11] + 20*gp^4*Ql1^2*Qv2^2*T[Ye11] + 
    20*gp^4*Qe1^2*Qv3^2*T[Ye11] + 20*gp^4*QHd^2*Qv3^2*T[Ye11] + 
    20*gp^4*Ql1^2*Qv3^2*T[Ye11] - 500*Ye11^2*conj[Ye11]^2*T[Ye11] + 
    20*gp^2*QHu^2*Yv11*conj[Yv11]*T[Ye11] - 20*gp^2*Ql1^2*Yv11*conj[Yv11]*
     T[Ye11] + 20*gp^2*Qv1^2*Yv11*conj[Yv11]*T[Ye11] - 
    30*Yv11^2*conj[Yv11]^2*T[Ye11] - 10*Yv11*Yv22*conj[Yv11]*conj[Yv22]*
     T[Ye11] - 10*Yv11*Yv33*conj[Yv11]*conj[Yv33]*T[Ye11] - 
    20*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]]*T[Ye11] + 
    20*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]]*T[Ye11] + 
    20*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]]*T[Ye11] - 
    20*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]]*T[Ye11] - 
    10*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]]*T[Ye11] - 
    10*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]]*T[Ye11] - 
    30*\[Lambda]^2*conj[\[Lambda]]^2*T[Ye11] - 30*Ye22*conj[Ye22]^2*
     (Ye22*T[Ye11] + 4*Ye11*T[Ye22]) - 30*Ye33*conj[Ye33]^2*
     (Ye33*T[Ye11] + 4*Ye11*T[Ye33]) + 40*gp^2*QHu^2*Ye11*conj[Yv11]*
     T[Yv11] - 40*gp^2*Ql1^2*Ye11*conj[Yv11]*T[Yv11] + 
    40*gp^2*Qv1^2*Ye11*conj[Yv11]*T[Yv11] - 120*Ye11*Yv11*conj[Yv11]^2*
     T[Yv11] - 20*Ye11*Yv22*conj[Yv11]*conj[Yv22]*T[Yv11] - 
    20*Ye11*Yv33*conj[Yv11]*conj[Yv33]*T[Yv11] - 40*Ye11*\[Lambda]*conj[Yv11]*
     conj[\[Lambda]]*T[Yv11] - 20*Ye11*Yv11*conj[Yv11]*conj[Yv22]*T[Yv22] - 
    20*Ye11*\[Lambda]*conj[Yv22]*conj[\[Lambda]]*T[Yv22] - 
    2*conj[Ye22]*(Ye22*(-6*g1^2 - 10*gp^2*(Qe2^2 - QHd^2 + Ql2^2) + 
        5*Yv22*conj[Yv22])*T[Ye11] + 
      2*Ye11*((-6*g1^2 - 10*gp^2*(Qe2^2 - QHd^2 + Ql2^2) + 5*Yv22*conj[Yv22])*
         T[Ye22] + Ye22*(6*g1^2*MassB + 10*gp^2*MassU*(Qe2^2 - QHd^2 + 
            Ql2^2) + 5*conj[Yv22]*T[Yv22]))) - 20*Ye11*Yv11*conj[Yv11]*
     conj[Yv33]*T[Yv33] - 20*Ye11*\[Lambda]*conj[Yv33]*conj[\[Lambda]]*
     T[Yv33] - 2*conj[Ye33]*
     (Ye33*(-6*g1^2 - 10*gp^2*(Qe3^2 - QHd^2 + Ql3^2) + 5*Yv33*conj[Yv33])*
       T[Ye11] + 2*Ye11*((-6*g1^2 - 10*gp^2*(Qe3^2 - QHd^2 + Ql3^2) + 
          5*Yv33*conj[Yv33])*T[Ye33] + Ye33*(6*g1^2*MassB + 
          10*gp^2*MassU*(Qe3^2 - QHd^2 + Ql3^2) + 5*conj[Yv33]*T[Yv33]))) - 
    40*gp^2*QHd^2*Ye11*conj[\[Lambda]]*T[\[Lambda]] + 
    40*gp^2*QHu^2*Ye11*conj[\[Lambda]]*T[\[Lambda]] + 
    40*gp^2*Qs^2*Ye11*conj[\[Lambda]]*T[\[Lambda]] - 
    40*Ye11*Yv11*conj[Yv11]*conj[\[Lambda]]*T[\[Lambda]] - 
    20*Ye11*Yv22*conj[Yv22]*conj[\[Lambda]]*T[\[Lambda]] - 
    20*Ye11*Yv33*conj[Yv33]*conj[\[Lambda]]*T[\[Lambda]] - 
    120*Ye11*\[Lambda]*conj[\[Lambda]]^2*T[\[Lambda]] + 
    8*g1^2*MassB*Ye11*trace[Yd, Adj[Yd]] - 320*g3^2*MassG*Ye11*
     trace[Yd, Adj[Yd]] - 120*gp^2*MassU*Qd^2*Ye11*trace[Yd, Adj[Yd]] + 
    120*gp^2*MassU*QHd^2*Ye11*trace[Yd, Adj[Yd]] - 
    120*gp^2*MassU*Qq^2*Ye11*trace[Yd, Adj[Yd]] - 
    4*g1^2*T[Ye11]*trace[Yd, Adj[Yd]] + 160*g3^2*T[Ye11]*trace[Yd, Adj[Yd]] + 
    60*gp^2*Qd^2*T[Ye11]*trace[Yd, Adj[Yd]] - 60*gp^2*QHd^2*T[Ye11]*
     trace[Yd, Adj[Yd]] + 60*gp^2*Qq^2*T[Ye11]*trace[Yd, Adj[Yd]] - 
    30*Yv11*conj[Yv11]*T[Ye11]*trace[Yu, Adj[Yu]] - 
    30*\[Lambda]*conj[\[Lambda]]*T[Ye11]*trace[Yu, Adj[Yu]] - 
    60*Ye11*conj[Yv11]*T[Yv11]*trace[Yu, Adj[Yu]] - 
    60*Ye11*conj[\[Lambda]]*T[\[Lambda]]*trace[Yu, Adj[Yu]] - 
    8*g1^2*Ye11*trace[Adj[Yd], T[Yd]] + 320*g3^2*Ye11*trace[Adj[Yd], T[Yd]] + 
    120*gp^2*Qd^2*Ye11*trace[Adj[Yd], T[Yd]] - 120*gp^2*QHd^2*Ye11*
     trace[Adj[Yd], T[Yd]] + 120*gp^2*Qq^2*Ye11*trace[Adj[Yd], T[Yd]] - 
    2*Ye11*conj[Ye11]*(T[Ye11]*(-18*g1^2 - 90*g2^2 - 60*gp^2*QHd^2 - 
        60*gp^2*Ql1^2 + 45*Ye22*conj[Ye22] + 45*Ye33*conj[Ye33] + 
        45*Yv11*conj[Yv11] + 45*\[Lambda]*conj[\[Lambda]] + 
        135*trace[Yd, Adj[Yd]]) + 2*Ye11*(6*g1^2*MassB + 30*g2^2*MassWB + 
        20*gp^2*MassU*QHd^2 + 20*gp^2*MassU*Ql1^2 + 15*conj[Ye22]*T[Ye22] + 
        15*conj[Ye33]*T[Ye33] + 15*conj[Yv11]*T[Yv11] + 
        15*conj[\[Lambda]]*T[\[Lambda]] + 45*trace[Adj[Yd], T[Yd]])) - 
    60*Ye11*Yv11*conj[Yv11]*trace[Adj[Yu], T[Yu]] - 
    60*Ye11*\[Lambda]*conj[\[Lambda]]*trace[Adj[Yu], T[Yu]] - 
    90*T[Ye11]*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 
    360*Ye11*trace[Yd, Adj[Yd], T[Yd], Adj[Yd]] - 
    30*T[Ye11]*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
    60*Ye11*trace[Yd, Adj[Yu], T[Yu], Adj[Yd]] - 
    60*Ye11*trace[Yu, Adj[Yd], T[Yd], Adj[Yu]])/10}, 
 {T[Ye22], conj[Ye11]*(2*Ye22*T[Ye11] + Ye11*T[Ye22]) + 
   T[Ye22]*((-9*g1^2)/5 - 3*g2^2 - 2*gp^2*Qe2^2 - 2*gp^2*QHd^2 - 
     2*gp^2*Ql2^2 + 12*Ye22*conj[Ye22] + Ye33*conj[Ye33] + Yv22*conj[Yv22] + 
     \[Lambda]*conj[\[Lambda]] + 3*trace[Yd, Adj[Yd]]) + 
   (2*Ye22*(9*g1^2*MassB + 15*g2^2*MassWB + 10*gp^2*MassU*Qe2^2 + 
      10*gp^2*MassU*QHd^2 + 10*gp^2*MassU*Ql2^2 + 5*conj[Ye33]*T[Ye33] + 
      5*conj[Yv22]*T[Yv22] + 5*conj[\[Lambda]]*T[\[Lambda]] + 
      15*trace[Adj[Yd], T[Yd]]))/5, 
  (-540*g1^4*MassB*Ye22 - 36*g1^2*g2^2*MassB*Ye22 - 
    36*g1^2*g2^2*MassWB*Ye22 - 300*g2^4*MassWB*Ye22 - 
    144*g1^2*gp^2*MassB*Qd*Qe2*Ye22 - 144*g1^2*gp^2*MassU*Qd*Qe2*Ye22 - 
    48*g1^2*gp^2*MassB*Qe1*Qe2*Ye22 - 48*g1^2*gp^2*MassU*Qe1*Qe2*Ye22 - 
    144*g1^2*gp^2*MassB*Qe2^2*Ye22 - 144*g1^2*gp^2*MassU*Qe2^2*Ye22 - 
    720*gp^4*MassU*Qd^2*Qe2^2*Ye22 - 80*gp^4*MassU*Qe1^2*Qe2^2*Ye22 - 
    240*gp^4*MassU*Qe2^4*Ye22 - 48*g1^2*gp^2*MassB*Qe2*Qe3*Ye22 - 
    48*g1^2*gp^2*MassU*Qe2*Qe3*Ye22 - 80*gp^4*MassU*Qe2^2*Qe3^2*Ye22 + 
    72*g1^2*gp^2*MassB*Qd*QHd*Ye22 + 72*g1^2*gp^2*MassU*Qd*QHd*Ye22 + 
    24*g1^2*gp^2*MassB*Qe1*QHd*Ye22 + 24*g1^2*gp^2*MassU*Qe1*QHd*Ye22 + 
    72*g1^2*gp^2*MassB*Qe2*QHd*Ye22 + 72*g1^2*gp^2*MassU*Qe2*QHd*Ye22 + 
    24*g1^2*gp^2*MassB*Qe3*QHd*Ye22 + 24*g1^2*gp^2*MassU*Qe3*QHd*Ye22 - 
    48*g1^2*gp^2*MassB*QHd^2*Ye22 - 48*g1^2*gp^2*MassU*QHd^2*Ye22 - 
    120*g2^2*gp^2*MassU*QHd^2*Ye22 - 120*g2^2*gp^2*MassWB*QHd^2*Ye22 - 
    720*gp^4*MassU*Qd^2*QHd^2*Ye22 - 80*gp^4*MassU*Qe1^2*QHd^2*Ye22 - 
    240*gp^4*MassU*Qe2^2*QHd^2*Ye22 - 80*gp^4*MassU*Qe3^2*QHd^2*Ye22 - 
    320*gp^4*MassU*QHd^4*Ye22 - 48*g1^2*gp^2*MassB*Qe2*QHu*Ye22 - 
    48*g1^2*gp^2*MassU*Qe2*QHu*Ye22 + 24*g1^2*gp^2*MassB*QHd*QHu*Ye22 + 
    24*g1^2*gp^2*MassU*QHd*QHu*Ye22 - 160*gp^4*MassU*Qe2^2*QHu^2*Ye22 - 
    160*gp^4*MassU*QHd^2*QHu^2*Ye22 + 48*g1^2*gp^2*MassB*Qe2*Ql1*Ye22 + 
    48*g1^2*gp^2*MassU*Qe2*Ql1*Ye22 - 24*g1^2*gp^2*MassB*QHd*Ql1*Ye22 - 
    24*g1^2*gp^2*MassU*QHd*Ql1*Ye22 - 160*gp^4*MassU*Qe2^2*Ql1^2*Ye22 - 
    160*gp^4*MassU*QHd^2*Ql1^2*Ye22 + 72*g1^2*gp^2*MassB*Qd*Ql2*Ye22 + 
    72*g1^2*gp^2*MassU*Qd*Ql2*Ye22 + 24*g1^2*gp^2*MassB*Qe1*Ql2*Ye22 + 
    24*g1^2*gp^2*MassU*Qe1*Ql2*Ye22 + 72*g1^2*gp^2*MassB*Qe2*Ql2*Ye22 + 
    72*g1^2*gp^2*MassU*Qe2*Ql2*Ye22 + 24*g1^2*gp^2*MassB*Qe3*Ql2*Ye22 + 
    24*g1^2*gp^2*MassU*Qe3*Ql2*Ye22 - 48*g1^2*gp^2*MassB*QHd*Ql2*Ye22 - 
    48*g1^2*gp^2*MassU*QHd*Ql2*Ye22 + 24*g1^2*gp^2*MassB*QHu*Ql2*Ye22 + 
    24*g1^2*gp^2*MassU*QHu*Ql2*Ye22 - 24*g1^2*gp^2*MassB*Ql1*Ql2*Ye22 - 
    24*g1^2*gp^2*MassU*Ql1*Ql2*Ye22 - 48*g1^2*gp^2*MassB*Ql2^2*Ye22 - 
    48*g1^2*gp^2*MassU*Ql2^2*Ye22 - 120*g2^2*gp^2*MassU*Ql2^2*Ye22 - 
    120*g2^2*gp^2*MassWB*Ql2^2*Ye22 - 720*gp^4*MassU*Qd^2*Ql2^2*Ye22 - 
    80*gp^4*MassU*Qe1^2*Ql2^2*Ye22 - 240*gp^4*MassU*Qe2^2*Ql2^2*Ye22 - 
    80*gp^4*MassU*Qe3^2*Ql2^2*Ye22 - 320*gp^4*MassU*QHd^2*Ql2^2*Ye22 - 
    160*gp^4*MassU*QHu^2*Ql2^2*Ye22 - 160*gp^4*MassU*Ql1^2*Ql2^2*Ye22 - 
    320*gp^4*MassU*Ql2^4*Ye22 + 48*g1^2*gp^2*MassB*Qe2*Ql3*Ye22 + 
    48*g1^2*gp^2*MassU*Qe2*Ql3*Ye22 - 24*g1^2*gp^2*MassB*QHd*Ql3*Ye22 - 
    24*g1^2*gp^2*MassU*QHd*Ql3*Ye22 - 24*g1^2*gp^2*MassB*Ql2*Ql3*Ye22 - 
    24*g1^2*gp^2*MassU*Ql2*Ql3*Ye22 - 160*gp^4*MassU*Qe2^2*Ql3^2*Ye22 - 
    160*gp^4*MassU*QHd^2*Ql3^2*Ye22 - 160*gp^4*MassU*Ql2^2*Ql3^2*Ye22 - 
    144*g1^2*gp^2*MassB*Qe2*Qq*Ye22 - 144*g1^2*gp^2*MassU*Qe2*Qq*Ye22 + 
    72*g1^2*gp^2*MassB*QHd*Qq*Ye22 + 72*g1^2*gp^2*MassU*QHd*Qq*Ye22 + 
    72*g1^2*gp^2*MassB*Ql2*Qq*Ye22 + 72*g1^2*gp^2*MassU*Ql2*Qq*Ye22 - 
    1440*gp^4*MassU*Qe2^2*Qq^2*Ye22 - 1440*gp^4*MassU*QHd^2*Qq^2*Ye22 - 
    1440*gp^4*MassU*Ql2^2*Qq^2*Ye22 - 80*gp^4*MassU*Qe2^2*Qs^2*Ye22 - 
    80*gp^4*MassU*QHd^2*Qs^2*Ye22 - 80*gp^4*MassU*Ql2^2*Qs^2*Ye22 + 
    288*g1^2*gp^2*MassB*Qe2*Qu*Ye22 + 288*g1^2*gp^2*MassU*Qe2*Qu*Ye22 - 
    144*g1^2*gp^2*MassB*QHd*Qu*Ye22 - 144*g1^2*gp^2*MassU*QHd*Qu*Ye22 - 
    144*g1^2*gp^2*MassB*Ql2*Qu*Ye22 - 144*g1^2*gp^2*MassU*Ql2*Qu*Ye22 - 
    720*gp^4*MassU*Qe2^2*Qu^2*Ye22 - 720*gp^4*MassU*QHd^2*Qu^2*Ye22 - 
    720*gp^4*MassU*Ql2^2*Qu^2*Ye22 - 80*gp^4*MassU*Qe2^2*Qv1^2*Ye22 - 
    80*gp^4*MassU*QHd^2*Qv1^2*Ye22 - 80*gp^4*MassU*Ql2^2*Qv1^2*Ye22 - 
    80*gp^4*MassU*Qe2^2*Qv2^2*Ye22 - 80*gp^4*MassU*QHd^2*Qv2^2*Ye22 - 
    80*gp^4*MassU*Ql2^2*Qv2^2*Ye22 - 80*gp^4*MassU*Qe2^2*Qv3^2*Ye22 - 
    80*gp^4*MassU*QHd^2*Qv3^2*Ye22 - 80*gp^4*MassU*Ql2^2*Qv3^2*Ye22 - 
    24*g1^2*MassB*Ye22*Ye33*conj[Ye33] - 40*gp^2*MassU*Qe3^2*Ye22*Ye33*
     conj[Ye33] + 40*gp^2*MassU*QHd^2*Ye22*Ye33*conj[Ye33] - 
    40*gp^2*MassU*Ql3^2*Ye22*Ye33*conj[Ye33] - 40*gp^2*MassU*QHu^2*Ye22*Yv22*
     conj[Yv22] + 40*gp^2*MassU*Ql2^2*Ye22*Yv22*conj[Yv22] - 
    40*gp^2*MassU*Qv2^2*Ye22*Yv22*conj[Yv22] + 40*gp^2*MassU*QHd^2*Ye22*
     \[Lambda]*conj[\[Lambda]] - 40*gp^2*MassU*QHu^2*Ye22*\[Lambda]*
     conj[\[Lambda]] - 40*gp^2*MassU*Qs^2*Ye22*\[Lambda]*conj[\[Lambda]] + 
    135*g1^4*T[Ye22] + 18*g1^2*g2^2*T[Ye22] + 75*g2^4*T[Ye22] + 
    72*g1^2*gp^2*Qd*Qe2*T[Ye22] + 24*g1^2*gp^2*Qe1*Qe2*T[Ye22] + 
    72*g1^2*gp^2*Qe2^2*T[Ye22] + 180*gp^4*Qd^2*Qe2^2*T[Ye22] + 
    20*gp^4*Qe1^2*Qe2^2*T[Ye22] + 60*gp^4*Qe2^4*T[Ye22] + 
    24*g1^2*gp^2*Qe2*Qe3*T[Ye22] + 20*gp^4*Qe2^2*Qe3^2*T[Ye22] - 
    36*g1^2*gp^2*Qd*QHd*T[Ye22] - 12*g1^2*gp^2*Qe1*QHd*T[Ye22] - 
    36*g1^2*gp^2*Qe2*QHd*T[Ye22] - 12*g1^2*gp^2*Qe3*QHd*T[Ye22] + 
    24*g1^2*gp^2*QHd^2*T[Ye22] + 60*g2^2*gp^2*QHd^2*T[Ye22] + 
    180*gp^4*Qd^2*QHd^2*T[Ye22] + 20*gp^4*Qe1^2*QHd^2*T[Ye22] + 
    60*gp^4*Qe2^2*QHd^2*T[Ye22] + 20*gp^4*Qe3^2*QHd^2*T[Ye22] + 
    80*gp^4*QHd^4*T[Ye22] + 24*g1^2*gp^2*Qe2*QHu*T[Ye22] - 
    12*g1^2*gp^2*QHd*QHu*T[Ye22] + 40*gp^4*Qe2^2*QHu^2*T[Ye22] + 
    40*gp^4*QHd^2*QHu^2*T[Ye22] - 24*g1^2*gp^2*Qe2*Ql1*T[Ye22] + 
    12*g1^2*gp^2*QHd*Ql1*T[Ye22] + 40*gp^4*Qe2^2*Ql1^2*T[Ye22] + 
    40*gp^4*QHd^2*Ql1^2*T[Ye22] - 36*g1^2*gp^2*Qd*Ql2*T[Ye22] - 
    12*g1^2*gp^2*Qe1*Ql2*T[Ye22] - 36*g1^2*gp^2*Qe2*Ql2*T[Ye22] - 
    12*g1^2*gp^2*Qe3*Ql2*T[Ye22] + 24*g1^2*gp^2*QHd*Ql2*T[Ye22] - 
    12*g1^2*gp^2*QHu*Ql2*T[Ye22] + 12*g1^2*gp^2*Ql1*Ql2*T[Ye22] + 
    24*g1^2*gp^2*Ql2^2*T[Ye22] + 60*g2^2*gp^2*Ql2^2*T[Ye22] + 
    180*gp^4*Qd^2*Ql2^2*T[Ye22] + 20*gp^4*Qe1^2*Ql2^2*T[Ye22] + 
    60*gp^4*Qe2^2*Ql2^2*T[Ye22] + 20*gp^4*Qe3^2*Ql2^2*T[Ye22] + 
    80*gp^4*QHd^2*Ql2^2*T[Ye22] + 40*gp^4*QHu^2*Ql2^2*T[Ye22] + 
    40*gp^4*Ql1^2*Ql2^2*T[Ye22] + 80*gp^4*Ql2^4*T[Ye22] - 
    24*g1^2*gp^2*Qe2*Ql3*T[Ye22] + 12*g1^2*gp^2*QHd*Ql3*T[Ye22] + 
    12*g1^2*gp^2*Ql2*Ql3*T[Ye22] + 40*gp^4*Qe2^2*Ql3^2*T[Ye22] + 
    40*gp^4*QHd^2*Ql3^2*T[Ye22] + 40*gp^4*Ql2^2*Ql3^2*T[Ye22] + 
    72*g1^2*gp^2*Qe2*Qq*T[Ye22] - 36*g1^2*gp^2*QHd*Qq*T[Ye22] - 
    36*g1^2*gp^2*Ql2*Qq*T[Ye22] + 360*gp^4*Qe2^2*Qq^2*T[Ye22] + 
    360*gp^4*QHd^2*Qq^2*T[Ye22] + 360*gp^4*Ql2^2*Qq^2*T[Ye22] + 
    20*gp^4*Qe2^2*Qs^2*T[Ye22] + 20*gp^4*QHd^2*Qs^2*T[Ye22] + 
    20*gp^4*Ql2^2*Qs^2*T[Ye22] - 144*g1^2*gp^2*Qe2*Qu*T[Ye22] + 
    72*g1^2*gp^2*QHd*Qu*T[Ye22] + 72*g1^2*gp^2*Ql2*Qu*T[Ye22] + 
    180*gp^4*Qe2^2*Qu^2*T[Ye22] + 180*gp^4*QHd^2*Qu^2*T[Ye22] + 
    180*gp^4*Ql2^2*Qu^2*T[Ye22] + 20*gp^4*Qe2^2*Qv1^2*T[Ye22] + 
    20*gp^4*QHd^2*Qv1^2*T[Ye22] + 20*gp^4*Ql2^2*Qv1^2*T[Ye22] + 
    20*gp^4*Qe2^2*Qv2^2*T[Ye22] + 20*gp^4*QHd^2*Qv2^2*T[Ye22] + 
    20*gp^4*Ql2^2*Qv2^2*T[Ye22] + 20*gp^4*Qe2^2*Qv3^2*T[Ye22] + 
    20*gp^4*QHd^2*Qv3^2*T[Ye22] + 20*gp^4*Ql2^2*Qv3^2*T[Ye22] - 
    500*Ye22^2*conj[Ye22]^2*T[Ye22] + 12*g1^2*Ye33*conj[Ye33]*T[Ye22] + 
    20*gp^2*Qe3^2*Ye33*conj[Ye33]*T[Ye22] - 20*gp^2*QHd^2*Ye33*conj[Ye33]*
     T[Ye22] + 20*gp^2*Ql3^2*Ye33*conj[Ye33]*T[Ye22] - 
    30*Ye33^2*conj[Ye33]^2*T[Ye22] + 20*gp^2*QHu^2*Yv22*conj[Yv22]*T[Ye22] - 
    20*gp^2*Ql2^2*Yv22*conj[Yv22]*T[Ye22] + 20*gp^2*Qv2^2*Yv22*conj[Yv22]*
     T[Ye22] - 10*Yv11*Yv22*conj[Yv11]*conj[Yv22]*T[Ye22] - 
    30*Yv22^2*conj[Yv22]^2*T[Ye22] - 10*Ye33*Yv33*conj[Ye33]*conj[Yv33]*
     T[Ye22] - 10*Yv22*Yv33*conj[Yv22]*conj[Yv33]*T[Ye22] - 
    20*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]]*T[Ye22] + 
    20*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]]*T[Ye22] + 
    20*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]]*T[Ye22] - 
    10*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]]*T[Ye22] - 
    20*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]]*T[Ye22] - 
    10*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]]*T[Ye22] - 
    30*\[Lambda]^2*conj[\[Lambda]]^2*T[Ye22] - 30*Ye11*conj[Ye11]^2*
     (4*Ye22*T[Ye11] + Ye11*T[Ye22]) + 24*g1^2*Ye22*conj[Ye33]*T[Ye33] + 
    40*gp^2*Qe3^2*Ye22*conj[Ye33]*T[Ye33] - 40*gp^2*QHd^2*Ye22*conj[Ye33]*
     T[Ye33] + 40*gp^2*Ql3^2*Ye22*conj[Ye33]*T[Ye33] - 
    120*Ye22*Ye33*conj[Ye33]^2*T[Ye33] - 20*Ye22*Yv33*conj[Ye33]*conj[Yv33]*
     T[Ye33] - 20*Ye22*Yv22*conj[Yv11]*conj[Yv22]*T[Yv11] - 
    20*Ye22*\[Lambda]*conj[Yv11]*conj[\[Lambda]]*T[Yv11] - 
    2*conj[Ye11]*(2*Ye22*(-6*g1^2 - 10*gp^2*(Qe1^2 - QHd^2 + Ql1^2) + 
        15*Ye22*conj[Ye22] + 5*Yv11*conj[Yv11])*T[Ye11] + 
      Ye11*(-6*g1^2 - 10*gp^2*(Qe1^2 - QHd^2 + Ql1^2) + 45*Ye22*conj[Ye22] + 
        5*Yv11*conj[Yv11])*T[Ye22] + 2*Ye11*Ye22*(6*g1^2*MassB + 
        10*gp^2*MassU*(Qe1^2 - QHd^2 + Ql1^2) + 5*conj[Yv11]*T[Yv11])) + 
    40*gp^2*QHu^2*Ye22*conj[Yv22]*T[Yv22] - 40*gp^2*Ql2^2*Ye22*conj[Yv22]*
     T[Yv22] + 40*gp^2*Qv2^2*Ye22*conj[Yv22]*T[Yv22] - 
    20*Ye22*Yv11*conj[Yv11]*conj[Yv22]*T[Yv22] - 120*Ye22*Yv22*conj[Yv22]^2*
     T[Yv22] - 20*Ye22*Yv33*conj[Yv22]*conj[Yv33]*T[Yv22] - 
    40*Ye22*\[Lambda]*conj[Yv22]*conj[\[Lambda]]*T[Yv22] - 
    20*Ye22*Ye33*conj[Ye33]*conj[Yv33]*T[Yv33] - 20*Ye22*Yv22*conj[Yv22]*
     conj[Yv33]*T[Yv33] - 20*Ye22*\[Lambda]*conj[Yv33]*conj[\[Lambda]]*
     T[Yv33] - 40*gp^2*QHd^2*Ye22*conj[\[Lambda]]*T[\[Lambda]] + 
    40*gp^2*QHu^2*Ye22*conj[\[Lambda]]*T[\[Lambda]] + 
    40*gp^2*Qs^2*Ye22*conj[\[Lambda]]*T[\[Lambda]] - 
    20*Ye22*Yv11*conj[Yv11]*conj[\[Lambda]]*T[\[Lambda]] - 
    40*Ye22*Yv22*conj[Yv22]*conj[\[Lambda]]*T[\[Lambda]] - 
    20*Ye22*Yv33*conj[Yv33]*conj[\[Lambda]]*T[\[Lambda]] - 
    120*Ye22*\[Lambda]*conj[\[Lambda]]^2*T[\[Lambda]] + 
    8*g1^2*MassB*Ye22*trace[Yd, Adj[Yd]] - 320*g3^2*MassG*Ye22*
     trace[Yd, Adj[Yd]] - 120*gp^2*MassU*Qd^2*Ye22*trace[Yd, Adj[Yd]] + 
    120*gp^2*MassU*QHd^2*Ye22*trace[Yd, Adj[Yd]] - 
    120*gp^2*MassU*Qq^2*Ye22*trace[Yd, Adj[Yd]] - 
    4*g1^2*T[Ye22]*trace[Yd, Adj[Yd]] + 160*g3^2*T[Ye22]*trace[Yd, Adj[Yd]] + 
    60*gp^2*Qd^2*T[Ye22]*trace[Yd, Adj[Yd]] - 60*gp^2*QHd^2*T[Ye22]*
     trace[Yd, Adj[Yd]] + 60*gp^2*Qq^2*T[Ye22]*trace[Yd, Adj[Yd]] - 
    30*Yv22*conj[Yv22]*T[Ye22]*trace[Yu, Adj[Yu]] - 
    30*\[Lambda]*conj[\[Lambda]]*T[Ye22]*trace[Yu, Adj[Yu]] - 
    60*Ye22*conj[Yv22]*T[Yv22]*trace[Yu, Adj[Yu]] - 
    60*Ye22*conj[\[Lambda]]*T[\[Lambda]]*trace[Yu, Adj[Yu]] - 
    8*g1^2*Ye22*trace[Adj[Yd], T[Yd]] + 320*g3^2*Ye22*trace[Adj[Yd], T[Yd]] + 
    120*gp^2*Qd^2*Ye22*trace[Adj[Yd], T[Yd]] - 120*gp^2*QHd^2*Ye22*
     trace[Adj[Yd], T[Yd]] + 120*gp^2*Qq^2*Ye22*trace[Adj[Yd], T[Yd]] - 
    2*Ye22*conj[Ye22]*(-3*T[Ye22]*(6*g1^2 + 30*g2^2 + 20*gp^2*QHd^2 + 
        20*gp^2*Ql2^2 - 15*Ye33*conj[Ye33] - 15*Yv22*conj[Yv22] - 
        15*\[Lambda]*conj[\[Lambda]] - 45*trace[Yd, Adj[Yd]]) + 
      2*Ye22*(6*g1^2*MassB + 30*g2^2*MassWB + 20*gp^2*MassU*QHd^2 + 
        20*gp^2*MassU*Ql2^2 + 15*conj[Ye33]*T[Ye33] + 15*conj[Yv22]*T[Yv22] + 
        15*conj[\[Lambda]]*T[\[Lambda]] + 45*trace[Adj[Yd], T[Yd]])) - 
    60*Ye22*Yv22*conj[Yv22]*trace[Adj[Yu], T[Yu]] - 
    60*Ye22*\[Lambda]*conj[\[Lambda]]*trace[Adj[Yu], T[Yu]] - 
    90*T[Ye22]*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 
    360*Ye22*trace[Yd, Adj[Yd], T[Yd], Adj[Yd]] - 
    30*T[Ye22]*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
    60*Ye22*trace[Yd, Adj[Yu], T[Yu], Adj[Yd]] - 
    60*Ye22*trace[Yu, Adj[Yd], T[Yd], Adj[Yu]])/10}, 
 {T[Ye33], (18*g1^2*MassB*Ye33)/5 + 6*g2^2*MassWB*Ye33 + 
   4*gp^2*MassU*Qe3^2*Ye33 + 4*gp^2*MassU*QHd^2*Ye33 + 
   4*gp^2*MassU*Ql3^2*Ye33 - (9*g1^2*T[Ye33])/5 - 3*g2^2*T[Ye33] - 
   2*gp^2*Qe3^2*T[Ye33] - 2*gp^2*QHd^2*T[Ye33] - 2*gp^2*Ql3^2*T[Ye33] + 
   12*Ye33*conj[Ye33]*T[Ye33] + Yv33*conj[Yv33]*T[Ye33] + 
   \[Lambda]*conj[\[Lambda]]*T[Ye33] + 
   conj[Ye11]*(2*Ye33*T[Ye11] + Ye11*T[Ye33]) + 
   conj[Ye22]*(2*Ye33*T[Ye22] + Ye22*T[Ye33]) + 2*Ye33*conj[Yv33]*T[Yv33] + 
   2*Ye33*conj[\[Lambda]]*T[\[Lambda]] + 3*T[Ye33]*trace[Yd, Adj[Yd]] + 
   6*Ye33*trace[Adj[Yd], T[Yd]], 
  (-540*g1^4*MassB*Ye33 - 36*g1^2*g2^2*MassB*Ye33 - 
    36*g1^2*g2^2*MassWB*Ye33 - 300*g2^4*MassWB*Ye33 - 
    144*g1^2*gp^2*MassB*Qd*Qe3*Ye33 - 144*g1^2*gp^2*MassU*Qd*Qe3*Ye33 - 
    48*g1^2*gp^2*MassB*Qe1*Qe3*Ye33 - 48*g1^2*gp^2*MassU*Qe1*Qe3*Ye33 - 
    48*g1^2*gp^2*MassB*Qe2*Qe3*Ye33 - 48*g1^2*gp^2*MassU*Qe2*Qe3*Ye33 - 
    144*g1^2*gp^2*MassB*Qe3^2*Ye33 - 144*g1^2*gp^2*MassU*Qe3^2*Ye33 - 
    720*gp^4*MassU*Qd^2*Qe3^2*Ye33 - 80*gp^4*MassU*Qe1^2*Qe3^2*Ye33 - 
    80*gp^4*MassU*Qe2^2*Qe3^2*Ye33 - 240*gp^4*MassU*Qe3^4*Ye33 + 
    72*g1^2*gp^2*MassB*Qd*QHd*Ye33 + 72*g1^2*gp^2*MassU*Qd*QHd*Ye33 + 
    24*g1^2*gp^2*MassB*Qe1*QHd*Ye33 + 24*g1^2*gp^2*MassU*Qe1*QHd*Ye33 + 
    24*g1^2*gp^2*MassB*Qe2*QHd*Ye33 + 24*g1^2*gp^2*MassU*Qe2*QHd*Ye33 + 
    72*g1^2*gp^2*MassB*Qe3*QHd*Ye33 + 72*g1^2*gp^2*MassU*Qe3*QHd*Ye33 - 
    48*g1^2*gp^2*MassB*QHd^2*Ye33 - 48*g1^2*gp^2*MassU*QHd^2*Ye33 - 
    120*g2^2*gp^2*MassU*QHd^2*Ye33 - 120*g2^2*gp^2*MassWB*QHd^2*Ye33 - 
    720*gp^4*MassU*Qd^2*QHd^2*Ye33 - 80*gp^4*MassU*Qe1^2*QHd^2*Ye33 - 
    80*gp^4*MassU*Qe2^2*QHd^2*Ye33 - 240*gp^4*MassU*Qe3^2*QHd^2*Ye33 - 
    320*gp^4*MassU*QHd^4*Ye33 - 48*g1^2*gp^2*MassB*Qe3*QHu*Ye33 - 
    48*g1^2*gp^2*MassU*Qe3*QHu*Ye33 + 24*g1^2*gp^2*MassB*QHd*QHu*Ye33 + 
    24*g1^2*gp^2*MassU*QHd*QHu*Ye33 - 160*gp^4*MassU*Qe3^2*QHu^2*Ye33 - 
    160*gp^4*MassU*QHd^2*QHu^2*Ye33 + 48*g1^2*gp^2*MassB*Qe3*Ql1*Ye33 + 
    48*g1^2*gp^2*MassU*Qe3*Ql1*Ye33 - 24*g1^2*gp^2*MassB*QHd*Ql1*Ye33 - 
    24*g1^2*gp^2*MassU*QHd*Ql1*Ye33 - 160*gp^4*MassU*Qe3^2*Ql1^2*Ye33 - 
    160*gp^4*MassU*QHd^2*Ql1^2*Ye33 + 48*g1^2*gp^2*MassB*Qe3*Ql2*Ye33 + 
    48*g1^2*gp^2*MassU*Qe3*Ql2*Ye33 - 24*g1^2*gp^2*MassB*QHd*Ql2*Ye33 - 
    24*g1^2*gp^2*MassU*QHd*Ql2*Ye33 - 160*gp^4*MassU*Qe3^2*Ql2^2*Ye33 - 
    160*gp^4*MassU*QHd^2*Ql2^2*Ye33 + 72*g1^2*gp^2*MassB*Qd*Ql3*Ye33 + 
    72*g1^2*gp^2*MassU*Qd*Ql3*Ye33 + 24*g1^2*gp^2*MassB*Qe1*Ql3*Ye33 + 
    24*g1^2*gp^2*MassU*Qe1*Ql3*Ye33 + 24*g1^2*gp^2*MassB*Qe2*Ql3*Ye33 + 
    24*g1^2*gp^2*MassU*Qe2*Ql3*Ye33 + 72*g1^2*gp^2*MassB*Qe3*Ql3*Ye33 + 
    72*g1^2*gp^2*MassU*Qe3*Ql3*Ye33 - 48*g1^2*gp^2*MassB*QHd*Ql3*Ye33 - 
    48*g1^2*gp^2*MassU*QHd*Ql3*Ye33 + 24*g1^2*gp^2*MassB*QHu*Ql3*Ye33 + 
    24*g1^2*gp^2*MassU*QHu*Ql3*Ye33 - 24*g1^2*gp^2*MassB*Ql1*Ql3*Ye33 - 
    24*g1^2*gp^2*MassU*Ql1*Ql3*Ye33 - 24*g1^2*gp^2*MassB*Ql2*Ql3*Ye33 - 
    24*g1^2*gp^2*MassU*Ql2*Ql3*Ye33 - 48*g1^2*gp^2*MassB*Ql3^2*Ye33 - 
    48*g1^2*gp^2*MassU*Ql3^2*Ye33 - 120*g2^2*gp^2*MassU*Ql3^2*Ye33 - 
    120*g2^2*gp^2*MassWB*Ql3^2*Ye33 - 720*gp^4*MassU*Qd^2*Ql3^2*Ye33 - 
    80*gp^4*MassU*Qe1^2*Ql3^2*Ye33 - 80*gp^4*MassU*Qe2^2*Ql3^2*Ye33 - 
    240*gp^4*MassU*Qe3^2*Ql3^2*Ye33 - 320*gp^4*MassU*QHd^2*Ql3^2*Ye33 - 
    160*gp^4*MassU*QHu^2*Ql3^2*Ye33 - 160*gp^4*MassU*Ql1^2*Ql3^2*Ye33 - 
    160*gp^4*MassU*Ql2^2*Ql3^2*Ye33 - 320*gp^4*MassU*Ql3^4*Ye33 - 
    144*g1^2*gp^2*MassB*Qe3*Qq*Ye33 - 144*g1^2*gp^2*MassU*Qe3*Qq*Ye33 + 
    72*g1^2*gp^2*MassB*QHd*Qq*Ye33 + 72*g1^2*gp^2*MassU*QHd*Qq*Ye33 + 
    72*g1^2*gp^2*MassB*Ql3*Qq*Ye33 + 72*g1^2*gp^2*MassU*Ql3*Qq*Ye33 - 
    1440*gp^4*MassU*Qe3^2*Qq^2*Ye33 - 1440*gp^4*MassU*QHd^2*Qq^2*Ye33 - 
    1440*gp^4*MassU*Ql3^2*Qq^2*Ye33 - 80*gp^4*MassU*Qe3^2*Qs^2*Ye33 - 
    80*gp^4*MassU*QHd^2*Qs^2*Ye33 - 80*gp^4*MassU*Ql3^2*Qs^2*Ye33 + 
    288*g1^2*gp^2*MassB*Qe3*Qu*Ye33 + 288*g1^2*gp^2*MassU*Qe3*Qu*Ye33 - 
    144*g1^2*gp^2*MassB*QHd*Qu*Ye33 - 144*g1^2*gp^2*MassU*QHd*Qu*Ye33 - 
    144*g1^2*gp^2*MassB*Ql3*Qu*Ye33 - 144*g1^2*gp^2*MassU*Ql3*Qu*Ye33 - 
    720*gp^4*MassU*Qe3^2*Qu^2*Ye33 - 720*gp^4*MassU*QHd^2*Qu^2*Ye33 - 
    720*gp^4*MassU*Ql3^2*Qu^2*Ye33 - 80*gp^4*MassU*Qe3^2*Qv1^2*Ye33 - 
    80*gp^4*MassU*QHd^2*Qv1^2*Ye33 - 80*gp^4*MassU*Ql3^2*Qv1^2*Ye33 - 
    80*gp^4*MassU*Qe3^2*Qv2^2*Ye33 - 80*gp^4*MassU*QHd^2*Qv2^2*Ye33 - 
    80*gp^4*MassU*Ql3^2*Qv2^2*Ye33 - 80*gp^4*MassU*Qe3^2*Qv3^2*Ye33 - 
    80*gp^4*MassU*QHd^2*Qv3^2*Ye33 - 80*gp^4*MassU*Ql3^2*Qv3^2*Ye33 - 
    40*gp^2*MassU*QHu^2*Ye33*Yv33*conj[Yv33] + 40*gp^2*MassU*Ql3^2*Ye33*Yv33*
     conj[Yv33] - 40*gp^2*MassU*Qv3^2*Ye33*Yv33*conj[Yv33] + 
    40*gp^2*MassU*QHd^2*Ye33*\[Lambda]*conj[\[Lambda]] - 
    40*gp^2*MassU*QHu^2*Ye33*\[Lambda]*conj[\[Lambda]] - 
    40*gp^2*MassU*Qs^2*Ye33*\[Lambda]*conj[\[Lambda]] + 135*g1^4*T[Ye33] + 
    18*g1^2*g2^2*T[Ye33] + 75*g2^4*T[Ye33] + 72*g1^2*gp^2*Qd*Qe3*T[Ye33] + 
    24*g1^2*gp^2*Qe1*Qe3*T[Ye33] + 24*g1^2*gp^2*Qe2*Qe3*T[Ye33] + 
    72*g1^2*gp^2*Qe3^2*T[Ye33] + 180*gp^4*Qd^2*Qe3^2*T[Ye33] + 
    20*gp^4*Qe1^2*Qe3^2*T[Ye33] + 20*gp^4*Qe2^2*Qe3^2*T[Ye33] + 
    60*gp^4*Qe3^4*T[Ye33] - 36*g1^2*gp^2*Qd*QHd*T[Ye33] - 
    12*g1^2*gp^2*Qe1*QHd*T[Ye33] - 12*g1^2*gp^2*Qe2*QHd*T[Ye33] - 
    36*g1^2*gp^2*Qe3*QHd*T[Ye33] + 24*g1^2*gp^2*QHd^2*T[Ye33] + 
    60*g2^2*gp^2*QHd^2*T[Ye33] + 180*gp^4*Qd^2*QHd^2*T[Ye33] + 
    20*gp^4*Qe1^2*QHd^2*T[Ye33] + 20*gp^4*Qe2^2*QHd^2*T[Ye33] + 
    60*gp^4*Qe3^2*QHd^2*T[Ye33] + 80*gp^4*QHd^4*T[Ye33] + 
    24*g1^2*gp^2*Qe3*QHu*T[Ye33] - 12*g1^2*gp^2*QHd*QHu*T[Ye33] + 
    40*gp^4*Qe3^2*QHu^2*T[Ye33] + 40*gp^4*QHd^2*QHu^2*T[Ye33] - 
    24*g1^2*gp^2*Qe3*Ql1*T[Ye33] + 12*g1^2*gp^2*QHd*Ql1*T[Ye33] + 
    40*gp^4*Qe3^2*Ql1^2*T[Ye33] + 40*gp^4*QHd^2*Ql1^2*T[Ye33] - 
    24*g1^2*gp^2*Qe3*Ql2*T[Ye33] + 12*g1^2*gp^2*QHd*Ql2*T[Ye33] + 
    40*gp^4*Qe3^2*Ql2^2*T[Ye33] + 40*gp^4*QHd^2*Ql2^2*T[Ye33] - 
    36*g1^2*gp^2*Qd*Ql3*T[Ye33] - 12*g1^2*gp^2*Qe1*Ql3*T[Ye33] - 
    12*g1^2*gp^2*Qe2*Ql3*T[Ye33] - 36*g1^2*gp^2*Qe3*Ql3*T[Ye33] + 
    24*g1^2*gp^2*QHd*Ql3*T[Ye33] - 12*g1^2*gp^2*QHu*Ql3*T[Ye33] + 
    12*g1^2*gp^2*Ql1*Ql3*T[Ye33] + 12*g1^2*gp^2*Ql2*Ql3*T[Ye33] + 
    24*g1^2*gp^2*Ql3^2*T[Ye33] + 60*g2^2*gp^2*Ql3^2*T[Ye33] + 
    180*gp^4*Qd^2*Ql3^2*T[Ye33] + 20*gp^4*Qe1^2*Ql3^2*T[Ye33] + 
    20*gp^4*Qe2^2*Ql3^2*T[Ye33] + 60*gp^4*Qe3^2*Ql3^2*T[Ye33] + 
    80*gp^4*QHd^2*Ql3^2*T[Ye33] + 40*gp^4*QHu^2*Ql3^2*T[Ye33] + 
    40*gp^4*Ql1^2*Ql3^2*T[Ye33] + 40*gp^4*Ql2^2*Ql3^2*T[Ye33] + 
    80*gp^4*Ql3^4*T[Ye33] + 72*g1^2*gp^2*Qe3*Qq*T[Ye33] - 
    36*g1^2*gp^2*QHd*Qq*T[Ye33] - 36*g1^2*gp^2*Ql3*Qq*T[Ye33] + 
    360*gp^4*Qe3^2*Qq^2*T[Ye33] + 360*gp^4*QHd^2*Qq^2*T[Ye33] + 
    360*gp^4*Ql3^2*Qq^2*T[Ye33] + 20*gp^4*Qe3^2*Qs^2*T[Ye33] + 
    20*gp^4*QHd^2*Qs^2*T[Ye33] + 20*gp^4*Ql3^2*Qs^2*T[Ye33] - 
    144*g1^2*gp^2*Qe3*Qu*T[Ye33] + 72*g1^2*gp^2*QHd*Qu*T[Ye33] + 
    72*g1^2*gp^2*Ql3*Qu*T[Ye33] + 180*gp^4*Qe3^2*Qu^2*T[Ye33] + 
    180*gp^4*QHd^2*Qu^2*T[Ye33] + 180*gp^4*Ql3^2*Qu^2*T[Ye33] + 
    20*gp^4*Qe3^2*Qv1^2*T[Ye33] + 20*gp^4*QHd^2*Qv1^2*T[Ye33] + 
    20*gp^4*Ql3^2*Qv1^2*T[Ye33] + 20*gp^4*Qe3^2*Qv2^2*T[Ye33] + 
    20*gp^4*QHd^2*Qv2^2*T[Ye33] + 20*gp^4*Ql3^2*Qv2^2*T[Ye33] + 
    20*gp^4*Qe3^2*Qv3^2*T[Ye33] + 20*gp^4*QHd^2*Qv3^2*T[Ye33] + 
    20*gp^4*Ql3^2*Qv3^2*T[Ye33] - 500*Ye33^2*conj[Ye33]^2*T[Ye33] + 
    20*gp^2*QHu^2*Yv33*conj[Yv33]*T[Ye33] - 20*gp^2*Ql3^2*Yv33*conj[Yv33]*
     T[Ye33] + 20*gp^2*Qv3^2*Yv33*conj[Yv33]*T[Ye33] - 
    10*Yv11*Yv33*conj[Yv11]*conj[Yv33]*T[Ye33] - 10*Yv22*Yv33*conj[Yv22]*
     conj[Yv33]*T[Ye33] - 30*Yv33^2*conj[Yv33]^2*T[Ye33] - 
    20*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]]*T[Ye33] + 
    20*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]]*T[Ye33] + 
    20*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]]*T[Ye33] - 
    10*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]]*T[Ye33] - 
    10*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]]*T[Ye33] - 
    20*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]]*T[Ye33] - 
    30*\[Lambda]^2*conj[\[Lambda]]^2*T[Ye33] - 30*Ye11*conj[Ye11]^2*
     (4*Ye33*T[Ye11] + Ye11*T[Ye33]) - 30*Ye22*conj[Ye22]^2*
     (4*Ye33*T[Ye22] + Ye22*T[Ye33]) - 20*Ye33*Yv33*conj[Yv11]*conj[Yv33]*
     T[Yv11] - 20*Ye33*\[Lambda]*conj[Yv11]*conj[\[Lambda]]*T[Yv11] - 
    2*conj[Ye11]*(2*Ye33*(-6*g1^2 - 10*gp^2*(Qe1^2 - QHd^2 + Ql1^2) + 
        15*Ye33*conj[Ye33] + 5*Yv11*conj[Yv11])*T[Ye11] + 
      Ye11*(-6*g1^2 - 10*gp^2*(Qe1^2 - QHd^2 + Ql1^2) + 45*Ye33*conj[Ye33] + 
        5*Yv11*conj[Yv11])*T[Ye33] + 2*Ye11*Ye33*(6*g1^2*MassB + 
        10*gp^2*MassU*(Qe1^2 - QHd^2 + Ql1^2) + 5*conj[Yv11]*T[Yv11])) - 
    20*Ye33*Yv33*conj[Yv22]*conj[Yv33]*T[Yv22] - 20*Ye33*\[Lambda]*conj[Yv22]*
     conj[\[Lambda]]*T[Yv22] - 2*conj[Ye22]*
     (2*Ye33*(-6*g1^2 - 10*gp^2*(Qe2^2 - QHd^2 + Ql2^2) + 
        15*Ye33*conj[Ye33] + 5*Yv22*conj[Yv22])*T[Ye22] + 
      Ye22*(-6*g1^2 - 10*gp^2*(Qe2^2 - QHd^2 + Ql2^2) + 45*Ye33*conj[Ye33] + 
        5*Yv22*conj[Yv22])*T[Ye33] + 2*Ye22*Ye33*(6*g1^2*MassB + 
        10*gp^2*MassU*(Qe2^2 - QHd^2 + Ql2^2) + 5*conj[Yv22]*T[Yv22])) + 
    40*gp^2*QHu^2*Ye33*conj[Yv33]*T[Yv33] - 40*gp^2*Ql3^2*Ye33*conj[Yv33]*
     T[Yv33] + 40*gp^2*Qv3^2*Ye33*conj[Yv33]*T[Yv33] - 
    20*Ye33*Yv11*conj[Yv11]*conj[Yv33]*T[Yv33] - 20*Ye33*Yv22*conj[Yv22]*
     conj[Yv33]*T[Yv33] - 120*Ye33*Yv33*conj[Yv33]^2*T[Yv33] - 
    40*Ye33*\[Lambda]*conj[Yv33]*conj[\[Lambda]]*T[Yv33] - 
    40*gp^2*QHd^2*Ye33*conj[\[Lambda]]*T[\[Lambda]] + 
    40*gp^2*QHu^2*Ye33*conj[\[Lambda]]*T[\[Lambda]] + 
    40*gp^2*Qs^2*Ye33*conj[\[Lambda]]*T[\[Lambda]] - 
    20*Ye33*Yv11*conj[Yv11]*conj[\[Lambda]]*T[\[Lambda]] - 
    20*Ye33*Yv22*conj[Yv22]*conj[\[Lambda]]*T[\[Lambda]] - 
    40*Ye33*Yv33*conj[Yv33]*conj[\[Lambda]]*T[\[Lambda]] - 
    120*Ye33*\[Lambda]*conj[\[Lambda]]^2*T[\[Lambda]] + 
    8*g1^2*MassB*Ye33*trace[Yd, Adj[Yd]] - 320*g3^2*MassG*Ye33*
     trace[Yd, Adj[Yd]] - 120*gp^2*MassU*Qd^2*Ye33*trace[Yd, Adj[Yd]] + 
    120*gp^2*MassU*QHd^2*Ye33*trace[Yd, Adj[Yd]] - 
    120*gp^2*MassU*Qq^2*Ye33*trace[Yd, Adj[Yd]] - 
    4*g1^2*T[Ye33]*trace[Yd, Adj[Yd]] + 160*g3^2*T[Ye33]*trace[Yd, Adj[Yd]] + 
    60*gp^2*Qd^2*T[Ye33]*trace[Yd, Adj[Yd]] - 60*gp^2*QHd^2*T[Ye33]*
     trace[Yd, Adj[Yd]] + 60*gp^2*Qq^2*T[Ye33]*trace[Yd, Adj[Yd]] - 
    30*Yv33*conj[Yv33]*T[Ye33]*trace[Yu, Adj[Yu]] - 
    30*\[Lambda]*conj[\[Lambda]]*T[Ye33]*trace[Yu, Adj[Yu]] - 
    60*Ye33*conj[Yv33]*T[Yv33]*trace[Yu, Adj[Yu]] - 
    60*Ye33*conj[\[Lambda]]*T[\[Lambda]]*trace[Yu, Adj[Yu]] - 
    8*g1^2*Ye33*trace[Adj[Yd], T[Yd]] + 320*g3^2*Ye33*trace[Adj[Yd], T[Yd]] + 
    120*gp^2*Qd^2*Ye33*trace[Adj[Yd], T[Yd]] - 120*gp^2*QHd^2*Ye33*
     trace[Adj[Yd], T[Yd]] + 120*gp^2*Qq^2*Ye33*trace[Adj[Yd], T[Yd]] - 
    2*Ye33*conj[Ye33]*(-3*T[Ye33]*(6*g1^2 + 30*g2^2 + 20*gp^2*QHd^2 + 
        20*gp^2*Ql3^2 - 15*Yv33*conj[Yv33] - 15*\[Lambda]*conj[\[Lambda]] - 
        45*trace[Yd, Adj[Yd]]) + 2*Ye33*(6*g1^2*MassB + 30*g2^2*MassWB + 
        20*gp^2*MassU*QHd^2 + 20*gp^2*MassU*Ql3^2 + 15*conj[Yv33]*T[Yv33] + 
        15*conj[\[Lambda]]*T[\[Lambda]] + 45*trace[Adj[Yd], T[Yd]])) - 
    60*Ye33*Yv33*conj[Yv33]*trace[Adj[Yu], T[Yu]] - 
    60*Ye33*\[Lambda]*conj[\[Lambda]]*trace[Adj[Yu], T[Yu]] - 
    90*T[Ye33]*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 
    360*Ye33*trace[Yd, Adj[Yd], T[Yd], Adj[Yd]] - 
    30*T[Ye33]*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
    60*Ye33*trace[Yd, Adj[Yu], T[Yu], Adj[Yd]] - 
    60*Ye33*trace[Yu, Adj[Yd], T[Yd], Adj[Yu]])/10}, 
 {T[\[Lambda]], (6*g1^2*MassB*\[Lambda])/5 + 6*g2^2*MassWB*\[Lambda] + 
   4*gp^2*MassU*QHd^2*\[Lambda] + 4*gp^2*MassU*QHu^2*\[Lambda] + 
   4*gp^2*MassU*Qs^2*\[Lambda] + 2*\[Lambda]*conj[Ye33]*T[Ye33] + 
   2*\[Lambda]*conj[Yv11]*T[Yv11] + 2*\[Lambda]*conj[Yv22]*T[Yv22] + 
   2*\[Lambda]*conj[Yv33]*T[Yv33] - (3*g1^2*T[\[Lambda]])/5 - 
   3*g2^2*T[\[Lambda]] - 2*gp^2*QHd^2*T[\[Lambda]] - 
   2*gp^2*QHu^2*T[\[Lambda]] - 2*gp^2*Qs^2*T[\[Lambda]] + 
   Ye33*conj[Ye33]*T[\[Lambda]] + Yv11*conj[Yv11]*T[\[Lambda]] + 
   Yv22*conj[Yv22]*T[\[Lambda]] + Yv33*conj[Yv33]*T[\[Lambda]] + 
   12*\[Lambda]*conj[\[Lambda]]*T[\[Lambda]] + 
   conj[Ye11]*(2*\[Lambda]*T[Ye11] + Ye11*T[\[Lambda]]) + 
   conj[Ye22]*(2*\[Lambda]*T[Ye22] + Ye22*T[\[Lambda]]) + 
   3*T[\[Lambda]]*trace[Yd, Adj[Yd]] + 3*T[\[Lambda]]*trace[Yu, Adj[Yu]] + 
   6*\[Lambda]*trace[Adj[Yd], T[Yd]] + 6*\[Lambda]*trace[Adj[Yu], T[Yu]], 
  (-414*g1^4*MassB*\[Lambda])/25 - (18*g1^2*g2^2*MassB*\[Lambda])/5 - 
   (18*g1^2*g2^2*MassWB*\[Lambda])/5 - 30*g2^4*MassWB*\[Lambda] + 
   (36*g1^2*gp^2*MassB*Qd*QHd*\[Lambda])/5 + 
   (36*g1^2*gp^2*MassU*Qd*QHd*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassB*Qe1*QHd*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassU*Qe1*QHd*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassB*Qe2*QHd*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassU*Qe2*QHd*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassB*Qe3*QHd*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassU*Qe3*QHd*\[Lambda])/5 - 
   (24*g1^2*gp^2*MassB*QHd^2*\[Lambda])/5 - 
   (24*g1^2*gp^2*MassU*QHd^2*\[Lambda])/5 - 12*g2^2*gp^2*MassU*QHd^2*
    \[Lambda] - 12*g2^2*gp^2*MassWB*QHd^2*\[Lambda] - 
   72*gp^4*MassU*Qd^2*QHd^2*\[Lambda] - 8*gp^4*MassU*Qe1^2*QHd^2*\[Lambda] - 
   8*gp^4*MassU*Qe2^2*QHd^2*\[Lambda] - 8*gp^4*MassU*Qe3^2*QHd^2*\[Lambda] - 
   32*gp^4*MassU*QHd^4*\[Lambda] - (36*g1^2*gp^2*MassB*Qd*QHu*\[Lambda])/5 - 
   (36*g1^2*gp^2*MassU*Qd*QHu*\[Lambda])/5 - 
   (12*g1^2*gp^2*MassB*Qe1*QHu*\[Lambda])/5 - 
   (12*g1^2*gp^2*MassU*Qe1*QHu*\[Lambda])/5 - 
   (12*g1^2*gp^2*MassB*Qe2*QHu*\[Lambda])/5 - 
   (12*g1^2*gp^2*MassU*Qe2*QHu*\[Lambda])/5 - 
   (12*g1^2*gp^2*MassB*Qe3*QHu*\[Lambda])/5 - 
   (12*g1^2*gp^2*MassU*Qe3*QHu*\[Lambda])/5 + 
   (24*g1^2*gp^2*MassB*QHd*QHu*\[Lambda])/5 + 
   (24*g1^2*gp^2*MassU*QHd*QHu*\[Lambda])/5 - 
   (24*g1^2*gp^2*MassB*QHu^2*\[Lambda])/5 - 
   (24*g1^2*gp^2*MassU*QHu^2*\[Lambda])/5 - 12*g2^2*gp^2*MassU*QHu^2*
    \[Lambda] - 12*g2^2*gp^2*MassWB*QHu^2*\[Lambda] - 
   72*gp^4*MassU*Qd^2*QHu^2*\[Lambda] - 8*gp^4*MassU*Qe1^2*QHu^2*\[Lambda] - 
   8*gp^4*MassU*Qe2^2*QHu^2*\[Lambda] - 8*gp^4*MassU*Qe3^2*QHu^2*\[Lambda] - 
   32*gp^4*MassU*QHd^2*QHu^2*\[Lambda] - 32*gp^4*MassU*QHu^4*\[Lambda] - 
   (12*g1^2*gp^2*MassB*QHd*Ql1*\[Lambda])/5 - 
   (12*g1^2*gp^2*MassU*QHd*Ql1*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassB*QHu*Ql1*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassU*QHu*Ql1*\[Lambda])/5 - 16*gp^4*MassU*QHd^2*Ql1^2*
    \[Lambda] - 16*gp^4*MassU*QHu^2*Ql1^2*\[Lambda] - 
   (12*g1^2*gp^2*MassB*QHd*Ql2*\[Lambda])/5 - 
   (12*g1^2*gp^2*MassU*QHd*Ql2*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassB*QHu*Ql2*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassU*QHu*Ql2*\[Lambda])/5 - 16*gp^4*MassU*QHd^2*Ql2^2*
    \[Lambda] - 16*gp^4*MassU*QHu^2*Ql2^2*\[Lambda] - 
   (12*g1^2*gp^2*MassB*QHd*Ql3*\[Lambda])/5 - 
   (12*g1^2*gp^2*MassU*QHd*Ql3*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassB*QHu*Ql3*\[Lambda])/5 + 
   (12*g1^2*gp^2*MassU*QHu*Ql3*\[Lambda])/5 - 16*gp^4*MassU*QHd^2*Ql3^2*
    \[Lambda] - 16*gp^4*MassU*QHu^2*Ql3^2*\[Lambda] + 
   (36*g1^2*gp^2*MassB*QHd*Qq*\[Lambda])/5 + 
   (36*g1^2*gp^2*MassU*QHd*Qq*\[Lambda])/5 - 
   (36*g1^2*gp^2*MassB*QHu*Qq*\[Lambda])/5 - 
   (36*g1^2*gp^2*MassU*QHu*Qq*\[Lambda])/5 - 144*gp^4*MassU*QHd^2*Qq^2*
    \[Lambda] - 144*gp^4*MassU*QHu^2*Qq^2*\[Lambda] - 
   72*gp^4*MassU*Qd^2*Qs^2*\[Lambda] - 8*gp^4*MassU*Qe1^2*Qs^2*\[Lambda] - 
   8*gp^4*MassU*Qe2^2*Qs^2*\[Lambda] - 8*gp^4*MassU*Qe3^2*Qs^2*\[Lambda] - 
   24*gp^4*MassU*QHd^2*Qs^2*\[Lambda] - 24*gp^4*MassU*QHu^2*Qs^2*\[Lambda] - 
   16*gp^4*MassU*Ql1^2*Qs^2*\[Lambda] - 16*gp^4*MassU*Ql2^2*Qs^2*\[Lambda] - 
   16*gp^4*MassU*Ql3^2*Qs^2*\[Lambda] - 144*gp^4*MassU*Qq^2*Qs^2*\[Lambda] - 
   24*gp^4*MassU*Qs^4*\[Lambda] - (72*g1^2*gp^2*MassB*QHd*Qu*\[Lambda])/5 - 
   (72*g1^2*gp^2*MassU*QHd*Qu*\[Lambda])/5 + 
   (72*g1^2*gp^2*MassB*QHu*Qu*\[Lambda])/5 + 
   (72*g1^2*gp^2*MassU*QHu*Qu*\[Lambda])/5 - 72*gp^4*MassU*QHd^2*Qu^2*
    \[Lambda] - 72*gp^4*MassU*QHu^2*Qu^2*\[Lambda] - 
   72*gp^4*MassU*Qs^2*Qu^2*\[Lambda] - 8*gp^4*MassU*QHd^2*Qv1^2*\[Lambda] - 
   8*gp^4*MassU*QHu^2*Qv1^2*\[Lambda] - 8*gp^4*MassU*Qs^2*Qv1^2*\[Lambda] - 
   8*gp^4*MassU*QHd^2*Qv2^2*\[Lambda] - 8*gp^4*MassU*QHu^2*Qv2^2*\[Lambda] - 
   8*gp^4*MassU*Qs^2*Qv2^2*\[Lambda] - 8*gp^4*MassU*QHd^2*Qv3^2*\[Lambda] - 
   8*gp^4*MassU*QHu^2*Qv3^2*\[Lambda] - 8*gp^4*MassU*Qs^2*Qv3^2*\[Lambda] - 
   (12*g1^2*MassB*Ye33*\[Lambda]*conj[Ye33])/5 - 
   4*gp^2*MassU*Qe3^2*Ye33*\[Lambda]*conj[Ye33] + 
   4*gp^2*MassU*QHd^2*Ye33*\[Lambda]*conj[Ye33] - 
   4*gp^2*MassU*Ql3^2*Ye33*\[Lambda]*conj[Ye33] + 
   4*gp^2*MassU*QHu^2*Yv11*\[Lambda]*conj[Yv11] - 
   4*gp^2*MassU*Ql1^2*Yv11*\[Lambda]*conj[Yv11] - 
   4*gp^2*MassU*Qv1^2*Yv11*\[Lambda]*conj[Yv11] + 
   4*gp^2*MassU*QHu^2*Yv22*\[Lambda]*conj[Yv22] - 
   4*gp^2*MassU*Ql2^2*Yv22*\[Lambda]*conj[Yv22] - 
   4*gp^2*MassU*Qv2^2*Yv22*\[Lambda]*conj[Yv22] + 
   4*gp^2*MassU*QHu^2*Yv33*\[Lambda]*conj[Yv33] - 
   4*gp^2*MassU*Ql3^2*Yv33*\[Lambda]*conj[Yv33] - 
   4*gp^2*MassU*Qv3^2*Yv33*\[Lambda]*conj[Yv33] - 
   (12*g1^2*MassB*\[Lambda]^2*conj[\[Lambda]])/5 - 
   12*g2^2*MassWB*\[Lambda]^2*conj[\[Lambda]] - 
   8*gp^2*MassU*QHd^2*\[Lambda]^2*conj[\[Lambda]] - 
   8*gp^2*MassU*QHu^2*\[Lambda]^2*conj[\[Lambda]] + 
   (12*g1^2*\[Lambda]*conj[Ye33]*T[Ye33])/5 + 4*gp^2*Qe3^2*\[Lambda]*
    conj[Ye33]*T[Ye33] - 4*gp^2*QHd^2*\[Lambda]*conj[Ye33]*T[Ye33] + 
   4*gp^2*Ql3^2*\[Lambda]*conj[Ye33]*T[Ye33] - 12*Ye33*\[Lambda]*conj[Ye33]^2*
    T[Ye33] - 4*Yv33*\[Lambda]*conj[Ye33]*conj[Yv33]*T[Ye33] - 
   6*\[Lambda]^2*conj[Ye33]*conj[\[Lambda]]*T[Ye33] - 
   4*gp^2*QHu^2*\[Lambda]*conj[Yv11]*T[Yv11] + 4*gp^2*Ql1^2*\[Lambda]*
    conj[Yv11]*T[Yv11] + 4*gp^2*Qv1^2*\[Lambda]*conj[Yv11]*T[Yv11] - 
   12*Yv11*\[Lambda]*conj[Yv11]^2*T[Yv11] - 6*\[Lambda]^2*conj[Yv11]*
    conj[\[Lambda]]*T[Yv11] - 4*gp^2*QHu^2*\[Lambda]*conj[Yv22]*T[Yv22] + 
   4*gp^2*Ql2^2*\[Lambda]*conj[Yv22]*T[Yv22] + 4*gp^2*Qv2^2*\[Lambda]*
    conj[Yv22]*T[Yv22] - 12*Yv22*\[Lambda]*conj[Yv22]^2*T[Yv22] - 
   6*\[Lambda]^2*conj[Yv22]*conj[\[Lambda]]*T[Yv22] - 
   4*gp^2*QHu^2*\[Lambda]*conj[Yv33]*T[Yv33] + 4*gp^2*Ql3^2*\[Lambda]*
    conj[Yv33]*T[Yv33] + 4*gp^2*Qv3^2*\[Lambda]*conj[Yv33]*T[Yv33] - 
   4*Ye33*\[Lambda]*conj[Ye33]*conj[Yv33]*T[Yv33] - 
   12*Yv33*\[Lambda]*conj[Yv33]^2*T[Yv33] - 6*\[Lambda]^2*conj[Yv33]*
    conj[\[Lambda]]*T[Yv33] + (207*g1^4*T[\[Lambda]])/50 + 
   (9*g1^2*g2^2*T[\[Lambda]])/5 + (15*g2^4*T[\[Lambda]])/2 - 
   (18*g1^2*gp^2*Qd*QHd*T[\[Lambda]])/5 - (6*g1^2*gp^2*Qe1*QHd*T[\[Lambda]])/
    5 - (6*g1^2*gp^2*Qe2*QHd*T[\[Lambda]])/5 - 
   (6*g1^2*gp^2*Qe3*QHd*T[\[Lambda]])/5 + (12*g1^2*gp^2*QHd^2*T[\[Lambda]])/
    5 + 6*g2^2*gp^2*QHd^2*T[\[Lambda]] + 18*gp^4*Qd^2*QHd^2*T[\[Lambda]] + 
   2*gp^4*Qe1^2*QHd^2*T[\[Lambda]] + 2*gp^4*Qe2^2*QHd^2*T[\[Lambda]] + 
   2*gp^4*Qe3^2*QHd^2*T[\[Lambda]] + 8*gp^4*QHd^4*T[\[Lambda]] + 
   (18*g1^2*gp^2*Qd*QHu*T[\[Lambda]])/5 + (6*g1^2*gp^2*Qe1*QHu*T[\[Lambda]])/
    5 + (6*g1^2*gp^2*Qe2*QHu*T[\[Lambda]])/5 + 
   (6*g1^2*gp^2*Qe3*QHu*T[\[Lambda]])/5 - (12*g1^2*gp^2*QHd*QHu*T[\[Lambda]])/
    5 + (12*g1^2*gp^2*QHu^2*T[\[Lambda]])/5 + 
   6*g2^2*gp^2*QHu^2*T[\[Lambda]] + 18*gp^4*Qd^2*QHu^2*T[\[Lambda]] + 
   2*gp^4*Qe1^2*QHu^2*T[\[Lambda]] + 2*gp^4*Qe2^2*QHu^2*T[\[Lambda]] + 
   2*gp^4*Qe3^2*QHu^2*T[\[Lambda]] + 8*gp^4*QHd^2*QHu^2*T[\[Lambda]] + 
   8*gp^4*QHu^4*T[\[Lambda]] + (6*g1^2*gp^2*QHd*Ql1*T[\[Lambda]])/5 - 
   (6*g1^2*gp^2*QHu*Ql1*T[\[Lambda]])/5 + 4*gp^4*QHd^2*Ql1^2*T[\[Lambda]] + 
   4*gp^4*QHu^2*Ql1^2*T[\[Lambda]] + (6*g1^2*gp^2*QHd*Ql2*T[\[Lambda]])/5 - 
   (6*g1^2*gp^2*QHu*Ql2*T[\[Lambda]])/5 + 4*gp^4*QHd^2*Ql2^2*T[\[Lambda]] + 
   4*gp^4*QHu^2*Ql2^2*T[\[Lambda]] + (6*g1^2*gp^2*QHd*Ql3*T[\[Lambda]])/5 - 
   (6*g1^2*gp^2*QHu*Ql3*T[\[Lambda]])/5 + 4*gp^4*QHd^2*Ql3^2*T[\[Lambda]] + 
   4*gp^4*QHu^2*Ql3^2*T[\[Lambda]] - (18*g1^2*gp^2*QHd*Qq*T[\[Lambda]])/5 + 
   (18*g1^2*gp^2*QHu*Qq*T[\[Lambda]])/5 + 36*gp^4*QHd^2*Qq^2*T[\[Lambda]] + 
   36*gp^4*QHu^2*Qq^2*T[\[Lambda]] + 18*gp^4*Qd^2*Qs^2*T[\[Lambda]] + 
   2*gp^4*Qe1^2*Qs^2*T[\[Lambda]] + 2*gp^4*Qe2^2*Qs^2*T[\[Lambda]] + 
   2*gp^4*Qe3^2*Qs^2*T[\[Lambda]] + 6*gp^4*QHd^2*Qs^2*T[\[Lambda]] + 
   6*gp^4*QHu^2*Qs^2*T[\[Lambda]] + 4*gp^4*Ql1^2*Qs^2*T[\[Lambda]] + 
   4*gp^4*Ql2^2*Qs^2*T[\[Lambda]] + 4*gp^4*Ql3^2*Qs^2*T[\[Lambda]] + 
   36*gp^4*Qq^2*Qs^2*T[\[Lambda]] + 6*gp^4*Qs^4*T[\[Lambda]] + 
   (36*g1^2*gp^2*QHd*Qu*T[\[Lambda]])/5 - (36*g1^2*gp^2*QHu*Qu*T[\[Lambda]])/
    5 + 18*gp^4*QHd^2*Qu^2*T[\[Lambda]] + 18*gp^4*QHu^2*Qu^2*T[\[Lambda]] + 
   18*gp^4*Qs^2*Qu^2*T[\[Lambda]] + 2*gp^4*QHd^2*Qv1^2*T[\[Lambda]] + 
   2*gp^4*QHu^2*Qv1^2*T[\[Lambda]] + 2*gp^4*Qs^2*Qv1^2*T[\[Lambda]] + 
   2*gp^4*QHd^2*Qv2^2*T[\[Lambda]] + 2*gp^4*QHu^2*Qv2^2*T[\[Lambda]] + 
   2*gp^4*Qs^2*Qv2^2*T[\[Lambda]] + 2*gp^4*QHd^2*Qv3^2*T[\[Lambda]] + 
   2*gp^4*QHu^2*Qv3^2*T[\[Lambda]] + 2*gp^4*Qs^2*Qv3^2*T[\[Lambda]] + 
   (6*g1^2*Ye33*conj[Ye33]*T[\[Lambda]])/5 + 2*gp^2*Qe3^2*Ye33*conj[Ye33]*
    T[\[Lambda]] - 2*gp^2*QHd^2*Ye33*conj[Ye33]*T[\[Lambda]] + 
   2*gp^2*Ql3^2*Ye33*conj[Ye33]*T[\[Lambda]] - 3*Ye33^2*conj[Ye33]^2*
    T[\[Lambda]] - 2*gp^2*QHu^2*Yv11*conj[Yv11]*T[\[Lambda]] + 
   2*gp^2*Ql1^2*Yv11*conj[Yv11]*T[\[Lambda]] + 2*gp^2*Qv1^2*Yv11*conj[Yv11]*
    T[\[Lambda]] - 3*Yv11^2*conj[Yv11]^2*T[\[Lambda]] - 
   2*gp^2*QHu^2*Yv22*conj[Yv22]*T[\[Lambda]] + 2*gp^2*Ql2^2*Yv22*conj[Yv22]*
    T[\[Lambda]] + 2*gp^2*Qv2^2*Yv22*conj[Yv22]*T[\[Lambda]] - 
   3*Yv22^2*conj[Yv22]^2*T[\[Lambda]] - 2*gp^2*QHu^2*Yv33*conj[Yv33]*
    T[\[Lambda]] + 2*gp^2*Ql3^2*Yv33*conj[Yv33]*T[\[Lambda]] + 
   2*gp^2*Qv3^2*Yv33*conj[Yv33]*T[\[Lambda]] - 2*Ye33*Yv33*conj[Ye33]*
    conj[Yv33]*T[\[Lambda]] - 3*Yv33^2*conj[Yv33]^2*T[\[Lambda]] + 
   (18*g1^2*\[Lambda]*conj[\[Lambda]]*T[\[Lambda]])/5 + 
   18*g2^2*\[Lambda]*conj[\[Lambda]]*T[\[Lambda]] + 
   12*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]]*T[\[Lambda]] + 
   12*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]]*T[\[Lambda]] - 
   9*Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]]*T[\[Lambda]] - 
   9*Yv11*\[Lambda]*conj[Yv11]*conj[\[Lambda]]*T[\[Lambda]] - 
   9*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]]*T[\[Lambda]] - 
   9*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]]*T[\[Lambda]] - 
   50*\[Lambda]^2*conj[\[Lambda]]^2*T[\[Lambda]] - 
   3*Ye11*conj[Ye11]^2*(4*\[Lambda]*T[Ye11] + Ye11*T[\[Lambda]]) - 
   3*Ye22*conj[Ye22]^2*(4*\[Lambda]*T[Ye22] + Ye22*T[\[Lambda]]) - 
   (conj[Ye11]*(2*\[Lambda]*(-6*g1^2 - 10*gp^2*(Qe1^2 - QHd^2 + Ql1^2) + 
        10*Yv11*conj[Yv11] + 15*\[Lambda]*conj[\[Lambda]])*T[Ye11] + 
      Ye11*(4*(3*g1^2*MassB + 5*gp^2*MassU*(Qe1^2 - QHd^2 + Ql1^2))*
         \[Lambda] + (-6*g1^2 - 10*gp^2*(Qe1^2 - QHd^2 + Ql1^2) + 
          45*\[Lambda]*conj[\[Lambda]])*T[\[Lambda]] + 
        10*conj[Yv11]*(2*\[Lambda]*T[Yv11] + Yv11*T[\[Lambda]]))))/5 - 
   (conj[Ye22]*(2*\[Lambda]*(-6*g1^2 - 10*gp^2*(Qe2^2 - QHd^2 + Ql2^2) + 
        10*Yv22*conj[Yv22] + 15*\[Lambda]*conj[\[Lambda]])*T[Ye22] + 
      Ye22*(4*(3*g1^2*MassB + 5*gp^2*MassU*(Qe2^2 - QHd^2 + Ql2^2))*
         \[Lambda] + (-6*g1^2 - 10*gp^2*(Qe2^2 - QHd^2 + Ql2^2) + 
          45*\[Lambda]*conj[\[Lambda]])*T[\[Lambda]] + 
        10*conj[Yv22]*(2*\[Lambda]*T[Yv22] + Yv22*T[\[Lambda]]))))/5 + 
   (4*g1^2*MassB*\[Lambda]*trace[Yd, Adj[Yd]])/5 - 
   32*g3^2*MassG*\[Lambda]*trace[Yd, Adj[Yd]] - 12*gp^2*MassU*Qd^2*\[Lambda]*
    trace[Yd, Adj[Yd]] + 12*gp^2*MassU*QHd^2*\[Lambda]*trace[Yd, Adj[Yd]] - 
   12*gp^2*MassU*Qq^2*\[Lambda]*trace[Yd, Adj[Yd]] - 
   (2*g1^2*T[\[Lambda]]*trace[Yd, Adj[Yd]])/5 + 
   16*g3^2*T[\[Lambda]]*trace[Yd, Adj[Yd]] + 6*gp^2*Qd^2*T[\[Lambda]]*
    trace[Yd, Adj[Yd]] - 6*gp^2*QHd^2*T[\[Lambda]]*trace[Yd, Adj[Yd]] + 
   6*gp^2*Qq^2*T[\[Lambda]]*trace[Yd, Adj[Yd]] - 27*\[Lambda]*conj[\[Lambda]]*
    T[\[Lambda]]*trace[Yd, Adj[Yd]] - 
   (8*g1^2*MassB*\[Lambda]*trace[Yu, Adj[Yu]])/5 - 
   32*g3^2*MassG*\[Lambda]*trace[Yu, Adj[Yu]] + 12*gp^2*MassU*QHu^2*\[Lambda]*
    trace[Yu, Adj[Yu]] - 12*gp^2*MassU*Qq^2*\[Lambda]*trace[Yu, Adj[Yu]] - 
   12*gp^2*MassU*Qu^2*\[Lambda]*trace[Yu, Adj[Yu]] + 
   (4*g1^2*T[\[Lambda]]*trace[Yu, Adj[Yu]])/5 + 
   16*g3^2*T[\[Lambda]]*trace[Yu, Adj[Yu]] - 6*gp^2*QHu^2*T[\[Lambda]]*
    trace[Yu, Adj[Yu]] + 6*gp^2*Qq^2*T[\[Lambda]]*trace[Yu, Adj[Yu]] + 
   6*gp^2*Qu^2*T[\[Lambda]]*trace[Yu, Adj[Yu]] - 27*\[Lambda]*conj[\[Lambda]]*
    T[\[Lambda]]*trace[Yu, Adj[Yu]] - 
   (4*g1^2*\[Lambda]*trace[Adj[Yd], T[Yd]])/5 + 
   32*g3^2*\[Lambda]*trace[Adj[Yd], T[Yd]] + 12*gp^2*Qd^2*\[Lambda]*
    trace[Adj[Yd], T[Yd]] - 12*gp^2*QHd^2*\[Lambda]*trace[Adj[Yd], T[Yd]] + 
   12*gp^2*Qq^2*\[Lambda]*trace[Adj[Yd], T[Yd]] - 
   18*\[Lambda]^2*conj[\[Lambda]]*trace[Adj[Yd], T[Yd]] + 
   (8*g1^2*\[Lambda]*trace[Adj[Yu], T[Yu]])/5 + 
   32*g3^2*\[Lambda]*trace[Adj[Yu], T[Yu]] - 12*gp^2*QHu^2*\[Lambda]*
    trace[Adj[Yu], T[Yu]] + 12*gp^2*Qq^2*\[Lambda]*trace[Adj[Yu], T[Yu]] + 
   12*gp^2*Qu^2*\[Lambda]*trace[Adj[Yu], T[Yu]] - 
   18*\[Lambda]^2*conj[\[Lambda]]*trace[Adj[Yu], T[Yu]] - 
   9*T[\[Lambda]]*trace[Yd, Adj[Yd], Yd, Adj[Yd]] - 
   36*\[Lambda]*trace[Yd, Adj[Yd], T[Yd], Adj[Yd]] - 
   6*T[\[Lambda]]*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   12*\[Lambda]*trace[Yd, Adj[Yu], T[Yu], Adj[Yd]] - 
   12*\[Lambda]*trace[Yu, Adj[Yd], T[Yd], Adj[Yu]] - 
   9*T[\[Lambda]]*trace[Yu, Adj[Yu], Yu, Adj[Yu]] - 
   36*\[Lambda]*trace[Yu, Adj[Yu], T[Yu], Adj[Yu]]}, 
 {T[Yv11], conj[Ye11]*(2*Yv11*T[Ye11] + Ye11*T[Yv11]) + 
   T[Yv11]*((-3*g1^2)/5 - 3*g2^2 - 2*gp^2*QHu^2 - 2*gp^2*Ql1^2 - 
     2*gp^2*Qv1^2 + 12*Yv11*conj[Yv11] + Yv22*conj[Yv22] + Yv33*conj[Yv33] + 
     \[Lambda]*conj[\[Lambda]] + 3*trace[Yu, Adj[Yu]]) + 
   (2*Yv11*(3*g1^2*MassB + 15*g2^2*MassWB + 10*gp^2*MassU*QHu^2 + 
      10*gp^2*MassU*Ql1^2 + 10*gp^2*MassU*Qv1^2 + 5*conj[Yv22]*T[Yv22] + 
      5*conj[Yv33]*T[Yv33] + 5*conj[\[Lambda]]*T[\[Lambda]] + 
      15*trace[Adj[Yu], T[Yu]]))/5, (-414*g1^4*MassB*Yv11)/25 - 
   (18*g1^2*g2^2*MassB*Yv11)/5 - (18*g1^2*g2^2*MassWB*Yv11)/5 - 
   30*g2^4*MassWB*Yv11 - (36*g1^2*gp^2*MassB*Qd*QHu*Yv11)/5 - 
   (36*g1^2*gp^2*MassU*Qd*QHu*Yv11)/5 - (12*g1^2*gp^2*MassB*Qe1*QHu*Yv11)/5 - 
   (12*g1^2*gp^2*MassU*Qe1*QHu*Yv11)/5 - (12*g1^2*gp^2*MassB*Qe2*QHu*Yv11)/
    5 - (12*g1^2*gp^2*MassU*Qe2*QHu*Yv11)/5 - 
   (12*g1^2*gp^2*MassB*Qe3*QHu*Yv11)/5 - (12*g1^2*gp^2*MassU*Qe3*QHu*Yv11)/
    5 + (12*g1^2*gp^2*MassB*QHd*QHu*Yv11)/5 + 
   (12*g1^2*gp^2*MassU*QHd*QHu*Yv11)/5 - (24*g1^2*gp^2*MassB*QHu^2*Yv11)/5 - 
   (24*g1^2*gp^2*MassU*QHu^2*Yv11)/5 - 12*g2^2*gp^2*MassU*QHu^2*Yv11 - 
   12*g2^2*gp^2*MassWB*QHu^2*Yv11 - 72*gp^4*MassU*Qd^2*QHu^2*Yv11 - 
   8*gp^4*MassU*Qe1^2*QHu^2*Yv11 - 8*gp^4*MassU*Qe2^2*QHu^2*Yv11 - 
   8*gp^4*MassU*Qe3^2*QHu^2*Yv11 - 16*gp^4*MassU*QHd^2*QHu^2*Yv11 - 
   32*gp^4*MassU*QHu^4*Yv11 + (36*g1^2*gp^2*MassB*Qd*Ql1*Yv11)/5 + 
   (36*g1^2*gp^2*MassU*Qd*Ql1*Yv11)/5 + (12*g1^2*gp^2*MassB*Qe1*Ql1*Yv11)/5 + 
   (12*g1^2*gp^2*MassU*Qe1*Ql1*Yv11)/5 + (12*g1^2*gp^2*MassB*Qe2*Ql1*Yv11)/
    5 + (12*g1^2*gp^2*MassU*Qe2*Ql1*Yv11)/5 + 
   (12*g1^2*gp^2*MassB*Qe3*Ql1*Yv11)/5 + (12*g1^2*gp^2*MassU*Qe3*Ql1*Yv11)/
    5 - (12*g1^2*gp^2*MassB*QHd*Ql1*Yv11)/5 - 
   (12*g1^2*gp^2*MassU*QHd*Ql1*Yv11)/5 + (24*g1^2*gp^2*MassB*QHu*Ql1*Yv11)/
    5 + (24*g1^2*gp^2*MassU*QHu*Ql1*Yv11)/5 - (24*g1^2*gp^2*MassB*Ql1^2*Yv11)/
    5 - (24*g1^2*gp^2*MassU*Ql1^2*Yv11)/5 - 12*g2^2*gp^2*MassU*Ql1^2*Yv11 - 
   12*g2^2*gp^2*MassWB*Ql1^2*Yv11 - 72*gp^4*MassU*Qd^2*Ql1^2*Yv11 - 
   8*gp^4*MassU*Qe1^2*Ql1^2*Yv11 - 8*gp^4*MassU*Qe2^2*Ql1^2*Yv11 - 
   8*gp^4*MassU*Qe3^2*Ql1^2*Yv11 - 16*gp^4*MassU*QHd^2*Ql1^2*Yv11 - 
   32*gp^4*MassU*QHu^2*Ql1^2*Yv11 - 32*gp^4*MassU*Ql1^4*Yv11 + 
   (12*g1^2*gp^2*MassB*QHu*Ql2*Yv11)/5 + (12*g1^2*gp^2*MassU*QHu*Ql2*Yv11)/
    5 - (12*g1^2*gp^2*MassB*Ql1*Ql2*Yv11)/5 - 
   (12*g1^2*gp^2*MassU*Ql1*Ql2*Yv11)/5 - 16*gp^4*MassU*QHu^2*Ql2^2*Yv11 - 
   16*gp^4*MassU*Ql1^2*Ql2^2*Yv11 + (12*g1^2*gp^2*MassB*QHu*Ql3*Yv11)/5 + 
   (12*g1^2*gp^2*MassU*QHu*Ql3*Yv11)/5 - (12*g1^2*gp^2*MassB*Ql1*Ql3*Yv11)/
    5 - (12*g1^2*gp^2*MassU*Ql1*Ql3*Yv11)/5 - 16*gp^4*MassU*QHu^2*Ql3^2*
    Yv11 - 16*gp^4*MassU*Ql1^2*Ql3^2*Yv11 - (36*g1^2*gp^2*MassB*QHu*Qq*Yv11)/
    5 - (36*g1^2*gp^2*MassU*QHu*Qq*Yv11)/5 + (36*g1^2*gp^2*MassB*Ql1*Qq*Yv11)/
    5 + (36*g1^2*gp^2*MassU*Ql1*Qq*Yv11)/5 - 144*gp^4*MassU*QHu^2*Qq^2*Yv11 - 
   144*gp^4*MassU*Ql1^2*Qq^2*Yv11 - 8*gp^4*MassU*QHu^2*Qs^2*Yv11 - 
   8*gp^4*MassU*Ql1^2*Qs^2*Yv11 + (72*g1^2*gp^2*MassB*QHu*Qu*Yv11)/5 + 
   (72*g1^2*gp^2*MassU*QHu*Qu*Yv11)/5 - (72*g1^2*gp^2*MassB*Ql1*Qu*Yv11)/5 - 
   (72*g1^2*gp^2*MassU*Ql1*Qu*Yv11)/5 - 72*gp^4*MassU*QHu^2*Qu^2*Yv11 - 
   72*gp^4*MassU*Ql1^2*Qu^2*Yv11 - 72*gp^4*MassU*Qd^2*Qv1^2*Yv11 - 
   8*gp^4*MassU*Qe1^2*Qv1^2*Yv11 - 8*gp^4*MassU*Qe2^2*Qv1^2*Yv11 - 
   8*gp^4*MassU*Qe3^2*Qv1^2*Yv11 - 16*gp^4*MassU*QHd^2*Qv1^2*Yv11 - 
   24*gp^4*MassU*QHu^2*Qv1^2*Yv11 - 24*gp^4*MassU*Ql1^2*Qv1^2*Yv11 - 
   16*gp^4*MassU*Ql2^2*Qv1^2*Yv11 - 16*gp^4*MassU*Ql3^2*Qv1^2*Yv11 - 
   144*gp^4*MassU*Qq^2*Qv1^2*Yv11 - 8*gp^4*MassU*Qs^2*Qv1^2*Yv11 - 
   72*gp^4*MassU*Qu^2*Qv1^2*Yv11 - 24*gp^4*MassU*Qv1^4*Yv11 - 
   8*gp^4*MassU*QHu^2*Qv2^2*Yv11 - 8*gp^4*MassU*Ql1^2*Qv2^2*Yv11 - 
   8*gp^4*MassU*Qv1^2*Qv2^2*Yv11 - 8*gp^4*MassU*QHu^2*Qv3^2*Yv11 - 
   8*gp^4*MassU*Ql1^2*Qv3^2*Yv11 - 8*gp^4*MassU*Qv1^2*Qv3^2*Yv11 + 
   4*gp^2*MassU*QHu^2*Yv11*Yv22*conj[Yv22] - 4*gp^2*MassU*Ql2^2*Yv11*Yv22*
    conj[Yv22] - 4*gp^2*MassU*Qv2^2*Yv11*Yv22*conj[Yv22] + 
   4*gp^2*MassU*QHu^2*Yv11*Yv33*conj[Yv33] - 4*gp^2*MassU*Ql3^2*Yv11*Yv33*
    conj[Yv33] - 4*gp^2*MassU*Qv3^2*Yv11*Yv33*conj[Yv33] - 
   4*gp^2*MassU*QHd^2*Yv11*\[Lambda]*conj[\[Lambda]] + 
   4*gp^2*MassU*QHu^2*Yv11*\[Lambda]*conj[\[Lambda]] - 
   4*gp^2*MassU*Qs^2*Yv11*\[Lambda]*conj[\[Lambda]] - 
   2*Yv11*Yv22*conj[Ye22]*conj[Yv22]*T[Ye22] - 2*Yv11*\[Lambda]*conj[Ye22]*
    conj[\[Lambda]]*T[Ye22] - 2*Yv11*Yv33*conj[Ye33]*conj[Yv33]*T[Ye33] - 
   2*Yv11*\[Lambda]*conj[Ye33]*conj[\[Lambda]]*T[Ye33] + 
   (207*g1^4*T[Yv11])/50 + (9*g1^2*g2^2*T[Yv11])/5 + (15*g2^4*T[Yv11])/2 + 
   (18*g1^2*gp^2*Qd*QHu*T[Yv11])/5 + (6*g1^2*gp^2*Qe1*QHu*T[Yv11])/5 + 
   (6*g1^2*gp^2*Qe2*QHu*T[Yv11])/5 + (6*g1^2*gp^2*Qe3*QHu*T[Yv11])/5 - 
   (6*g1^2*gp^2*QHd*QHu*T[Yv11])/5 + (12*g1^2*gp^2*QHu^2*T[Yv11])/5 + 
   6*g2^2*gp^2*QHu^2*T[Yv11] + 18*gp^4*Qd^2*QHu^2*T[Yv11] + 
   2*gp^4*Qe1^2*QHu^2*T[Yv11] + 2*gp^4*Qe2^2*QHu^2*T[Yv11] + 
   2*gp^4*Qe3^2*QHu^2*T[Yv11] + 4*gp^4*QHd^2*QHu^2*T[Yv11] + 
   8*gp^4*QHu^4*T[Yv11] - (18*g1^2*gp^2*Qd*Ql1*T[Yv11])/5 - 
   (6*g1^2*gp^2*Qe1*Ql1*T[Yv11])/5 - (6*g1^2*gp^2*Qe2*Ql1*T[Yv11])/5 - 
   (6*g1^2*gp^2*Qe3*Ql1*T[Yv11])/5 + (6*g1^2*gp^2*QHd*Ql1*T[Yv11])/5 - 
   (12*g1^2*gp^2*QHu*Ql1*T[Yv11])/5 + (12*g1^2*gp^2*Ql1^2*T[Yv11])/5 + 
   6*g2^2*gp^2*Ql1^2*T[Yv11] + 18*gp^4*Qd^2*Ql1^2*T[Yv11] + 
   2*gp^4*Qe1^2*Ql1^2*T[Yv11] + 2*gp^4*Qe2^2*Ql1^2*T[Yv11] + 
   2*gp^4*Qe3^2*Ql1^2*T[Yv11] + 4*gp^4*QHd^2*Ql1^2*T[Yv11] + 
   8*gp^4*QHu^2*Ql1^2*T[Yv11] + 8*gp^4*Ql1^4*T[Yv11] - 
   (6*g1^2*gp^2*QHu*Ql2*T[Yv11])/5 + (6*g1^2*gp^2*Ql1*Ql2*T[Yv11])/5 + 
   4*gp^4*QHu^2*Ql2^2*T[Yv11] + 4*gp^4*Ql1^2*Ql2^2*T[Yv11] - 
   (6*g1^2*gp^2*QHu*Ql3*T[Yv11])/5 + (6*g1^2*gp^2*Ql1*Ql3*T[Yv11])/5 + 
   4*gp^4*QHu^2*Ql3^2*T[Yv11] + 4*gp^4*Ql1^2*Ql3^2*T[Yv11] + 
   (18*g1^2*gp^2*QHu*Qq*T[Yv11])/5 - (18*g1^2*gp^2*Ql1*Qq*T[Yv11])/5 + 
   36*gp^4*QHu^2*Qq^2*T[Yv11] + 36*gp^4*Ql1^2*Qq^2*T[Yv11] + 
   2*gp^4*QHu^2*Qs^2*T[Yv11] + 2*gp^4*Ql1^2*Qs^2*T[Yv11] - 
   (36*g1^2*gp^2*QHu*Qu*T[Yv11])/5 + (36*g1^2*gp^2*Ql1*Qu*T[Yv11])/5 + 
   18*gp^4*QHu^2*Qu^2*T[Yv11] + 18*gp^4*Ql1^2*Qu^2*T[Yv11] + 
   18*gp^4*Qd^2*Qv1^2*T[Yv11] + 2*gp^4*Qe1^2*Qv1^2*T[Yv11] + 
   2*gp^4*Qe2^2*Qv1^2*T[Yv11] + 2*gp^4*Qe3^2*Qv1^2*T[Yv11] + 
   4*gp^4*QHd^2*Qv1^2*T[Yv11] + 6*gp^4*QHu^2*Qv1^2*T[Yv11] + 
   6*gp^4*Ql1^2*Qv1^2*T[Yv11] + 4*gp^4*Ql2^2*Qv1^2*T[Yv11] + 
   4*gp^4*Ql3^2*Qv1^2*T[Yv11] + 36*gp^4*Qq^2*Qv1^2*T[Yv11] + 
   2*gp^4*Qs^2*Qv1^2*T[Yv11] + 18*gp^4*Qu^2*Qv1^2*T[Yv11] + 
   6*gp^4*Qv1^4*T[Yv11] + 2*gp^4*QHu^2*Qv2^2*T[Yv11] + 
   2*gp^4*Ql1^2*Qv2^2*T[Yv11] + 2*gp^4*Qv1^2*Qv2^2*T[Yv11] + 
   2*gp^4*QHu^2*Qv3^2*T[Yv11] + 2*gp^4*Ql1^2*Qv3^2*T[Yv11] + 
   2*gp^4*Qv1^2*Qv3^2*T[Yv11] - 50*Yv11^2*conj[Yv11]^2*T[Yv11] - 
   2*gp^2*QHu^2*Yv22*conj[Yv22]*T[Yv11] + 2*gp^2*Ql2^2*Yv22*conj[Yv22]*
    T[Yv11] + 2*gp^2*Qv2^2*Yv22*conj[Yv22]*T[Yv11] - 
   Ye22*Yv22*conj[Ye22]*conj[Yv22]*T[Yv11] - 3*Yv22^2*conj[Yv22]^2*T[Yv11] - 
   2*gp^2*QHu^2*Yv33*conj[Yv33]*T[Yv11] + 2*gp^2*Ql3^2*Yv33*conj[Yv33]*
    T[Yv11] + 2*gp^2*Qv3^2*Yv33*conj[Yv33]*T[Yv11] - 
   Ye33*Yv33*conj[Ye33]*conj[Yv33]*T[Yv11] - 3*Yv33^2*conj[Yv33]^2*T[Yv11] + 
   2*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]]*T[Yv11] - 
   2*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]]*T[Yv11] + 
   2*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]]*T[Yv11] - 
   Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]]*T[Yv11] - 
   Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]]*T[Yv11] - 
   3*\[Lambda]^2*conj[\[Lambda]]^2*T[Yv11] - 3*Ye11*conj[Ye11]^2*
    (4*Yv11*T[Ye11] + Ye11*T[Yv11]) - 4*gp^2*QHu^2*Yv11*conj[Yv22]*T[Yv22] + 
   4*gp^2*Ql2^2*Yv11*conj[Yv22]*T[Yv22] + 4*gp^2*Qv2^2*Yv11*conj[Yv22]*
    T[Yv22] - 2*Ye22*Yv11*conj[Ye22]*conj[Yv22]*T[Yv22] - 
   12*Yv11*Yv22*conj[Yv22]^2*T[Yv22] - 4*gp^2*QHu^2*Yv11*conj[Yv33]*T[Yv33] + 
   4*gp^2*Ql3^2*Yv11*conj[Yv33]*T[Yv33] + 4*gp^2*Qv3^2*Yv11*conj[Yv33]*
    T[Yv33] - 2*Ye33*Yv11*conj[Ye33]*conj[Yv33]*T[Yv33] - 
   12*Yv11*Yv33*conj[Yv33]^2*T[Yv33] + 4*gp^2*QHd^2*Yv11*conj[\[Lambda]]*
    T[\[Lambda]] - 4*gp^2*QHu^2*Yv11*conj[\[Lambda]]*T[\[Lambda]] + 
   4*gp^2*Qs^2*Yv11*conj[\[Lambda]]*T[\[Lambda]] - 
   2*Ye22*Yv11*conj[Ye22]*conj[\[Lambda]]*T[\[Lambda]] - 
   2*Ye33*Yv11*conj[Ye33]*conj[\[Lambda]]*T[\[Lambda]] - 
   12*Yv11*\[Lambda]*conj[\[Lambda]]^2*T[\[Lambda]] - 
   3*\[Lambda]*conj[\[Lambda]]*T[Yv11]*trace[Yd, Adj[Yd]] - 
   6*Yv11*conj[\[Lambda]]*T[\[Lambda]]*trace[Yd, Adj[Yd]] - 
   (8*g1^2*MassB*Yv11*trace[Yu, Adj[Yu]])/5 - 32*g3^2*MassG*Yv11*
    trace[Yu, Adj[Yu]] + 12*gp^2*MassU*QHu^2*Yv11*trace[Yu, Adj[Yu]] - 
   12*gp^2*MassU*Qq^2*Yv11*trace[Yu, Adj[Yu]] - 12*gp^2*MassU*Qu^2*Yv11*
    trace[Yu, Adj[Yu]] + (4*g1^2*T[Yv11]*trace[Yu, Adj[Yu]])/5 + 
   16*g3^2*T[Yv11]*trace[Yu, Adj[Yu]] - 6*gp^2*QHu^2*T[Yv11]*
    trace[Yu, Adj[Yu]] + 6*gp^2*Qq^2*T[Yv11]*trace[Yu, Adj[Yu]] + 
   6*gp^2*Qu^2*T[Yv11]*trace[Yu, Adj[Yu]] - 6*Yv11*\[Lambda]*conj[\[Lambda]]*
    trace[Adj[Yd], T[Yd]] - 
   (conj[Ye11]*(2*Yv11*T[Ye11]*(-6*g1^2 - 10*gp^2*Qe1^2 - 10*gp^2*QHd^2 + 
        10*gp^2*Ql1^2 + 5*Ye22*conj[Ye22] + 5*Ye33*conj[Ye33] + 
        15*Yv11*conj[Yv11] + 10*\[Lambda]*conj[\[Lambda]] + 
        15*trace[Yd, Adj[Yd]]) + Ye11*(12*g1^2*MassB*Yv11 + 
        20*gp^2*MassU*Qe1^2*Yv11 + 20*gp^2*MassU*QHd^2*Yv11 - 
        20*gp^2*MassU*Ql1^2*Yv11 - 6*g1^2*T[Yv11] - 10*gp^2*Qe1^2*T[Yv11] - 
        10*gp^2*QHd^2*T[Yv11] + 10*gp^2*Ql1^2*T[Yv11] + 
        45*Yv11*conj[Yv11]*T[Yv11] + 10*\[Lambda]*conj[\[Lambda]]*T[Yv11] + 
        5*conj[Ye22]*(2*Yv11*T[Ye22] + Ye22*T[Yv11]) + 
        5*conj[Ye33]*(2*Yv11*T[Ye33] + Ye33*T[Yv11]) + 
        20*Yv11*conj[\[Lambda]]*T[\[Lambda]] + 15*T[Yv11]*
         trace[Yd, Adj[Yd]] + 30*Yv11*trace[Adj[Yd], T[Yd]])))/5 + 
   (8*g1^2*Yv11*trace[Adj[Yu], T[Yu]])/5 + 
   32*g3^2*Yv11*trace[Adj[Yu], T[Yu]] - 12*gp^2*QHu^2*Yv11*
    trace[Adj[Yu], T[Yu]] + 12*gp^2*Qq^2*Yv11*trace[Adj[Yu], T[Yu]] + 
   12*gp^2*Qu^2*Yv11*trace[Adj[Yu], T[Yu]] - 
   (Yv11*conj[Yv11]*(-3*T[Yv11]*(6*g1^2 + 30*g2^2 + 20*gp^2*QHu^2 + 
        20*gp^2*Ql1^2 - 15*Yv22*conj[Yv22] - 15*Yv33*conj[Yv33] - 
        15*\[Lambda]*conj[\[Lambda]] - 45*trace[Yu, Adj[Yu]]) + 
      2*Yv11*(6*g1^2*MassB + 30*g2^2*MassWB + 20*gp^2*MassU*QHu^2 + 
        20*gp^2*MassU*Ql1^2 + 15*conj[Yv22]*T[Yv22] + 15*conj[Yv33]*T[Yv33] + 
        15*conj[\[Lambda]]*T[\[Lambda]] + 45*trace[Adj[Yu], T[Yu]])))/5 - 
   3*T[Yv11]*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   6*Yv11*trace[Yd, Adj[Yu], T[Yu], Adj[Yd]] - 
   6*Yv11*trace[Yu, Adj[Yd], T[Yd], Adj[Yu]] - 
   9*T[Yv11]*trace[Yu, Adj[Yu], Yu, Adj[Yu]] - 
   36*Yv11*trace[Yu, Adj[Yu], T[Yu], Adj[Yu]]}, 
 {T[Yv22], (6*g1^2*MassB*Yv22)/5 + 6*g2^2*MassWB*Yv22 + 
   4*gp^2*MassU*QHu^2*Yv22 + 4*gp^2*MassU*Ql2^2*Yv22 + 
   4*gp^2*MassU*Qv2^2*Yv22 - (3*g1^2*T[Yv22])/5 - 3*g2^2*T[Yv22] - 
   2*gp^2*QHu^2*T[Yv22] - 2*gp^2*Ql2^2*T[Yv22] - 2*gp^2*Qv2^2*T[Yv22] + 
   12*Yv22*conj[Yv22]*T[Yv22] + Yv33*conj[Yv33]*T[Yv22] + 
   \[Lambda]*conj[\[Lambda]]*T[Yv22] + 
   conj[Ye22]*(2*Yv22*T[Ye22] + Ye22*T[Yv22]) + 
   conj[Yv11]*(2*Yv22*T[Yv11] + Yv11*T[Yv22]) + 2*Yv22*conj[Yv33]*T[Yv33] + 
   2*Yv22*conj[\[Lambda]]*T[\[Lambda]] + 3*T[Yv22]*trace[Yu, Adj[Yu]] + 
   6*Yv22*trace[Adj[Yu], T[Yu]], (-414*g1^4*MassB*Yv22)/25 - 
   (18*g1^2*g2^2*MassB*Yv22)/5 - (18*g1^2*g2^2*MassWB*Yv22)/5 - 
   30*g2^4*MassWB*Yv22 - (36*g1^2*gp^2*MassB*Qd*QHu*Yv22)/5 - 
   (36*g1^2*gp^2*MassU*Qd*QHu*Yv22)/5 - (12*g1^2*gp^2*MassB*Qe1*QHu*Yv22)/5 - 
   (12*g1^2*gp^2*MassU*Qe1*QHu*Yv22)/5 - (12*g1^2*gp^2*MassB*Qe2*QHu*Yv22)/
    5 - (12*g1^2*gp^2*MassU*Qe2*QHu*Yv22)/5 - 
   (12*g1^2*gp^2*MassB*Qe3*QHu*Yv22)/5 - (12*g1^2*gp^2*MassU*Qe3*QHu*Yv22)/
    5 + (12*g1^2*gp^2*MassB*QHd*QHu*Yv22)/5 + 
   (12*g1^2*gp^2*MassU*QHd*QHu*Yv22)/5 - (24*g1^2*gp^2*MassB*QHu^2*Yv22)/5 - 
   (24*g1^2*gp^2*MassU*QHu^2*Yv22)/5 - 12*g2^2*gp^2*MassU*QHu^2*Yv22 - 
   12*g2^2*gp^2*MassWB*QHu^2*Yv22 - 72*gp^4*MassU*Qd^2*QHu^2*Yv22 - 
   8*gp^4*MassU*Qe1^2*QHu^2*Yv22 - 8*gp^4*MassU*Qe2^2*QHu^2*Yv22 - 
   8*gp^4*MassU*Qe3^2*QHu^2*Yv22 - 16*gp^4*MassU*QHd^2*QHu^2*Yv22 - 
   32*gp^4*MassU*QHu^4*Yv22 + (12*g1^2*gp^2*MassB*QHu*Ql1*Yv22)/5 + 
   (12*g1^2*gp^2*MassU*QHu*Ql1*Yv22)/5 - 16*gp^4*MassU*QHu^2*Ql1^2*Yv22 + 
   (36*g1^2*gp^2*MassB*Qd*Ql2*Yv22)/5 + (36*g1^2*gp^2*MassU*Qd*Ql2*Yv22)/5 + 
   (12*g1^2*gp^2*MassB*Qe1*Ql2*Yv22)/5 + (12*g1^2*gp^2*MassU*Qe1*Ql2*Yv22)/
    5 + (12*g1^2*gp^2*MassB*Qe2*Ql2*Yv22)/5 + 
   (12*g1^2*gp^2*MassU*Qe2*Ql2*Yv22)/5 + (12*g1^2*gp^2*MassB*Qe3*Ql2*Yv22)/
    5 + (12*g1^2*gp^2*MassU*Qe3*Ql2*Yv22)/5 - 
   (12*g1^2*gp^2*MassB*QHd*Ql2*Yv22)/5 - (12*g1^2*gp^2*MassU*QHd*Ql2*Yv22)/
    5 + (24*g1^2*gp^2*MassB*QHu*Ql2*Yv22)/5 + 
   (24*g1^2*gp^2*MassU*QHu*Ql2*Yv22)/5 - (12*g1^2*gp^2*MassB*Ql1*Ql2*Yv22)/
    5 - (12*g1^2*gp^2*MassU*Ql1*Ql2*Yv22)/5 - (24*g1^2*gp^2*MassB*Ql2^2*Yv22)/
    5 - (24*g1^2*gp^2*MassU*Ql2^2*Yv22)/5 - 12*g2^2*gp^2*MassU*Ql2^2*Yv22 - 
   12*g2^2*gp^2*MassWB*Ql2^2*Yv22 - 72*gp^4*MassU*Qd^2*Ql2^2*Yv22 - 
   8*gp^4*MassU*Qe1^2*Ql2^2*Yv22 - 8*gp^4*MassU*Qe2^2*Ql2^2*Yv22 - 
   8*gp^4*MassU*Qe3^2*Ql2^2*Yv22 - 16*gp^4*MassU*QHd^2*Ql2^2*Yv22 - 
   32*gp^4*MassU*QHu^2*Ql2^2*Yv22 - 16*gp^4*MassU*Ql1^2*Ql2^2*Yv22 - 
   32*gp^4*MassU*Ql2^4*Yv22 + (12*g1^2*gp^2*MassB*QHu*Ql3*Yv22)/5 + 
   (12*g1^2*gp^2*MassU*QHu*Ql3*Yv22)/5 - (12*g1^2*gp^2*MassB*Ql2*Ql3*Yv22)/
    5 - (12*g1^2*gp^2*MassU*Ql2*Ql3*Yv22)/5 - 16*gp^4*MassU*QHu^2*Ql3^2*
    Yv22 - 16*gp^4*MassU*Ql2^2*Ql3^2*Yv22 - (36*g1^2*gp^2*MassB*QHu*Qq*Yv22)/
    5 - (36*g1^2*gp^2*MassU*QHu*Qq*Yv22)/5 + (36*g1^2*gp^2*MassB*Ql2*Qq*Yv22)/
    5 + (36*g1^2*gp^2*MassU*Ql2*Qq*Yv22)/5 - 144*gp^4*MassU*QHu^2*Qq^2*Yv22 - 
   144*gp^4*MassU*Ql2^2*Qq^2*Yv22 - 8*gp^4*MassU*QHu^2*Qs^2*Yv22 - 
   8*gp^4*MassU*Ql2^2*Qs^2*Yv22 + (72*g1^2*gp^2*MassB*QHu*Qu*Yv22)/5 + 
   (72*g1^2*gp^2*MassU*QHu*Qu*Yv22)/5 - (72*g1^2*gp^2*MassB*Ql2*Qu*Yv22)/5 - 
   (72*g1^2*gp^2*MassU*Ql2*Qu*Yv22)/5 - 72*gp^4*MassU*QHu^2*Qu^2*Yv22 - 
   72*gp^4*MassU*Ql2^2*Qu^2*Yv22 - 8*gp^4*MassU*QHu^2*Qv1^2*Yv22 - 
   8*gp^4*MassU*Ql2^2*Qv1^2*Yv22 - 72*gp^4*MassU*Qd^2*Qv2^2*Yv22 - 
   8*gp^4*MassU*Qe1^2*Qv2^2*Yv22 - 8*gp^4*MassU*Qe2^2*Qv2^2*Yv22 - 
   8*gp^4*MassU*Qe3^2*Qv2^2*Yv22 - 16*gp^4*MassU*QHd^2*Qv2^2*Yv22 - 
   24*gp^4*MassU*QHu^2*Qv2^2*Yv22 - 16*gp^4*MassU*Ql1^2*Qv2^2*Yv22 - 
   24*gp^4*MassU*Ql2^2*Qv2^2*Yv22 - 16*gp^4*MassU*Ql3^2*Qv2^2*Yv22 - 
   144*gp^4*MassU*Qq^2*Qv2^2*Yv22 - 8*gp^4*MassU*Qs^2*Qv2^2*Yv22 - 
   72*gp^4*MassU*Qu^2*Qv2^2*Yv22 - 8*gp^4*MassU*Qv1^2*Qv2^2*Yv22 - 
   24*gp^4*MassU*Qv2^4*Yv22 - 8*gp^4*MassU*QHu^2*Qv3^2*Yv22 - 
   8*gp^4*MassU*Ql2^2*Qv3^2*Yv22 - 8*gp^4*MassU*Qv2^2*Qv3^2*Yv22 - 
   (12*g1^2*MassB*Yv22^2*conj[Yv22])/5 - 12*g2^2*MassWB*Yv22^2*conj[Yv22] - 
   8*gp^2*MassU*QHu^2*Yv22^2*conj[Yv22] - 8*gp^2*MassU*Ql2^2*Yv22^2*
    conj[Yv22] + 4*gp^2*MassU*QHu^2*Yv22*Yv33*conj[Yv33] - 
   4*gp^2*MassU*Ql3^2*Yv22*Yv33*conj[Yv33] - 4*gp^2*MassU*Qv3^2*Yv22*Yv33*
    conj[Yv33] - 4*gp^2*MassU*QHd^2*Yv22*\[Lambda]*conj[\[Lambda]] + 
   4*gp^2*MassU*QHu^2*Yv22*\[Lambda]*conj[\[Lambda]] - 
   4*gp^2*MassU*Qs^2*Yv22*\[Lambda]*conj[\[Lambda]] - 
   2*Yv22*\[Lambda]*conj[Ye11]*conj[\[Lambda]]*T[Ye11] - 
   2*Yv22*Yv33*conj[Ye33]*conj[Yv33]*T[Ye33] - 2*Yv22*\[Lambda]*conj[Ye33]*
    conj[\[Lambda]]*T[Ye33] + (207*g1^4*T[Yv22])/50 + 
   (9*g1^2*g2^2*T[Yv22])/5 + (15*g2^4*T[Yv22])/2 + 
   (18*g1^2*gp^2*Qd*QHu*T[Yv22])/5 + (6*g1^2*gp^2*Qe1*QHu*T[Yv22])/5 + 
   (6*g1^2*gp^2*Qe2*QHu*T[Yv22])/5 + (6*g1^2*gp^2*Qe3*QHu*T[Yv22])/5 - 
   (6*g1^2*gp^2*QHd*QHu*T[Yv22])/5 + (12*g1^2*gp^2*QHu^2*T[Yv22])/5 + 
   6*g2^2*gp^2*QHu^2*T[Yv22] + 18*gp^4*Qd^2*QHu^2*T[Yv22] + 
   2*gp^4*Qe1^2*QHu^2*T[Yv22] + 2*gp^4*Qe2^2*QHu^2*T[Yv22] + 
   2*gp^4*Qe3^2*QHu^2*T[Yv22] + 4*gp^4*QHd^2*QHu^2*T[Yv22] + 
   8*gp^4*QHu^4*T[Yv22] - (6*g1^2*gp^2*QHu*Ql1*T[Yv22])/5 + 
   4*gp^4*QHu^2*Ql1^2*T[Yv22] - (18*g1^2*gp^2*Qd*Ql2*T[Yv22])/5 - 
   (6*g1^2*gp^2*Qe1*Ql2*T[Yv22])/5 - (6*g1^2*gp^2*Qe2*Ql2*T[Yv22])/5 - 
   (6*g1^2*gp^2*Qe3*Ql2*T[Yv22])/5 + (6*g1^2*gp^2*QHd*Ql2*T[Yv22])/5 - 
   (12*g1^2*gp^2*QHu*Ql2*T[Yv22])/5 + (6*g1^2*gp^2*Ql1*Ql2*T[Yv22])/5 + 
   (12*g1^2*gp^2*Ql2^2*T[Yv22])/5 + 6*g2^2*gp^2*Ql2^2*T[Yv22] + 
   18*gp^4*Qd^2*Ql2^2*T[Yv22] + 2*gp^4*Qe1^2*Ql2^2*T[Yv22] + 
   2*gp^4*Qe2^2*Ql2^2*T[Yv22] + 2*gp^4*Qe3^2*Ql2^2*T[Yv22] + 
   4*gp^4*QHd^2*Ql2^2*T[Yv22] + 8*gp^4*QHu^2*Ql2^2*T[Yv22] + 
   4*gp^4*Ql1^2*Ql2^2*T[Yv22] + 8*gp^4*Ql2^4*T[Yv22] - 
   (6*g1^2*gp^2*QHu*Ql3*T[Yv22])/5 + (6*g1^2*gp^2*Ql2*Ql3*T[Yv22])/5 + 
   4*gp^4*QHu^2*Ql3^2*T[Yv22] + 4*gp^4*Ql2^2*Ql3^2*T[Yv22] + 
   (18*g1^2*gp^2*QHu*Qq*T[Yv22])/5 - (18*g1^2*gp^2*Ql2*Qq*T[Yv22])/5 + 
   36*gp^4*QHu^2*Qq^2*T[Yv22] + 36*gp^4*Ql2^2*Qq^2*T[Yv22] + 
   2*gp^4*QHu^2*Qs^2*T[Yv22] + 2*gp^4*Ql2^2*Qs^2*T[Yv22] - 
   (36*g1^2*gp^2*QHu*Qu*T[Yv22])/5 + (36*g1^2*gp^2*Ql2*Qu*T[Yv22])/5 + 
   18*gp^4*QHu^2*Qu^2*T[Yv22] + 18*gp^4*Ql2^2*Qu^2*T[Yv22] + 
   2*gp^4*QHu^2*Qv1^2*T[Yv22] + 2*gp^4*Ql2^2*Qv1^2*T[Yv22] + 
   18*gp^4*Qd^2*Qv2^2*T[Yv22] + 2*gp^4*Qe1^2*Qv2^2*T[Yv22] + 
   2*gp^4*Qe2^2*Qv2^2*T[Yv22] + 2*gp^4*Qe3^2*Qv2^2*T[Yv22] + 
   4*gp^4*QHd^2*Qv2^2*T[Yv22] + 6*gp^4*QHu^2*Qv2^2*T[Yv22] + 
   4*gp^4*Ql1^2*Qv2^2*T[Yv22] + 6*gp^4*Ql2^2*Qv2^2*T[Yv22] + 
   4*gp^4*Ql3^2*Qv2^2*T[Yv22] + 36*gp^4*Qq^2*Qv2^2*T[Yv22] + 
   2*gp^4*Qs^2*Qv2^2*T[Yv22] + 18*gp^4*Qu^2*Qv2^2*T[Yv22] + 
   2*gp^4*Qv1^2*Qv2^2*T[Yv22] + 6*gp^4*Qv2^4*T[Yv22] + 
   2*gp^4*QHu^2*Qv3^2*T[Yv22] + 2*gp^4*Ql2^2*Qv3^2*T[Yv22] + 
   2*gp^4*Qv2^2*Qv3^2*T[Yv22] + (18*g1^2*Yv22*conj[Yv22]*T[Yv22])/5 + 
   18*g2^2*Yv22*conj[Yv22]*T[Yv22] + 12*gp^2*QHu^2*Yv22*conj[Yv22]*T[Yv22] + 
   12*gp^2*Ql2^2*Yv22*conj[Yv22]*T[Yv22] - 50*Yv22^2*conj[Yv22]^2*T[Yv22] - 
   2*gp^2*QHu^2*Yv33*conj[Yv33]*T[Yv22] + 2*gp^2*Ql3^2*Yv33*conj[Yv33]*
    T[Yv22] + 2*gp^2*Qv3^2*Yv33*conj[Yv33]*T[Yv22] - 
   Ye33*Yv33*conj[Ye33]*conj[Yv33]*T[Yv22] - 9*Yv22*Yv33*conj[Yv22]*
    conj[Yv33]*T[Yv22] - 3*Yv33^2*conj[Yv33]^2*T[Yv22] + 
   2*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]]*T[Yv22] - 
   2*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]]*T[Yv22] + 
   2*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]]*T[Yv22] - 
   Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]]*T[Yv22] - 
   Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]]*T[Yv22] - 
   9*Yv22*\[Lambda]*conj[Yv22]*conj[\[Lambda]]*T[Yv22] - 
   3*\[Lambda]^2*conj[\[Lambda]]^2*T[Yv22] - 3*Ye22*conj[Ye22]^2*
    (4*Yv22*T[Ye22] + Ye22*T[Yv22]) - 3*Yv11*conj[Yv11]^2*
    (4*Yv22*T[Yv11] + Yv11*T[Yv22]) + 
   conj[Yv11]*(2*Yv22*(2*gp^2*(-QHu^2 + Ql1^2 + Qv1^2) - 3*Yv22*conj[Yv22])*
      T[Yv11] - conj[Ye11]*(2*Yv11*Yv22*T[Ye11] + 2*Ye11*Yv22*T[Yv11] + 
       Ye11*Yv11*T[Yv22]) + Yv11*(4*gp^2*MassU*(QHu^2 - Ql1^2 - Qv1^2)*Yv22 + 
       (2*gp^2*(-QHu^2 + Ql1^2 + Qv1^2) - 9*Yv22*conj[Yv22])*T[Yv22])) - 
   4*gp^2*QHu^2*Yv22*conj[Yv33]*T[Yv33] + 4*gp^2*Ql3^2*Yv22*conj[Yv33]*
    T[Yv33] + 4*gp^2*Qv3^2*Yv22*conj[Yv33]*T[Yv33] - 
   2*Ye33*Yv22*conj[Ye33]*conj[Yv33]*T[Yv33] - 6*Yv22^2*conj[Yv22]*conj[Yv33]*
    T[Yv33] - 12*Yv22*Yv33*conj[Yv33]^2*T[Yv33] + 
   4*gp^2*QHd^2*Yv22*conj[\[Lambda]]*T[\[Lambda]] - 
   4*gp^2*QHu^2*Yv22*conj[\[Lambda]]*T[\[Lambda]] + 
   4*gp^2*Qs^2*Yv22*conj[\[Lambda]]*T[\[Lambda]] - 
   2*Ye11*Yv22*conj[Ye11]*conj[\[Lambda]]*T[\[Lambda]] - 
   2*Ye33*Yv22*conj[Ye33]*conj[\[Lambda]]*T[\[Lambda]] - 
   6*Yv22^2*conj[Yv22]*conj[\[Lambda]]*T[\[Lambda]] - 
   12*Yv22*\[Lambda]*conj[\[Lambda]]^2*T[\[Lambda]] - 
   3*\[Lambda]*conj[\[Lambda]]*T[Yv22]*trace[Yd, Adj[Yd]] - 
   6*Yv22*conj[\[Lambda]]*T[\[Lambda]]*trace[Yd, Adj[Yd]] - 
   (8*g1^2*MassB*Yv22*trace[Yu, Adj[Yu]])/5 - 32*g3^2*MassG*Yv22*
    trace[Yu, Adj[Yu]] + 12*gp^2*MassU*QHu^2*Yv22*trace[Yu, Adj[Yu]] - 
   12*gp^2*MassU*Qq^2*Yv22*trace[Yu, Adj[Yu]] - 12*gp^2*MassU*Qu^2*Yv22*
    trace[Yu, Adj[Yu]] + (4*g1^2*T[Yv22]*trace[Yu, Adj[Yu]])/5 + 
   16*g3^2*T[Yv22]*trace[Yu, Adj[Yu]] - 6*gp^2*QHu^2*T[Yv22]*
    trace[Yu, Adj[Yu]] + 6*gp^2*Qq^2*T[Yv22]*trace[Yu, Adj[Yu]] + 
   6*gp^2*Qu^2*T[Yv22]*trace[Yu, Adj[Yu]] - 27*Yv22*conj[Yv22]*T[Yv22]*
    trace[Yu, Adj[Yu]] - 6*Yv22*\[Lambda]*conj[\[Lambda]]*
    trace[Adj[Yd], T[Yd]] - 
   (conj[Ye22]*(5*conj[Ye11]*(2*Ye22*Yv22*T[Ye11] + 2*Ye11*Yv22*T[Ye22] + 
        Ye11*Ye22*T[Yv22]) + 2*Yv22*T[Ye22]*(-6*g1^2 - 10*gp^2*Qe2^2 - 
        10*gp^2*QHd^2 + 10*gp^2*Ql2^2 + 5*Ye33*conj[Ye33] + 
        15*Yv22*conj[Yv22] + 10*\[Lambda]*conj[\[Lambda]] + 
        15*trace[Yd, Adj[Yd]]) + 
      Ye22*(5*conj[Ye33]*(2*Yv22*T[Ye33] + Ye33*T[Yv22]) + 
        T[Yv22]*(-6*g1^2 - 10*gp^2*Qe2^2 - 10*gp^2*QHd^2 + 10*gp^2*Ql2^2 + 
          45*Yv22*conj[Yv22] + 10*\[Lambda]*conj[\[Lambda]] + 
          15*trace[Yd, Adj[Yd]]) + 2*Yv22*(6*g1^2*MassB + 
          10*gp^2*MassU*Qe2^2 + 10*gp^2*MassU*QHd^2 - 10*gp^2*MassU*Ql2^2 + 
          10*conj[\[Lambda]]*T[\[Lambda]] + 15*trace[Adj[Yd], T[Yd]]))))/5 + 
   (8*g1^2*Yv22*trace[Adj[Yu], T[Yu]])/5 + 
   32*g3^2*Yv22*trace[Adj[Yu], T[Yu]] - 12*gp^2*QHu^2*Yv22*
    trace[Adj[Yu], T[Yu]] + 12*gp^2*Qq^2*Yv22*trace[Adj[Yu], T[Yu]] + 
   12*gp^2*Qu^2*Yv22*trace[Adj[Yu], T[Yu]] - 18*Yv22^2*conj[Yv22]*
    trace[Adj[Yu], T[Yu]] - 3*T[Yv22]*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   6*Yv22*trace[Yd, Adj[Yu], T[Yu], Adj[Yd]] - 
   6*Yv22*trace[Yu, Adj[Yd], T[Yd], Adj[Yu]] - 
   9*T[Yv22]*trace[Yu, Adj[Yu], Yu, Adj[Yu]] - 
   36*Yv22*trace[Yu, Adj[Yu], T[Yu], Adj[Yu]]}, 
 {T[Yv33], (6*g1^2*MassB*Yv33)/5 + 6*g2^2*MassWB*Yv33 + 
   4*gp^2*MassU*QHu^2*Yv33 + 4*gp^2*MassU*Ql3^2*Yv33 + 
   4*gp^2*MassU*Qv3^2*Yv33 + 2*Yv33*conj[Yv22]*T[Yv22] - (3*g1^2*T[Yv33])/5 - 
   3*g2^2*T[Yv33] - 2*gp^2*QHu^2*T[Yv33] - 2*gp^2*Ql3^2*T[Yv33] - 
   2*gp^2*Qv3^2*T[Yv33] + Yv22*conj[Yv22]*T[Yv33] + 
   12*Yv33*conj[Yv33]*T[Yv33] + \[Lambda]*conj[\[Lambda]]*T[Yv33] + 
   conj[Ye33]*(2*Yv33*T[Ye33] + Ye33*T[Yv33]) + 
   conj[Yv11]*(2*Yv33*T[Yv11] + Yv11*T[Yv33]) + 2*Yv33*conj[\[Lambda]]*
    T[\[Lambda]] + 3*T[Yv33]*trace[Yu, Adj[Yu]] + 
   6*Yv33*trace[Adj[Yu], T[Yu]], (-414*g1^4*MassB*Yv33)/25 - 
   (18*g1^2*g2^2*MassB*Yv33)/5 - (18*g1^2*g2^2*MassWB*Yv33)/5 - 
   30*g2^4*MassWB*Yv33 - (36*g1^2*gp^2*MassB*Qd*QHu*Yv33)/5 - 
   (36*g1^2*gp^2*MassU*Qd*QHu*Yv33)/5 - (12*g1^2*gp^2*MassB*Qe1*QHu*Yv33)/5 - 
   (12*g1^2*gp^2*MassU*Qe1*QHu*Yv33)/5 - (12*g1^2*gp^2*MassB*Qe2*QHu*Yv33)/
    5 - (12*g1^2*gp^2*MassU*Qe2*QHu*Yv33)/5 - 
   (12*g1^2*gp^2*MassB*Qe3*QHu*Yv33)/5 - (12*g1^2*gp^2*MassU*Qe3*QHu*Yv33)/
    5 + (12*g1^2*gp^2*MassB*QHd*QHu*Yv33)/5 + 
   (12*g1^2*gp^2*MassU*QHd*QHu*Yv33)/5 - (24*g1^2*gp^2*MassB*QHu^2*Yv33)/5 - 
   (24*g1^2*gp^2*MassU*QHu^2*Yv33)/5 - 12*g2^2*gp^2*MassU*QHu^2*Yv33 - 
   12*g2^2*gp^2*MassWB*QHu^2*Yv33 - 72*gp^4*MassU*Qd^2*QHu^2*Yv33 - 
   8*gp^4*MassU*Qe1^2*QHu^2*Yv33 - 8*gp^4*MassU*Qe2^2*QHu^2*Yv33 - 
   8*gp^4*MassU*Qe3^2*QHu^2*Yv33 - 16*gp^4*MassU*QHd^2*QHu^2*Yv33 - 
   32*gp^4*MassU*QHu^4*Yv33 + (12*g1^2*gp^2*MassB*QHu*Ql1*Yv33)/5 + 
   (12*g1^2*gp^2*MassU*QHu*Ql1*Yv33)/5 - 16*gp^4*MassU*QHu^2*Ql1^2*Yv33 + 
   (12*g1^2*gp^2*MassB*QHu*Ql2*Yv33)/5 + (12*g1^2*gp^2*MassU*QHu*Ql2*Yv33)/
    5 - 16*gp^4*MassU*QHu^2*Ql2^2*Yv33 + (36*g1^2*gp^2*MassB*Qd*Ql3*Yv33)/5 + 
   (36*g1^2*gp^2*MassU*Qd*Ql3*Yv33)/5 + (12*g1^2*gp^2*MassB*Qe1*Ql3*Yv33)/5 + 
   (12*g1^2*gp^2*MassU*Qe1*Ql3*Yv33)/5 + (12*g1^2*gp^2*MassB*Qe2*Ql3*Yv33)/
    5 + (12*g1^2*gp^2*MassU*Qe2*Ql3*Yv33)/5 + 
   (12*g1^2*gp^2*MassB*Qe3*Ql3*Yv33)/5 + (12*g1^2*gp^2*MassU*Qe3*Ql3*Yv33)/
    5 - (12*g1^2*gp^2*MassB*QHd*Ql3*Yv33)/5 - 
   (12*g1^2*gp^2*MassU*QHd*Ql3*Yv33)/5 + (24*g1^2*gp^2*MassB*QHu*Ql3*Yv33)/
    5 + (24*g1^2*gp^2*MassU*QHu*Ql3*Yv33)/5 - 
   (12*g1^2*gp^2*MassB*Ql1*Ql3*Yv33)/5 - (12*g1^2*gp^2*MassU*Ql1*Ql3*Yv33)/
    5 - (12*g1^2*gp^2*MassB*Ql2*Ql3*Yv33)/5 - 
   (12*g1^2*gp^2*MassU*Ql2*Ql3*Yv33)/5 - (24*g1^2*gp^2*MassB*Ql3^2*Yv33)/5 - 
   (24*g1^2*gp^2*MassU*Ql3^2*Yv33)/5 - 12*g2^2*gp^2*MassU*Ql3^2*Yv33 - 
   12*g2^2*gp^2*MassWB*Ql3^2*Yv33 - 72*gp^4*MassU*Qd^2*Ql3^2*Yv33 - 
   8*gp^4*MassU*Qe1^2*Ql3^2*Yv33 - 8*gp^4*MassU*Qe2^2*Ql3^2*Yv33 - 
   8*gp^4*MassU*Qe3^2*Ql3^2*Yv33 - 16*gp^4*MassU*QHd^2*Ql3^2*Yv33 - 
   32*gp^4*MassU*QHu^2*Ql3^2*Yv33 - 16*gp^4*MassU*Ql1^2*Ql3^2*Yv33 - 
   16*gp^4*MassU*Ql2^2*Ql3^2*Yv33 - 32*gp^4*MassU*Ql3^4*Yv33 - 
   (36*g1^2*gp^2*MassB*QHu*Qq*Yv33)/5 - (36*g1^2*gp^2*MassU*QHu*Qq*Yv33)/5 + 
   (36*g1^2*gp^2*MassB*Ql3*Qq*Yv33)/5 + (36*g1^2*gp^2*MassU*Ql3*Qq*Yv33)/5 - 
   144*gp^4*MassU*QHu^2*Qq^2*Yv33 - 144*gp^4*MassU*Ql3^2*Qq^2*Yv33 - 
   8*gp^4*MassU*QHu^2*Qs^2*Yv33 - 8*gp^4*MassU*Ql3^2*Qs^2*Yv33 + 
   (72*g1^2*gp^2*MassB*QHu*Qu*Yv33)/5 + (72*g1^2*gp^2*MassU*QHu*Qu*Yv33)/5 - 
   (72*g1^2*gp^2*MassB*Ql3*Qu*Yv33)/5 - (72*g1^2*gp^2*MassU*Ql3*Qu*Yv33)/5 - 
   72*gp^4*MassU*QHu^2*Qu^2*Yv33 - 72*gp^4*MassU*Ql3^2*Qu^2*Yv33 - 
   8*gp^4*MassU*QHu^2*Qv1^2*Yv33 - 8*gp^4*MassU*Ql3^2*Qv1^2*Yv33 - 
   8*gp^4*MassU*QHu^2*Qv2^2*Yv33 - 8*gp^4*MassU*Ql3^2*Qv2^2*Yv33 - 
   72*gp^4*MassU*Qd^2*Qv3^2*Yv33 - 8*gp^4*MassU*Qe1^2*Qv3^2*Yv33 - 
   8*gp^4*MassU*Qe2^2*Qv3^2*Yv33 - 8*gp^4*MassU*Qe3^2*Qv3^2*Yv33 - 
   16*gp^4*MassU*QHd^2*Qv3^2*Yv33 - 24*gp^4*MassU*QHu^2*Qv3^2*Yv33 - 
   16*gp^4*MassU*Ql1^2*Qv3^2*Yv33 - 16*gp^4*MassU*Ql2^2*Qv3^2*Yv33 - 
   24*gp^4*MassU*Ql3^2*Qv3^2*Yv33 - 144*gp^4*MassU*Qq^2*Qv3^2*Yv33 - 
   8*gp^4*MassU*Qs^2*Qv3^2*Yv33 - 72*gp^4*MassU*Qu^2*Qv3^2*Yv33 - 
   8*gp^4*MassU*Qv1^2*Qv3^2*Yv33 - 8*gp^4*MassU*Qv2^2*Qv3^2*Yv33 - 
   24*gp^4*MassU*Qv3^4*Yv33 + 4*gp^2*MassU*QHu^2*Yv22*Yv33*conj[Yv22] - 
   4*gp^2*MassU*Ql2^2*Yv22*Yv33*conj[Yv22] - 4*gp^2*MassU*Qv2^2*Yv22*Yv33*
    conj[Yv22] - (12*g1^2*MassB*Yv33^2*conj[Yv33])/5 - 
   12*g2^2*MassWB*Yv33^2*conj[Yv33] - 8*gp^2*MassU*QHu^2*Yv33^2*conj[Yv33] - 
   8*gp^2*MassU*Ql3^2*Yv33^2*conj[Yv33] - 4*gp^2*MassU*QHd^2*Yv33*\[Lambda]*
    conj[\[Lambda]] + 4*gp^2*MassU*QHu^2*Yv33*\[Lambda]*conj[\[Lambda]] - 
   4*gp^2*MassU*Qs^2*Yv33*\[Lambda]*conj[\[Lambda]] - 
   2*Yv33*\[Lambda]*conj[Ye11]*conj[\[Lambda]]*T[Ye11] - 
   2*Yv22*Yv33*conj[Ye22]*conj[Yv22]*T[Ye22] - 2*Yv33*\[Lambda]*conj[Ye22]*
    conj[\[Lambda]]*T[Ye22] - 4*gp^2*QHu^2*Yv33*conj[Yv22]*T[Yv22] + 
   4*gp^2*Ql2^2*Yv33*conj[Yv22]*T[Yv22] + 4*gp^2*Qv2^2*Yv33*conj[Yv22]*
    T[Yv22] - 2*Ye22*Yv33*conj[Ye22]*conj[Yv22]*T[Yv22] - 
   12*Yv22*Yv33*conj[Yv22]^2*T[Yv22] - 6*Yv33^2*conj[Yv22]*conj[Yv33]*
    T[Yv22] + (207*g1^4*T[Yv33])/50 + (9*g1^2*g2^2*T[Yv33])/5 + 
   (15*g2^4*T[Yv33])/2 + (18*g1^2*gp^2*Qd*QHu*T[Yv33])/5 + 
   (6*g1^2*gp^2*Qe1*QHu*T[Yv33])/5 + (6*g1^2*gp^2*Qe2*QHu*T[Yv33])/5 + 
   (6*g1^2*gp^2*Qe3*QHu*T[Yv33])/5 - (6*g1^2*gp^2*QHd*QHu*T[Yv33])/5 + 
   (12*g1^2*gp^2*QHu^2*T[Yv33])/5 + 6*g2^2*gp^2*QHu^2*T[Yv33] + 
   18*gp^4*Qd^2*QHu^2*T[Yv33] + 2*gp^4*Qe1^2*QHu^2*T[Yv33] + 
   2*gp^4*Qe2^2*QHu^2*T[Yv33] + 2*gp^4*Qe3^2*QHu^2*T[Yv33] + 
   4*gp^4*QHd^2*QHu^2*T[Yv33] + 8*gp^4*QHu^4*T[Yv33] - 
   (6*g1^2*gp^2*QHu*Ql1*T[Yv33])/5 + 4*gp^4*QHu^2*Ql1^2*T[Yv33] - 
   (6*g1^2*gp^2*QHu*Ql2*T[Yv33])/5 + 4*gp^4*QHu^2*Ql2^2*T[Yv33] - 
   (18*g1^2*gp^2*Qd*Ql3*T[Yv33])/5 - (6*g1^2*gp^2*Qe1*Ql3*T[Yv33])/5 - 
   (6*g1^2*gp^2*Qe2*Ql3*T[Yv33])/5 - (6*g1^2*gp^2*Qe3*Ql3*T[Yv33])/5 + 
   (6*g1^2*gp^2*QHd*Ql3*T[Yv33])/5 - (12*g1^2*gp^2*QHu*Ql3*T[Yv33])/5 + 
   (6*g1^2*gp^2*Ql1*Ql3*T[Yv33])/5 + (6*g1^2*gp^2*Ql2*Ql3*T[Yv33])/5 + 
   (12*g1^2*gp^2*Ql3^2*T[Yv33])/5 + 6*g2^2*gp^2*Ql3^2*T[Yv33] + 
   18*gp^4*Qd^2*Ql3^2*T[Yv33] + 2*gp^4*Qe1^2*Ql3^2*T[Yv33] + 
   2*gp^4*Qe2^2*Ql3^2*T[Yv33] + 2*gp^4*Qe3^2*Ql3^2*T[Yv33] + 
   4*gp^4*QHd^2*Ql3^2*T[Yv33] + 8*gp^4*QHu^2*Ql3^2*T[Yv33] + 
   4*gp^4*Ql1^2*Ql3^2*T[Yv33] + 4*gp^4*Ql2^2*Ql3^2*T[Yv33] + 
   8*gp^4*Ql3^4*T[Yv33] + (18*g1^2*gp^2*QHu*Qq*T[Yv33])/5 - 
   (18*g1^2*gp^2*Ql3*Qq*T[Yv33])/5 + 36*gp^4*QHu^2*Qq^2*T[Yv33] + 
   36*gp^4*Ql3^2*Qq^2*T[Yv33] + 2*gp^4*QHu^2*Qs^2*T[Yv33] + 
   2*gp^4*Ql3^2*Qs^2*T[Yv33] - (36*g1^2*gp^2*QHu*Qu*T[Yv33])/5 + 
   (36*g1^2*gp^2*Ql3*Qu*T[Yv33])/5 + 18*gp^4*QHu^2*Qu^2*T[Yv33] + 
   18*gp^4*Ql3^2*Qu^2*T[Yv33] + 2*gp^4*QHu^2*Qv1^2*T[Yv33] + 
   2*gp^4*Ql3^2*Qv1^2*T[Yv33] + 2*gp^4*QHu^2*Qv2^2*T[Yv33] + 
   2*gp^4*Ql3^2*Qv2^2*T[Yv33] + 18*gp^4*Qd^2*Qv3^2*T[Yv33] + 
   2*gp^4*Qe1^2*Qv3^2*T[Yv33] + 2*gp^4*Qe2^2*Qv3^2*T[Yv33] + 
   2*gp^4*Qe3^2*Qv3^2*T[Yv33] + 4*gp^4*QHd^2*Qv3^2*T[Yv33] + 
   6*gp^4*QHu^2*Qv3^2*T[Yv33] + 4*gp^4*Ql1^2*Qv3^2*T[Yv33] + 
   4*gp^4*Ql2^2*Qv3^2*T[Yv33] + 6*gp^4*Ql3^2*Qv3^2*T[Yv33] + 
   36*gp^4*Qq^2*Qv3^2*T[Yv33] + 2*gp^4*Qs^2*Qv3^2*T[Yv33] + 
   18*gp^4*Qu^2*Qv3^2*T[Yv33] + 2*gp^4*Qv1^2*Qv3^2*T[Yv33] + 
   2*gp^4*Qv2^2*Qv3^2*T[Yv33] + 6*gp^4*Qv3^4*T[Yv33] - 
   2*gp^2*QHu^2*Yv22*conj[Yv22]*T[Yv33] + 2*gp^2*Ql2^2*Yv22*conj[Yv22]*
    T[Yv33] + 2*gp^2*Qv2^2*Yv22*conj[Yv22]*T[Yv33] - 
   Ye22*Yv22*conj[Ye22]*conj[Yv22]*T[Yv33] - 3*Yv22^2*conj[Yv22]^2*T[Yv33] + 
   (18*g1^2*Yv33*conj[Yv33]*T[Yv33])/5 + 18*g2^2*Yv33*conj[Yv33]*T[Yv33] + 
   12*gp^2*QHu^2*Yv33*conj[Yv33]*T[Yv33] + 12*gp^2*Ql3^2*Yv33*conj[Yv33]*
    T[Yv33] - 9*Yv22*Yv33*conj[Yv22]*conj[Yv33]*T[Yv33] - 
   50*Yv33^2*conj[Yv33]^2*T[Yv33] + 2*gp^2*QHd^2*\[Lambda]*conj[\[Lambda]]*
    T[Yv33] - 2*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]]*T[Yv33] + 
   2*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]]*T[Yv33] - 
   Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]]*T[Yv33] - 
   Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]]*T[Yv33] - 
   9*Yv33*\[Lambda]*conj[Yv33]*conj[\[Lambda]]*T[Yv33] - 
   3*\[Lambda]^2*conj[\[Lambda]]^2*T[Yv33] - 3*Ye33*conj[Ye33]^2*
    (4*Yv33*T[Ye33] + Ye33*T[Yv33]) - 3*Yv11*conj[Yv11]^2*
    (4*Yv33*T[Yv11] + Yv11*T[Yv33]) + 
   conj[Yv11]*(2*Yv33*(2*gp^2*(-QHu^2 + Ql1^2 + Qv1^2) - 3*Yv33*conj[Yv33])*
      T[Yv11] - conj[Ye11]*(2*Yv11*Yv33*T[Ye11] + 2*Ye11*Yv33*T[Yv11] + 
       Ye11*Yv11*T[Yv33]) + Yv11*(4*gp^2*MassU*(QHu^2 - Ql1^2 - Qv1^2)*Yv33 + 
       (2*gp^2*(-QHu^2 + Ql1^2 + Qv1^2) - 9*Yv33*conj[Yv33])*T[Yv33])) + 
   4*gp^2*QHd^2*Yv33*conj[\[Lambda]]*T[\[Lambda]] - 
   4*gp^2*QHu^2*Yv33*conj[\[Lambda]]*T[\[Lambda]] + 
   4*gp^2*Qs^2*Yv33*conj[\[Lambda]]*T[\[Lambda]] - 
   2*Ye11*Yv33*conj[Ye11]*conj[\[Lambda]]*T[\[Lambda]] - 
   2*Ye22*Yv33*conj[Ye22]*conj[\[Lambda]]*T[\[Lambda]] - 
   6*Yv33^2*conj[Yv33]*conj[\[Lambda]]*T[\[Lambda]] - 
   12*Yv33*\[Lambda]*conj[\[Lambda]]^2*T[\[Lambda]] - 
   3*\[Lambda]*conj[\[Lambda]]*T[Yv33]*trace[Yd, Adj[Yd]] - 
   6*Yv33*conj[\[Lambda]]*T[\[Lambda]]*trace[Yd, Adj[Yd]] - 
   (8*g1^2*MassB*Yv33*trace[Yu, Adj[Yu]])/5 - 32*g3^2*MassG*Yv33*
    trace[Yu, Adj[Yu]] + 12*gp^2*MassU*QHu^2*Yv33*trace[Yu, Adj[Yu]] - 
   12*gp^2*MassU*Qq^2*Yv33*trace[Yu, Adj[Yu]] - 12*gp^2*MassU*Qu^2*Yv33*
    trace[Yu, Adj[Yu]] + (4*g1^2*T[Yv33]*trace[Yu, Adj[Yu]])/5 + 
   16*g3^2*T[Yv33]*trace[Yu, Adj[Yu]] - 6*gp^2*QHu^2*T[Yv33]*
    trace[Yu, Adj[Yu]] + 6*gp^2*Qq^2*T[Yv33]*trace[Yu, Adj[Yu]] + 
   6*gp^2*Qu^2*T[Yv33]*trace[Yu, Adj[Yu]] - 27*Yv33*conj[Yv33]*T[Yv33]*
    trace[Yu, Adj[Yu]] - 6*Yv33*\[Lambda]*conj[\[Lambda]]*
    trace[Adj[Yd], T[Yd]] + conj[Ye33]*((-12*g1^2*MassB*Ye33*Yv33)/5 - 
     4*gp^2*MassU*Qe3^2*Ye33*Yv33 - 4*gp^2*MassU*QHd^2*Ye33*Yv33 + 
     4*gp^2*MassU*Ql3^2*Ye33*Yv33 + (12*g1^2*Yv33*T[Ye33])/5 + 
     4*gp^2*Qe3^2*Yv33*T[Ye33] + 4*gp^2*QHd^2*Yv33*T[Ye33] - 
     4*gp^2*Ql3^2*Yv33*T[Ye33] - 6*Yv33^2*conj[Yv33]*T[Ye33] - 
     4*Yv33*\[Lambda]*conj[\[Lambda]]*T[Ye33] + (6*g1^2*Ye33*T[Yv33])/5 + 
     2*gp^2*Qe3^2*Ye33*T[Yv33] + 2*gp^2*QHd^2*Ye33*T[Yv33] - 
     2*gp^2*Ql3^2*Ye33*T[Yv33] - 9*Ye33*Yv33*conj[Yv33]*T[Yv33] - 
     2*Ye33*\[Lambda]*conj[\[Lambda]]*T[Yv33] - 
     conj[Ye11]*(2*Ye33*Yv33*T[Ye11] + 2*Ye11*Yv33*T[Ye33] + 
       Ye11*Ye33*T[Yv33]) - conj[Ye22]*(2*Ye33*Yv33*T[Ye22] + 
       2*Ye22*Yv33*T[Ye33] + Ye22*Ye33*T[Yv33]) - 4*Ye33*Yv33*conj[\[Lambda]]*
      T[\[Lambda]] - 6*Yv33*T[Ye33]*trace[Yd, Adj[Yd]] - 
     3*Ye33*T[Yv33]*trace[Yd, Adj[Yd]] - 6*Ye33*Yv33*trace[Adj[Yd], T[Yd]]) + 
   (8*g1^2*Yv33*trace[Adj[Yu], T[Yu]])/5 + 
   32*g3^2*Yv33*trace[Adj[Yu], T[Yu]] - 12*gp^2*QHu^2*Yv33*
    trace[Adj[Yu], T[Yu]] + 12*gp^2*Qq^2*Yv33*trace[Adj[Yu], T[Yu]] + 
   12*gp^2*Qu^2*Yv33*trace[Adj[Yu], T[Yu]] - 18*Yv33^2*conj[Yv33]*
    trace[Adj[Yu], T[Yu]] - 3*T[Yv33]*trace[Yd, Adj[Yu], Yu, Adj[Yd]] - 
   6*Yv33*trace[Yd, Adj[Yu], T[Yu], Adj[Yd]] - 
   6*Yv33*trace[Yu, Adj[Yd], T[Yd], Adj[Yu]] - 
   9*T[Yv33]*trace[Yu, Adj[Yu], Yu, Adj[Yu]] - 
   36*Yv33*trace[Yu, Adj[Yu], T[Yu], Adj[Yu]]}, 
 {T[Yu][i1, i2], ((26*g1^2*MassB)/15 + (32*g3^2*MassG)/3 + 6*g2^2*MassWB + 
     4*gp^2*MassU*QHu^2 + 4*gp^2*MassU*Qq^2 + 4*gp^2*MassU*Qu^2 + 
     2*conj[Yv11]*T[Yv11] + 2*conj[Yv22]*T[Yv22] + 2*conj[Yv33]*T[Yv33] + 
     2*conj[\[Lambda]]*T[\[Lambda]] + 6*trace[Adj[Yu], T[Yu]])*Yu[i1, i2] + 
   2*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2] + 
   4*MatMul[Yu, Adj[Yu], T[Yu]][i1, i2] + MatMul[T[Yu], Adj[Yd], Yd][i1, 
    i2] + 5*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] - (13*g1^2*T[Yu][i1, i2])/15 - 
   3*g2^2*T[Yu][i1, i2] - (16*g3^2*T[Yu][i1, i2])/3 - 
   2*gp^2*QHu^2*T[Yu][i1, i2] - 2*gp^2*Qq^2*T[Yu][i1, i2] - 
   2*gp^2*Qu^2*T[Yu][i1, i2] + Yv11*conj[Yv11]*T[Yu][i1, i2] + 
   Yv22*conj[Yv22]*T[Yu][i1, i2] + Yv33*conj[Yv33]*T[Yu][i1, i2] + 
   \[Lambda]*conj[\[Lambda]]*T[Yu][i1, i2] + 3*trace[Yu, Adj[Yu]]*
    T[Yu][i1, i2], ((-5486*g1^4*MassB)/225 - 2*g1^2*g2^2*MassB - 
     (272*g1^2*g3^2*MassB)/45 - (272*g1^2*g3^2*MassG)/45 - 
     16*g2^2*g3^2*MassG + (64*g3^4*MassG)/9 - 2*g1^2*g2^2*MassWB - 
     30*g2^4*MassWB - 16*g2^2*g3^2*MassWB - (36*g1^2*gp^2*MassB*Qd*QHu)/5 - 
     (36*g1^2*gp^2*MassU*Qd*QHu)/5 - (12*g1^2*gp^2*MassB*Qe1*QHu)/5 - 
     (12*g1^2*gp^2*MassU*Qe1*QHu)/5 - (12*g1^2*gp^2*MassB*Qe2*QHu)/5 - 
     (12*g1^2*gp^2*MassU*Qe2*QHu)/5 - (12*g1^2*gp^2*MassB*Qe3*QHu)/5 - 
     (12*g1^2*gp^2*MassU*Qe3*QHu)/5 + (12*g1^2*gp^2*MassB*QHd*QHu)/5 + 
     (12*g1^2*gp^2*MassU*QHd*QHu)/5 - (24*g1^2*gp^2*MassB*QHu^2)/5 - 
     (24*g1^2*gp^2*MassU*QHu^2)/5 - 12*g2^2*gp^2*MassU*QHu^2 - 
     12*g2^2*gp^2*MassWB*QHu^2 - 72*gp^4*MassU*Qd^2*QHu^2 - 
     8*gp^4*MassU*Qe1^2*QHu^2 - 8*gp^4*MassU*Qe2^2*QHu^2 - 
     8*gp^4*MassU*Qe3^2*QHu^2 - 16*gp^4*MassU*QHd^2*QHu^2 - 
     32*gp^4*MassU*QHu^4 + (12*g1^2*gp^2*MassB*QHu*Ql1)/5 + 
     (12*g1^2*gp^2*MassU*QHu*Ql1)/5 - 16*gp^4*MassU*QHu^2*Ql1^2 + 
     (12*g1^2*gp^2*MassB*QHu*Ql2)/5 + (12*g1^2*gp^2*MassU*QHu*Ql2)/5 - 
     16*gp^4*MassU*QHu^2*Ql2^2 + (12*g1^2*gp^2*MassB*QHu*Ql3)/5 + 
     (12*g1^2*gp^2*MassU*QHu*Ql3)/5 - 16*gp^4*MassU*QHu^2*Ql3^2 - 
     (12*g1^2*gp^2*MassB*Qd*Qq)/5 - (12*g1^2*gp^2*MassU*Qd*Qq)/5 - 
     (4*g1^2*gp^2*MassB*Qe1*Qq)/5 - (4*g1^2*gp^2*MassU*Qe1*Qq)/5 - 
     (4*g1^2*gp^2*MassB*Qe2*Qq)/5 - (4*g1^2*gp^2*MassU*Qe2*Qq)/5 - 
     (4*g1^2*gp^2*MassB*Qe3*Qq)/5 - (4*g1^2*gp^2*MassU*Qe3*Qq)/5 + 
     (4*g1^2*gp^2*MassB*QHd*Qq)/5 + (4*g1^2*gp^2*MassU*QHd*Qq)/5 - 
     8*g1^2*gp^2*MassB*QHu*Qq - 8*g1^2*gp^2*MassU*QHu*Qq + 
     (4*g1^2*gp^2*MassB*Ql1*Qq)/5 + (4*g1^2*gp^2*MassU*Ql1*Qq)/5 + 
     (4*g1^2*gp^2*MassB*Ql2*Qq)/5 + (4*g1^2*gp^2*MassU*Ql2*Qq)/5 + 
     (4*g1^2*gp^2*MassB*Ql3*Qq)/5 + (4*g1^2*gp^2*MassU*Ql3*Qq)/5 - 
     (8*g1^2*gp^2*MassB*Qq^2)/3 - (64*g3^2*gp^2*MassG*Qq^2)/3 - 
     (8*g1^2*gp^2*MassU*Qq^2)/3 - 12*g2^2*gp^2*MassU*Qq^2 - 
     (64*g3^2*gp^2*MassU*Qq^2)/3 - 12*g2^2*gp^2*MassWB*Qq^2 - 
     72*gp^4*MassU*Qd^2*Qq^2 - 8*gp^4*MassU*Qe1^2*Qq^2 - 
     8*gp^4*MassU*Qe2^2*Qq^2 - 8*gp^4*MassU*Qe3^2*Qq^2 - 
     16*gp^4*MassU*QHd^2*Qq^2 - 160*gp^4*MassU*QHu^2*Qq^2 - 
     16*gp^4*MassU*Ql1^2*Qq^2 - 16*gp^4*MassU*Ql2^2*Qq^2 - 
     16*gp^4*MassU*Ql3^2*Qq^2 - 160*gp^4*MassU*Qq^4 - 
     8*gp^4*MassU*QHu^2*Qs^2 - 8*gp^4*MassU*Qq^2*Qs^2 + 
     (48*g1^2*gp^2*MassB*Qd*Qu)/5 + (48*g1^2*gp^2*MassU*Qd*Qu)/5 + 
     (16*g1^2*gp^2*MassB*Qe1*Qu)/5 + (16*g1^2*gp^2*MassU*Qe1*Qu)/5 + 
     (16*g1^2*gp^2*MassB*Qe2*Qu)/5 + (16*g1^2*gp^2*MassU*Qe2*Qu)/5 + 
     (16*g1^2*gp^2*MassB*Qe3*Qu)/5 + (16*g1^2*gp^2*MassU*Qe3*Qu)/5 - 
     (16*g1^2*gp^2*MassB*QHd*Qu)/5 - (16*g1^2*gp^2*MassU*QHd*Qu)/5 + 
     (88*g1^2*gp^2*MassB*QHu*Qu)/5 + (88*g1^2*gp^2*MassU*QHu*Qu)/5 - 
     (16*g1^2*gp^2*MassB*Ql1*Qu)/5 - (16*g1^2*gp^2*MassU*Ql1*Qu)/5 - 
     (16*g1^2*gp^2*MassB*Ql2*Qu)/5 - (16*g1^2*gp^2*MassU*Ql2*Qu)/5 - 
     (16*g1^2*gp^2*MassB*Ql3*Qu)/5 - (16*g1^2*gp^2*MassU*Ql3*Qu)/5 + 
     (72*g1^2*gp^2*MassB*Qq*Qu)/5 + (72*g1^2*gp^2*MassU*Qq*Qu)/5 - 
     (352*g1^2*gp^2*MassB*Qu^2)/15 - (64*g3^2*gp^2*MassG*Qu^2)/3 - 
     (352*g1^2*gp^2*MassU*Qu^2)/15 - (64*g3^2*gp^2*MassU*Qu^2)/3 - 
     72*gp^4*MassU*Qd^2*Qu^2 - 8*gp^4*MassU*Qe1^2*Qu^2 - 
     8*gp^4*MassU*Qe2^2*Qu^2 - 8*gp^4*MassU*Qe3^2*Qu^2 - 
     16*gp^4*MassU*QHd^2*Qu^2 - 88*gp^4*MassU*QHu^2*Qu^2 - 
     16*gp^4*MassU*Ql1^2*Qu^2 - 16*gp^4*MassU*Ql2^2*Qu^2 - 
     16*gp^4*MassU*Ql3^2*Qu^2 - 216*gp^4*MassU*Qq^2*Qu^2 - 
     8*gp^4*MassU*Qs^2*Qu^2 - 88*gp^4*MassU*Qu^4 - 8*gp^4*MassU*QHu^2*Qv1^2 - 
     8*gp^4*MassU*Qq^2*Qv1^2 - 8*gp^4*MassU*Qu^2*Qv1^2 - 
     8*gp^4*MassU*QHu^2*Qv2^2 - 8*gp^4*MassU*Qq^2*Qv2^2 - 
     8*gp^4*MassU*Qu^2*Qv2^2 - 8*gp^4*MassU*QHu^2*Qv3^2 - 
     8*gp^4*MassU*Qq^2*Qv3^2 - 8*gp^4*MassU*Qu^2*Qv3^2 + 
     4*gp^2*MassU*QHu^2*Yv33*conj[Yv33] - 4*gp^2*MassU*Ql3^2*Yv33*
      conj[Yv33] - 4*gp^2*MassU*Qv3^2*Yv33*conj[Yv33] - 
     4*gp^2*MassU*QHd^2*\[Lambda]*conj[\[Lambda]] + 
     4*gp^2*MassU*QHu^2*\[Lambda]*conj[\[Lambda]] - 
     4*gp^2*MassU*Qs^2*\[Lambda]*conj[\[Lambda]] - 2*\[Lambda]*conj[Ye11]*
      conj[\[Lambda]]*T[Ye11] - 2*\[Lambda]*conj[Ye22]*conj[\[Lambda]]*
      T[Ye22] - 2*Yv33*conj[Ye33]*conj[Yv33]*T[Ye33] - 
     2*\[Lambda]*conj[Ye33]*conj[\[Lambda]]*T[Ye33] - 
     12*Yv11*conj[Yv11]^2*T[Yv11] + conj[Yv11]*
      (4*gp^2*(QHu^2 - Ql1^2 - Qv1^2)*(MassU*Yv11 - T[Yv11]) - 
       2*conj[Ye11]*(Yv11*T[Ye11] + Ye11*T[Yv11])) - 
     12*Yv22*conj[Yv22]^2*T[Yv22] + conj[Yv22]*
      (4*gp^2*(QHu^2 - Ql2^2 - Qv2^2)*(MassU*Yv22 - T[Yv22]) - 
       2*conj[Ye22]*(Yv22*T[Ye22] + Ye22*T[Yv22])) - 
     4*gp^2*QHu^2*conj[Yv33]*T[Yv33] + 4*gp^2*Ql3^2*conj[Yv33]*T[Yv33] + 
     4*gp^2*Qv3^2*conj[Yv33]*T[Yv33] - 2*Ye33*conj[Ye33]*conj[Yv33]*T[Yv33] - 
     12*Yv33*conj[Yv33]^2*T[Yv33] + 4*gp^2*QHd^2*conj[\[Lambda]]*
      T[\[Lambda]] - 4*gp^2*QHu^2*conj[\[Lambda]]*T[\[Lambda]] + 
     4*gp^2*Qs^2*conj[\[Lambda]]*T[\[Lambda]] - 2*Ye11*conj[Ye11]*
      conj[\[Lambda]]*T[\[Lambda]] - 2*Ye22*conj[Ye22]*conj[\[Lambda]]*
      T[\[Lambda]] - 2*Ye33*conj[Ye33]*conj[\[Lambda]]*T[\[Lambda]] - 
     12*\[Lambda]*conj[\[Lambda]]^2*T[\[Lambda]] - 
     6*conj[\[Lambda]]*T[\[Lambda]]*trace[Yd, Adj[Yd]] - 
     (8*g1^2*MassB*trace[Yu, Adj[Yu]])/5 - 32*g3^2*MassG*trace[Yu, Adj[Yu]] + 
     12*gp^2*MassU*QHu^2*trace[Yu, Adj[Yu]] - 12*gp^2*MassU*Qq^2*
      trace[Yu, Adj[Yu]] - 12*gp^2*MassU*Qu^2*trace[Yu, Adj[Yu]] - 
     6*\[Lambda]*conj[\[Lambda]]*trace[Adj[Yd], T[Yd]] + 
     (8*g1^2*trace[Adj[Yu], T[Yu]])/5 + 32*g3^2*trace[Adj[Yu], T[Yu]] - 
     12*gp^2*QHu^2*trace[Adj[Yu], T[Yu]] + 12*gp^2*Qq^2*
      trace[Adj[Yu], T[Yu]] + 12*gp^2*Qu^2*trace[Adj[Yu], T[Yu]] - 
     6*trace[Yd, Adj[Yu], T[Yu], Adj[Yd]] - 
     6*trace[Yu, Adj[Yd], T[Yd], Adj[Yu]] - 
     36*trace[Yu, Adj[Yu], T[Yu], Adj[Yu]])*Yu[i1, i2] - 
   (2*(2*g1^2*MassB + 10*gp^2*MassU*Qd^2 + 10*gp^2*MassU*QHd^2 - 
      10*gp^2*MassU*Qq^2 + 5*conj[Ye11]*T[Ye11] + 5*conj[Ye22]*T[Ye22] + 
      5*conj[Ye33]*T[Ye33] + 5*conj[\[Lambda]]*T[\[Lambda]] + 
      15*trace[Adj[Yd], T[Yd]])*MatMul[Yu, Adj[Yd], Yd][i1, i2])/5 + 
   (4*g1^2*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2])/5 + 
   4*gp^2*Qd^2*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2] + 
   4*gp^2*QHd^2*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2] - 
   4*gp^2*Qq^2*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2] - 
   2*Ye11*conj[Ye11]*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2] - 
   2*Ye22*conj[Ye22]*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2] - 
   2*Ye33*conj[Ye33]*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2] - 
   2*\[Lambda]*conj[\[Lambda]]*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2] - 
   6*trace[Yd, Adj[Yd]]*MatMul[Yu, Adj[Yd], T[Yd]][i1, i2] - 
   (4*g1^2*MassB*MatMul[Yu, Adj[Yu], Yu][i1, i2])/5 - 
   12*g2^2*MassWB*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   12*gp^2*MassU*QHu^2*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   4*gp^2*MassU*Qq^2*MatMul[Yu, Adj[Yu], Yu][i1, i2] + 
   4*gp^2*MassU*Qu^2*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   6*conj[Yv11]*T[Yv11]*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   6*conj[Yv22]*T[Yv22]*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   6*conj[Yv33]*T[Yv33]*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   6*conj[\[Lambda]]*T[\[Lambda]]*MatMul[Yu, Adj[Yu], Yu][i1, i2] - 
   18*trace[Adj[Yu], T[Yu]]*MatMul[Yu, Adj[Yu], Yu][i1, i2] + 
   (6*g1^2*MatMul[Yu, Adj[Yu], T[Yu]][i1, i2])/5 + 
   6*g2^2*MatMul[Yu, Adj[Yu], T[Yu]][i1, i2] + 
   8*gp^2*QHu^2*MatMul[Yu, Adj[Yu], T[Yu]][i1, i2] - 
   4*Yv11*conj[Yv11]*MatMul[Yu, Adj[Yu], T[Yu]][i1, i2] - 
   4*Yv22*conj[Yv22]*MatMul[Yu, Adj[Yu], T[Yu]][i1, i2] - 
   4*Yv33*conj[Yv33]*MatMul[Yu, Adj[Yu], T[Yu]][i1, i2] - 
   4*\[Lambda]*conj[\[Lambda]]*MatMul[Yu, Adj[Yu], T[Yu]][i1, i2] - 
   12*trace[Yu, Adj[Yu]]*MatMul[Yu, Adj[Yu], T[Yu]][i1, i2] + 
   (2*g1^2*MatMul[T[Yu], Adj[Yd], Yd][i1, i2])/5 + 
   2*gp^2*Qd^2*MatMul[T[Yu], Adj[Yd], Yd][i1, i2] + 
   2*gp^2*QHd^2*MatMul[T[Yu], Adj[Yd], Yd][i1, i2] - 
   2*gp^2*Qq^2*MatMul[T[Yu], Adj[Yd], Yd][i1, i2] - 
   Ye11*conj[Ye11]*MatMul[T[Yu], Adj[Yd], Yd][i1, i2] - 
   Ye22*conj[Ye22]*MatMul[T[Yu], Adj[Yd], Yd][i1, i2] - 
   Ye33*conj[Ye33]*MatMul[T[Yu], Adj[Yd], Yd][i1, i2] - 
   \[Lambda]*conj[\[Lambda]]*MatMul[T[Yu], Adj[Yd], Yd][i1, i2] - 
   3*trace[Yd, Adj[Yd]]*MatMul[T[Yu], Adj[Yd], Yd][i1, i2] + 
   12*g2^2*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] + 
   10*gp^2*QHu^2*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] + 
   6*gp^2*Qq^2*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] - 
   6*gp^2*Qu^2*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] - 
   5*Yv11*conj[Yv11]*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] - 
   5*Yv22*conj[Yv22]*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] - 
   5*Yv33*conj[Yv33]*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] - 
   5*\[Lambda]*conj[\[Lambda]]*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] - 
   15*trace[Yu, Adj[Yu]]*MatMul[T[Yu], Adj[Yu], Yu][i1, i2] - 
   4*MatMul[Yu, Adj[Yd], Yd, Adj[Yd], T[Yd]][i1, i2] - 
   2*MatMul[Yu, Adj[Yd], Yd, Adj[Yu], T[Yu]][i1, i2] - 
   4*MatMul[Yu, Adj[Yd], T[Yd], Adj[Yd], Yd][i1, i2] - 
   4*MatMul[Yu, Adj[Yd], T[Yd], Adj[Yu], Yu][i1, i2] - 
   6*MatMul[Yu, Adj[Yu], Yu, Adj[Yu], T[Yu]][i1, i2] - 
   8*MatMul[Yu, Adj[Yu], T[Yu], Adj[Yu], Yu][i1, i2] - 
   2*MatMul[T[Yu], Adj[Yd], Yd, Adj[Yd], Yd][i1, i2] - 
   4*MatMul[T[Yu], Adj[Yd], Yd, Adj[Yu], Yu][i1, i2] - 
   6*MatMul[T[Yu], Adj[Yu], Yu, Adj[Yu], Yu][i1, i2] + 
   (2743*g1^4*T[Yu][i1, i2])/450 + g1^2*g2^2*T[Yu][i1, i2] + 
   (15*g2^4*T[Yu][i1, i2])/2 + (136*g1^2*g3^2*T[Yu][i1, i2])/45 + 
   8*g2^2*g3^2*T[Yu][i1, i2] - (16*g3^4*T[Yu][i1, i2])/9 + 
   (18*g1^2*gp^2*Qd*QHu*T[Yu][i1, i2])/5 + 
   (6*g1^2*gp^2*Qe1*QHu*T[Yu][i1, i2])/5 + 
   (6*g1^2*gp^2*Qe2*QHu*T[Yu][i1, i2])/5 + 
   (6*g1^2*gp^2*Qe3*QHu*T[Yu][i1, i2])/5 - 
   (6*g1^2*gp^2*QHd*QHu*T[Yu][i1, i2])/5 + (12*g1^2*gp^2*QHu^2*T[Yu][i1, i2])/
    5 + 6*g2^2*gp^2*QHu^2*T[Yu][i1, i2] + 18*gp^4*Qd^2*QHu^2*T[Yu][i1, i2] + 
   2*gp^4*Qe1^2*QHu^2*T[Yu][i1, i2] + 2*gp^4*Qe2^2*QHu^2*T[Yu][i1, i2] + 
   2*gp^4*Qe3^2*QHu^2*T[Yu][i1, i2] + 4*gp^4*QHd^2*QHu^2*T[Yu][i1, i2] + 
   8*gp^4*QHu^4*T[Yu][i1, i2] - (6*g1^2*gp^2*QHu*Ql1*T[Yu][i1, i2])/5 + 
   4*gp^4*QHu^2*Ql1^2*T[Yu][i1, i2] - (6*g1^2*gp^2*QHu*Ql2*T[Yu][i1, i2])/5 + 
   4*gp^4*QHu^2*Ql2^2*T[Yu][i1, i2] - (6*g1^2*gp^2*QHu*Ql3*T[Yu][i1, i2])/5 + 
   4*gp^4*QHu^2*Ql3^2*T[Yu][i1, i2] + (6*g1^2*gp^2*Qd*Qq*T[Yu][i1, i2])/5 + 
   (2*g1^2*gp^2*Qe1*Qq*T[Yu][i1, i2])/5 + (2*g1^2*gp^2*Qe2*Qq*T[Yu][i1, i2])/
    5 + (2*g1^2*gp^2*Qe3*Qq*T[Yu][i1, i2])/5 - 
   (2*g1^2*gp^2*QHd*Qq*T[Yu][i1, i2])/5 + 4*g1^2*gp^2*QHu*Qq*T[Yu][i1, i2] - 
   (2*g1^2*gp^2*Ql1*Qq*T[Yu][i1, i2])/5 - (2*g1^2*gp^2*Ql2*Qq*T[Yu][i1, i2])/
    5 - (2*g1^2*gp^2*Ql3*Qq*T[Yu][i1, i2])/5 + 
   (4*g1^2*gp^2*Qq^2*T[Yu][i1, i2])/3 + 6*g2^2*gp^2*Qq^2*T[Yu][i1, i2] + 
   (32*g3^2*gp^2*Qq^2*T[Yu][i1, i2])/3 + 18*gp^4*Qd^2*Qq^2*T[Yu][i1, i2] + 
   2*gp^4*Qe1^2*Qq^2*T[Yu][i1, i2] + 2*gp^4*Qe2^2*Qq^2*T[Yu][i1, i2] + 
   2*gp^4*Qe3^2*Qq^2*T[Yu][i1, i2] + 4*gp^4*QHd^2*Qq^2*T[Yu][i1, i2] + 
   40*gp^4*QHu^2*Qq^2*T[Yu][i1, i2] + 4*gp^4*Ql1^2*Qq^2*T[Yu][i1, i2] + 
   4*gp^4*Ql2^2*Qq^2*T[Yu][i1, i2] + 4*gp^4*Ql3^2*Qq^2*T[Yu][i1, i2] + 
   40*gp^4*Qq^4*T[Yu][i1, i2] + 2*gp^4*QHu^2*Qs^2*T[Yu][i1, i2] + 
   2*gp^4*Qq^2*Qs^2*T[Yu][i1, i2] - (24*g1^2*gp^2*Qd*Qu*T[Yu][i1, i2])/5 - 
   (8*g1^2*gp^2*Qe1*Qu*T[Yu][i1, i2])/5 - (8*g1^2*gp^2*Qe2*Qu*T[Yu][i1, i2])/
    5 - (8*g1^2*gp^2*Qe3*Qu*T[Yu][i1, i2])/5 + 
   (8*g1^2*gp^2*QHd*Qu*T[Yu][i1, i2])/5 - (44*g1^2*gp^2*QHu*Qu*T[Yu][i1, i2])/
    5 + (8*g1^2*gp^2*Ql1*Qu*T[Yu][i1, i2])/5 + 
   (8*g1^2*gp^2*Ql2*Qu*T[Yu][i1, i2])/5 + (8*g1^2*gp^2*Ql3*Qu*T[Yu][i1, i2])/
    5 - (36*g1^2*gp^2*Qq*Qu*T[Yu][i1, i2])/5 + 
   (176*g1^2*gp^2*Qu^2*T[Yu][i1, i2])/15 + (32*g3^2*gp^2*Qu^2*T[Yu][i1, i2])/
    3 + 18*gp^4*Qd^2*Qu^2*T[Yu][i1, i2] + 2*gp^4*Qe1^2*Qu^2*T[Yu][i1, i2] + 
   2*gp^4*Qe2^2*Qu^2*T[Yu][i1, i2] + 2*gp^4*Qe3^2*Qu^2*T[Yu][i1, i2] + 
   4*gp^4*QHd^2*Qu^2*T[Yu][i1, i2] + 22*gp^4*QHu^2*Qu^2*T[Yu][i1, i2] + 
   4*gp^4*Ql1^2*Qu^2*T[Yu][i1, i2] + 4*gp^4*Ql2^2*Qu^2*T[Yu][i1, i2] + 
   4*gp^4*Ql3^2*Qu^2*T[Yu][i1, i2] + 54*gp^4*Qq^2*Qu^2*T[Yu][i1, i2] + 
   2*gp^4*Qs^2*Qu^2*T[Yu][i1, i2] + 22*gp^4*Qu^4*T[Yu][i1, i2] + 
   2*gp^4*QHu^2*Qv1^2*T[Yu][i1, i2] + 2*gp^4*Qq^2*Qv1^2*T[Yu][i1, i2] + 
   2*gp^4*Qu^2*Qv1^2*T[Yu][i1, i2] + 2*gp^4*QHu^2*Qv2^2*T[Yu][i1, i2] + 
   2*gp^4*Qq^2*Qv2^2*T[Yu][i1, i2] + 2*gp^4*Qu^2*Qv2^2*T[Yu][i1, i2] + 
   2*gp^4*QHu^2*Qv3^2*T[Yu][i1, i2] + 2*gp^4*Qq^2*Qv3^2*T[Yu][i1, i2] + 
   2*gp^4*Qu^2*Qv3^2*T[Yu][i1, i2] - 2*gp^2*QHu^2*Yv11*conj[Yv11]*
    T[Yu][i1, i2] + 2*gp^2*Ql1^2*Yv11*conj[Yv11]*T[Yu][i1, i2] + 
   2*gp^2*Qv1^2*Yv11*conj[Yv11]*T[Yu][i1, i2] - 
   Ye11*Yv11*conj[Ye11]*conj[Yv11]*T[Yu][i1, i2] - 
   3*Yv11^2*conj[Yv11]^2*T[Yu][i1, i2] - 2*gp^2*QHu^2*Yv22*conj[Yv22]*
    T[Yu][i1, i2] + 2*gp^2*Ql2^2*Yv22*conj[Yv22]*T[Yu][i1, i2] + 
   2*gp^2*Qv2^2*Yv22*conj[Yv22]*T[Yu][i1, i2] - 
   Ye22*Yv22*conj[Ye22]*conj[Yv22]*T[Yu][i1, i2] - 
   3*Yv22^2*conj[Yv22]^2*T[Yu][i1, i2] - 2*gp^2*QHu^2*Yv33*conj[Yv33]*
    T[Yu][i1, i2] + 2*gp^2*Ql3^2*Yv33*conj[Yv33]*T[Yu][i1, i2] + 
   2*gp^2*Qv3^2*Yv33*conj[Yv33]*T[Yu][i1, i2] - 
   Ye33*Yv33*conj[Ye33]*conj[Yv33]*T[Yu][i1, i2] - 
   3*Yv33^2*conj[Yv33]^2*T[Yu][i1, i2] + 2*gp^2*QHd^2*\[Lambda]*
    conj[\[Lambda]]*T[Yu][i1, i2] - 2*gp^2*QHu^2*\[Lambda]*conj[\[Lambda]]*
    T[Yu][i1, i2] + 2*gp^2*Qs^2*\[Lambda]*conj[\[Lambda]]*T[Yu][i1, i2] - 
   Ye11*\[Lambda]*conj[Ye11]*conj[\[Lambda]]*T[Yu][i1, i2] - 
   Ye22*\[Lambda]*conj[Ye22]*conj[\[Lambda]]*T[Yu][i1, i2] - 
   Ye33*\[Lambda]*conj[Ye33]*conj[\[Lambda]]*T[Yu][i1, i2] - 
   3*\[Lambda]^2*conj[\[Lambda]]^2*T[Yu][i1, i2] - 
   3*\[Lambda]*conj[\[Lambda]]*trace[Yd, Adj[Yd]]*T[Yu][i1, i2] + 
   (4*g1^2*trace[Yu, Adj[Yu]]*T[Yu][i1, i2])/5 + 16*g3^2*trace[Yu, Adj[Yu]]*
    T[Yu][i1, i2] - 6*gp^2*QHu^2*trace[Yu, Adj[Yu]]*T[Yu][i1, i2] + 
   6*gp^2*Qq^2*trace[Yu, Adj[Yu]]*T[Yu][i1, i2] + 
   6*gp^2*Qu^2*trace[Yu, Adj[Yu]]*T[Yu][i1, i2] - 
   3*trace[Yd, Adj[Yu], Yu, Adj[Yd]]*T[Yu][i1, i2] - 
   9*trace[Yu, Adj[Yu], Yu, Adj[Yu]]*T[Yu][i1, i2]}}
