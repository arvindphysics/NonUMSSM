{{Tep, (-6*g1^2*Tep)/5 - 2*gp^2*Qe1^2*Tep + 2*gp^2*QHu^2*Tep - 
   2*gp^2*Ql1^2*Tep + 5*Tep*Ye11*conj[Ye11] + 2*Tmup*Ye11*conj[Ye22] + 
   4*Tep*Yv11*conj[Yv11] + Tep*Yv22*conj[Yv22] + Tep*Yv33*conj[Yv33] + 
   Tep*\[Lambda]*conj[\[Lambda]] + 3*Tep*trace[Yu, Adj[Yu]], 0}, 
 {Tmup, (-6*g1^2*Tmup)/5 - 2*gp^2*Qe2^2*Tmup + 2*gp^2*QHu^2*Tmup - 
   2*gp^2*Ql2^2*Tmup + 2*Tep*Ye22*conj[Ye11] + 5*Tmup*Ye22*conj[Ye22] + 
   Tmup*Yv11*conj[Yv11] + 4*Tmup*Yv22*conj[Yv22] + Tmup*Yv33*conj[Yv33] + 
   Tmup*\[Lambda]*conj[\[Lambda]] + 3*Tmup*trace[Yu, Adj[Yu]], 0}}
